#!/bin/bash

# Usage: gdk_data_prep.sh [--interactive | --batch | ]
#
# Interactive prompts Y/N for every step
# Batch does not prompt at all (Y for every step)
# no flag, prompts Y/N until you enter the first Y, and then switches to Batch
#
#
#  Other flags that can be used:
#  --drop-all-indexes      Drop and rebuild the indexes for the data mart tables
#  --drop-drug-indexes     Drop and rebuild the indexes for the data mart drug tables",
#  --drop-reaction-indexes Drop and rebuild the indexes for the data mart reaction tables",
#

venv_bindir=/opt/commonwealth/gsk-etl/gsk_data_prep_env/bin
source ${venv_bindir}/activate
# Virtualenv is now active.

base_dir="/opt/commonwealth/gsk-etl/gsk_data_prep"

# app26
#export LD_LIBRARY_PATH=/opt/oracle/instantclient_19_6:$LD_LIBRARY_PATH
#export ORACLE_HOME=/opt/oracle/instantclient_19_6:$LD_LIBRARY_PATH

#cvw-app5
export LD_LIBRARY_PATH=/usr/lib/oracle/19.8/client64/lib:$LD_LIBRARY_PATH
export ORACLE_HOME=/usr/lib/oracle/19.8/client64

# Unset the TZ environment variable so that the times in the log
# reflect local time
unset TZ

cd ${base_dir}

python src/gsk_data_prep.py \
       --config-file etc/gsk_data_prep.ini \
       --secrets-file etc/secrets.ini \
	   $@



