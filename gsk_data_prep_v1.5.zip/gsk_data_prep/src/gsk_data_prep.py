'''
@author: rschaaf
'''

from datetime import datetime
from glob import glob
import os
import sys
import zipfile
import steps
from encrypt_key import EncryptKey
from steps import StartDataPrep, StartRDSInstance, LoadFromS3, MigrateToPostgreSQL, StopRDSInstance, FinishDataPrep, ClearStagingSchema, PrepareCases, OasisTableDifference, GatherSnapshotInfo

#from steps FetchFaersData, LoadFaersQuarters
#from steps import ClearFaersCombinedSchema, DetermineCaseVersionsOfInterest
#from steps import ClearFaersStagingSchema, CreateDrugMap, PrepareCases
#from steps import ClearFaersDupStagingSchema, IdentifyDups
#from steps import CreateSnapshotSchema, CreateSnapshot
#from steps import GatherSnapshotInfo
from util import AppError, MainHelper, EmailUtils, SmtpSettings
from steps.time_stamp_cases import TimeStampCases


VERSION = "1.5.0"

def create_archive(app):
    '''
    Archive files from the run of the application
    '''
    info_dir = app._settings.get("data_prep", "info_dir")
    log_dir = app._settings.get("logging", "log_dir")
    log_file = app._settings.get("logging", "log_file")
    status_path = app._settings.get("data_prep", "status_file")
    status_dir, status_file = os.path.split(status_path)

    archive_patterns = [ (log_dir, "log", os.path.basename(log_file)),
                         (info_dir, "info", "*"),
                         (status_dir, "", status_file),
                        ]

    archive_dir = app._settings.get("data_prep", "archive_dir")

    # determine the current date
    cur_yyyymmdd = datetime.today().strftime('%Y%m%d')

    archive_file = f"GSK_ETL_prepare_snapshot_{cur_yyyymmdd}.zip"
    archive_path = os.path.join(archive_dir, archive_file)

    zf = zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED)
    for dir_path, arc_name_prefix, pattern in archive_patterns:
        os.chdir(dir_path)
        for f in glob(pattern):
            zf.write(f, os.path.join(arc_name_prefix, f))
    zf.close()
    return archive_path

def send_email(app, archive_path):
    '''
    Send an email notification indicating success or failure
    Attach a .zip archive containing log files and other information
    useful in troubleshooting problems.
    '''
    smtp_settings = SmtpSettings(app._settings.get("email", "smtp_server"),
                                 app._settings.getint("email", "smtp_port"),
                                 app._settings.get("email", "smtp_encryption"),
                                 app._settings.getboolean("email", "smtp_requires_authentication"),
                                 app._settings.get("email", "smtp_auth_user"),
                                 app._settings.getsecret("email", "smtp_auth_pass"))
    
    # don't try to send email unless an SMTP server has been configured
    if smtp_settings.server:        
        subject = "The GSK Oasis Data Prep script "
        subject += "completed successfully" if not app._app_error else "failed"
        body_text = "Please see the attached archive for run execution details.\r\n"
        msg_from = app._settings.get("email", "msg_from")
        admins = [ addr.strip() for addr in app._settings.get("email", "admins").split(",") ]
        zips = [ archive_path ]
        
        msg = EmailUtils.create_message_with_zips(msg_from, admins, subject, body_text, zips)
        EmailUtils.send_email(msg_from, admins, msg, smtp_settings)

        # send mail to the watchers for successful executions
        watchers = [ addr.strip() for addr in app._settings.get("email", "watchers").split(",") ]
        if watchers and not app._app_error:
            msg = EmailUtils.create_message_with_zips(msg_from, watchers, subject, None, [])
            EmailUtils.send_email(msg_from, watchers, msg, smtp_settings)


class MyMainHelper(MainHelper):
    '''
    Override the MainHelper class to change the handling of command line args
    '''

    def __init__(self, app_version, log_file_option, log_level_option,
                 run_status_file_option, run_vars_file_prefix, encrypt_key):
        '''
        Constructor
        '''
        MainHelper.__init__(self,
                            app_version, log_file_option, log_level_option,
                            run_status_file_option, run_vars_file_prefix,
                            encrypt_key)
        
    def extend_cmd_args_parser(self, parser):
        '''
        Extend the parsing of the command line arguments.
        '''
        parser.add_argument("--meddra-schema",
                            default=False,
                            help="MedDRA schema name (e.g., meddra_210) to use for preparing the data",
                            action="store", dest="meddra_schema")
        parser.add_argument("--drop-all-indexes",
                            default=False,
                            help="drop and rebuild the indexes for the data mart tables",
                            action="store_true", dest="drop_all_indexes")
        parser.add_argument("--drop-drug-indexes",
                            default=False,
                            help="drop and rebuild the indexes for the data mart drug tables",
                            action="store_true", dest="drop_drug_indexes")
        parser.add_argument("--drop-reaction-indexes",
                            default=False,
                            help="drop and rebuild the indexes for the data mart reaction tables",
                            action="store_true", dest="drop_reaction_indexes")
        return parser


if __name__ == '__main__':
    app = MyMainHelper(VERSION,
                       "log_file",
                       "log_level",
                       "status_file",
                       "",
                       EncryptKey.KEY)

    #meddra_schema = app._cmd_options.meddra_schema
    meddra_schema = "meddra"
    
     # determine whether to drop and rebuild indexes for the data mart tables
    drop_all_indexes = True if app._cmd_options.drop_all_indexes else False
    drop_drug_indexes = True if app._cmd_options.drop_drug_indexes else False
    drop_reaction_indexes = True if app._cmd_options.drop_reaction_indexes else False

    steps = [StartDataPrep(),
             StartRDSInstance(),
             LoadFromS3(),
             OasisTableDifference(),
             MigrateToPostgreSQL(),
             ClearStagingSchema(),
             PrepareCases(meddra_schema,VERSION),
             TimeStampCases(drop_all_indexes,drop_drug_indexes,drop_reaction_indexes),
             # GatherSnapshotInfo(VERSION),
             FinishDataPrep(),
             StopRDSInstance()
            ]
    
    # Write the config settings to the log
    with open(app._cmd_options.config_file) as f:
        indented_lines = [ f"  {line}" for line in f.readlines() ]
        app._logger.info("Configuration settings:\n" + "".join(indented_lines))
        app._logger.info(f"MedDRA schema is {meddra_schema}")

    try:
        app.execute_steps(steps)
    except AppError as e:
        app._app_error = True
        app._logger.error(e.message)
    except Exception as e:
        app._app_error = True
        app._logger.error(e)
        app._logger.critical("Fatal exception", exc_info=e)

    app._logger.info("Finished logging")

    # record the end time
    now = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
    app._run_status.set_inprogress_setting("end_time", now)

    # For a successful completion, set the end_time and rotate the
    # status settings (prev->deleted, last->prev, inprogress->last)
    if not app._app_error:
        app._run_status.rotate()

    # create an archive
    archive_path = create_archive(app)
    
    # send email notification
    send_email(app, archive_path)

    # if there was an error, set the exit code to 1
    if app._app_error:
        sys.exit(1)
