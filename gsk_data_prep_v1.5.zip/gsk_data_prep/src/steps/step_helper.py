'''
Created on May 21, 2020

@author: mfilho
'''
import os, fnmatch
from util import BaseStep, DbUtils, DbCsvLoader

class PopulateLookupTable(BaseStep):
    '''
    Populate a lookup table to use in mapping names
    
    '''
    def __init__(self, parent_step, cursor, schema, data_dir,
                 lookup_type, file_pattern, table, lookup_col,
                 mapped_col, seq_col=None):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"populate_{lookup_type}_lookup",
                          f"Populate the {lookup_col} -> {mapped_col} lookup table",
                          parent_step)
        self._cursor = cursor
        self._schema = schema
        self._data_dir = data_dir
        self._lookup_type = lookup_type
        self._file_pattern = file_pattern
        self._table = table
        self._lookup_col = lookup_col
        self._mapped_col = mapped_col
        self._seq_col = seq_col

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(PopulateLookupTable, self)._do_step(
            interactive, config_settings, run_vars, run_status)
        
        table = self._table
        staging = f"tmp_{self._table}"

        # (re)create the lookup table
        cols = f"id SERIAL, {self._lookup_col} VARCHAR, {self._mapped_col} VARCHAR"
        if self._seq_col:
            cols += f", {self._seq_col} INTEGER"
        DbUtils.drop_table(self._cursor, "", table)
        DbUtils.create_table(self._cursor, "", table,  cols)

        matched_files = fnmatch.filter(os.listdir(self._data_dir), self._file_pattern)
        for file in sorted(matched_files):
            self._logger.info(f"Importing {self._lookup_type} name mappings from {file}")
            
            # (re)create the staging table
            DbUtils.drop_table(self._cursor, "", staging)
            DbUtils.create_table(self._cursor, "", staging, cols)

            # use DbCsvLoader to load the data
            loader = DbCsvLoader(f"{self._data_dir}/{file}", self._schema,
                                 staging, num_header_rows=2)
            loader.insert_data(self._cursor, {})
            
            # delete rows in table that will be replaced by rows in staging
            delete_sql = (f"DELETE FROM {table}\n"
                          f" WHERE {self._lookup_col} IN (SELECT {self._lookup_col} FROM {staging})")
            self._cursor.execute(delete_sql)
            
            # insert rows from staging
            insert_cols = f"{self._lookup_col}, {self._mapped_col}"
            partition_cols = f"{self._lookup_col}"
            if self._seq_col:
                insert_cols += f", {self._seq_col}"
                partition_cols += f", {self._seq_col}"
            insert_sql = (f"INSERT INTO {table} ({insert_cols})\n"
                          f"WITH ranked AS (\n"
                          f"    SELECT {insert_cols},\n"
                          f"           row_number() OVER (PARTITION BY {partition_cols} ORDER BY {self._mapped_col}) rn\n"
                          f"      FROM {staging})\n"
                          f"SELECT {insert_cols} FROM ranked WHERE rn = 1")
            self._cursor.execute(insert_sql)
            
            # commit the merged data
            DbUtils.commit(self._cursor)
        
        # drop the staging table
        DbUtils.drop_table(self._cursor, "", staging)


class PopulateSingleColTable(BaseStep):
    '''
    Populate a single column table
    '''
    def __init__(self, parent_step, cursor, schema, data_dir,
                 table_type, file_pattern, table, col):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"populate_{table_type}_table",
                          f"Populate the {table_type} table",
                          parent_step)
        self._cursor = cursor
        self._schema = schema
        self._data_dir = data_dir
        self._table_type = table_type
        self._file_pattern = file_pattern
        self._table = table
        self._col = col

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(PopulateSingleColTable, self)._do_step(
            interactive, config_settings, run_vars, run_status)
        
        table = self._table
        staging = f"tmp_{self._table}"

        # (re)create the table
        DbUtils.drop_table(self._cursor, "", table)
        DbUtils.create_table(self._cursor, "", table, cols=f"{self._col} VARCHAR")

        matched_files = fnmatch.filter(os.listdir(self._data_dir), self._file_pattern)
        for file in sorted(matched_files):
            self._logger.info(f"Importing {self._table_type} name mappings from {file}")
            
            # (re)create the staging table
            DbUtils.drop_table(self._cursor, "", staging)
            DbUtils.create_table(self._cursor, "", staging,
                                 cols=f"{self._col} VARCHAR")

            # use DbCsvLoader to load the data
            loader = DbCsvLoader(f"{self._data_dir}/{file}", self._schema,
                                 staging, num_header_rows=2)
            loader.insert_data(self._cursor, {})
            
            # insert rows from staging
            insert_sql = (f"INSERT INTO {table} ({self._col})\n"
                          f"SELECT {self._col} FROM {staging}\n"
                          f"EXCEPT\n"
                          f"SELECT {self._col} FROM {table}")
            self._cursor.execute(insert_sql)
            
            # commit the inserted data
            DbUtils.commit(self._cursor)
        
        # drop the staging table
        DbUtils.drop_table(self._cursor, "", staging)

class CopyToTable(BaseStep):
    '''
    Copy data from a file to a table
    
    '''
    def __init__(self, parent_step, cursor, path, table, cols=[], fmt=None,
                 delimiter=None, null=None, header=None, quote=None,
                 escape=None, encoding=None, size=None):
        '''
        Constructor
        
        Arguments:
          parent_step - parent data prep step
          cursor - database cursor
          path - path for the file to be loaded
          table - table name
          cols - list of the columns to import; if not specified import all columns
          fmt - one of 'text', 'csv' or 'binary'
          delimiter - specifies the character that separates columns within each row
          null - specifies the string that represents a null value
          header - specifies that the file contains a header line with the names of
             each column in the file. This option is allowed only when using CSV format.
          quote - specifies the quoting character to be used when a data value is quoted
          escape - specifies the character that should appear before a data character
             that matches the QUOTE value
          encoding - Specifies that the file is encoded in the <encoding>
          size - size of the buffer used to read from the file
        '''
        BaseStep.__init__(self,
                          f"populate_{table}_table",
                          f"Populate the {table} table",
                          parent_step)
        self._cursor = cursor
        self._path = path
        self._table = table
        self._cols = cols
        self._fmt = fmt
        self._delimiter = delimiter
        self._null = null
        self._header = header
        self._quote = quote
        self._escape = escape
        self._encoding = encoding
        self._size = size

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CopyToTable, self)._do_step(
              interactive, config_settings, run_vars, run_status)
        
        # remove any rows that may already be present in the target table
        self._cursor.execute(f"TRUNCATE {self._table}")
        
        DbUtils.copy_from(self._cursor, self._path, self._table, self._cols,
                          self._fmt, self._delimiter, self._null,
                          self._header, self._quote, self._escape,
                          self._encoding, self._size)


