'''
@author: vgohil
'''
from datetime import datetime
from time import sleep
from util import BaseStep
import boto3
import cx_Oracle
import os
from util.util_file import FileUtils

# #############################
# Set local date/time
now = datetime.now()
year = now.strftime("%Y")
month = now.strftime("%m")
day = now.strftime("%d")
time = now.strftime("%H:%M:%S")
log_date = now.strftime("%Y%m%d_%H%M%S")


class LoadFromS3(BaseStep):
    '''
    Load data from an S3 bucket
    '''

    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "load_from_s3",
                          "Load data from an S3 bucket")

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(LoadFromS3, self)._init_cursors(settings)
        
        self._oracle_user = settings.get("oracle", "oracle_user")
        self._oracle_user_pass = settings.getsecret("oracle", "oracle_user_pass")
        self._oracle_host = settings.get("oracle", "oracle_host")
        self._oracle_port = settings.get("oracle", "oracle_port")
        self._service_name= settings.get("oracle", "oracle_service_name")
             
        self._conn_srcrds = cx_Oracle.makedsn(host=self._oracle_host, port=self._oracle_port, service_name=self._service_name) # will user oracle_connect_str        
        self._conn_src = cx_Oracle.connect(user=self._oracle_user, password=self._oracle_user_pass, dsn=self._conn_srcrds)
        
        self._oracle_cursor = self._conn_src.cursor()
    
        
    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(LoadFromS3, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        
        
        
        icsr_folder = config_settings.get("s3", "icsr_folder")
        source_icsr_schema = config_settings.get("oracle", "source_icsr_schema")
        target_icsr_schema = config_settings.get("oracle", "target_icsr_schema")
        
        meddra_folder = config_settings.get("s3", "meddra_folder")
        source_meddra_schema = config_settings.get("oracle", "source_meddra_schema")
        target_meddra_schema = config_settings.get("oracle", "target_meddra_schema")
        
        whodrug_folder = config_settings.get("s3", "whodrug_folder")
        source_whodrug_schema = config_settings.get("oracle", "source_whodrug_schema")
        target_whodrug_schema = config_settings.get("oracle", "target_whodrug_schema")
        
        substeps = [ CheckForDumpFiles(self, self._conn_src, self._oracle_cursor, icsr_folder, run_vars),
                     ImportNewData(self, icsr_folder),
                     ImportIntoOracle(self, self._conn_src, self._oracle_cursor, icsr_folder, source_icsr_schema, target_icsr_schema),
                     CheckOracleRowCounts(self, self._conn_src, self._oracle_cursor, target_icsr_schema, icsr_folder),
                     CheckForDumpFiles(self, self._conn_src, self._oracle_cursor, meddra_folder, run_vars),
                     ImportNewData(self, meddra_folder),
                     ImportIntoOracle(self, self._conn_src, self._oracle_cursor, meddra_folder, source_meddra_schema, target_meddra_schema),
                     CheckOracleRowCounts(self, self._conn_src, self._oracle_cursor, target_meddra_schema, meddra_folder),
                     CheckForDumpFiles(self, self._conn_src, self._oracle_cursor, whodrug_folder, run_vars),
                     ImportNewData(self, whodrug_folder),
                     ImportIntoOracle(self, self._conn_src, self._oracle_cursor, whodrug_folder, source_whodrug_schema, target_whodrug_schema),
                     CheckOracleRowCounts(self, self._conn_src, self._oracle_cursor, target_whodrug_schema, whodrug_folder)
                   ]
        
        self.execute_substeps(substeps)
        
        # close database connection
        self._logger.info('==== Closing database connection ====')
        self._conn_src.close()

class CheckForDumpFiles(BaseStep):
    '''
    Check dump files from s3 Bucket Prefix
    '''
    
    def __init__(self, parent_step, conn_src, cursor, folder, run_vars):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"import_new_data_{folder}",
                          f"Check Dumpfiles from S3 {folder} folder in DATA_PUMP_DIR",
                          parent=parent_step)
        self._folder = folder
        self._conn_src = conn_src
        self._oracle_cursor = cursor
        run_vars.set(f"s3_folder_{self._folder}", self._folder)
       
      

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CheckForDumpFiles, self)._do_step(interactive, config_settings,
                                              run_vars, run_status)
        
        # save the file name so that it is available for subsequent steps
         
        self._filename = run_vars.get(f"s3_folder_{self._folder}")       
        s3_bucket = config_settings.get("s3", "s3_bucket")
        
        
        '''
        Set cursor object
        '''
        src = self._oracle_cursor
    
       
        s3 = boto3.resource('s3')
        
        bucket_name = config_settings.get("s3", "s3_bucket")
        bucket = s3.Bucket(bucket_name)
        
        objects = list(bucket.objects.filter(Prefix=f"{self._folder}/"))
    
        filenames = []
    
        for obj in objects:
            if obj.key.endswith('.dmp'):
                obj = obj.key.split('/',1)[1]
                filenames.append(obj)
        
        '''
        check for Dumpfiles in DATA_PUMP_DIR
        '''
        for i in range(len(filenames)):
            sql_statement = 'SELECT filename FROM table (rdsadmin.rds_file_util.listdir(' + '\'' + 'DATA_PUMP_DIR' + '\'' + '))'
            sql_statement += ' WHERE filename = '
            sql_statement += '\'' 
            sql_statement += filenames[i] + '\'' 
            self._logger.info(sql_statement)
            src.execute(sql_statement)
            result = src.fetchall()
            if (len(result) != 0):
                sql_statement = 'BEGIN'
                sql_statement += '\n UTL_FILE.fremove (' + '\'' + 'DATA_PUMP_DIR' + '\'' + ',' + '\'' + filenames[i] + '\'' + ');'
                sql_statement += '\n END;'
                self._logger.info(sql_statement)
                # Delete dumpfiles if existing in DATA_PUMP_DIR      
                try:
                    src.execute(sql_statement)
                except cx_Oracle.DatabaseError:
                    self._conn_src.close()
                    raise Exception("Dump files do not exists on DATA_PUMP_DIR")
                else:
                    self._logger.info("Files deleted from DATA_PUMP_DIR")         
        

class ImportNewData(BaseStep):
    '''
    Check for and import new data from S3
    '''
    
    def __init__(self, parent_step, folder):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"import_new_data_{folder}",
                          f"Read descriptor file from S3 {folder} folder",
                          parent=parent_step)
        self._folder = folder

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(ImportNewData, self)._do_step(interactive, config_settings,
                                              run_vars, run_status)
        
        
        oracle_user = config_settings.get("oracle", "oracle_user")
        self._filename = run_vars.get(f"s3_folder_{self._folder}")       
        s3_bucket = config_settings.get("s3", "s3_bucket")   
        
        '''
        s3 resource
        '''
        s3 = boto3.resource('s3')
        
        # bucket
        bucket_name = config_settings.get("s3", "s3_bucket")
        bucket = s3.Bucket(bucket_name)
                                     
        # list objects within given folder
        objects = list(bucket.objects.filter(Prefix=f"{self._folder}/"))
        
        
        
        ##############################
        # Download and verify file from s3 Bucket
        ##############################
    
        download_dir = config_settings.get("s3", "download_dir")
        FileUtils.ensure_dir_exists(download_dir)

        for obj in objects:
            if obj.key.endswith('.txt'):
                path, filename = os.path.split(obj.key)
                self._logger.debug(obj.key)
    
                # Download file from s3 prefix
                bucket.download_file(obj.key, os.path.join(download_dir,self._folder + '_descriptor.txt'))
    
                # open downloaded file and check the filename definition for the dumpfiles
                with open(os.path.join(download_dir, self._folder + '_descriptor.txt'), 'r', encoding='utf-8') as dfile:
                    firstlines = dfile.readlines()
                    filename = firstlines[0].rstrip().split('=',1)[1]
                    filename = filename.strip('"')
                    self._logger.info('Descriptor Filename: ' + filename)
    
                # Break out of the loop. Do not loop for every file under the s3 folder.
                break
            
        else:
            # if no file of .txt extension found print.
            self._logger.info('--- no object key with .txt extension found !! ---')
            
        # save the file name so that it is available for subsequent steps
        self._run_vars.set(f"s3_folder_{self._folder}", filename)
         
class ImportIntoOracle(BaseStep):
    '''
    Import data from S3 into Oracle
    '''
    
    def __init__(self, parent_step, conn_src, cursor, folder, source_schema, target_schema):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"import_into_oracle_from_{folder}",
                          f"Copy from S3 {folder} folder and run data pump",
                          parent=parent_step)
        self._conn_src = conn_src
        self._oracle_cursor = cursor
        self._folder = folder
        self._source_schema = source_schema
        self._target_schema = target_schema

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(ImportIntoOracle, self)._do_step(interactive, config_settings,
                                               run_vars, run_status)
        self._filename = run_vars.get(f"s3_folder_{self._folder}")       
        s3_bucket = config_settings.get("s3", "s3_bucket")
        
        '''
        Set cursor object
        '''
        src = self._oracle_cursor    
        
        '''
        Set variables
        '''
        self._dump_files_list = []
        
        '''
        Run query to copy dumpfile from S3 bucket 
        to oracle DATA_PUMP_DIR directory
        '''
        sql_statement = 'SELECT rdsadmin.rdsadmin_s3_tasks.download_from_s3 ( p_bucket_name  => '
        sql_statement += '\''
        sql_statement += f"{s3_bucket}"  # e.g: 'cwi-data-transfer-gsk'
        sql_statement += '\'' 
        sql_statement += ', p_s3_prefix => '
        sql_statement += '\''
        sql_statement += f"{self._folder}" # e.g.: 'rds10/'
        sql_statement += '/'
        sql_statement += '\''
        sql_statement += ', p_directory_name => ' + '\'' + 'DATA_PUMP_DIR' + '\'' + ') AS TASK_ID FROM DUAL'
        self._logger.info(sql_statement)
        src.execute(sql_statement)
        self._conn_src.commit()
        
        '''
        Fetch the result of the query
        '''
        res = src.fetchone()[0]
        self._logger.info('Task Id: ' + str(res))
        self._res = res
        sleep(5)
        self.check_task()
        
    '''
    Create temporary table to read output of select query
    '''
    def read_task_log(self):
        self.drop_tmptable()
        sql_statement = 'create table tmp_task_table AS('
        sql_statement += 'SELECT text FROM table(rdsadmin.rds_file_util.read_text_file(' + '\'' + 'BDUMP' + '\'' + ',' + '\'' + 'dbtask-' + str(self._res) + '.log' + '\'' + ')))' 
        self._logger.info(sql_statement)
        self._oracle_cursor.execute(sql_statement)
        self._conn_src.commit()
        
    def check_task(self):
        self._logger.info('=== Running Check Task Function ==')
        sql_statement = 'select * from tmp_task_table'
        sleep(10)
        while True:
            self.read_task_log()
            sleep(10)
            self._oracle_cursor.execute(sql_statement)
            self._log_res = self._oracle_cursor.fetchall()
            log_res_size = len(self._log_res)
            self._logger.info('Size of tmp_task_table: ' + str(log_res_size))
            if(log_res_size == 0):
                self._logger.info('=== Running Check Task Function if clause ===')
                self._logger.info('No task to be selected')
            else:
                self._logger.info('=== Running Check Task Function else clause ===')
                check_string = str(self._log_res[log_res_size-1])
                self._logger.info(check_string)
                str_complete = 'The task finished successfully'
                if str_complete in check_string:
                    log_res_size = len(self._log_res)
                    self._logger.info(self._log_res)
                    self._logger.info(check_string)
                    self._logger.info('==== S3 Copy to DATAPUMP Directory Task is Completed ====')
                    self.check_dump_files(self._filename)
                    self.view_log_data_dump()

                    break
 
                else:
                    #print(log_res)
                    print('Task still running')
                    sleep(50)

    '''
    Verify dumpfiles to be imported
    '''        
     
    def check_dump_files(self, _filename):
        self._logger.info('=== Running Check Dump Files Function ===')
        sql_statement = 'select * from tmp_task_table where (lower (text) like '
        sql_statement += '\'' + '%the task successfully downloaded%' + '\'' + ' and lower(text) like '
        sql_statement += '\'' 
        sql_statement +=  '%' +self._filename+ '%'
        sql_statement +=  '\'' + ' and lower(text) like ' + '\'' + '%.dmp%' + '\'' + ')'
        self._logger.info(sql_statement)
        self._oracle_cursor.execute(sql_statement)
        cdf_res = self._oracle_cursor.fetchall()
        cdf_res_size = len(cdf_res)
        # If no dump files are found on the bucket then abort the import process
        if(cdf_res_size == 0):
            self._conn_src.close()
            raise Exception ("No Dumpfiles found in the bucket!")
        else:
          
            '''
            Start the import
            '''    
            sql_statement = 'DECLARE hdnl NUMBER; v_job_state varchar2(4000); BEGIN hdnl := DBMS_DATAPUMP.OPEN( operation => '
            sql_statement += '\''
            sql_statement += 'IMPORT'
            sql_statement += '\''
            sql_statement += ', job_mode => '
            sql_statement += '\''
            sql_statement += 'TABLE'
            sql_statement += '\''
            sql_statement += ', job_name=>null);'
            for i in range(cdf_res_size):
                dump_file = str(cdf_res[i])
                dump_file = dump_file.split('/',1)[1]
                dump_file = dump_file.replace(".',)","")
                dump_file = dump_file.replace(" to the location /rdsdbdata/datapump","")
                self._dump_files_list.append(dump_file)
                self._logger.info('The following file: ' + dump_file + ' will be imported')
                sql_statement += '\n DBMS_DATAPUMP.ADD_FILE( handle => hdnl, filename => '
                sql_statement += '\''
                sql_statement += dump_file
                sql_statement += '\''
                sql_statement += ', directory => '
                sql_statement += '\''
                sql_statement += 'DATA_PUMP_DIR'
                sql_statement += '\''
                sql_statement += ', filetype => dbms_datapump.ku$_file_type_dump_file);'
                 
            self._logger.info('========= DataPump Import Execution =========')
     
            sql_statement += '\n DBMS_DATAPUMP.ADD_FILE( handle => hdnl, filename => '
            sql_statement += '\''
            sql_statement += self._target_schema + '_extract_' + str(log_date) + '_import.log' + '\'' + ','
            sql_statement += ' directory => '
            sql_statement += '\''
            sql_statement += 'DATA_PUMP_DIR'
            sql_statement += '\''
            sql_statement += ',  filetype => dbms_datapump.ku$_file_type_log_file, reusefile => 1);'
            sql_statement += '\n DBMS_DATAPUMP.SET_PARAMETER(handle => hdnl, name => ' + '\'' + 'ENCRYPTION_PASSWORD' + '\'' + ',' + ' value => ' + '\'' + 'foo' + '\'' + ');'
            sql_statement += '\n DBMS_DATAPUMP.SET_PARAMETER(handle => hdnl, name => ' + '\'' + 'TABLE_EXISTS_ACTION' + '\'' + ',' + ' value => ' + '\'' + 'REPLACE' + '\'' + ');'
            sql_statement += '\n DBMS_DATAPUMP.METADATA_FILTER(hdnl,' + '\'' + 'EXCLUDE_PATH_EXPR' + '\'' + ',' + '\'' + 'IN' + '(' + '\'' + '\'' + 'STATISTICS' + '\'' + '\'' + ',' + '\'' + '\'' + 'GRANT' + '\'' + '\'' + ',' + '\'' + '\'' + 'REF_CONSTRAINT' + '\'' + '\'' + ',' + '\'' + '\'' + 'TRIGGER' + '\'' + '\'' + ',' + '\'' + '\'' + 'INDEX' + '\'' + '\'' + ')' + '\'' + ');'
            sql_statement += '\n DBMS_DATAPUMP.METADATA_REMAP(handle => hdnl, name => ' + '\'' + 'REMAP_SCHEMA' + '\'' + ',' +  ' old_value => ' + '\'' + self._source_schema + '\'' + ',' +  ' value=> ' + '\'' + self._target_schema  + '\'' + ');'
            sql_statement += '\n DBMS_DATAPUMP.METADATA_REMAP(handle => hdnl, name => ' + '\'' + 'REMAP_TABLESPACE' + '\'' + ',' + ' old_value => ' + '\'' + '%' + '\'' + ',' +  ' value=> ' + '\'' + self._target_schema  + '\'' + ');'
            sql_statement += '\n DBMS_DATAPUMP.START_JOB(hdnl);'
            sql_statement += '\n DBMS_DATAPUMP.WAIT_FOR_JOB(hdnl, v_job_state);'
            sql_statement += '\n END;'
            self._logger.info(sql_statement)
            self._oracle_cursor.execute(sql_statement)
            sleep(5)
        
    '''
    View import log
    '''
    
    def view_log_data_dump(self):
        sleep(5)
        self._logger.info('=== Running View log Function ===')
        #View log of DataPump import
        sql_statement = 'SELECT * FROM table (rdsadmin.rds_file_util.read_text_file(p_directory => ' + '\'' + 'DATA_PUMP_DIR' + '\'' + ',' + 'p_filename  => ' + '\'' + self._target_schema + '_extract_' + str(log_date) + '_import.log' + '\'' + '))'
        self._logger.info(sql_statement)
        self._oracle_cursor.execute(sql_statement)
        result = self._oracle_cursor.fetchall()
        result_size = len(result)
        check_string = str(result[result_size-1])
        self._logger.info(result)
        str_complete = 'successfully completed'

        string_result = str(result)
        self._logger.info(string_result)
        resultByLine = string_result.split(",),")
        resultByLineSize = len(resultByLine)

        if str_complete in check_string:
            self._logger.info(check_string)
            if(resultByLineSize != 0):
                for i in range(resultByLineSize):
                    stringLine = str(resultByLine[i])
                    stringLine = stringLine.replace("('","")
                    stringLine = stringLine.replace("rows'","rows")
                    self._logger.info(stringLine)
            else:
                self._logger.info("empty result")
    
            self._logger.info('==== DataPump Import is Completed ====')
            self.delete_dump_files()

        else:
            if(resultByLineSize != 0):
                for i in range(resultByLineSize):
                    stringLine = str(resultByLine[i])
                    self._logger.info(stringLine)
            self._conn_src.close()
            raise Exception ('=== DATA PUMP IMPORT FAILED ===')

        self.drop_tmptable()

    '''
    Delete Dump Files
    '''
    def delete_dump_files(self):
        dump_files_list_size = len(self._dump_files_list)
        sql_statement = 'BEGIN'
        for i in range(dump_files_list_size):
            sql_statement += '\n UTL_FILE.fremove (' + '\'' + 'DATA_PUMP_DIR' + '\'' + ',' + '\'' + self._dump_files_list[i] + '\'' + ');'
        sql_statement += '\n END;'
        self._oracle_cursor.execute(sql_statement)
        self._conn_src.commit()
        self._logger.info(sql_statement)
        self._logger.info('===== Dump files deleted from DATA_PUMP_DIR =====')

    '''
    Drop temporary tables
    '''        
    def drop_tmptable(self):
        try:
            sql_statement = 'drop table tmp_task_table'
            self._oracle_cursor.execute(sql_statement)
            self._conn_src.commit()
            self._logger.info('==== Tmp Table dropped ====')
        except(Exception, cx_Oracle.Error) as error:
            self._logger.error("Error: " + str(error))
        finally:
            self._logger.info('==== Process Complete ====')

                
class CheckOracleRowCounts(BaseStep):
    '''
    Check actual versus expected row counts to determine if the data was
    fully loaded.
    '''
    
    def __init__(self, parent_step, conn_src, cursor, target_schema, folder):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"check_oracle_row_counts for {target_schema}",
                          f"Check Oracle row counts for {target_schema}",
                          parent=parent_step)
        self._conn_src = conn_src
        self._oracle_cursor = cursor
        self._target_schema = target_schema
        self._folder = folder
       

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CheckOracleRowCounts, self)._do_step(interactive, config_settings,
                                                   run_vars, run_status)
        
        download_dir = config_settings.get("s3", "download_dir") 
    
        '''
        List expected rowcount from descriptor file
        '''
        
        descriptor_fileDict = {}
        self._logger.info('==== Expected Row Count from Descriptor File ====')
        
        with open (os.path.join(download_dir, self._folder + '_descriptor.txt'), 'r', encoding='utf-8') as f:
            for line in f:
                line = str(line).rstrip()
                if "ROWCOUNT" in line:
                    line = line.replace("_ROWCOUNT",'')
                    line = line.replace('"','') 
                    key, value = line.strip().split('=')
                    descriptor_fileDict[key] = int(value)
                    self._logger.info(line)
                    
            src = self._oracle_cursor           
        
            '''
            run gather_schema_stats for target_schema
            '''
            
            src.callproc("DBMS_STATS.GATHER_SCHEMA_STATS", [self._target_schema])
            self._logger.info('==== Gathering Table Statistics ====')
            
            '''
            list actual rowcount from DBA_ALL_TABLES where owner is target_schema
            '''
            
            self._logger.info('==== Actual Row Count from Import ====')
            sql_statement = 'SELECT table_name, num_rows FROM dba_all_tables WHERE owner = ' + '\'' + self._target_schema + '\'' + ' ORDER BY 1'
            self._logger.info(sql_statement)
            src.execute(sql_statement)
            result = src.fetchall()
            self._logger.info(result)
            
            importDict = {k:v for k, v in result}
            
        def compare_dict(dict1, dict2):
            for k in dict1.keys():             
                z = dict1.get(k) == dict2.get(k)
                if not z:
                    self._logger.info('Key: ' + str(k))
                    self._logger.info('Imported Table Rowcount Value: ' + str(dict1.get(k)) + ' Descriptor File Value: ' + str(dict2.get(k)))
                    self._logger.info('-----\n')
                    raise Exception ('Error: Mismatch between Imported table and Descriptor rowcounts. ' + str(k) + ': ' + 'Imported rowcount: ' + str(dict1.get(k)) + ' Descriptor rowcount: ' + str(dict2.get(k)))
            else:
                self._logger.info('==== No mismatch between actual vs expected rowcount ====')
                
        compare_dict(importDict, descriptor_fileDict)