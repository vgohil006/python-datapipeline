'''
Created on May 20, 2020

@author: mfilho
'''
from util import BaseStep, DbUtils

class ClearStagingSchema(BaseStep):
    '''
    Drop all tables and views from the staging schema
    '''
    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "clear_staging_schema",
                          "Drop all tables and views from the staging schema")

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(ClearStagingSchema, self)._init_cursors(settings)
        self._oasis_staging_user = settings.get("postgresql", "postgresql_user")
        self._oasis_staging_pass = settings.getsecret("postgresql", "postgresql_user_pass")
        self._oasis_staging_schema = settings.get("db-common", "icsr_staging_schema")
        
        self._cursor = self._cursors.get_cursor(self._oasis_staging_user,
                                                self._oasis_staging_pass,
                                                self._db_connect_str,
                                                self._oasis_staging_schema)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(ClearStagingSchema, self)._do_step(interactive, config_settings,
                                                       run_vars, run_status)
        DbUtils.drop_all_tables(self._cursor, self._oasis_staging_schema)
        DbUtils.drop_all_views(self._cursor, self._oasis_staging_schema)