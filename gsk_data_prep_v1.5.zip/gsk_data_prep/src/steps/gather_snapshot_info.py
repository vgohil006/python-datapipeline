'''
Created on Jul 29, 2020

@author: mfilho
'''
from util import BaseStep, DbUtils, YyyyQqUtils, IsoWeekUtils, util_datetime
import datetime
from _datetime import date


class GatherSnapshotInfo(BaseStep):
    '''
    Gather snapshot info
    '''
    # Common active moieties
    COMMON_ACTIVE_MOIETIES = [ "Nicotine",
                               "Bupropion hydrochloride",
                               "Fluticasone prop & salmeterol xinafoate",
                               "Paroxetine hydrochloride",
                               "HBV",
                               "Rosiglitazone maleate",
                             ]
    # Common MedDRA PTs
    COMMON_MEDDRA_PTS = ["Drug ineffective",
                         "Death",
                         "Fatigue",
                         "Headache",
                         "Nausea",
                        ]
    def __init__(self, data_prep_version):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "gather_snapshot_info",
                          "Gather snapshot info")
        self._data_prep_version = data_prep_version
        
    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(GatherSnapshotInfo, self)._init_cursors(settings)
        
        #Set run_vars
        
    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(GatherSnapshotInfo, self)._do_step(interactive, config_settings,
                                                 run_vars, run_status)

        # create a cursor for working in the prep_info_schema      
        self._prep_info_user = config_settings.get("postgresql", "postgresql_user")
        self._prep_info_pass = config_settings.getsecret("postgresql", "postgresql_user_pass")
        self._prep_info_schema = config_settings.get("db-common", "prep_info_schema")
        self._icsr_staging_schema = config_settings.get("db-common","icsr_staging_schema")
        
        self._cursor = self._cursors.get_cursor(self._prep_info_user,
                                                          self._prep_info_pass,
                                                          self._db_connect_str,
                                                          self._prep_info_schema)
        
        self._cursor_icsr = self._cursors.get_cursor(self._prep_info_user,
                                                          self._prep_info_pass,
                                                          self._db_connect_str,
                                                          self._icsr_staging_schema)
        
        self._snapshot_info_table = "snapshot_info"
        asof_date = self._run_vars.get("asof_date")
        year = int(asof_date.strip()[6:10])
        month = int(asof_date.strip()[0:2])
        day = int(asof_date.strip()[3:5])
        a_date = datetime.date(year,month,day)
        iso_week = a_date.isocalendar()[1]
        self._week =  str(year) + 'W' + str(iso_week)
        
        tables_exist = DbUtils.table_exists(self._cursor, self._prep_info_schema, self._snapshot_info_table)
        if (tables_exist == False):
            self._logger.info('------ Creating Table snapshot_info -------')
            # columns for the snapshot_info table
            cols = ("id          SERIAL NOT NULL PRIMARY KEY,\n"
                    "week     VARCHAR(10) NOT NULL,\n"
                    "description VARCHAR NOT NULL,\n"
                    "result_int  INTEGER,\n"
                    "result_txt  VARCHAR")

            # (re)create the table
            DbUtils.drop_table(self._cursor, "", "snapshot_info")
            DbUtils.create_table(self._cursor, "", "snapshot_info", cols=cols)
            DbUtils.commit(self._cursor)
        
        # delete the snapshot_info table entry if it already exists for the week
        delete_sql = (f"DELETE FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                      f" WHERE week = %(week)s")
        self._cursor.execute(delete_sql, { "week": self._week })
        
        # ---------- Version info ----------
        # Snapshot week
        self._add_snapshot_info("Snapshot week", value=self._week)
        
        # Data prep version
        self._add_snapshot_info("Data prep version", value=self._data_prep_version)
        
        # MedDRA version
        meddra_version = run_vars.get("meddra_version")
        self._add_snapshot_info("MedDRA version", value=meddra_version)
        
        # ---------- Table row counts ----------
        # Add row counts for all of the tables in the staging_schema
        tables = DbUtils.get_all_tables(self._cursor, self._icsr_staging_schema)
        for table in tables:
            self._add_snapshot_info(f"Row count: {table}",
                                    query=f"SELECT COUNT(*) FROM {self._icsr_staging_schema}.{table}")
        
        # ---------- New or changed reports ----------
        # Number new or changed reports since last week
        self._add_snapshot_info("Number new or changed reports this week",
                                query=(f"SELECT COUNT(DISTINCT case_id)\n"
                                       f"  FROM {self._icsr_staging_schema}.safety_report\n"
                                       f" WHERE UPPER(last_signif_update_week) = '{self._week}'"))        
        
        # ---------- Reactions ----------
        # Number of distinct PTs
        self._add_snapshot_info("Number of distinct PTs",
                                query=(f"SELECT COUNT(DISTINCT reaction_pt_plus_smq)\n"
                                       f"  FROM {self._icsr_staging_schema}.reaction\n"
                                       f" WHERE reaction_type = 'PT'"))
        
        # Number of distinct PTs + SMQs
        self._add_snapshot_info("Number of distinct PTs plus SMQs",
                                query=(f"SELECT COUNT(DISTINCT reaction_pt_plus_smq)\n"
                                       f"  FROM {self._icsr_staging_schema}.reaction"))        
        
        # Number of reports for common PTs
        for pt in GatherSnapshotInfo.COMMON_MEDDRA_PTS:
            self._add_snapshot_info(f"Report count for PT: {pt}",
                                    query=(f"SELECT COUNT(DISTINCT case_id)\n"
                                           f"  FROM {self._icsr_staging_schema}.reaction\n"
                                           f" WHERE reaction_pt_plus_smq = '{pt}'"))         
        
        prev_week = IsoWeekUtils.incr_yyyyWww(self._week, -1)
        snapshot_prefix = self._settings.get("database", "snapshot_prefix")
        prev_week_schema = f"{snapshot_prefix}{prev_week}".lower()
        
        # ---------- Compare snapshot info with results from the prior week ----------
        cur_week = self._week
        
        
       # For the set of COMMON_ACTIVE_MOIETIES compare the number of reports
        for moiety in GatherSnapshotInfo.COMMON_ACTIVE_MOIETIES:
            self._add_week_over_week_info(f"Report count for active moiety: {moiety}",
                                                prev_week, cur_week)

        # Number of distinct active ingredients
        self._add_week_over_week_info("Number of distinct active ingredients", prev_week, cur_week)

        # Number of distinct active moieties
        self._add_week_over_week_info("Number of distinct active moieties", prev_week, cur_week)

        # Number of cases associated with most common unmapped drug verbatim, don't warn if this number goes down
        self._add_week_over_week_info("Number of cases for the most common unmapped drug verbatim",
                                            prev_week, cur_week, warn=False)
        
        # For the set of COMMON_MEDDRA_PTS compare the number of reports
        for pt in GatherSnapshotInfo.COMMON_MEDDRA_PTS:
            self._add_week_over_week_info(f"Report count for PT: {pt}",
                                                prev_week, cur_week)

        # Number of distinct event terms (PTs plus SMQs)
        self._add_week_over_week_info("Number of distinct PTs plus SMQs", prev_week, cur_week)

        # Number of unmapped reaction verbatims
        self._add_week_over_week_info("Number of distinct unmapped reaction verbatims",
                                            prev_week, cur_week, warn=False)

        # Unmapped reaction verbatims that are new this week
        self._add_list_to_snapshot_info("New this week: Unmapped reaction verbatim values",
                                       (f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped reaction verbatim')\n"
                                        f"   AND UPPER(week) = '{cur_week}'\n"
                                        f"EXCEPT\n"
                                        f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped reaction verbatim')\n"
                                        f"   AND UPPER(week) = '{prev_week}'\n"
                                        f"ORDER BY 1"))

        # Number of unmapped indication verbatims
        self._add_week_over_week_info("Number of distinct unmapped indication verbatims",
                                            prev_week, cur_week, warn=False)

        # Unmapped indication verbatims that are new this week
        self._add_list_to_snapshot_info("New this week: Unmapped indication verbatim values",
                                       (f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped indication verbatim')\n"
                                        f"   AND UPPER(week) = '{cur_week}'\n"
                                        f"EXCEPT\n"
                                        f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped indication verbatim')\n"
                                        f"   AND UPPER(week) = '{prev_week}'\n"
                                        f"ORDER BY 1"))

        # Number of reports with unmapped country code verbatims
        self._add_week_over_week_info("Number of distinct unmapped country code verbatims",
                                            prev_week, cur_week, warn=False)

        # Unmapped country code verbatims that are new this week
        self._add_list_to_snapshot_info("New this week: Unmapped country code verbatim values",
                                       (f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped country code verbatim')\n"
                                        f"   AND UPPER(week) = '{cur_week}'\n"
                                        f"EXCEPT\n"
                                        f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped country code verbatim')\n"
                                        f"   AND UPPER(week) = '{prev_week}'\n"
                                        f"ORDER BY 1"))

        # Number of reports with unmapped country codes
        self._add_week_over_week_info("Number of distinct unmapped country codes",
                                            prev_week, cur_week, warn=False)
        
        # Unmapped country codes that are new this week
        self._add_list_to_snapshot_info("New this week: Unmapped country code values",
                                       (f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped country code')\n"
                                        f"   AND UPPER(week) = '{cur_week}'\n"
                                        f"EXCEPT\n"
                                        f"SELECT result_txt\n"
                                        f"   FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                                        f" WHERE UPPER(description) = UPPER('Unmapped country code')\n"
                                        f"   AND UPPER(week) = '{prev_week}'\n"
                                        f"ORDER BY 1"))


    def _add_week_over_week_info(self, item, prev_week, cur_week, warn=True):
        '''
        For the specified item, extract counts from the snapshot info for the
        specified weeks, calculate the delta and add a row to the snapshot_info
        table with the week over week result.
        
        If warn is true, add "WARNING: " as a prefix for the item description if
        the delta is <= 0
        '''
        query = (f"SELECT result_int\n"
                 f"  FROM {self._prep_info_schema}.snapshot_info\n"
                 f" WHERE UPPER(description) = %(item)s\n"
                 f"   AND UPPER(week) = %(week)s")
        self._cursor.execute(query, {'item': item.upper(), 'week': prev_week.upper()})
        prev_cnt = 0 if self._cursor.rowcount == 0 else self._cursor.fetchone()[0]
        
        self._cursor.execute(query, {'item': item.upper(), 'week': cur_week.upper()})
        cur_cnt = 0 if self._cursor.rowcount == 0 else self._cursor.fetchone()[0]
        
        delta = cur_cnt - prev_cnt
        warn = "WARNING: " if warn and delta <= 0 else ""
        
        self._add_snapshot_info(f"{warn}Week over week change for {item}",
                                value=delta)

    def _add_snapshot_info(self, description, query=None, value=None):
        '''
        Add a row of information to the snapshot_info table
        
        If a query argument is supplied, it is used to query the database for
        the result of interest; otherwise the supplied value argument is inserted.
        
        If the type of the result to be inserted is an int, it will be inserted into
        the result_int column of the snapshot_info table; otherwise the result will
        be inserted into the result_txt column.
        '''
        # if a query was supplied, fetch the result from the database
        if query:
            self._cursor.execute(query)
            result = self._cursor.fetchone()[0]
        else:
            result = value
        
        # populate the result_int and result_txt variables based on the type of result
        if isinstance(result, int):
            result_int, result_txt = (result, None)
        else:
            result_int, result_txt = (None, result)
        
        # insert the snapshot_info item into the table
        insert_sql = (f"INSERT INTO {self._prep_info_schema}.{self._snapshot_info_table}\n"
                      f"       (week, description, result_int, result_txt)\n"
                      f"VALUES (%(week)s, %(description)s, %(result_int)s, %(result_txt)s)")
        self._cursor.execute(insert_sql, { "week": self._week, "description": description,
                                           "result_int": result_int, "result_txt": result_txt })
        DbUtils.commit(self._cursor)

    def _add_list_to_snapshot_info(self, description, query):
        '''
        Add a list of values to the snapshot_info table (one row per value)
        
        The query argument is used to obtain the list of values from the database.
        '''
        # insert the list of items into the snapshot_info table
        insert_sql = (f"INSERT INTO {self._prep_info_schema}.{self._snapshot_info_table}\n"
                      f"       (week, description, result_txt)\n"
                      f"SELECT t1.week, t1.description, t2.*\n"
                      f"  FROM (SELECT %(week)s AS week, %(description)s AS description) t1\n"
                      f"  CROSS JOIN ({query}) t2\n"
                      f"ORDER BY 3")
        self._cursor.execute(insert_sql, { "week": self._week, "description": description })
        DbUtils.commit(self._cursor)
  
    def _create_snapshot_info_for_week_table(self):
        '''
        Store a copy of this week's snapshot info in the snapshot schema
        '''
        DbUtils.drop_table(self._cursor, "", self._snapshot_info_table)
        DbUtils.create_table(self._cursor, "", self._snapshot_info_table,
                             "id serial, description VARCHAR, result_int INTEGER, result_txt VARCHAR")
        insert_sql = (f"INSERT INTO {self._snapshot_info_table} (description, result_int, result_txt)\n"
                      f"SELECT description, result_int, result_txt\n"
                      f"  FROM {self._prep_info_schema}.{self._snapshot_info_table}\n"
                      f" WHERE week = %(week)s\n"
                      f"ORDER BY id")
        self._cursor.execute(insert_sql, { "week": self._week })
        DbUtils.commit(self._cursor)

        