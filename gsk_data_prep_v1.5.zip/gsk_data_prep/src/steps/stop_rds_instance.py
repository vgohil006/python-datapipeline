'''
@author: vgohil
'''

from util import BaseStep
import boto3
from time import sleep



class StopRDSInstance(BaseStep):
    '''
    Stop the Oracle instance needed for the AWS Data Migration Service
    '''

    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "stop_rds_instance",
                          "Stop the Oracle instance for AWS DMS")
        
 
    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(StopRDSInstance, self)._init_cursors(settings)
        
        self._source_endpoint = settings.get("dms", "source_endpoint")

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(StopRDSInstance, self)._do_step(interactive, config_settings,
                                       run_vars, run_status)
        
        self._source_endpoint = config_settings.get("dms", "source_endpoint")
        
        # The code to stop the Oracle instance goes here
        client = boto3.client('rds')
        
        response = client.describe_db_instances(DBInstanceIdentifier = self._source_endpoint,
                                        MaxRecords=100,
                                        Marker='string')
        
        status = response['DBInstances'][0]['DBInstanceStatus']

        self._logger.info('==== Source Database Instance Status ====\n')
        
        self._logger.info(response['DBInstances'][0]['DBInstanceIdentifier'] + ' => ' + response['DBInstances'][0]['DBInstanceArn'])
        
        self._logger.info(f"\n --- RDS Instance: {status} ---")
        
        client.stop_db_instance(DBInstanceIdentifier=self._source_endpoint)

        WAIT_TIME = 30 # seconds to wait between each poll
        MAX_RETRY = 2000 # the max number of seconds to poll before timing out
        
        retry = 0
                         
        while True:
           
            retry += WAIT_TIME
            sleep(WAIT_TIME)
        
        
            rds_response = client.describe_db_instances(DBInstanceIdentifier=self._source_endpoint,
                                                        MaxRecords = 100, 
                                                        Marker='string')
            
            state = rds_response['DBInstances'][0]['DBInstanceStatus']
            self._logger.info(f"--- RDS Instance: {state} --- ")
        
            if state == 'stopped':
                self._logger.info(f"--- RDS Instance: {state} ---")
                break
            elif state in ('failed',) or retry > MAX_RETRY:
                raise Exception('--- RDS Instance failed or timed out ---')
