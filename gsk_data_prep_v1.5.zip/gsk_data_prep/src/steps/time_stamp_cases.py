'''
Created on May 27, 2020

@author: mfilho
'''

from util import BaseStep, DbUtils
import os
import platform
import subprocess
import re


class TimeStampCases(BaseStep):
    '''
    Prepare the case data for loading into the data mart
    '''

    def __init__(self, drop_all_indexes,drop_drug_indexes,drop_reaction_indexes):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "time_stamp_cases",
                          "Time Stamp the cases")
        self._drop_all_indexes = drop_all_indexes
        self._drop_drug_indexes = drop_drug_indexes
        self._drop_reaction_indexes = drop_reaction_indexes
        

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(TimeStampCases, self)._init_cursors(settings)

        self._oasis_user = settings.get("postgresql", "postgresql_user")
        self._oasis_pass = settings.getsecret("postgresql", "postgresql_user_pass")
        self._staging_schema = settings.get("db-common", "icsr_staging_schema")
        self._mart_schema = settings.get("db-common","mart_schema")

        self._admin_schema = settings.get("db-common","cvw_admin_schema")
        self._investigate_schema = settings.get("db-common","cvw_investigate_schema")
        self._investigate_role = settings.get("db-common","cvw_investigate_role")

        self._mart_ro_role = settings.get("db-common", "mart_ro_role");
        self._mart_rw_role = settings.get("db-common", "mart_rw_role");

        # Two cursors ... one with search path of staging_schema
        # one with search path mart_schema, staging_schema
        self._staging_cursor = self._cursors.get_cursor(self._oasis_user,
                                                        self._oasis_pass,
                                                        self._db_connect_str,
                                                        self._staging_schema)

        self._mart_cursor = self._cursors.get_cursor(self._oasis_user,
                                                     self._oasis_pass,
                                                     self._db_connect_str,
                                                     self._mart_schema)
#                                                    self._mart_schema + "," + self._staging_schema)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        
        '''
        super(TimeStampCases, self)._do_step(interactive, config_settings,
                                           run_vars, run_status)
        
        self._icsr_tables = [ "drug","drug_dosage","drug_indication","drug_reaction", "followup", "lab_data", "literature","narrative",
                              "neonates","parent","patient","patient_deathcause","patient_hist", "pregnancy", "reaction","reporters",
                              "safety_report","study",
                            ]

        substeps = [StartMerge(self),
             CopyTimestampedTables(self, self._mart_cursor, self._mart_schema, self._staging_schema, self._mart_ro_role, self._mart_rw_role),
             CopyTables(self, self._mart_cursor, self._mart_schema, self._staging_schema, self._mart_ro_role, self._mart_rw_role),
             CopyReferenceTables(self, self._mart_cursor, self._investigate_schema, self._investigate_role, self._staging_schema, self._oasis_user),
             CopySequences(self, self._mart_cursor, self._mart_schema, self._staging_schema, self._mart_ro_role, self._mart_rw_role),
             CopyViews(self, self._mart_cursor, self._mart_schema, self._staging_schema, self._mart_ro_role, self._mart_rw_role),
             DropIndexes(self, self._mart_cursor, self._mart_schema, self._staging_schema, self._drop_all_indexes, self._drop_drug_indexes, self._drop_reaction_indexes),
             MergeData(self, self._staging_schema, self._mart_cursor, self._icsr_tables),
             CreateExtensions(self, self._mart_cursor),
             CreateIndexes(self, self._mart_schema, self._staging_schema, self._mart_cursor),
             ComputeStatistics(self, self._mart_cursor, self._mart_schema),
             UpdateAdminMetaData(self, self._staging_cursor, self._staging_schema, self._admin_schema),
             UpdateMergeDate(self, self._mart_cursor, self._staging_schema)
            ]
        
        self.execute_substeps(substeps)


class StartMerge(BaseStep):
    '''
    Start the merge process
    '''
    def __init__(self,parent_step):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "start_merge",
                          "Start the merge process",
                          parent=parent_step)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(StartMerge, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)


class CopyTimestampedTables(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, mart_cursor, mart_schema, staging_schema, mart_ro_role, mart_rw_role):
        BaseStep.__init__(self,
                          "copy_timestamped_tables",
                          "Copy timestamped tables from staging",
                          parent=parent_step)
        self._cursor = mart_cursor
        self._staging_schema = staging_schema
        self._mart_schema = mart_schema
        self._mart_ro_role = mart_ro_role;
        self._mart_rw_role = mart_rw_role;

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CopyTimestampedTables, self)._do_step(interactive, config_settings,
                                                      run_vars, run_status)
        # determine the staging asof
        sql = f"SELECT MAX(valid_start) FROM {self._staging_schema}.valid_asof"
        self._cursor.execute(sql)
        asof = self._cursor.fetchone()[0]        
        run_vars.set("staging_asof", asof.strftime("%m/%d/%Y %H:%M:%S"))

        self._copy_timestamped_tables(asof)

    def _copy_timestamped_tables(self, asof):
        '''
        For each of the timestamped (including UVT) tables that are not already
        present, copy the table from the staging schema to the mart schema
        '''
        sql = (f"SELECT object_name, object_type\n"
               f"  FROM {self._staging_schema}.mart_objects\n"
               f" WHERE UPPER(object_type) IN ('TIMESTAMPED TABLE', 'UVT')\n"
               f"ORDER BY object_name")

        rw_grantee_list = [f"{self._mart_rw_role}"]
        ro_grantee_list = [f"{self._mart_ro_role}"]
        rw_priv_list = ["ALL"]
        ro_priv_list = ["SELECT"]

        for row in list(DbUtils.execute_query(self._cursor, sql)):
            table = row['object_name']
            if not DbUtils.table_exists(self._cursor, self._mart_schema, table):
                sql = (f"CREATE TABLE {table} AS\n"
                       f"SELECT t.*,\n"
                       f"       %(asof)s::TIMESTAMP WITHOUT TIME ZONE AS valid_start,\n"
                       f"       %(valid_end)s::TIMESTAMP WITHOUT TIME ZONE AS valid_end\n"
                       f"  FROM {self._staging_schema}.{table} t")
                self._cursor.execute(sql, {"asof": asof.strftime("%d-%b-%Y"),
                                           "valid_end": "01-JAN-2500"})

                # Grant permissions on the table
                db_object_list = [f"{self._mart_schema}.{table}"]
                DbUtils.grant_privileges(self._cursor, ro_priv_list, db_object_list, ro_grantee_list)
                DbUtils.grant_privileges(self._cursor, rw_priv_list, db_object_list, rw_grantee_list)

                DbUtils.commit(self._cursor)


class CopyTables(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, mart_cursor, mart_schema, staging_schema, mart_ro_role, mart_rw_role ):
        BaseStep.__init__(self,
                          "copy_tables",
                          "Copy non-timestamped tables from staging",
                          parent=parent_step)
        self._cursor = mart_cursor
        self._staging_schema = staging_schema
        self._mart_schema = mart_schema
        self._mart_ro_role = mart_ro_role;
        self._mart_rw_role = mart_rw_role;

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CopyTables, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        self._copy_tables()

    def _copy_tables(self):
        '''
        For each of the non-timestamped tables that are not already present,
        copy the table from the staging schema to the mart schema
        '''
        sql = (f"SELECT object_name, object_type\n"
               f"  FROM {self._staging_schema}.mart_objects\n"
               f" WHERE UPPER(object_type) = 'TABLE'\n"
               f"ORDER BY object_name")

        rw_grantee_list = [f"{self._mart_rw_role}"]
        ro_grantee_list = [f"{self._mart_ro_role}"]
        rw_priv_list = ["ALL"]
        ro_priv_list = ["SELECT"]

        for row in list(DbUtils.execute_query(self._cursor, sql)):
            table = row['object_name']
            if not DbUtils.table_exists(self._cursor, self._mart_schema, table):
                # Create a table like the one being copied including constraints,
                # comments and defaults
                sql = (f"CREATE TABLE {table} (\n"
                       f"       LIKE {self._staging_schema}.{table}\n"
                       f"       INCLUDING COMMENTS INCLUDING CONSTRAINTS INCLUDING DEFAULTS)")
                self._cursor.execute(sql)

                # Grant permissions on the table
                db_object_list = [f"{self._mart_schema}.{table}"]
                DbUtils.grant_privileges(self._cursor, ro_priv_list, db_object_list, ro_grantee_list)
                DbUtils.grant_privileges(self._cursor, rw_priv_list, db_object_list, rw_grantee_list)

                # Populate the table
                sql = (f"INSERT INTO {table}\n"
                       f"SELECT * FROM {self._staging_schema}.{table}")
                self._cursor.execute(sql)

                DbUtils.commit(self._cursor)

 
class CopyReferenceTables(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, mart_cursor, investigate_schema, investigate_role, staging_schema, oasis_user ):
        BaseStep.__init__(self,
                          "copy_reference_tables",
                          "Copy reference tables from staging",
                          parent=parent_step)

        self._cursor = mart_cursor
        self._staging_schema = staging_schema
        self._investigate_schema = investigate_schema
        self._investigate_role = investigate_role
        self._oasis_user = oasis_user

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CopyReferenceTables, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        self._copy_tables()

    def _copy_tables(self):
        '''
        For each of the non-timestamped tables that are not already present,
        copy the table from the staging schema to the mart schema
        '''
        sql = (f"SELECT object_name, object_type\n"
               f"  FROM {self._staging_schema}.reference_objects\n"
               f" WHERE UPPER(object_type) = 'TABLE'\n"
               f"ORDER BY object_name")

        for row in list(DbUtils.execute_query(self._cursor, sql)):
            table = row['object_name']
            DbUtils.drop_table(self._cursor, self._investigate_schema, table)
                       
            # Create a table like the one being copied including constraints,
            # comments and defaults
            sql = (f"CREATE TABLE {self._investigate_schema}.{table} (\n"
                   f"       LIKE {self._staging_schema}.{table}\n"
                   f"       INCLUDING COMMENTS INCLUDING CONSTRAINTS INCLUDING DEFAULTS)")
            self._cursor.execute(sql)

            # Populate the table
            sql = (f"INSERT INTO {self._investigate_schema}.{table}\n"
                   f"SELECT * FROM {self._staging_schema}.{table}")
            self._cursor.execute(sql)
            
            # Change owner and grant privileges
            priv_list = ["ALL"]
            grantee_list = [self._oasis_user]
            db_object_list = [f"{self._investigate_schema}.{table}"]

            DbUtils.grant_privileges(self._cursor, priv_list, db_object_list, grantee_list)
            sql = (f"ALTER TABLE {self._investigate_schema}.{table} OWNER TO {self._investigate_role}")
            self._cursor.execute(sql)

            DbUtils.commit(self._cursor)


class CopySequences(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, mart_cursor, mart_schema, staging_schema, mart_ro_role, mart_rw_role):
        BaseStep.__init__(self,
                          "copy_sequences",
                          "Copy sequences from staging",
                          parent=parent_step)
        self._cursor = mart_cursor
        self._staging_schema = staging_schema
        self._mart_schema = mart_schema
        self._mart_ro_role = mart_ro_role;
        self._mart_rw_role = mart_rw_role;

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CopySequences, self)._do_step(interactive, config_settings,
                                            run_vars, run_status)
        self._copy_sequences()

    def _copy_sequences(self):
        '''
        For each of the sequences that are not already present,
        copy the sequence from the staging schema to the mart schema
        '''
        sql = (f"SELECT object_name, object_type\n"
               f"  FROM {self._staging_schema}.mart_objects\n"
               f" WHERE UPPER(object_type) = 'SEQUENCE'\n"
               f"ORDER BY object_name")
        
        for row in list(DbUtils.execute_query(self._cursor, sql)):
            sequence = row['object_name']
            if not DbUtils.sequence_exists(self._cursor, self._mart_schema, sequence):
                # determine the next value for the sequence in the staging schema
                self._cursor.execute(f"SELECT NEXTVAL('{self._staging_schema}.{sequence}')")
                nextval = self._cursor.fetchone()[0]
                
                # create the sequence in the mart schema setting the start value
                # to reflect the nextval from the staging schema
                DbUtils.create_sequence(self._cursor, None, sequence, nextval)
                DbUtils.commit(self._cursor)
                
                # Add grants to the sequence
                sql = f"GRANT ALL ON SEQUENCE {self._mart_schema}.{sequence} TO {self._mart_ro_role}"
                self._cursor.execute(sql)
                sql = f"GRANT ALL ON SEQUENCE {self._mart_schema}.{sequence} TO {self._mart_rw_role}"
                self._cursor.execute(sql)


class CopyViews(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, mart_cursor, mart_schema, staging_schema, mart_ro_role, mart_rw_role):
        BaseStep.__init__(self,
                          "copy_views",
                          "Copy views from staging",
                          parent=parent_step)
        self._cursor = mart_cursor
        self._staging_schema = staging_schema
        self._mart_schema = mart_schema
        self._mart_ro_role = mart_ro_role;
        self._mart_rw_role = mart_rw_role;

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CopyViews, self)._do_step(interactive, config_settings,
                                          run_vars, run_status)
        self._copy_views()
        
    def _copy_views(self):
        '''
        For each of the views that are not already present,
        copy the view from the staging schema to the mart schema
        '''
        sql = (f"SELECT object_name, object_type\n"
               f"  FROM {self._staging_schema}.mart_objects\n"
               f" WHERE UPPER(object_type) = 'VIEW'\n"
               f"ORDER BY object_name")

        grantee_list = [f"{self._mart_rw_role}", f"{self._mart_ro_role}"]
        priv_list = ["SELECT"]

        for row in list(DbUtils.execute_query(self._cursor, sql)):
            view = row['object_name']
            if not DbUtils.view_exists(self._cursor, self._mart_schema, view):
                # determine the definition for the view in the staging schema
                sql = f"SELECT pg_get_viewdef('{self._staging_schema}.{view}', true)";
                self._cursor.execute(sql)
                view_def = self._cursor.fetchone()[0]
                
                # adjust the view_definition by adding valid_start and valid_end
                pattern = re.compile("(?P<start>.*\s+)(?P<table_alias>\w+)\.(?P<last_exp>\w+)(?P<rest>\s+FROM\s+.*)",
                                     re.IGNORECASE | re.MULTILINE | re.DOTALL)
                m = re.match(pattern, view_def)
                groups = m.groupdict()
                start = groups["start"]
                alias = groups["table_alias"]
                exp = groups["last_exp"]
                rest = groups["rest"]
                adjusted_def = f"{start}{alias}.{exp}, {alias}.valid_start, {alias}.valid_end{rest}"
                
                # replace references to the staging_schema with the mart_schema
                schema_pat = re.compile(f"(\s+){self._staging_schema}.",
                                        re.IGNORECASE | re.MULTILINE | re.DOTALL)
                adjusted_def = re.sub(schema_pat, f"\\1{self._mart_schema}.", adjusted_def)
                
                # create the sequence in the mart schema setting the start value
                # to reflect the nextval from the staging schema
                DbUtils.create_view(self._cursor, None, view, adjusted_def)
                
                # Grant permissions on the view
                db_object_list = [f"{self._mart_schema}.{view}"]
                DbUtils.grant_privileges(self._cursor, priv_list, db_object_list, grantee_list)

                DbUtils.commit(self._cursor)


class DropIndexes(BaseStep):
    '''
    Drop indexes for the data mart tables
    '''
    def __init__(self, parent_step,  mart_cursor, mart_schema, staging_schema, drop_all_indexes, drop_drug_indexes, drop_reaction_indexes):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "drop_indexes",
                          "Drop indexes for the data mart tables",
                           parent=parent_step)
        self._mart_cursor = mart_cursor
        self._mart_schema = mart_schema
        self._staging_schema = staging_schema
        self._drop_all_indexes = drop_all_indexes
        self._drop_drug_indexes = drop_drug_indexes
        self._drop_reaction_indexes = drop_reaction_indexes

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(DropIndexes, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        # tables affected when self._drop_drug_indexes is True
        drop_drug_index_tables = ["drug", "drug_dosage","drug_indication","drug_reaction",
                                 ]
        
        # tables affected when self._drop_reaction_indexes is True
        drop_reaction_index_tables = ["reaction", "drug_reaction",
                                     ]
        
        # Indexes on columns in the drop_index_excluded_cols list are
        # retained regardless of the drop_all_indexes, drop_drug_indexes and
        # drop_reaction_indexes flag values
        drop_index_excluded_cols = ["case_id",
                                    "case_id, prod_seq_num",
                                    "case_id, reaction_seq_num",
                                    "case_id, prod_seq_num, reaction_seq_num"
                                   ]

        if self._drop_all_indexes or self._drop_drug_indexes or self._drop_reaction_indexes:
            sql = (f"SELECT index_name, table_name, cols_or_expr\n"
                   f"  FROM {self._staging_schema}.mart_indexes\n"
                   f"ORDER BY index_name")
            
            for row in list(DbUtils.execute_query(self._mart_cursor, sql)):
                index = row["index_name"]
                table_name = row["table_name"]
                cols_or_expr = row["cols_or_expr"]
                
                # keep UVT indexes and indexes for cols in the drop_index_excluded_cols list
                if index.startswith('uvt_') or cols_or_expr in drop_index_excluded_cols:
                    continue
                
                # determine whether to drop the index
                if self._drop_all_indexes or \
                   (self._drop_drug_indexes and table_name in drop_drug_index_tables) or \
                   (self._drop_reaction_indexes and table_name in drop_reaction_index_tables):
                    # drop the index if it exists
                    if DbUtils.index_exists(self._mart_cursor, self._mart_schema, index):
                        DbUtils.drop_index(self._mart_cursor, self._mart_schema, index)


class MergeData(BaseStep):
    '''
    Merge the snapshot into the data mart
    '''
    def __init__(self, parent_step, staging_schema, mart_cursor, icsr_tables):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "merge_data",
                          "Merge the snapshot into the data mart",
                          parent=parent_step)
        self._staging_schema = staging_schema
        self._mart_cursor = mart_cursor
        self._icsr_tables = icsr_tables


    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(MergeData, self)._do_step(interactive, config_settings,
                                        run_vars, run_status)
        
        substeps = [
            Timestamp(self, self._mart_cursor, self._staging_schema, self._icsr_tables ,self._parent._db_connect_str),
            UpdateMartMetadata(self, self._mart_cursor, self._staging_schema),
        ]
        
        self.execute_substeps(substeps)


class Timestamp(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, mart_cursor, staging_schema, icsr_tables, db_connect_str):
        BaseStep.__init__(self,
                          "timestamp",
                          "Timestamp the ICSR and UVT tables",
                          parent=parent_step)
        self._cursor = mart_cursor
        self._staging_schema = staging_schema
        self._db_connect_str = db_connect_str
        self._icsr_tables = icsr_tables

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(Timestamp, self)._do_step(interactive, config_settings,
                                        run_vars, run_status)
        settings = self._gather_settings()
        self._execute_timestamper(settings)

    def _gather_settings(self):
        '''
        Gather the information needed to provision the timestamper
        '''
        settings = {}
        
        host, port, database = DbUtils.parse_connect_string(self._db_connect_str)
        settings["mart_host"] = host
        settings["mart_port"] = port
        settings["mart_database"] = database
        
        settings["mart_user"] = self._settings.get("postgresql", "postgresql_user")
        settings["mart_pass"] = self._settings.getsecret("postgresql", "postgresql_user_pass")
        settings["mart_schema"] = self._settings.get("db-common", "mart_schema")
        
        settings["staging_schema"] = self._staging_schema
        
        # get the list of timestamped ICSR tables
        sql = (f"SELECT object_name\n"
               f"  FROM {self._staging_schema}.mart_objects\n"
               f" WHERE UPPER(object_type) = 'TIMESTAMPED TABLE'\n"
               f"ORDER BY 1")
        self._cursor.execute(sql)
        tables = [ row[0] for row in self._cursor.fetchall() ]

        # get the list of timestamped UVT tables
        sql = (f"SELECT object_name\n"
               f"  FROM {self._staging_schema}.mart_objects\n"
               f" WHERE UPPER(object_type) = 'UVT'\n"
               f"ORDER BY 1")
        self._cursor.execute(sql)
        uvts = [ row[0] for row in self._cursor.fetchall() ]
        
        settings["num_tables"] = len(tables) + len(uvts)
        
        i = 1
        timestamp_table_names = []
        timestamp_update_names = []
        for table in tables + uvts:
            timestamp_table_names.append(f"tables.timestamp.{i}.name = {settings['mart_schema']}.{table}")
            timestamp_update_names.append(f"tables.update.{i}.name = {self._staging_schema}.{table}")
            i += 1
            
        settings["timestamp_table_names"] = "\n".join(timestamp_table_names)
        settings["timestamp_update_names"] = "\n".join(timestamp_update_names)
            
        i = 1
        timestamp_index_columns = []
        timestamp_case_ids = []
        for table in tables:
            timestamp_index_columns.append(f"tables.timestamp.{i}.index_columns = case_id")
            timestamp_case_ids.append(f"tables.timestamp.{i}.case_id = case_id")
            i += 1
            
        for uvt in uvts:
            timestamp_index_columns.append(f"tables.timestamp.{i}.index_columns = item_value")
            i += 1
            
        settings["timestamp_index_columns"] = "\n".join(timestamp_index_columns)
        settings["timestamp_case_ids"] = "\n".join(timestamp_case_ids)
        
        return settings
            
    def _execute_timestamper(self, settings):
        '''
        Integrate data from the snapshot into the data mart
        '''
        
        java_path = self._settings.get("timestamper", "java_exe_path")
        timestamper_dir = self._settings.get("timestamper", "timestamper_dir")
        settings_template = self._settings.get("timestamper", "settings_template")
        asof = self._run_vars.get("asof_date")

        # Create the timestamper settings file
        with open(f"{timestamper_dir}/{settings_template}", "r") as in_f:
            content = in_f.read()
            content = content.format_map(settings)
        
        settings_file_name = "oasis_settings.txt"
        settings_file_path = f"{timestamper_dir}/{settings_file_name}"
        with open(settings_file_path, "w") as out_f:
            out_f.write(content)
 
        # Run the timestamper
        # the classpath separator character depends on the system type
        classpath_sep = ";" if platform.system().lower() == "windows" else ":"
        classpath = f"./*{classpath_sep}."
        cmd = [ java_path, "-classpath", classpath,
                "com.commoninf.timestamper.Timestamper",
                settings_file_name, asof ]
        result = subprocess.run(cmd, cwd="timestamper", text=True, capture_output=True)
        msg = "Result from timestamper:\n"
        msg = msg + "returncode=" + str(result.returncode) + "\n"
        msg = msg + "stdout=" + result.stdout + "\n"
        if result.returncode != 0:
            msg = msg + "stderr=" + result.stderr
            self._logger.error(msg)
        else:
            self._logger.info(msg)
 
        # Remove the settings file
        os.remove(settings_file_path)
 
        result.check_returncode()


class UpdateMartMetadata(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, mart_cursor, staging_schema):
        BaseStep.__init__(self,
                          "update_mart_metadata",
                          "Update the metadata for the data mart",
                          parent=parent_step)
        self._cursor = mart_cursor
        self._staging_schema = staging_schema

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(UpdateMartMetadata, self)._do_step(interactive, config_settings,
                                                 run_vars, run_status)
        # update term_hierarchy_dates
        sql = (f"WITH\n"
               f"candidates AS (\n"
               f"    SELECT *\n"
               f"      FROM {self._staging_schema}.term_hierarchy_dates),\n"
               f"new_rows AS (\n"
               f"    SELECT db_schema FROM candidates\n"
               f"    EXCEPT\n"
               f"    SELECT db_schema FROM term_hierarchy_dates)\n"
               f"INSERT INTO term_hierarchy_dates (\n"
               f"    name, version, db_schema, term_type, valid_start, update_user)\n"
               f"SELECT c.name, c.version, c.db_schema, c.term_type, c.valid_start, c.update_user\n"
               f"  FROM candidates c\n"
               f"  JOIN new_rows nr\n"
               f"    ON c.db_schema = nr.db_schema")
        self._cursor.execute(sql)
        DbUtils.commit(self._cursor)
        
        # update snapshot_version
        sql = (f"WITH\n"
               f"candidates AS (\n"
               f"    SELECT snapshot_schema, snapshot_version, data_prep_version, create_timestamp\n"
               f"      FROM {self._staging_schema}.snapshot_version),\n"
               f"new_rows AS (\n"
               f"    SELECT snapshot_schema, snapshot_version FROM candidates\n"
               f"    EXCEPT\n"
               f"    SELECT snapshot_schema, snapshot_version FROM snapshot_version)\n"
               f"INSERT INTO snapshot_version (snapshot_schema, snapshot_version,\n"
               f"                              data_prep_version, create_timestamp)\n"
               f"SELECT c.snapshot_schema, c.snapshot_version, c.data_prep_version,\n"
               f"       c.create_timestamp\n"
               f"  FROM candidates c\n"
               f"  JOIN new_rows nr\n"
               f"    ON c.snapshot_schema = nr.snapshot_schema\n"
               f"       AND c.snapshot_version = nr.snapshot_version")
        self._cursor.execute(sql)
        DbUtils.commit(self._cursor)
        
        # update valid_asof
        sql = (f"WITH\n"
               f"candidates AS (\n"
               f"    SELECT valid_start\n"
               f"      FROM {self._staging_schema}.valid_asof),\n"
               f"new_rows AS (\n"
               f"    SELECT valid_start FROM candidates\n"
               f"    EXCEPT\n"
               f"    SELECT valid_start FROM valid_asof)\n"
               f"INSERT INTO valid_asof (valid_start)\n"
               f"SELECT valid_start FROM new_rows")
        self._cursor.execute(sql)
        DbUtils.commit(self._cursor)


class CreateExtensions(BaseStep):
    '''
    Create the database extensions needed for data preparation
    '''

    def __init__(self, parent_step,mart_cursor):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "create_extensions",
                          "Create the database extensions needed for data prep",
                          parent=parent_step)
        
        self._mart_cursor = mart_cursor


    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateExtensions, self)._do_step(interactive, config_settings,
                                               run_vars, run_status)
        # Add the extensions
        for extension in ["fuzzystrmatch", "pg_trgm"]:
            sql = f"CREATE EXTENSION IF NOT EXISTS {extension} schema pg_catalog"
            self._mart_cursor.execute(sql)
            
        DbUtils.commit(self._mart_cursor)


'''
@author: rschaaf
'''
class CreateIndexes(BaseStep):
    '''
    Create indexes for the data mart tables
    '''
    def __init__(self, parent_step, mart_schema, staging_schema, mart_cursor):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "create_indexes",
                          "Create indexes for the data mart tables",
                          parent=parent_step)
        self._mart_schema = mart_schema
        self._staging_schema = staging_schema
        self._mart_cursor = mart_cursor

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''mart_
        Execute the step
        '''
        super(CreateIndexes, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        sql = (f"SELECT index_name, table_name, method,\n"
               f"       UPPER(unique_yn) AS unique_yn, cols_or_expr\n"
               f"  FROM {self._staging_schema}.mart_indexes\n"
               f"ORDER BY index_name")
        
        for row in list(DbUtils.execute_query(self._mart_cursor, sql)):
            index = row["index_name"]
            unique = (row["unique_yn"].upper() == "Y")
            if not DbUtils.index_exists(self._mart_cursor, self._mart_schema, index):
                DbUtils.create_index(self._mart_cursor, self._mart_schema,
                                     row["table_name"], index,
                                     row["cols_or_expr"],
                                     unique, row["method"])


class ComputeStatistics(BaseStep):
    '''
    Compute statistics for the data mart tables
    '''
    def __init__(self, parent_step, mart_cursor, mart_schema):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "compute_stats",
                          "Compute statistics for the data mart tables",
                          parent=parent_step)
        
        self._mart_cursor = mart_cursor
        self._mart_schema = mart_schema

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''mart_
        Execute the step
        '''
        super(ComputeStatistics, self)._do_step(interactive, config_settings,
                                                run_vars, run_status)
        DbUtils.compute_schema_statistics(self._mart_cursor, self._mart_schema)


'''
@author: wlebow
'''
class UpdateAdminMetaData(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, staging_cursor, staging_schema, admin_schema):
        BaseStep.__init__(self,
                          "update_CMQ_metadata",
                          "Update Metadata in the CVW Admin schema",
                          parent=parent_step)
        self._cursor = staging_cursor
        self._staging_schema = staging_schema
        self._admin_schema = admin_schema

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(UpdateAdminMetaData, self)._do_step(interactive, config_settings,
                                                 run_vars, run_status)
        # update term_hierarchy_dates
        sql = (f"WITH\n"
               f"candidates AS (\n"
               f"    SELECT DISTINCT reaction_pt_plus_smq AS name\n"
               f"      FROM {self._staging_schema}.reaction\n"
               f"      WHERE reaction_type = 'CMQ'),\n"
               f"new_rows AS (\n"
               f"    SELECT name FROM candidates\n"
               f"    EXCEPT\n"
               f"    SELECT name FROM {self._admin_schema}.cmq)\n"
               f"INSERT INTO {self._admin_schema}.cmq(id,name)\n"
               f"SELECT NEXTVAL('{self._admin_schema}.cmq_id_seq'), name\n"
               f"  FROM new_rows")

        self._cursor.execute(sql)
        DbUtils.commit(self._cursor)


class UpdateMergeDate(BaseStep):
    '''
    Finish the merge process
    '''
    def __init__(self, parent_step, mart_cursor, staging_schema):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "update_merge_date",
                          "Update the merge date in the snapshot_version table",
                          parent=parent_step)
        
        self._mart_cursor = mart_cursor
        self._staging_schema= staging_schema
        

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(UpdateMergeDate, self)._do_step(interactive, config_settings,
                                              run_vars, run_status)
        
        sql = (f"UPDATE snapshot_version sv\n"
               f"   SET merge_timestamp = CURRENT_TIMESTAMP\n"
               f" WHERE EXISTS (SELECT 1\n"
               f"                 FROM {self._staging_schema}.snapshot_version\n"
               f"                WHERE snapshot_schema = sv.snapshot_schema\n"
               f"                  AND snapshot_version = sv.snapshot_version)")
        self._mart_cursor.execute(sql)
        DbUtils.commit(self._mart_cursor)


class FinishMerge(BaseStep):
    '''
    Finish the merge process
    '''
    def __init__(self, parent_step):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "finish_merge",
                          "Finish the merge process",
                          parent=parent_step)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(FinishMerge, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)