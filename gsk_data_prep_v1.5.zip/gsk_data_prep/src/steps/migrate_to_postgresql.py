'''
@author: vgohil 
update - 07-Jul-2020
'''
import boto3
import os
from time import sleep
from util import BaseStep



class MigrateToPostgreSQL(BaseStep):
    '''
    Migrate data from Oracle to PostgreSQL
    '''

    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "migrate_to_postgresql",
                          "Migrate data from Oracle to PostgreSQL")

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(MigrateToPostgreSQL, self)._init_cursors(settings)
        self._oasis_orig_user = settings.get("postgresql", "postgresql_user")
        self._oasis_orig_pass = settings.getsecret("postgresql", "postgresql_user_pass")
        self._oasis_orig_schema = settings.get("db-common", "icsr_orig_schema")
        self._oasis_meddra_schema = settings.get("db-common", "oasis_meddra_schema")
        self._whodrug_schema = settings.get("db-common", "whodrug_schema")
        
        self._cursor = self._cursors.get_cursor(self._oasis_orig_user,
                                                self._oasis_orig_pass,
                                                self._db_connect_str,
                                                self._oasis_orig_schema)
        
        
        self._cursor_meddra = self._cursors.get_cursor(self._oasis_orig_user,
                                                self._oasis_orig_pass,
                                                self._db_connect_str,
                                                self._oasis_meddra_schema)
        
        
        self._cursor_whodrug = self._cursors.get_cursor(self._oasis_orig_user,
                                                self._oasis_orig_pass,
                                                self._db_connect_str,
                                                self._whodrug_schema)

        self._icsr_folder = settings.get("s3", "icsr_folder")
        self._meddra_folder = settings.get("s3", "meddra_folder")
        self._whodrug_folder = settings.get("s3", "whodrug_folder")

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(MigrateToPostgreSQL, self)._do_step(interactive, config_settings,
                                                  run_vars, run_status)

        substeps = [ LaunchDmsTask(self, self._cursor, self._cursor_meddra, self._cursor_whodrug, self._oasis_orig_schema, self._oasis_meddra_schema, self._whodrug_schema)
                   ]
        
        self.execute_substeps(substeps)


class LaunchDmsTask(BaseStep):
    '''
    Launch the DMS task
    '''
    
    def __init__(self, parent_step, cursor, meddra_cursor, whodrug_cursor, oasis_orig_schema, oasis_meddra_schema, whodrug_schema):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "launch_dms_task",
                          "Launch the DMS task",
                          parent=parent_step)
        
        self._cursor = cursor
        self._cursor_meddra = meddra_cursor
        self._cursor_whodrug = whodrug_cursor
        self._oasis_orig_schema = oasis_orig_schema
        self._oasis_meddra_schema = oasis_meddra_schema
        self._whodrug_schema = whodrug_schema

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(LaunchDmsTask, self)._do_step(interactive, config_settings,
                                            run_vars, run_status)
        
        icsr_task_1 = config_settings.get("dms", "icsr_task_1")
        icsr_task_2 = config_settings.get("dms", "icsr_task_2")
        meddra_task = config_settings.get("dms", "meddra_task")
        whodrug_task = config_settings.get("dms", "whodrug_task")
        
        icsr_folder = config_settings.get("s3", "icsr_folder")
        meddra_folder = config_settings.get("s3", "meddra_folder")
        whodrug_folder = config_settings.get("s3", "whodrug_folder") 
        
        
        substeps = [start_dms_task(self, icsr_task_1),
                    start_dms_task(self, icsr_task_2),
                    CheckPostgresRowCounts(self, self._cursor, self._oasis_orig_schema, icsr_folder), 
                    start_dms_task(self, meddra_task),
                    CheckPostgresRowCounts(self, self._cursor_meddra, self._oasis_meddra_schema, meddra_folder),
                    start_dms_task(self, whodrug_task),
                    CheckPostgresRowCounts(self, self._cursor_whodrug, self._whodrug_schema, whodrug_folder)
                   ]
    
        self.execute_substeps(substeps)


class start_dms_task(BaseStep):
    '''
    Run DMS for one schema
    '''
    
    def __init__(self, parent_step, task_name):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"Run the {task_name} task",
                          f"Copy data for {task_name} to Postgres",
                          parent=parent_step)
        self._task_name = task_name


    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(start_dms_task, self)._do_step(interactive, config_settings,
                                              run_vars, run_status)

    
        client = boto3.client('dms', region_name='us-east-1')
        
        dms = client.describe_replication_tasks(
                Filters=[
                    {
                        'Name': 'replication-task-id',
                        'Values': [
                            self._task_name,
                        ]
                    },
                ]
            )

        dms_dict = dict(dms)
    
        for val in dms_dict['ReplicationTasks']:
            dms_dict[val['ReplicationTaskIdentifier']] = val['ReplicationTaskArn']
        
        # Loop over dictionary items and verify taskid 
        for k, v in dms_dict.items():
            if k == self._task_name:
                self._logger.info(k +' : '+ v)
                self._logger.info(f"\n Task launched: {k}")
                
        # Start the DMS replication task
        
        response = client.start_replication_task(ReplicationTaskArn = v, StartReplicationTaskType='reload-target')  

        self._logger.info(f"\n DMS Response: {response}")
        
        self._logger.info(" --- Replication Task starting --- ")
        self._logger.info("sleep time 20s")
        sleep(20)
        
        
        # Poll to wait until task status is Running
        self._logger.info(" --- Replication Task running --- ")
        
        WAIT_TIME = 60 # seconds to wait between each poll
        MAX_RETRY = 20000 # the max number of seconds to poll before timing out
        
        retry = 0    
        while True:
            retry += WAIT_TIME
            sleep(WAIT_TIME)
        
            dms_resp = client.describe_replication_tasks(
                Filters=[
                    {
                        'Name': 'replication-task-id',
                        'Values': [self._task_name,
                        ]
                    },
                ],
                MaxRecords=100,
                Marker='string',
                WithoutSettings=True|False
            )
        
            state = dms_resp['ReplicationTasks'][0]['Status']
            self._logger.info(f" --- Replication Task {state} --- ")
            if state == 'stopped':
                self._logger.info(f"--- Replication Task {state} ---")
                break
            elif state in ('failed',) or retry > MAX_RETRY:
                raise Exception("Replication task failed or timed out")
                self._logger.info("Replication task failed or timed out")
                
                
class CheckPostgresRowCounts(BaseStep):
    '''
    Check actual versus expected row counts to determine if the data was
    fully loaded.
    '''
    
    def __init__(self, parent_step, cursor, target_schema, folder):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          f"check_postgres_row_counts for {target_schema}",
                          f"Check Postgres row counts for {target_schema}",
                          parent=parent_step)
        self._postgres_cursor = cursor
        self._target_schema = target_schema
        self._folder = folder
       

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CheckPostgresRowCounts, self)._do_step(interactive, config_settings,
                                                   run_vars, run_status)
        
        download_dir = config_settings.get("s3", "download_dir") 
    
        '''
        List expected rowcount from descriptor file
        '''
        
        descriptor_fileDict = {}
        self._logger.info('==== Expected Row Count from Descriptor File ====')
        
        
        
        with open (os.path.join(download_dir, self._folder + '_descriptor.txt'), 'r', encoding='utf-8') as f:
            for line in f:
                line = str(line).rstrip()
                if "ROWCOUNT" in line:
                    line = line.replace("_ROWCOUNT",'')
                    line = line.replace('"','') 
                    key, value = line.lower().strip().split('=')
                    descriptor_fileDict[key] = int(value)
                    self._logger.info(line)

            
            self._logger.info('==== Actual Row Count from Import ====')
            sql_statement = (f"""
                            select table_name, 
            (xpath('/row/cnt/text()', xml_count))[1]::text::int as row_count
                from (
            select table_name, table_schema, 
            query_to_xml(format('select count(*) as cnt from %I.%I', table_schema, table_name), false, true, '') as xml_count
            from information_schema.tables
            where table_schema = '{self._target_schema}' and table_name not like '%_j') t;
            """)
            
            self._logger.info(sql_statement)
            self._postgres_cursor.execute(sql_statement)
            result = self._postgres_cursor.fetchall()
            self._logger.info(result)
            
            pg_Dict = {k:v for k, v in result}
            
        def compare_dict(dict1, dict2):
            for k in dict1.keys():
                z = dict1.get(k) == dict2.get(k)
                if not z:
                    self._logger.info('key', k)
                    self._logger.info('value A', dict1.get(k), '\nvalue B', dict2.get(k))
                    self._logger.info('-----\n')
            else:
                self._logger.info('==== No mistmatch between actual vs expected rowcount ====')
                
        compare_dict(pg_Dict, descriptor_fileDict)