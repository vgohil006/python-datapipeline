# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

import hashlib
import os
from contextlib import suppress

class FileUtils(object):
    '''
    Utility methods for working with files and directories
    '''
    @staticmethod
    def ensure_dir_exists(dirname):
        '''
        create the directory if it doesn't already exist
        '''
        try:
            os.stat(dirname)
        except:
            os.makedirs(dirname)        


    @staticmethod
    def ensure_file_exists(filename):
        '''
        create the file if it doesn't already exist
        '''
        try:
            os.stat(filename)
        except:
            f = open(filename, 'a')
            f.close()

    @staticmethod
    def compute_md5_hash(filename):
        digest = hashlib.md5(open(filename, 'rb').read()).hexdigest()
        return digest

    @staticmethod
    def silent_remove(filename):
        with suppress(FileNotFoundError):
            os.remove(filename)
