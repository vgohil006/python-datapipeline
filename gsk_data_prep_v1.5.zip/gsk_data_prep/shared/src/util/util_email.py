# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

import os.path
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class SmtpSettings(object):
    '''
    Encapsulate SMTP connection settings
    '''
    def __init__(self, server, port=25, encrypt_type="None",
                 requires_auth=False, auth_user=None, auth_pass=None):
        self.server = server
        self.port = port
        if encrypt_type == None:
            encrypt_type = "NONE"
        else:
            self.encrypt_type = encrypt_type.upper()
        self.requires_auth = requires_auth
        self.auth_user = auth_user
        self.auth_pass= auth_pass
        
        self._check_valid_encrypt_type(encrypt_type)

    def is_ssl(self):
        return self.encrypt_type == "SSL"
    
    def is_tls(self):
        return self.encrypt_type == "TLS"
    
    def _check_valid_encrypt_type(self, encrypt_type):
        valid_values = [ "NONE", "SSL", "TLS" ]
        encrypt_type_upper = encrypt_type.upper()
        
        valid = False
        for v in valid_values:
            if encrypt_type_upper == v:
                valid = True
                break
            
        if not valid:
            raise Exception("Unexpected SMTP encrypt_type: '%s'" % encrypt_type)

class EmailUtils(object):
    '''
    Email handling utilities
    '''
    @staticmethod
    def create_message_with_zips(msg_from, recipients, subject, body_text, zips):
        msg = MIMEMultipart()
        msg["From"] = msg_from
        msg["To"] = ", ".join(recipients)
        msg["Subject"] = subject

        if body_text or zips:
            msg.preamble = "I am not using a MIME-aware mail reader.\n"
        
        if body_text:
            part = MIMEText(body_text, 'plain')
            msg.attach(part)
        
        for zip_path in zips:
            f = open(zip_path, "rb")
            part = MIMEBase("application", "zip")
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", "attachment",
                            filename=os.path.basename(zip_path))
            msg.attach(part)
            f.close()
            
        return msg.as_string()
    
    @staticmethod
    def send_email(msg_from, recipients, message, smtp_settings):
        smtp = smtp_settings        
        try:
            if smtp.is_ssl():
                server = smtplib.SMTP_SSL(smtp.server, smtp.port)
            else:
                server = smtplib.SMTP(smtp.server, smtp.port)
            
            server.ehlo_or_helo_if_needed()
            
            if smtp.is_tls():
                server.starttls()
            
            if smtp.requires_auth:
                server.login(smtp.auth_user, smtp.auth_pass)
            
            server.sendmail(msg_from, recipients, message)
            server.quit()
            return True
        except:
            return False

if __name__ == '__main__':
    smtp_settings = SmtpSettings(server="smtp.gmail.com", port=465, encrypt_type="SSL",
                                 requires_auth=True, auth_user="xxx",
                                 auth_pass="xxx")
#     smtp_settings = SmtpSettings(server="smtp.gmail.com", port=587, encrypt_type="TLS",
#                                  requires_auth=True, auth_user="xxx",
#                                  auth_pass="xxx")
    body_text = "Body text line 1\r\nBody text line 2\r\n"
    msg_from = "xxx"
    recipients = [ "xxx", ]
    subject = "Test message with three zips"
    zips = [ "E:/temp/test_file_1.zip",
             "E:/temp/test_file_1_and_2.zip",
             "E:/temp/test_zip_folder.zip",
            ]
    msg = EmailUtils.create_message_with_zips(msg_from, recipients, subject, body_text, zips)
    status = EmailUtils.send_email(msg_from, recipients, msg, smtp_settings)
    if status:
        print("Successfully sent email")
    else:
        print("Failed to send email")
    
