# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

from util import ConfigParserExt
from configparser import ConfigParser
from datetime import datetime
from argparse import ArgumentParser
from util import FileUtils
from util import LoggingUtils
import errno
import logging
import os
import platform
import psutil
import re

class MainHelper(object):
    '''
    Application Utils
    '''
    def __init__(self, app_version, log_file_option, log_level_option,
                 run_status_file_option, run_vars_file_prefix, encrypt_key):
        '''
        Constructor
        
        Arguments:
          app_version - application version
          log_file_option - config file option for log file
          log_level_option - config file option for logging level
          run_status_file_option - config file option for run status file
          run_vars_file_prefix - prefix to use for the run var files that
            are used to pass state information between steps
          encrypt_key - key used for encrypting/decrypting secrets in config
            files
        '''
        self.app_version = app_version

        # Process the command line arguments
        options = self._parse_cmd_args()
            
        # Parse the configuration settings
        settings = self._load_settings(options.config_file,
                                       options.secrets_file,
                                       encrypt_key)
        
        # Parse the run status file
        run_status = RunStatus(settings.get("data_prep", run_status_file_option))
        
        # Make sure that the output directories and files exist
        self._ensure_output_files_exist(settings)
        
        # Check to make sure there isn't a previous job that is still running
        if run_status.has_inprogress_setting("pid"):
            inprogress_pid = int(run_status.get_inprogress_setting("pid"))
            if self._pid_exists(inprogress_pid):
                # Fail if the previous instance of this job is still running
                msg = "The previous instance of this job (pid={:d}) is still running"
                msg = msg.format(inprogress_pid)
                raise AppError(msg)
                
        # Record the process id for this execution
        pid = os.getpid()
        run_status.set_inprogress_setting("pid", str(pid))
        
        # Enable logging
        # keep the existing log file in resume mode
        remove_if_exists = not self._is_resume_mode(options, run_status)
        LoggingUtils.init_logging(settings.get("logging", log_file_option),
                                  settings.get("logging", "log_format", raw=True),
                                  settings.get("logging", log_level_option),
                                  removeIfExists=remove_if_exists)
        logger = logging.getLogger("main")
        logger.info("Started logging")
        logger.info("version is %s" % self.app_version)
        
        run_vars = RunVars(settings.get("data_prep", "info_dir"),
                           run_vars_file_prefix)
        
        self._cmd_options = options
        self._settings = settings
        self._run_vars = run_vars
        self._run_status = run_status
        self._logger = logger

    def execute_steps(self, steps):
        '''
        Execute the application steps.
        
        Arguments:
          steps - list of application steps
        '''
        # Determine whether to run in "resume" mode
        resume = self._is_resume_mode(self._cmd_options, self._run_status)

        # Set the inprogress/start_time
        # If this is still set when the application next runs, we know that
        # the previous run did not complete successfully
        now = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
        self._run_status.set_inprogress_setting("start_time", now)

        batch = self._cmd_options.batch
        interactive = self._cmd_options.interactive and not batch
        self._logger.info("resume mode is %s" % resume)
        self._logger.info("batch is %s" % batch)
        self._logger.info("interactive is %s" % interactive)

        # Loop through the processing steps
        self._app_error = False
        step_number = 1
        for step in steps:
            resume = step.execute(resume, step_number, interactive,
                                  self._settings, self._run_vars,
                                  self._run_status)
            step_number += 1

    def extend_cmd_args_parser(self, parser):
        '''
        Extend the parsing of the command line arguments.
        
        This is intended to allow a subclass to change the default
        behavior for handling command line arguments
        '''
        return parser

    def _parse_cmd_args(self):
        '''
        parse the command line arguments
        '''
        parser = ArgumentParser()
        parser.add_argument("-v", "--version",
                            action='version',
                            version='%(prog)s {version}'.format(version=self.app_version))
        parser.add_argument("-c", "--config-file",
                            help="configuration file",
                            action="store", dest="config_file")
        parser.add_argument("-s", "--secrets-file",
                            help="secrets file",
                            action="store", dest="secrets_file")
        parser.add_argument("-b", "--batch",
                            default=False,
                            help="execute without prompting for input",
                            action="store_true", dest="batch")
        parser.add_argument("-i", "--interactive",
                            default=False,
                            help="prompt user during execution",
                            action="store_true", dest="interactive")
        
        # Give subclasses an opportunity to override the default
        # behavior for handling command line arguments
        parser = self.extend_cmd_args_parser(parser)

        # Check for the presence of required arguments
        options = parser.parse_args()
        if not options.config_file:
            parser.error("no config_file")
        if not options.secrets_file:
            parser.error("no secrets_file")
            
        return options
    
    def _load_settings(self, config_filename, secrets_filename, encrypt_key):
        '''
        parse the settings file
        '''
        settings = ConfigParserExt(encrypt_key)
        settings.read([config_filename, secrets_filename])
        return settings
    
    def _ensure_output_files_exist(self, config):
        '''
        if they don't already exist, create the output directories
        and files expected by the application
        '''
        for section, dirname in [("DEFAULT", "base_dir"),
                                 ("data_prep", "archive_dir"),
                                 ("data_prep", "info_dir"),
                                  ("logging", "log_dir"),
                                 ]:
            d = config.get(section, dirname)
            FileUtils.ensure_dir_exists(d)
            
        for section, filename in [("data_prep", "status_file"),
                                  ("logging", "log_file"),
                                  ]:
            f = config.get(section, filename)
            FileUtils.ensure_file_exists(f)
            
    def _is_resume_mode(self, options, run_status):
        '''
        if the previous run failed to complete and the --batch (-b)
        command switch was not specified, the run in "resume" mode
        which allows the user to skip (previously completed) processing
        steps.  Once the user chooses to execute a step, the system will
        leave resume mode and execute all remaining steps.
        '''
        resume_mode = run_status.get_inprogress_setting("start_time") and not options.batch
        if resume_mode is None:
            resume_mode = False
        return resume_mode

    def _pid_exists(self, pid):
        '''
        Return True if the indicated pid exists, otherwise False 
        '''
        system = platform.system()
        try:
            if system == "Linux":
                os.kill(pid, 0)
                return True
            elif system == "Windows":
                return psutil.pid_exists(pid)
            else:
                raise AppError(f"Unexpected system type: {system}")
        except OSError as err:
            if err.errno == errno.ESRCH:
                # ESRCH == No such process
                return False
            elif err.errno == errno.EPERM:
                # EPERM means there's a process to deny access to
                return True
            else:
                # Not expecting to get here
                raise


class AppError(Exception):
    '''
    Exception used to raise application errors
    '''
    def __init__(self, message):
        self.message = message


class RunStatus(object):
    '''
    Keep track of status items for the "inprogress", "last" (last completed)
    and "prev (next to last completed) runs
    '''

    def __init__(self, filename):
        '''
        Constructor
        '''
        self.filename = filename
        self.status = ConfigParser()
        self.status.read(filename)
        
    def has_inprogress_setting(self, name):
        return self._has_setting("inprogress", name)
        
    def get_inprogress_setting(self, name):
        return self._get_status("inprogress", name)
    
    def set_inprogress_setting(self, name, value):
        self._set_status("inprogress", name, value)
        
    def remove_inprogress_setting(self, name):
        self._remove_status("inprogress", name)
        
    def has_last_setting(self, name):
        return self._has_setting("last", name)
        
    def get_last_setting(self, name):
        return self._get_status("last", name)
    
    def set_last_setting(self, name, value):
        self._set_status("last", name, value)
        
    def remove_last_setting(self, name):
        self._remove_status("last", name)
        
    def has_prev_setting(self, name):
        return self._has_setting("prev", name)
        
    def get_prev_setting(self, name):
        return self._get_status("prev", name)
    
    def set_prev_setting(self, name, value):
        self._set_status("prev", name, value)
        
    def remove_prev_setting(self, name):
        self._remove_status("prev", name)
        
    def rotate(self):
        '''
        rotate statuses by:
          removing "prev" settings
          moving "last" settings to "prev"
          moving "inprogress" settings to "last"
        '''
        # remove "prev" settings
        if self.status.has_section("prev"):
            for (name, value) in self.status.items("prev"):
                self.status.remove_option("prev", name)
        else:
            self.status.add_section("prev")

        # move "last" settings to "prev"
        if self.status.has_section("last"):
            for (name, value) in self.status.items("last"):
                self.status.remove_option("last", name)
                self.status.set("prev", name, value)
        else:
            self.status.add_section("last")

        # move "inprogress" settings to "last" and then
        if self.status.has_section("inprogress"):
            for (name, value) in self.status.items("inprogress"):
                self.status.remove_option("inprogress", name)
                self.status.set("last", name, value)
        else:
            self.status.add_section("inprogress")

        self._write()

    def _has_setting(self, section, name):
        '''
        check if setting exists
        '''
        exists = False
        if self.status.has_section(section):
            exists = self.status.has_option(section, name)
        return exists
        
    def _get_status(self, section, name):
        '''
        get status value
        '''
        try:
            return self.status.get(section, name)
        except:
            return None

    def _set_status(self, section, name, value):
        '''
        set status value
        '''
        if not self.status.has_section(section):
            self.status.add_section(section)
            
        if value is None:
            value = ""
            
        self.status.set(section, name, value)
        self._write()

    def _remove_status(self, section, name):
        '''
        remove status
        '''
        if self.status.has_option(section, name):
            self.status.remove_option(section, name)
            self._write()
     
    def _write(self):
        '''
        write changes back to the underlying file
        '''
        fp = open(self.filename, "w")
        self.status.write(fp)
        fp.close()

class RunVars(object):
    '''
    Keep track of variables that are used in the application run.
    In order to support run restartability, the run variables for each
    step are stored in a separate file.
    '''
    SECTION_NAME = "RUNVARS"
    
    def __init__(self, base_dir, file_prefix="RUNVARS_"):
        '''
        Arguments:
          base_dir - The directory in which run variable information
            is stored.  There is one stored run variable file per step.
          file_prefix - The file name prefix for run variable files
        '''
        self.basedir = base_dir
        self.file_prefix = file_prefix
        self.prior_vars = ConfigParser()
        self.cur_vars = ConfigParser()
        self.prior_vars.add_section(RunVars.SECTION_NAME)
        self.cur_vars.add_section(RunVars.SECTION_NAME)
        
    def clear(self):
        '''
        Delete all files in base_dir that start with file_prefix
        '''
        for name in os.listdir(self.base_dir):
            if name.startswith(self.file_prefix):
                os.remove(self.base_dir + os.sep + name)
    
    def load(self, step_name):
        '''
        Load the run variables for a step from a file.
        
        Raise an AppError exception if step_name contains characters other
        than letters, numbers and underscores.
        
        Arguments:
          step_name: An identifier consisting of letters, numbers and
            underscores
        '''
        self._test_step_name(step_name)
        fname = self.basedir + os.sep + self.file_prefix + step_name
        
        # load the run variables into prior_vars so that if we choose to not
        # execute this step, we have the variable values from when this step
        # was previously executed
        self.prior_vars.read(fname)
        
        # Load the run variables into cur_vars so that partial re-execution
        # of the step will retain those run variable settings for portions
        # of the step that did not get re-executed.
        self.cur_vars = ConfigParser()
        self.cur_vars.add_section(RunVars.SECTION_NAME)
        self.cur_vars.read(fname)
        
    def store(self, step_name):
        '''
        Store the run variables from the current step to a file.
        
        Raise an AppError exception if step_name contains characters other
        than letters, numbers and underscores.
        
        Arguments:
          step_name: An identifier consisting of letters, numbers and
            underscores
        '''
        self._test_step_name(step_name)
        fname = self.basedir + os.sep + self.file_prefix + step_name
        fp = open(fname, "w+")
        
        # write out the run variables from this step
        self.cur_vars.write(fp)
        fp.close()
        
        # add the run variables from this step to the prior_vars
        self.load(step_name)
        
        # clear the current run variables
        self.cur_vars = ConfigParser()
        self.cur_vars.add_section(RunVars.SECTION_NAME)
        
    def set(self, name, value):
        '''
        Add the name/value pair to the run variables for the current step
        '''
        self.cur_vars.set(RunVars.SECTION_NAME, name, value)
        
    def get(self, name):
        '''
        Return the value for the specified run variable.
        
        Raise an AppError if the variable is not defined.
        '''
        if self.cur_vars.has_option(RunVars.SECTION_NAME, name):
            return self.cur_vars.get(RunVars.SECTION_NAME, name, raw=True)
        elif self.prior_vars.has_option(RunVars.SECTION_NAME, name):
            return self.prior_vars.get(RunVars.SECTION_NAME, name, raw=True)
        else:
            raise AppError("Run variable not found: %s" % name)
        
    def exists(self, name):
        '''
        Test whether the specified run variable is defined.
        '''
        if self.cur_vars.has_option(RunVars.SECTION_NAME, name):
            return True
        elif self.prior_vars.has_option(RunVars.SECTION_NAME, name):
            return True
        else:
            return False

    def _test_step_name(self, step_name):
        '''
        Test whether step_name consists only of letters, numbers and
        underscores
        '''
        match = re.match(r'[_A-Za-z0-9]+', step_name)
        if not match or match.group() != step_name:
            raise AppError("Bad step name: %s" % step_name)
