# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

import psycopg2.errorcodes
import csv
import logging
import os
import re
import subprocess

from datetime import datetime
from util import StringUtils, Wrapper
from _ast import stmt

class DbUtils(object):
    '''
    Database utilities
    '''
    @staticmethod
    def execute_query(cursor, stmt, bind_vars={}):
        cursor.execute(stmt, bind_vars)
        return DbUtils.generate_dicts(cursor)
    
    @staticmethod
    def create_database(cursor, database, owner, tablespace=None):
        stmt = (f"CREATE DATABASE {database}\n"
                f"  WITH OWNER = {owner}")
        if tablespace:
            stmt += f"\n  TABLESPACE = {tablespace}"
            
        # Save the current autocommit setting and then set autocommit to True
        # This is done to avoid errors related to attempting to create a database
        # from within a transaction
        saved_autocommit = DbUtils.set_autocommit(cursor, True)
        try:
            # Create the database
            cursor.execute(stmt)
        finally:
            # Restore the saved autocommit status
            DbUtils.set_autocommit(cursor, saved_autocommit)
    
    @staticmethod
    def create_user(cursor, user, password):
        stmt = (f"CREATE USER {user}\n"
                f"  PASSWORD '{password}'")
        
        # Create the user
        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
    
    @staticmethod
    def create_tablespace(cursor, name, owner, location, options=None):
        stmt = (f"CREATE TABLESPACE {name}\n"
                f"  OWNER {owner}\n"
                f"  LOCATION '{location}'")
        if options:
            stmt += f"\n  WITH ({options})"

        # Save the current autocommit setting and then set autocommit to True
        # This is done to avoid errors related to attempting to create a tablespace
        # from within a transaction
        saved_autocommit = DbUtils.set_autocommit(cursor, True)
        try:
            # Create the database
            cursor.execute(stmt)
        finally:
            # Restore the saved autocommit status
            DbUtils.set_autocommit(cursor, saved_autocommit)
    
    @staticmethod
    def create_schema(cursor, schema, owner=None):
        '''
        Create a schema
        '''
        stmt = f"CREATE SCHEMA {schema}"
        if owner:
            stmt += f"\n  AUTHORIZATION {owner}"

        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
           
    @staticmethod
    def create_table(cursor, schema, name, cols="", constraints="", select_stmt="",
                     nologging=False, storage_options="", tablespace=""):
        '''
        Create a table
        '''
        schema = schema + "." if schema else ""
        unlogged_str = "UNLOGGED " if nologging else ""        

        stmt = f"CREATE {unlogged_str} TABLE {schema}{name}\n"
        if constraints and cols:
            stmt += (f"   ({cols},\n"
                     f"    {constraints})")
        elif cols:
            stmt += f"   ({cols})"
        
        if storage_options:
            stmt += f"\n   WITH ({storage_options})"
            
        if tablespace:
            stmt += f"\n   TABLESPACE {tablespace}"
            
        if select_stmt:
            stmt += f"\nAS\n{select_stmt}"
            
        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
           
    @staticmethod
    def create_view(cursor, schema, name, body, replace=True):
        schema = schema + "." if schema else ""
        replace_str = "OR REPLACE " if replace else ""

        stmt = (f"CREATE {replace_str}VIEW {schema}{name} AS\n"
                f"{body}")
        
        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
    
    @staticmethod
    def create_sequence(cursor, schema, name, start=1):
        '''
        Create an ascending sequence that increments by 1
        '''
        schema = schema + "." if schema else ""
        stmt = f"CREATE SEQUENCE {schema}{name} START {start}"

        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
    
    @staticmethod
    def create_index(cursor, schema, table, index, cols, unique=False,
                     method="", tablespace="", predicate="", storage_options=""):
        schema = schema + "." if schema else ""        
        unique_str = " UNIQUE" if unique else ""
        using_str = f" USING {method}" if method else ""

        stmt = (f"CREATE{unique_str} INDEX {index}\n"
                f"   ON {schema}{table}{using_str}\n"
                f"   ({cols})")
        
        if storage_options:
            stmt += f"\n   WITH ({storage_options})"
            
        if tablespace:
            stmt += f"\n   TABLESPACE {tablespace}"
            
        if predicate:
            stmt += f"\n   WHERE {predicate}"

        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
    
    @staticmethod
    def get_table_or_view_columns(cursor, schema, name):
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']
            
        stmt = ("SELECT column_name\n"
                "  FROM information_schema.columns\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND UPPER(table_name) = UPPER(%(name)s)\n"
                "ORDER BY ordinal_position")
        cursor.execute(stmt, {'schema': schema, 'name': name})
        
        col_list = [row[0] for row in cursor.fetchall()]
        return col_list

    @staticmethod
    def database_exists(cursor, database):
        stmt = ("SELECT 1\n"
                "  FROM pg_database\n"
                " WHERE UPPER(datname) = UPPER(%s)")
        cursor.execute(stmt, (database,))
        return cursor.rowcount == 1

    @staticmethod
    def user_exists(cursor, name):
        stmt = ("SELECT COUNT(rolname) cnt\n"
                "  FROM pg_roles\n"
                " WHERE rolcanlogin AND UPPER(rolname) = UPPER(%s)")
        cursor.execute(stmt, (name,))
        count = cursor.fetchone()[0]
        return count == 1

    @staticmethod
    def tablespace_exists(cursor, name):
        stmt = ("SELECT COUNT(spcname) cnt\n"
                "  FROM pg_tablespace\n"
                " WHERE UPPER(spcname) = UPPER(%s)")
        cursor.execute(stmt, (name,))
        count = cursor.fetchone()[0]
        return count == 1

    @staticmethod
    def schema_exists(cursor, name):
        stmt = ("SELECT COUNT(schema_name) cnt\n"
                "  FROM information_schema.schemata\n"
                " WHERE UPPER(schema_name) = UPPER(%(name)s)")
        cursor.execute(stmt, {'name': name})
        count = cursor.fetchone()[0]
        return count == 1

    @staticmethod
    def table_exists(cursor, schema, name):
        
        # if no schema is specified, default to the name of the connection user
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']            

        stmt = ("SELECT COUNT(1) cnt\n"
                "  FROM information_schema.tables\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND UPPER(table_name) = UPPER(%(name)s)\n"
                "   AND table_type = 'BASE TABLE'")        
        cursor.execute(stmt, {'schema': schema, 'name': name})
        count = cursor.fetchone()[0]
        return count == 1
   
    @staticmethod
    def view_exists(cursor, schema, name):
        # if no schema is specified, default to the name of the connection user
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']            

        stmt = ("SELECT COUNT(1) cnt\n"
                "  FROM information_schema.tables\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND UPPER(table_name) = UPPER(%(name)s)\n"
                "   AND table_type = 'VIEW'")        
        cursor.execute(stmt, {'schema': schema, 'name': name})
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def index_exists(cursor, schema, name):
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']            

        stmt = ("SELECT COUNT(1) cnt\n"
                "  FROM pg_catalog.pg_indexes\n"
                " WHERE UPPER(schemaname) = UPPER(%(schema)s)\n"
                "   AND UPPER(indexname) = UPPER(%(name)s)")        
        cursor.execute(stmt, {'schema': schema, 'name': name})
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def sequence_exists(cursor, schema, name):        
        # if no schema is specified, default to the name of the connection user
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']

        stmt = ("SELECT COUNT(1) cnt\n"
                "  FROM information_schema.sequences\n"
                " WHERE UPPER(sequence_schema) = UPPER(%(schema)s)\n"
                "   AND UPPER(sequence_name) = UPPER(%(name)s)")
        cursor.execute(stmt, {'schema': schema, 'name': name})
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def get_current_user(cursor):
        cursor.execute("SELECT current_user")
        current_user = cursor.fetch_one()[0]
        return current_user

    @staticmethod
    def get_all_tables(cursor, schema):
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']
        stmt = ("SELECT table_name\n"
                "  FROM information_schema.tables\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND table_type = 'BASE TABLE'\n"
                "ORDER BY table_name")
        cursor.execute(stmt, {'schema': schema})
        names = [row[0] for row in cursor.fetchall()]

        return names

    @staticmethod
    def get_all_views(cursor, schema):
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']
        stmt = ("SELECT table_name\n"
                "  FROM information_schema.tables\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND table_type = 'VIEW'\n"
                "ORDER BY table_name")
        cursor.execute(stmt, {'schema': schema})
        names = [row[0] for row in cursor.fetchall()]
        
        return names

    @staticmethod
    def get_all_tables_and_views(cursor, schema):
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']
        stmt = ("SELECT table_name\n"
                "  FROM information_schema.tables\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND table_type IN ('BASE TABLE', 'VIEW')\n"
                "ORDER BY table_name")
        cursor.execute(stmt, {'schema': schema})
        names = [row[0] for row in cursor.fetchall()]

        return names

    @staticmethod
    def drop_all_tables(cursor, schema, cascade=True):
        names = DbUtils.get_all_tables(cursor, schema)
        for name in names:
            DbUtils.drop_table(cursor, schema, name, cascade)

    @staticmethod
    def drop_all_views(cursor, schema, cascade=True):
        names = DbUtils.get_all_views(cursor, schema)
        for name in names:
            DbUtils.drop_view(cursor, schema, name, cascade)

    @staticmethod
    def drop_database(cursor, database):
        stmt = f"DROP DATABASE {database}"
                
        # Save the current autocommit setting and then set autocommit to True
        # This is done to avoid errors related to attempting to drop a database
        # from within a transaction
        saved_autocommit = DbUtils.set_autocommit(cursor, True)
        try:
            cursor.execute(stmt)
        except psycopg2.DatabaseError as e:
            # catch and ignore database does not exist errors
            if e.pgcode == psycopg2.errorcodes.INVALID_CATALOG_NAME:
                pass
            else:
                raise
        finally:
            # Restore the saved autocommit status
            DbUtils.set_autocommit(cursor, saved_autocommit)

    @staticmethod
    def drop_user(cursor, user, cascade=False):
        if cascade:
            stmt = f"DROP OWNED BY {user}"
            try:
                cursor.execute(stmt)
            except Exception as e:
                # catch and ignore user does not exist errors
                if e.pgcode == psycopg2.errorcodes.UNDEFINED_OBJECT:
                    pass
                else:
                    raise
            finally:
                DbUtils.commit(cursor)
            
        stmt = f"DROP USER {user}"
        try:
            cursor.execute(stmt)
        except Exception as e:
            # catch and ignore user does not exist errors
            if e.pgcode == psycopg2.errorcodes.UNDEFINED_OBJECT:
                pass
            else:
                raise
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def drop_tablespace(cursor, name):
        stmt = f"DROP TABLESPACE {name}"

        # Save the current autocommit setting and then set autocommit to True
        # This is done to avoid errors related to attempting to drop a database
        # from within a transaction
        saved_autocommit = DbUtils.set_autocommit(cursor, True)                
        try:
            cursor.execute(stmt)
        except psycopg2.DatabaseError as e:
            # catch and ignore tablespace does not exist errors
            if e.pgcode == psycopg2.errorcodes.UNDEFINED_OBJECT:
                pass
            else:
                raise
        finally:
            # Restore the saved autocommit status
            DbUtils.set_autocommit(cursor, saved_autocommit)

    @staticmethod
    def drop_schema(cursor, name, cascade=False):
        cascade_str = " CASCADE" if cascade else ""

        stmt = f"DROP SCHEMA {name}{cascade_str}"
        try:
            cursor.execute(stmt)
        except psycopg2.DatabaseError as e:
            # catch and ignore schema does not exist errors
            if e.pgcode == psycopg2.errorcodes.INVALID_SCHEMA_NAME:
                pass
            else:
                raise
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def drop_table(cursor, schema, name, cascade=True):
        schema = schema + "." if schema else ""
        cascade_str = " CASCADE" if cascade else ""
        
        stmt = f"DROP TABLE {schema}{name}{cascade_str}"
        try:
            cursor.execute(stmt)
        except psycopg2.DatabaseError as e:
            # catch and ignore table does not exist errors
            if e.pgcode == psycopg2.errorcodes.UNDEFINED_TABLE:
                pass
            else:
                raise
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def drop_tables_like(cursor, schema, pattern, cascade=True):
        '''
        Drop tables matching the specified pattern, where the pattern may
        include the following wildcard characters:
            % matches any string of any length (including zero length)
            _ match a single character
        '''
        # if no schema is specified, default to the name of the connection user
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']            
        stmt = ("SELECT table_name\n"
                "  FROM information_schema.tables\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND UPPER(table_name) LIKE UPPER(%(pattern)s)\n"
                "   AND table_type = 'BASE TABLE'\n"
                "ORDER BY table_name")
        cursor.execute(stmt, {'schema': schema, 'pattern': pattern})
        names = [row[0] for row in cursor.fetchall()]

        for name in names:
            DbUtils.drop_table(cursor, schema, name, cascade)
        
    @staticmethod
    def drop_view(cursor, schema, name, cascade=True):
        schema = schema + "." if schema else ""
        cascade_str = " CASCADE" if cascade else ""
        
        stmt = f"DROP VIEW {schema}{name}{cascade_str}"
        try:
            cursor.execute(stmt)
        except psycopg2.DatabaseError as e:
            # catch and ignore view does not exist errors
            if e.pgcode == psycopg2.errorcodes.UNDEFINED_TABLE:
                pass
            else:
                raise
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def drop_views_like(cursor, schema, pattern, cascade=True):
        '''
        Drop views matching the specified pattern, where the pattern may
        include the following wildcard characters:
            % matches any string of any length (including zero length)
            _ match a single character
        '''
        # if no schema is specified, default to the name of the connection user
        if not schema:
            schema = cursor.connection.get_dsn_parameters()['user']            
        stmt = ("SELECT table_name\n"
                "  FROM information_schema.tables\n"
                " WHERE UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND UPPER(table_name) LIKE UPPER(%(pattern)s)\n"
                "   AND table_type = 'VIEW'\n"
                "ORDER BY table_name")
        cursor.execute(stmt, {'schema': schema, 'pattern': pattern})
        names = [row[0] for row in cursor.fetchall()]

        for name in names:
            DbUtils.drop_view(cursor, schema, name, cascade)
        
    @staticmethod
    def drop_sequence(cursor, schema, name, cascade=True):
        schema = schema + "." if schema else ""
        cascade_str = " CASCADE" if cascade else ""

        stmt = f"DROP SEQUENCE {schema}{name}{cascade_str}"            
        try:
            cursor.execute(stmt)
        except psycopg2.DatabaseError as e:
            # catch and ignore sequence does not exist errors
            if e.pgcode == psycopg2.errorcodes.UNDEFINED_TABLE:
                pass
            else:
                raise
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def drop_index(cursor, schema, name, cascade=True):
        schema = schema + "." if schema else ""
        cascade_str = " CASCADE" if cascade else ""

        stmt = f"DROP INDEX {schema}{name}{cascade_str}"
        try:
            cursor.execute(stmt)
        except psycopg2.DatabaseError as e:
            # catch and ignore index does not exist errors
            if e.pgcode == psycopg2.errorcodes.UNDEFINED_OBJECT:
                pass
            else:
                raise
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def copy_from(cursor, path, table, cols=[], fmt=None, delimiter=None, null=None,
                  header=None, quote=None, escape=None, encoding=None, size=None):
        '''
        Use the copy command to load data from a file into a table
        
        Arguments:
          cursor - database cursor
          path - path for the file to be loaded
          table - table name
          cols - list of the columns to import; if not specified import all columns
          fmt - one of 'text', 'csv' or 'binary'
          delimiter - specifies the character that separates columns within each row
          null - specifies the string that represents a null value
          header - specifies that the file contains a header line with the names of
             each column in the file. This option is allowed only when using CSV format.
          quote - specifies the quoting character to be used when a data value is quoted
          escape - specifies the character that should appear before a data character
             that matches the QUOTE value
          encoding - Specifies that the file is encoded in the <encoding>
          size - size of the buffer used to read from the file
        '''
        options = []
        if fmt:
            options.append(f"FORMAT {fmt}")
        
        if delimiter:
            options.append(f"DELIMITER {delimiter}")
            
        if null:
            options.append(f"NULL {null}")
            
        if header:
            options.append(f"HEADER {header}")
            
        if quote:
            options.append(f"QUOTE {quote}")
            
        if escape:
            options.append(f"ESCAPE {escape}")
            
        if encoding:
            if encoding[:1] not in ['"', "'"]:
                encoding = f"'{encoding}'"
            options.append(f"ENCODING {encoding}")
        
        col_list = "(" + ", ".join(cols) + ")" if cols else ""
        with_options = "WITH (" + ", ".join(options) + ")" if options else ""
        copy_command = f"COPY {table} {col_list} FROM STDIN {with_options}"
        if encoding:
            with open(path, "r", encoding=encoding) as f:
                if size:
                    cursor.copy_expert(copy_command, f, size)
                else:
                    cursor.copy_expert(copy_command, f)
        else:
            with open(path, "r") as f:
                if size:
                    cursor.copy_expert(copy_command, f, size)
                else:
                    cursor.copy_expert(copy_command, f)
            
        DbUtils.commit(cursor)

    @staticmethod
    def compute_table_statistics(cursor, schema, table_list):
        schema = schema + "." if schema else ""

        for name in table_list:
            stmt = f"ANALYZE {schema}{name}"
            cursor.execute(stmt)

    @staticmethod
    def compute_schema_statistics(cursor, schema):
        tables = DbUtils.get_all_tables(cursor, schema)
        DbUtils.compute_table_statistics(cursor, schema, tables)
    
    @staticmethod
    def vacuum_table(cursor, schema, table_list, analyze=True):
        schema = schema + "." if schema else ""
        analyze_str = " ANALYZE" if analyze else ""

        # Save the current autocommit setting and then set autocommit to True
        # This is done to avoid errors related to attempting to vacuum a table
        # from within a transaction
        saved_autocommit = DbUtils.set_autocommit(cursor, True)
        for name in table_list:
            stmt = f"VACUUM{analyze_str} {schema}{name}"
    
            # Vacuum the database
            cursor.execute(stmt)
            
        # Restore the saved autocommit status
        DbUtils.set_autocommit(cursor, saved_autocommit)                
    
    @staticmethod
    def vacuum_schema(cursor, schema, analyze=True):
        tables = DbUtils.get_all_tables(cursor, schema)
        DbUtils.vacuum_table(cursor, schema, tables, analyze)

    @staticmethod
    def vacuum_database(cursor, analyze=True):
        analyze_str = " ANALYZE" if analyze else ""
        stmt = f"VACUUM{analyze_str}"

        # Save the current autocommit setting and then set autocommit to True
        # This is done to avoid errors related to attempting to vacuum a database
        # from within a transaction
        saved_autocommit = DbUtils.set_autocommit(cursor, True)                
        try:
            # Vacuum the database
            cursor.execute(stmt)
        finally:
            # Restore the saved autocommit status
            DbUtils.set_autocommit(cursor, saved_autocommit)
    
    @staticmethod
    def grant_role(cursor, role_list, grantee_list, with_admin_option=False):
        roles_str = ", ".join(role_list)
        grantees_str = ", ".join(grantee_list)

        stmt = (f"GRANT {roles_str}\n"
                f"   TO {grantees_str}")       
        if with_admin_option:
            stmt += "\n   WITH ADMIN OPTION"
            
        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def revoke_role(cursor, role_list, grantee_list, admin_option=False, cascade=True):
        roles_str = ", ".join(role_list)
        grantees_str = ", ".join(grantee_list)
        admin_option_str = "ADMIN OPTION FOR " if admin_option else ""
        cascade_str = " CASCADE" if cascade else ""

        stmt = (f"REVOKE {admin_option_str}\n"
                f"       {roles_str}\n"
                f"  FROM {grantees_str}{cascade_str}")
        
        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
            
    @staticmethod
    def grant_privileges(cursor, priv_list, db_object_list, grantee_list,
                         with_grant_option=False, with_admin_option=False):
        privs_str = ", ".join(priv_list)
        db_objs_str = ", ".join(db_object_list)
        grantees_str = ", ".join(grantee_list)

        stmt = (f"GRANT {privs_str}\n"
                f"   ON {db_objs_str}\n"
                f"   TO {grantees_str}")       
        if with_grant_option:
            stmt += "\n   WITH GRANT OPTION"            
        elif with_admin_option:
            stmt += "\n   WITH ADMIN OPTION"
            
        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)

    @staticmethod
    def revoke_privileges(cursor, priv_list, db_object_list, grantee_list,
                          grant_option=False, admin_option=False, cascade=True):
        privs_str = ", ".join(priv_list)
        db_objs_str = ", ".join(db_object_list)
        grantees_str = ", ".join(grantee_list)
        grant_option_str = "GRANT OPTION FOR " if grant_option else ""
        admin_option_str = "ADMIN OPTION FOR " if admin_option else ""
        cascade_str = " CASCADE" if cascade else ""

        stmt = (f"REVOKE {grant_option_str}{admin_option_str}\n"
                f"       {privs_str}\n"
                f"    ON {db_objs_str}\n"
                f"  FROM {grantees_str}{cascade_str}")
        
        try:
            cursor.execute(stmt)
        finally:
            DbUtils.commit(cursor)
            
    @staticmethod
    def get_table_privileges(cursor, grantee, schema, name):
        stmt = ("SELECT privilege_type\n"
                "  FROM information_schema.role_table_grants\n"
                " WHERE UPPER(grantee) = UPPER(%(grantee)s)\n"
                "   AND UPPER(table_schema) = UPPER(%(schema)s)\n"
                "   AND UPPER(table_name) = UPPER(%(name)s)\n"
                "ORDER BY 1")
        cursor.execute(stmt, {'grantee': grantee, 'schema': schema, 'name': name})
        privs = [row[0] for row in cursor.fetchall()]
        
        return privs

    @staticmethod
    def parse_connect_string(conn_str):
        '''
        Parse the conn_str and return the result as a
        (host, port, database) tuple
        '''
        pattern = r'(?P<host>.+):(?P<port>\d+)/(?P<database>.+)'
        parts = re.match(pattern, conn_str).groupdict()
        return parts['host'], parts['port'], parts['database']

    @staticmethod
    def generate_dicts(cur):
        fieldnames = [d[0].lower() for d in cur.description]
        while True:
            rows = cur.fetchmany()
            if not rows: return
            for row in rows:
                yield dict(zip(fieldnames, row))
                
    @staticmethod
    def set_autocommit(cursor, autocommit):
        conn = cursor.connection
        conn.commit()   # make sure we aren't in a transaction before change autocommit
        saved_autocommit = conn.autocommit
        conn.autocommit = autocommit
        return saved_autocommit

    @staticmethod
    def commit(cursor):
        cursor.connection.commit()


class CursorWrapper(Wrapper):
    __wraps__ = psycopg2.extensions.cursor
    
    DEBUG_LOG_LEVEL = 10

    def __init__(self, obj):
        Wrapper.__init__(self, obj)
        self._logger = logging.getLogger('sql')
    
    def execute(self, *args, **kw_args):
        if self._logger.getEffectiveLevel() >= self.DEBUG_LOG_LEVEL:
            conn = self.connection
            user = conn.get_dsn_parameters()['user']
            sql = args[0]
            msg1 = f'user={user}'
            msg2 = '\n' + StringUtils.reindent(f'sql={sql}', 10)
            msg3 =''
            if len(args) > 1:
                bind_vars = args[1]
                msg3 = '\n' + StringUtils.reindent(f'vars: {bind_vars}', 10)
        self._logger.debug(msg1 + msg2 + msg3)
        self._obj.execute(*args, **kw_args)

   
class DbCursorRegistry(object):
    '''
    Maintain a registry of open database cursors
    '''
    def __init__(self):
        self.registry = {}
        
    def get_cursor(self, user, password, db, search_path=None):
        key = "%s@%s:%s" % (user, db, search_path)
        if not key in self.registry:
            self._create(user, password, db, search_path)
        return self.registry[key]
    
    def close_all(self):
        '''close all of the connections/cursors stored in the registry'''
        for k in list(self.registry.keys()):
            cursor = self.registry[k]
            conn = cursor.connection
            del self.registry[k]
            try:
                cursor.close()
            except Exception:
                # catch and ignore all exceptions resulting from closing a cursor
                pass

            try:
                conn.close()
            except Exception:
                # catch and ignore all exceptions resulting from closing a cursor
                pass
            
    def _create(self, user, password, db, search_path):
        '''
        Create a database connection and cursor
        '''
        # Note the effect of the following keepalive settings is:
        #   send keepalives from the client
        #   send a keepalive after the connection has been idle for 60 seconds
        #   retransmit the keepalive if not acknowledged within 10 seconds
        #   consider the connection to be dead after 8 consecutive unacknowledged keepalives
        #
        # For fast failover (in a high availability configuration, AWS Aurora PostgreSQL
        # recommends the following, more aggressive settings
        #   keepalives_idle=1
        #   keepalives_interval=10
        #   keepalives_count=5
        KEEPALIVES=1
        KEEPALIVES_COUNT=8
        KEEPALIVES_IDLE=60
        KEEPALIVES_INTERVAL=10
    
        key = "%s@%s:%s" % (user, db, search_path)
        
        if search_path:
            conn = psycopg2.connect("postgresql://" + db, user=user, password=password,
                                    keepalives=KEEPALIVES, keepalives_idle=KEEPALIVES_IDLE,
                                    keepalives_interval=KEEPALIVES_INTERVAL,
                                    keepalives_count=KEEPALIVES_COUNT,
                                    options=f"-c search_path={search_path}")
        else:
            conn = psycopg2.connect("postgresql://" + db, user=user, password=password,
                                    keepalives=KEEPALIVES, keepalives_idle=KEEPALIVES_IDLE,
                                    keepalives_interval=KEEPALIVES_INTERVAL,
                                    keepalives_count=KEEPALIVES_COUNT)
            
        cursor = conn.cursor()
        self.registry[key] = CursorWrapper(cursor)

class DbCsvColumnMeta(object):
    '''
    Metadata for database columns to be loaded from a text file
    '''
    
    def __init__(self, column_name, python_type):
        '''
        Arguments:
          col_name - name of the database column
          python_type = Python type (one of "str", "int", "float" or "date(<date_fmt>)"
             where <date_fmt> is the strptime format to use to convert the string to a
             datetime
          
        Raise Exception if:
          col_name is empty string
          python_type is not one of "str", "int", "float" or "date(<date_fmt>)"
        '''
        self.column_name = column_name
        
        if column_name == "":
            raise Exception("No value specified for column_name")
        
        pattern = r'str|int|float|date\((?P<date_fmt>.+)\)'

        # use a case insensitive match
        match = re.match(pattern, python_type, re.I)

        if match:
            python_type = python_type.strip().lower()
            if python_type.startswith("date"):
                python_type = "date"
            self.python_type = python_type
            self.type_format = match.groupdict()['date_fmt']
        else:   
            msg = 'python_type = %s, expected one of "str", "int", "float" or "date(<date_fmt>)"'
            raise Exception(msg % python_type)


class DbCsvLoader(object):
    '''
    Create and populate table from a text file.
    
    The text file may contain up to two rows of metadata where:
      Row 1: database column name
      Row 2: Python type to use for data values (one of "str", "int", "float"
             or "date")
    '''
    
    def __init__(self, path, schema, table, num_header_rows=2, sep="\t",
                 encoding="utf-8"):
        '''
        Arguments:
          path - path for the text file to be loaded
          schema - schema name
          table - table name
          num_header_rows - number of header rows, valid values are 0 or 2
             if num_header_rows == 0, the column metadata must be specified
                using the set_column_meta_list() method before calling either
                insert_data() or upsert(data)
             if num_header_rows == 1, the python_type defaults to "str"
          sep = the character that separates columns within rows
          encoding - the character set encoding to use for interpreting the file
             
        Raises an Exception if:
          num_header_rows is a value other than 0, 1 or 2
          the specified file does not exist
        '''
        self.path = path
        self.schema = schema
        self.table = table
        self.num_header_rows = num_header_rows
        self.sep = sep
        self.encoding = encoding
        self.column_meta_list = []
        
        if num_header_rows < 0 or num_header_rows > 2:
            msg = "num_header_rows = 5d, acceptable values are 0, 1 or 2"
            raise Exception(msg % num_header_rows)
        
        self.fp = open(path, "r", encoding=encoding)
        self.reader = csv.reader(self.fp, delimiter=sep)
        self._read_header_rows()
                    
    def get_column_meta_list(self):
        return self.column_meta_list
    
    def set_column_meta_list(self, column_meta_list):
        self.column_meta_list_list = column_meta_list
    
    def insert_data(self, db_cur, format_vars):
        '''
        Load the data from the text file using INSERT statements
        
        Raise an exception when the target table doesn't exist
        '''
        if not DbUtils.table_exists(db_cur, self.schema, self.table):
            raise Exception("Table not found: %s" % self.table)
        
        # Populate the table
        for row in self.reader:
            stmt, params = self._build_insert_statement(row, format_vars)
            db_cur.execute(stmt, params)
        
        db_cur.connection.commit()
        self.fp.close()
        
    def upsert_data(self, db_cur, format_vars, key_cols):
        '''
        For each row where the key_cols values already exist in the
        table, modify the row using an UPDATE statement.
        
        For each row where the key_col values do not exist in the
        table, load the data using an INSERT statement. 
        
        Raise an exception when the target table doesn't exist
        '''
        if not DbUtils.table_exists(db_cur, self.schema, self.table):
            raise Exception("Table not found: %s" % self.table)
            
        for row in self.reader:
            if self._exists(row, db_cur, format_vars, key_cols):
                stmt, params = self._build_update_statement(row, format_vars, key_cols)
            else:
                stmt, params = self._build_insert_statement(row, format_vars)
            db_cur.execute(stmt, params)
            
        db_cur.connection.commit()
        self.fp.close()
    
    def _read_header_rows(self):
        '''
        Read the column metadata from the header rows of the text file
        '''
        # If we don't expect any header rows, just return
        if self.num_header_rows == 0:
            return
        
        line_num = 0
        header_rows = []
        while line_num < self.num_header_rows:
            row = next(self.reader)
            if not row:
                msg = "File contains %d header rows, expected %d"
                raise Exception(msg % (line_num, self.num_header_rows))
            header_rows.append(row)
            line_num += 1
            
        # Test that each header row contains the same number of values
        expected_n = len(header_rows[0])
        header_row_num = 1
        while header_row_num < self.num_header_rows:
            actual_n = len(header_rows[header_row_num])
            if actual_n != expected_n:
                msg = "Header row $d contains %d values, expected %d"
                raise Exception(msg % (header_row_num, actual_n, expected_n))
            header_row_num += 1
            
        col_index = 0
        for name in header_rows[0]:
            if len(header_rows) > 1:
                python_type = header_rows[1][col_index]
            else:
                python_type = "str"
            
            col_meta = DbCsvColumnMeta(name, python_type)
            self.column_meta_list.append(col_meta)
            col_index += 1
    
    def _exists(self, row, db_cur, format_vars, key_cols):
        '''
        Determine whether a row with the same key_col values as the
        current row already exists in the database table.
        
        Raise an exception when:
          One or more of the key col names aren't found in the text file
          The combination of key column values is not unique in the table
        '''
        named_params = {}
        where_expr_list = []
        for col in key_cols:
            index = 0
            found = False
            for meta in self.column_meta_list:
                if col == meta.column_name:
                    found = True
                    break
                index += 1
            
            if not found:
                raise Exception("Key column not found: %s" % col)
        
            python_type = self.column_meta_list[index].python_type
            type_format = self.column_meta_list[index].type_format
            value_str = row[index]
            if value_str == "":
                # If there is no value for one or more key columns in the
                # text file, then insert the row
                return False
            
            value = self._convert_str(value_str, format_vars, python_type, type_format)
            named_params[col] = value
            where_expr_list.append("%s = :%s" % (col, col))
        
        table = self.table
        where_clause = "WHERE " + " AND ".join(where_expr_list)
        stmt = ("SELECT COUNT(*)"
                f"  FROM {table}"
                f" {where_clause}")
        
        db_cur.execute(stmt, named_params)
        count = db_cur.fetchone()[0]
        
        if count > 1:
            msg = "Values for key columns '%s' in table '%s' are not unique" 
            raise Exception(msg % (", ".join(key_cols), self.table))
        
        return count == 1

    def _build_insert_statement(self, row, format_vars):
        '''
        Create the SQL statement and named parameters needed
        to insert a row in the target table
        '''
        named_params = {}
        cols = []
        values = []
        col_index = 0
        for value in row:
            # Only insert those columns for which data was provided
            if value != "":
                meta = self.column_meta_list[col_index]
                col_name = meta.column_name
                python_type = meta.python_type
                type_format = meta.type_format
                col_value = self._convert_str(value, format_vars, python_type,
                                              type_format)
                named_params[col_name] = col_value
                
                cols.append(col_name)
                values.append(f"%({col_name})s")
            col_index += 1
        
        table = self.table
        insert_cols = ", ".join(cols)
        insert_values = ", ".join(values)
        
        stmt = (f"INSERT INTO {table} "
                f"  ({insert_cols})"
                " VALUES"
                f"  ({insert_values})")
        return stmt, named_params
    
    def _build_update_statement(self, row, format_vars, key_cols):
        '''
        Create the SQL statement and named parameters needed
        to update a row in the target table.
        '''
        named_params = {}
        update_expr_list = []
        where_expr_list = []
        col_index = 0
        for value in row:
            # Only update those columns for which data was provided
            if value != "":
                meta = self.column_meta_list[col_index]
                col_name = meta.column_name
                python_type = meta.python_type
                type_format = meta.type_format
                col_value = self._convert_str(value, format_vars, python_type,
                                              type_format)
                named_params[col_name] = col_value
                
                expr = "%s = :%s" % (col_name, col_name)
                if not self._is_key_column(col_name, key_cols):
                    update_expr_list.append(expr)
                else:
                    where_expr_list.append(expr)
            col_index += 1
        
        table = self.table
        update_set_clause = "SET " + ", ".join(update_expr_list)
        where_clause = "WHERE " + " AND ".join(where_expr_list)
        
        stmt = (f"UPDATE {table}"
                f"   {update_set_clause}"
                f"   {where_clause}")        
        return stmt, named_params
    
    def _is_key_column(self, col, key_cols):
        '''
        Test whether col is one of the key_cols
        '''
        found = False;
        for key_col in key_cols:
            if col == key_col:
                found = True
                break
        return found
    
    def _convert_str(self, str_value, format_vars, python_type, type_format):
        '''
        Substitute the format_vars dictionary values into str_value and then
        convert the result to a value of the appropriate Python type
        '''
        # only call the format() method if format_vars is not empty
        if format_vars:
            formatted_value = str_value.format(**format_vars)
        else:
            formatted_value = str_value
            
        if python_type == "int":
            return int(formatted_value)
        elif python_type == "float":
            return float(formatted_value)
        elif python_type == "date":
            return datetime.strptime(formatted_value, type_format)
        else:
            return formatted_value


class DbCsvWriter(object):
    '''
    Utility to write a csv-format file containing the results of a database
    query
    '''
    @staticmethod
    def export(cursor, csv_path):
        try:
            fp = open(csv_path, "wb")
            w = csv.writer(fp)
            headings = [ desc[0] for desc in cursor.description ]
            w.writerow(headings)
            for row in cursor.fetchall():
                w.writerow(row)
        finally:
            fp.close


class DbPsql(object):
    '''
    Utility to invoke a psql script
    '''
    @staticmethod
    def invoke_db_cmd(psql_path, working_dir, user, password, schema,
                      conn_str, script_file, script_args_list=[]):
        logger = logging.getLogger('DbPsql')

        host, port, database = DbUtils.parse_connect_string(conn_str)
        
        # We don't seem to be able to enter the password via stdin so
        # pass it through the PGPASS environment variable instead
        cmd_env = os.environ.copy()
        cmd_env['PGPASSWORD'] = password
        
        # As part of the -d argument, enable the sending of keepalives from the client:
        #   send a keepalive after the connection has been idle for 60 seconds
        #   retransmit the keepalive if not acknowledged within 10 seconds
        #   consider the connection to be dead after 8 consecutive unacknowledged keepalives
        cmd_args = ["-h", f"{host}",
                    "-p", f"{port}",
                    "-d", f"dbname={database} keepalives=1 keepalives_idle=60 keepalives_interval=10 keepalives_count=8",
                    "-U", f"{user}",
                    "-v", "ON_ERROR_STOP=1",  # exit after first script error
                    "-q",                     # run quietly
                    ]

        if script_args_list:
            cmd_args += script_args_list
        
        result = subprocess.run([psql_path] + cmd_args, env=cmd_env,
                                cwd=working_dir,
                                input=(f"SET search_path={schema};\n"
                                       f"\\i {script_file}\n"),
                                text=True,
                                capture_output=True)
        msg = "returncode=" + str(result.returncode) + f" from execution of '{script_file}'\n"
        msg = msg + "stdout=" + result.stdout + "\n"
        if result.returncode != 0:
            msg = msg + "stderr=" + result.stderr
            logger.error(msg)
        else:
            logger.info(msg)
        result.check_returncode()

        return result
