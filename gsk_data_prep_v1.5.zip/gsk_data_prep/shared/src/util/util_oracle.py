# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

import cx_Oracle
import csv
import logging
import re
import subprocess

from datetime import datetime
from util import StringUtils, Wrapper

class DbUtils(object):
    '''
    Database utilities
    '''
    INDEX_DOES_NOT_EXIST = 1418
    SEQUENCE_DOES_NOT_EXIST = 2289
    TABLE_OR_VIEW_DOES_NOT_EXIST = 942
    TABLESPACE_DOES_NOT_EXIST = 959
    TRIGGER_DOES_NOT_EXIST = 4080
    USER_DOES_NOT_EXIST = 1918
    DOMAIN_INDEXES_SECONDARY_OBJECTS = 29857
    
    @staticmethod
    def execute_query(cursor, stmt, bind_vars={}):
        cursor.execute(stmt, bind_vars)
        return DbUtils.generate_dicts(cursor)
    
    @staticmethod
    def create_user(cursor, user, password, tablespace, quota,
                    temp_tablespace):
        stmt = ("CREATE USER {user}\n"
                '  IDENTIFIED BY "{password}"\n'
                "  PROFILE DEFAULT\n"
                "  DEFAULT TABLESPACE {tablespace}\n"
                "  TEMPORARY TABLESPACE {temp_tablespace}\n"
                "  QUOTA {quota} ON {tablespace}\n"
                "  ACCOUNT UNLOCK")
        cursor.execute(stmt.format(user=user,
                                   password=password,
                                   tablespace=tablespace,
                                   quota=quota,
                                   temp_tablespace=temp_tablespace))
    
    @staticmethod
    def create_tablespace(cursor, tablespace, datafile, initial_size,
                          extend_size, max_size,  nologging=False,
                          compression=False, reuse=False):
        # In AWS RDS, you don't specify a named datafile when creating a tablespace.
        # To support that behavior, datafile may be specified as an empty string.
        
        # Conversely, if datafile is a non-empty string that doesn't start with a
        # quote then wrap the string in single quotes
        if datafile and datafile[0] != "'":
            datafile = "'%s'" % datafile
        
        compression_str = "DEFAULT COMPRESS" if compression else ""
        nologging_str = "NOLOGGING\n" if nologging else ""
        reuse_str = " REUSE" if reuse else ""
        
        stmt = ("CREATE BIGFILE TABLESPACE {tablespace}\n"
                "  DATAFILE {datafile}\n"
                "  SIZE {initial_size}{reuse}\n"
                "  AUTOEXTEND ON NEXT {extend_size}\n"
                "  MAXSIZE {max_size}\n"
                "  {nologging}{compression}")
        cursor.execute(stmt.format(tablespace=tablespace,
                                   datafile=datafile,
                                   initial_size=initial_size,
                                   extend_size=extend_size,
                                   max_size=max_size,
                                   nologging=nologging_str,
                                   compression=compression_str,
                                   reuse=reuse_str))
    
    @staticmethod
    def create_table(cursor, schema, name, cols="", constraints="",
                     select_stmt="", nologging=False, partition_clause=""):
        '''
        Create a table
        '''
        if len(schema) > 0:
            schema += "."

        if len(constraints) > 0 and len(cols) > 0:
            cols += ","
            
        select_str = "AS\n" + select_stmt if select_stmt else ""
        nologging_str = " NOLOGGING" if nologging else ""
        partition_str = partition_clause + "\n" if partition_clause else ""
        if cols:
            stmt = ("CREATE TABLE {schema}{name}{nologging}\n"
                    "   ({cols}\n"
                    "   {constraints})\n"
                    "{partition}"
                    "{select}")
            stmt = stmt.format(schema=schema, name=name,
                               nologging=nologging_str, cols=cols,
                               constraints=constraints,
                               partition=partition_str, select=select_str)
            cursor.execute(stmt)
        else:
            stmt = ("CREATE TABLE {schema}{name}{nologging}\n"
                    "{partition}"
                    "{select}")
            stmt = stmt.format(schema=schema, name=name,
                               nologging=nologging_str,
                               partition=partition_str, select=select_str)
            cursor.execute(stmt)
           
    @staticmethod
    def create_view(cursor, schema, name, body, replace=True, force=True):
        if len(schema) > 0:
            schema += "."
        
        replace = "OR REPLACE " if replace else ""
        force = "FORCE " if force else ""
        stmt = ("CREATE {replace}{force}VIEW {schema}{name} AS\n"
                "{body}"
                )
        stmt = stmt.format(schema=schema, name=name, replace=replace,
                           force=force, body=body)
        cursor.execute(stmt)
    
    @staticmethod
    def create_sequence(cursor, schema, name):
        '''
        Create a sequence that starts at 0 and increments by 1
        '''
        if len(schema) > 0:
            schema += "."
            
        stmt = ("CREATE SEQUENCE {schema}{name}\n"
                "  MINVALUE 0\n"
                "  NOCYCLE NOCACHE NOORDER")
        cursor.execute(stmt.format(schema=schema,
                                   name=name))
    
    @staticmethod
    def create_trigger(cursor, schema, table, trigger, trigger_type, body,
                       replace=True):
        if len(schema) > 0:
            schema += "."
        
        replace_str = " OR REPLACE" if replace else ""
        stmt = ("CREATE{replace}\n"
                "TRIGGER {schema}{trigger}\n"
                "  {type}\n"
                "   ON {schema}{table}\n"
                "  FOR EACH ROW\n"
                "{body}")
        cursor.execute(stmt.format(schema=schema,
                                   table=table,
                                   trigger=trigger,
                                   type=trigger_type,
                                   body=body,
                                   replace=replace_str))
        
    @staticmethod
    def create_index(cursor, schema, table, index, cols, unique=False,
                     parallel=False, compress=False, nologging=False,
                     tablespace=""):
        if len(schema) > 0:
            schema += "."
        
        unique_str = " UNIQUE" if unique else ""
        parallel_str = " PARALLEL" if parallel else ""
        compress_str = " COMPRESS" if compress else ""
        nologging_str = " NOLOGGING" if nologging else ""
        tblspc_str = " TABLESPACE %s" % tablespace if len(tablespace) > 0 else ""
        stmt = ("CREATE{unique} INDEX {schema}{index}\n"
                "  ON {schema}{table} ({cols})\n"
                "   {parallel}{compress}{nologging}{tablespace}")
        stmt = stmt.format(schema=schema, table=table, index=index, cols=cols,
                           unique=unique_str, parallel=parallel_str,
                           compress=compress_str, nologging=nologging_str,
                           tablespace=tblspc_str)
        cursor.execute(stmt)
        
        if parallel:
            # Once the index has been built, revert back to noparallel
            stmt = "ALTER INDEX {schema}{index} NOPARALLEL"
            stmt = stmt.format(schema=schema, index=index)
            cursor.execute(stmt)
        
    @staticmethod
    def create_database_link(cursor, dblink, user, password, conn_str, public=False):
        public_str = "PUBLIC " if public else ""
        stmt = ("CREATE {public}DATABASE LINK {dblink}\n"
                "       CONNECT TO {user} IDENTIFIED BY {password}\n"
                "       USING '{conn_str}'")
        cursor.execute(stmt.format(public=public_str, dblink=dblink, user=user,
                                   password=password, conn_str=conn_str))
    
    @staticmethod
    def rename(cursor, old_name, new_name):
        stmt = "RENAME {old} TO {new}"
        cursor.execute(stmt.format(old=old_name, new=new_name))

    @staticmethod
    def get_table_or_view_columns(cursor, schema, name):
        if len(schema) > 0:
            schema += "."
        
        stmt = ("SELECT *\n"
                "  FROM {schema}{name}\n"
                " WHERE rownum < 1")
        stmt = stmt.format(schema=schema, name=name)
        cursor.execute(stmt)
        col_list = [ col_desc[0].lower() for col_desc in cursor.description ]
        return col_list

    @staticmethod
    def user_exists(cursor, name):
        named_params = {"name": name,
                        }
        stmt = ("SELECT COUNT(username) cnt\n"
                "  FROM all_users\n"
                " WHERE username = UPPER(:name)")
        cursor.execute(stmt, named_params)
        count = cursor.fetchone()[0]
        return count == 1

    @staticmethod
    def tablespace_exists(cursor, name):
        named_params = {"name": name,
                        }
        stmt = ("SELECT COUNT(tablespace_name) cnt\n"
                "  FROM dba_tablespaces\n"
                " WHERE tablespace_name = UPPER(:name)")
        cursor.execute(stmt, named_params)
        count = cursor.fetchone()[0]
        return count == 1

    @staticmethod
    def table_exists(cursor, schema, name):
        named_params = {"table_name": name,
                        }
        
        if not schema or schema == "":
            table = "user_tables"
            owner_expr = ""
        else:
            table = "all_tables"
            owner_expr = "AND owner = UPPER(:owner)"
            named_params["owner"] = schema
            
        stmt = ("SELECT COUNT(table_name) cnt\n"
                "  FROM {table}\n"
                " WHERE table_name = UPPER(:table_name)\n"
                "       {owner_expr}")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def view_exists(cursor, schema, name):
        named_params = {"view_name": name,
                        }
        
        if not schema or schema == "":
            table = "user_views"
            owner_expr = ""
        else:
            table = "all_views"
            owner_expr = "AND owner = UPPER(:owner)"
            named_params["owner"] = schema
            
        stmt = ("SELECT COUNT(view_name) cnt\n"
                "  FROM {table}\n"
                " WHERE view_name = UPPER(:view_name)\n"
                "       {owner_expr}")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def index_exists(cursor, schema, name):
        named_params = {"index_name": name,
                        }
        
        if not schema or schema == "":
            table = "user_indexes"
            owner_expr = ""
        else:
            table = "all_indexes"
            owner_expr = "AND owner = UPPER(:owner)"
            named_params["owner"] = schema
            
        stmt = ("SELECT COUNT(index_name) cnt\n"
                "  FROM {table}\n"
                " WHERE index_name = UPPER(:index_name)\n"
                "       {owner_expr}")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def sequence_exists(cursor, schema, name):
        named_params = {"sequence_name": name,
                        }
        
        if not schema or schema == "":
            table = "user_sequences"
            owner_expr = ""
        else:
            table = "all_sequences"
            owner_expr = "AND sequence_owner = UPPER(:sequence_owner)"
            named_params["sequence_owner"] = schema
            
        stmt = ("SELECT COUNT(sequence_name) cnt\n"
                "  FROM {table}\n"
                " WHERE sequence_name = UPPER(:sequence_name)\n"
                "       {owner_expr}")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def database_link_exists(cursor, name):
        named_params = {"db_link": name,
                        }
        stmt = ("SELECT COUNT(db_link) cnt\n"
                "  FROM user_db_links\n"
                " WHERE db_link = UPPER(:db_link)")
        cursor.execute(stmt, named_params)
        count = cursor.fetchone()[0]
        return count == 1
    
    @staticmethod
    def trigger_exists(cursor, schema, name):
        named_params = {"trigger_name": name,
                        }
        
        if not schema or schema == "":
            table = "user_triggers"
            owner_expr = ""
        else:
            table = "all_triggers"
            owner_expr = "AND owner = UPPER(:owner)"
            named_params["owner"] = schema
            
        stmt = ("SELECT COUNT(trigger_name) cnt\n"
                "  FROM {table}\n"
                " WHERE trigger_name = UPPER(:trigger_name)\n"
                "       {owner_expr}")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        count = cursor.fetchone()[0]
        return count == 1
    
        names = DbUtils._get_all_tables(cursor, schema)
        for name in names:
            DbUtils.drop_table(cursor, schema, name)

    @staticmethod
    def get_all_tables(cursor, schema):
        named_params = {}
        if schema:
           table = "all_tables"
           owner_expr = "owner = UPPER(:owner)"
           named_params["owner"] = schema
        else:
           table = "user_tables"
           owner_expr = "1=1"
        
        stmt = ("SELECT table_name\n"
                "  FROM {table}\n"
                " WHERE {owner_expr}\n"
                "ORDER BY 1")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        names = [row[0] for row in cursor.fetchall()]

        return names

    @staticmethod
    def get_all_views(cursor, schema):
        named_params = {}
        if schema:
           table = "all_views"
           owner_expr = "owner = UPPER(:owner)"
           named_params["owner"] = schema
        else:
           table = "user_views"
           owner_expr = "1=1"

        stmt = ("SELECT view_name\n"
                "  FROM {table}\n"
                " WHERE {owner_expr}\n"
                "ORDER BY 1")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        names = [row[0] for row in cursor.fetchall()]

        return names

    @staticmethod
    def get_all_domain_indexes(cursor, schema):
        named_params = {}
        if schema:
           index = "all_indexes"
           owner_expr = "owner = UPPER(:owner)"
           named_params["owner"] = schema
        else:
           index = "user_indexes"
           owner_expr = "1=1"

        stmt = ("SELECT index_name\n"
                "  FROM {index}\n"
                " WHERE {owner_expr} AND index_type = 'DOMAIN'\n"
                "ORDER BY 1")
        cursor.execute(stmt.format(index=index, owner_expr=owner_expr),
                       named_params)
        names = [row[0] for row in cursor.fetchall()]

        return names

    @staticmethod
    def drop_all_domain_indexes(cursor, schema):
        names = DbUtils.get_all_domain_indexes(cursor, schema)
        for name in names:
            DbUtils.drop_index(cursor, schema, name)

    @staticmethod
    def drop_all_tables(cursor, schema, cascade=True, purge=True):
        names = DbUtils.get_all_tables(cursor, schema)
        for name in names:
            DbUtils.drop_table(cursor, schema, name, cascade, purge)

    @staticmethod
    def drop_all_views(cursor, schema, cascade=True):
        names = DbUtils.get_all_views(cursor, schema)
        for name in names:
            DbUtils.drop_view(cursor, schema, name, cascade)

    @staticmethod
    def drop_user(cursor, user, cascade=False):
        cascade_str = "CASCADE" if cascade else ""
        stmt = "DROP USER {user} {cascade}"
        try:
            cursor.execute(stmt.format(user=user,
                                       cascade=cascade_str))
        except cx_Oracle.DatabaseError as e:
            # catch and ignore user does not exist errors
            error, = e.args
            if error.code != DbUtils.USER_DOES_NOT_EXIST:
                raise

    @staticmethod
    def drop_tablespace(cursor, tablespace, include_contents=False,
                        include_datafiles=False, cascade=False):
        # if we are not deleting the tablespace contents, don't
        # include data files or cascade constraints
        if not include_contents:
            include_datafiles = False
            cascade = False
            
        # first take the tablespace offline
        try:
            stmt = "ALTER TABLESPACE {tablespace} OFFLINE"
            cursor.execute(stmt.format(tablespace=tablespace))
            
            # then drop the tablespace
            contents_str = " INCLUDING CONTENTS" if include_contents else ""
            datafiles_str = " AND DATAFILES" if include_datafiles else ""
            cascade_str = " CASCADE CONSTRAINTS" if cascade else ""
            
            stmt = ("DROP TABLESPACE {tablespace}\n"
                    "{contents}\n"
                    "{datafiles}\n"
                    "{cascade}")
            cursor.execute(stmt.format(tablespace=tablespace,
                                       contents=contents_str,
                                       datafiles=datafiles_str,
                                       cascade=cascade_str))
        except cx_Oracle.DatabaseError as e:
            # catch and ignore tablespace does not exist errors
            error, = e.args
            if error.code != DbUtils.TABLESPACE_DOES_NOT_EXIST:
                raise

    @staticmethod
    def drop_table(cursor, schema, name, cascade=True, purge=True):
        try:
            if len(schema) > 0:
                schema += "."
            cascade_str = " CASCADE CONSTRAINTS" if cascade else ""
            purge_str = " PURGE" if purge else ""
            
            stmt = ("DROP TABLE {schema}{name}\n"
                    "{cascade}\n"
                    "{purge}")
            cursor.execute(stmt.format(schema=schema,
                                       name=name,
                                       cascade=cascade_str,
                                       purge=purge_str))
        except cx_Oracle.DatabaseError as e:
            # catch and ignore table or view does not exist errors
            error, = e.args
            if error.code != DbUtils.TABLE_OR_VIEW_DOES_NOT_EXIST:
                raise

    @staticmethod
    def drop_tables_like(cursor, schema, pattern, cascade=True, purge=True):
        '''
        Drop tables matching the specified pattern, where the pattern may
        include the following wildcard characters:
            % matches any string of any length (including zero length)
            _ match a single character
        '''
        named_params = {"table_name": pattern,
                        }
        
        if not schema or schema == "":
            table = "user_tables"
            owner_expr = ""
        else:
            table = "all_tables"
            owner_expr = "AND owner = UPPER(:owner)"
            named_params["owner"] = schema
            
        stmt = ("SELECT table_name\n"
                "  FROM {table}\n"
                " WHERE table_name like UPPER(:table_name)\n"
                "       {owner_expr}\n"
                " ORDER BY 1")
        cursor.execute(stmt.format(table=table, owner_expr=owner_expr),
                       named_params)
        names = [row[0] for row in cursor.fetchall()]
        for name in names:
            DbUtils.drop_table(cursor, schema, name, cascade, purge)
        
    @staticmethod
    def drop_view(cursor, schema, name, cascade=True):
        try:
            if len(schema) > 0:
                schema += "."
            cascade_str = " CASCADE CONSTRAINTS" if cascade else ""
            
            stmt = ("DROP VIEW {schema}{name}\n"
                    "{cascade}")
            cursor.execute(stmt.format(schema=schema,
                                       name=name,
                                       cascade=cascade_str))
        except cx_Oracle.DatabaseError as e:
            # catch and ignore table or view does not exist errors
            error, = e.args
            if error.code != DbUtils.TABLE_OR_VIEW_DOES_NOT_EXIST:
                raise

    @staticmethod
    def drop_sequence(cursor, schema, name):
        try:
            if len(schema) > 0:
                schema += "."
            stmt = "DROP SEQUENCE {schema}{name}"
            cursor.execute(stmt.format(schema=schema,
                                       name=name))
        except cx_Oracle.DatabaseError as e:
            # catch and ignore sequence does not exist errors
            error, = e.args
            if error.code != DbUtils.SEQUENCE_DOES_NOT_EXIST:
                raise

    @staticmethod
    def drop_index(cursor, schema, name):
        try:
            if len(schema) > 0:
                schema += "."
            stmt = "DROP INDEX {schema}{name}"
            cursor.execute(stmt.format(schema=schema,
                                       name=name))
        except cx_Oracle.DatabaseError as e:
            # catch and ignore index does not exist errors
            error, = e.args
            if error.code != DbUtils.INDEX_DOES_NOT_EXIST:
                raise

    @staticmethod
    def drop_database_link(cursor, dblink, public=False):
        public_str = "PUBLIC" if public else ""
        stmt = "DROP {public} DATABASE LINK {dblink}"
        cursor.execute(stmt.format(public=public_str, dblink=dblink))

    @staticmethod
    def compute_table_statistics(cursor, schema, table_list, estimate_percent=""):
        if not schema:
            schema = cursor.connection.username

        # TODO: Add support for the estimate_percent argument
        for table in table_list:
            cursor.callproc("DBMS_STATS.GATHER_TABLE_STATS", [schema, table])

    @staticmethod
    def compute_schema_statistics(cursor, schema, estimate_percent=""):
        # TODO: Add support for the estimate_percent argument
        cursor.callproc("DBMS_STATS.GATHER_SCHEMA_STATS", [schema])
    
    @staticmethod
    def grant_system_privileges(cursor, user, priv_list):
        for priv in priv_list:
            stmt = "GRANT {priv} TO {user}"
            cursor.execute(stmt.format(user=user,
                                       priv=priv))
    
    @staticmethod
    def grant_object_privileges(cursor, priv_list, schema, db_object,
                                grantee_list, with_grant_option=False):
        if len(schema) > 0:
            schema += "."
            
        stmt = "GRANT {privs} on {schema}{db_object} TO {grantees}"
        if with_grant_option:
            stmt += " WITH GRANT OPTION"
        cursor.execute(stmt.format(privs=", ".join(priv_list),
                                   schema=schema,
                                   db_object=db_object,
                                   grantees=", ".join(grantee_list)))

    @staticmethod
    def revoke_system_privilege(cursor, user, priv_list):
        # TODO:
        pass
    
    @staticmethod
    def revoke_object_privileges(cursor, schema, priv_list, db_object):
        # TODO:
        pass
    
    @staticmethod
    def generate_dicts(cur):
        fieldnames = [d[0].lower() for d in cur.description]
        while True:
            rows = cur.fetchmany()
            if not rows: return
            for row in rows:
                yield dict(zip(fieldnames, row))


class CursorWrapper(Wrapper):
    __wraps__ = cx_Oracle.Cursor
    
    DEBUG_LOG_LEVEL = 10

    def __init__(self, obj):
        Wrapper.__init__(self, obj)
        self._logger = logging.getLogger('sql')
    
    def execute(self, *args, **kw_args):
        if self._logger.getEffectiveLevel() >= self.DEBUG_LOG_LEVEL:
            conn = self.connection
            user = conn.username
            schema = conn.current_schema if conn.current_schema else user
            msg1 = 'user={}, schema={}'.format(user, schema)
            msg2 = '\n' + StringUtils.reindent('sql={}'.format(args[0]), 10)
            msg3 =''
            if len(args) > 1:
                msg3 = '\n' + StringUtils.reindent('vars: {}'.format(args[1]), 10)
        self._logger.debug(msg1 + msg2 + msg3)
        self._obj.execute(*args, **kw_args)

   
class DbCursorRegistry(object):
    '''
    Maintain a registry of open database cursors
    '''
    
    def __init__(self):
        self.registry = {}
        
    def get_cursor(self, user, password, db):
        key = "%s@%s" % (user, db)
        if not key in self.registry:
            self._create(user, password, db)
        return self.registry[key]
    
    def close_all(self):
        '''close all of the connections/cursors stored in the registry'''
        for k in list(self.registry.keys()):
            cursor = self.registry[k]
            conn = cursor.connection
            del self.registry[k]
            try:
                cursor.close()
            except Exception:
                # catch and ignore all exceptions resulting from closing a cursor
                pass

            try:
                conn.close()
            except Exception:
                # catch and ignore all exceptions resulting from closing a cursor
                pass
            
    def _create(self, user, password, db):
        '''
        Create a database connection and cursor
        '''
        key = "%s@%s" % (user, db)
        
        conn = cx_Oracle.connect(user, password, db)
        cursor = conn.cursor()
        self.registry[key] = CursorWrapper(cursor)


class DbCsvColumnMeta(object):
    '''
    Metadata for database columns to be loaded from a text file
    '''
    
    def __init__(self, column_name, python_type):
        '''
        Arguments:
          col_name - name of the database column
          python_type = Python type (one of "str", "int", "float" or "date(<date_fmt>)"
             where <date_fmt> is the strptime format to use to convert the string to a
             datetime
          
        Raise Exception if:
          col_name is empty string
          python_type is not one of "str", "int", "float" or "date(<date_fmt>)"
        '''
        self.column_name = column_name
        
        if column_name == "":
            raise Exception("No value specified for column_name")
        
        pattern = r'str|int|float|date\((?P<date_fmt>.+)\)'

        # use a case insensitve match
        match = re.match(pattern, python_type, re.I)

        if match:
            python_type = python_type.strip().lower()
            if python_type.startswith("date"):
                python_type = "date"
            self.python_type = python_type
            self.type_format = match.groupdict()['date_fmt']
        else:   
            msg = 'python_type = %s, expected one of "str", "int", "float" or "date(<date_fmt>)"'
            raise Exception(msg % python_type)


class DbCsvLoader(object):
    '''
    Create and populate table from a text file.
    
    The text file may contain up to two rows of metadata where:
      Row 1: database column name
      Row 2: Python type to use for data values (one of "str", "int" or "float")
    '''
    
    def __init__(self, path, table, num_header_rows=2, sep="\t"):
        '''
        Arguments:
          file - path for the text file to be loaded
          table - table name
          num_header_rows - number of header rows, valid values are 0 or 2
             if num_header_rows == 0, the column metadata must be specified
                using the set_column_meta_list() method before calling either
                insert_data() or upsert(data)
             if num_header_rows == 1, the python_type defaults to "str"
             
        Raises an Exception if:
          num_header_rows is a value other than 0, 1 or 2
          the specified file does not exist
        '''
        self.path = path
        self.table = table
        self.num_header_rows = num_header_rows
        self.sep = sep
        self.column_meta_list = []
        
        if num_header_rows < 0 or num_header_rows > 2:
            msg = "num_header_rows = 5d, acceptable values are 0, 1 or 2"
            raise Exception(msg % num_header_rows)
        
        self.fp = open(path, "r")
        self.reader = csv.reader(self.fp, delimiter=sep)
        self._read_header_rows()
                    
    def get_column_meta_list(self):
        return self.column_meta_list
    
    def set_column_meta_list(self, column_meta_list):
        self.column_meta_list_list = column_meta_list
    
    def insert_data(self, db_cur, format_vars):
        '''
        Load the data from the text file using INSERT statements
        
        Raise an exception when the target table doesn't exist
        '''
        if not DbUtils.table_exists(db_cur, "", self.table):
            raise Exception("Table not found: %s" % self.table)
        
        # Populate the table
        for row in self.reader:
            stmt, params = self._build_insert_statement(row, format_vars)
            db_cur.execute(stmt, params)
        
        db_cur.connection.commit()
        self.fp.close()
        
    def upsert_data(self, db_cur, format_vars, key_cols):
        '''
        For each row where the key_cols values already exist in the
        table, modify the row using an UPDATE statement.
        
        For each row where the key_col values do not exist in the
        table, load the data using an INSERT statement. 
        
        Raise an exception when the target table doesn't exist
        '''
        if not DbUtils.table_exists(db_cur, "", self.table):
            raise Exception("Table not found: %s" % self.table)
            
        for row in self.reader:
            if self._exists(row, db_cur, format_vars, key_cols):
                stmt, params = self._build_update_statement(row, format_vars, key_cols)
            else:
                stmt, params = self._build_insert_statement(row, format_vars)
            db_cur.execute(stmt, params)
            
        db_cur.connection.commit()
        self.fp.close()
    
    def _read_header_rows(self):
        '''
        Read the column metadata from the header rows of the text file
        '''
        # If we don't expect any header rows, just return
        if self.num_header_rows == 0:
            return
        
        line_num = 0
        header_rows = []
        while line_num < self.num_header_rows:
            row = next(self.reader)
            if not row:
                msg = "File contains %d header rows, expected %d"
                raise Exception(msg % (line_num, self.num_header_rows))
            header_rows.append(row)
            line_num += 1
            
        # Test that each header row contains the same number of values
        expected_n = len(header_rows[0])
        header_row_num = 1
        while header_row_num < self.num_header_rows:
            actual_n = len(header_rows[header_row_num])
            if actual_n != expected_n:
                msg = "Header row $d contains %d values, expected %d"
                raise Exception(msg % (header_row_num, actual_n, expected_n))
            header_row_num += 1
            
        col_index = 0
        for name in header_rows[0]:
            if len(header_rows) > 1:
                python_type = header_rows[1][col_index]
            else:
                python_type = "str"
            
            col_meta = DbCsvColumnMeta(name, python_type)
            self.column_meta_list.append(col_meta)
            col_index += 1
    
    def _exists(self, row, db_cur, format_vars, key_cols):
        '''
        Determine whether a row with the same key_col values as the
        current row already exists in the database table.
        
        Raise an exception when:
          One or more of the key col names aren't found in the text file
          The combination of key column values is not unique in the table
        '''
        named_params = {}
        where_expr_list = []
        for col in key_cols:
            index = 0
            found = False
            for meta in self.column_meta_list:
                if col == meta.column_name:
                    found = True
                    break
                index += 1
            
            if not found:
                raise Exception("Key column not found: %s" % col)
        
            python_type = self.column_meta_list[index].python_type
            type_format = self.column_meta_list[index].type_format
            value_str = row[index]
            if value_str == "":
                # If there is no value for one or more key columns in the
                # text file, then insert the row
                return False
            
            value = self._convert_str(value_str, format_vars, python_type, type_format)
            named_params[col] = value
            where_expr_list.append("%s = :%s" % (col, col))
        
        where_clause = "WHERE " + " AND ".join(where_expr_list)
        stmt = ("SELECT COUNT(*)"
                "  FROM {table}"
                " {where_clause}")
        
        db_cur.execute(stmt.format(table=self.table, where_clause=where_clause),
                       named_params)
        count = db_cur.fetchone()[0]
        
        if count > 1:
            msg = "Values for key columns '%s' in table '%s' are not unique" 
            raise Exception(msg % (", ".join(key_cols), self.table))
        
        return count == 1

    def _build_insert_statement(self, row, format_vars):
        '''
        Create the SQL statement and named parameters needed
        to insert a row in the target table
        '''
        named_params = {}
        cols = []
        values = []
        col_index = 0
        for value in row:
            # Only insert those columns for which data was provided
            if value != "":
                meta = self.column_meta_list[col_index]
                col_name = meta.column_name
                python_type = meta.python_type
                type_format = meta.type_format
                col_value = self._convert_str(value, format_vars, python_type,
                                              type_format)
                named_params[col_name] = col_value
                
                cols.append(col_name)
                values.append(":" + col_name)
            col_index += 1
            
        insert_cols = ", ".join(cols)
        insert_values = ", ".join(values)
        
        stmt = ("INSERT INTO {table} "
                "  ({insert_cols})"
                " VALUES"
                "  ({insert_values})")
        return (stmt.format(table=self.table,
                            insert_cols=insert_cols,
                            insert_values=insert_values),
                named_params)
    
    def _build_update_statement(self, row, format_vars, key_cols):
        '''
        Create the SQL statement and named parameters needed
        to update a row in the target table.
        '''
        named_params = {}
        update_expr_list = []
        where_expr_list = []
        col_index = 0
        for value in row:
            # Only update those columns for which data was provided
            if value != "":
                meta = self.column_meta_list[col_index]
                col_name = meta.column_name
                python_type = meta.python_type
                type_format = meta.type_format
                col_value = self._convert_str(value, format_vars, python_type,
                                              type_format)
                named_params[col_name] = col_value
                
                expr = "%s = :%s" % (col_name, col_name)
                if not self._is_key_column(col_name, key_cols):
                    update_expr_list.append(expr)
                else:
                    where_expr_list.append(expr)
            col_index += 1
        
        update_set_clause = "SET " + ", ".join(update_expr_list)
        where_clause = "WHERE " + " AND ".join(where_expr_list)
        
        stmt = ("UPDATE {table}"
                "   {update_set_clause}"
                "   {where_clause}")        
        return (stmt.format(table=self.table,
                            update_set_clause=update_set_clause,
                            where_clause=where_clause),
                named_params)
    
    def _is_key_column(self, col, key_cols):
        '''
        Test whether col is one of the key_cols
        '''
        found = False;
        for key_col in key_cols:
            if col == key_col:
                found = True
                break
        return found
    
    def _convert_str(self, str_value, format_vars, python_type, type_format):
        '''
        Substitute the format_vars dictionary values into str_value and then
        convert the result to a value of the appropriate Python type
        '''
        formatted_value = str_value.format(**format_vars)
        if python_type == "int":
            return int(formatted_value)
        elif python_type == "float":
            return float(formatted_value)
        elif python_type == "date":
            return datetime.strptime(formatted_value, type_format)
        else:
            return formatted_value


class DbCsvWriter(object):
    '''
    Utility to write a csv-format file containing the results of a database
    query
    '''
    @staticmethod
    def export(cursor, csv_path):
        try:
            fp = open(csv_path, "wb")
            w = csv.writer(fp)
            headings = [ desc[0] for desc in cursor.description ]
            w.writerow(headings)
            for row in cursor.fetchall():
                w.writerow(row)
        finally:
            fp.close
            

class DbSqlPlus(object):
    '''
    Utility to invoke a SQL*Plus script
    '''
    @staticmethod
    def invoke_db_cmd(sqlplus_path, conn_str, working_dir, script,
                      script_args_list=[]):
        logger = logging.getLogger('DbSqlPlus')

        quoted_args_str = ""

        if script_args_list:
            quoted_args_list = [ '"{}"'.format(arg) for arg in script_args_list ]
            quoted_args_str = " ".join(quoted_args_list)

        result = subprocess.run([sqlplus_path, '-S'], cwd=working_dir,
                                input=(conn_str + '\n'
                                       '@' + script + " " + quoted_args_str),
                                text=True,
                                capture_output=True)
        msg = "returncode=" + str(result.returncode) + "\n"
        msg = msg + "stdout=" + result.stdout + "\n"
        if result.returncode != 0:
            msg = msg + "stderr=" + result.stderr
            logger.error(msg)
        else:
            logger.info(msg)
        result.check_returncode()

        return result
