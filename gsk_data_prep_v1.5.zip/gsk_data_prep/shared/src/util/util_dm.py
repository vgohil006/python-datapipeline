# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

from configparser import ConfigParser
from io import StringIO
import grp
import os
import re
import time

class DmRunLauncher(object):
    '''
    Data mining run launcher
    '''
    @staticmethod
    def cleanup(launch_dir):
        '''
        Remove vestiges of all completed data mining runs
        '''
        files = os.listdir(launch_dir)
        for f in files:
            if f.endswith(".done"):
                os.remove(os.path.join(launch_dir, f))
                    
    def __init__(self, launch_dir, name, desc, named_vars, template_path,
                 group=None, mode=None):
        '''
        Process the data mining run definition template file, substituting
        values from "named_vars" for the placeholders in the template.  Deposit
        the resulting file in the "launch_dir" to cause the corresponding data
        mining run to be launched by Empirica Signal.

        Arguments:
          launch_dir - run definition files deposited in this directory will
            cause Empirica Signal to launch the corresponding data mining run
          name - base file name (not including a file extension) to use for
            the instantiated run definition file
          desc - data mining run description
          named_vars - dictionary containing placeholder variable names and
            their corresponding values
          template_path - path name for the run definition template file
          group - if specified, the name of the group to which the file
            should be assigned
          mode - if specified, the numeric mode to assign to the file
        '''
        self._launch_dir = launch_dir
        self.name = name
        self.desc = desc
        self._target_path_base = os.path.join(launch_dir, name)
        self._run_info = None
        
        # check that name contains only alphanumeric and underscore characters
        self._test_run_name()
        
        # clean up leftover data mining run status
        self._remove_run_status()
        
        # read the run definition template file
        with open(template_path, "r") as source:
            lines = source.readlines()
        
        # instantiate the run definition file and deposit it in the launch dir
        target_path_tmp = self._target_path_base + ".tmp"
        with open(target_path_tmp, "w") as target:
            for line in lines:
                target.write(line.format(**named_vars))
        
        # if specified, set the group for the file
        if group:
            gid = grp.getgrnam(group).gr_gid
            os.chown(target_path_tmp, -1, gid)

        # if specified, set the mode for the file
        if mode:
            os.chmod(target_path_tmp, mode)

        # when the target file is complete, rename the file to append ".in"
        # to the name so that the file will be processed by Empirica Signal.
        target_path_in = self._target_path_base + ".in"
        os.rename(target_path_tmp, target_path_in)
    
    def get_run_id(self):
        '''
        Return the ID for the data mining run
        '''
        status = self.get_run_status()
        if status == "success" or status == "failure":
            return self._run_info.runid
        else:
            return None
    
    def get_run_error(self):
        '''
        If the run failed, return the error message; otherwise return ""
        '''
        if self.get_run_status() == "failure":
            return self._run_info.message
        else:
            return ""
    
    def get_run_status(self):
        '''
        Return the status of the data mining run
        Possible status values are:
          success - run completed successfully
          failure - run failed
          running - run is executing
          pending - run has not yet been started within Empirica Signal
        '''
        if os.path.exists(self._target_path_base + ".done"):
            if not self._run_info:
                self._run_info = DmRunInfo(self._target_path_base + ".done")
            return "success" if self._run_info.success else "failure"
        elif os.path.exists(self._target_path_base + ".proc"):
            return "running"
        else:
            return "pending"
    
    def remove_done_file(self):
        '''
        Remove the ".done" file associated with the run
        '''
        path = os.path.join(self._launch_dir, self.name + ".done")
        if os.path.exists(path):
            os.remove(path)
    
    def _remove_run_status(self):
        '''
        Remove vestiges of prior data mining runs associated with this name
        '''
        exts = [".tmp", ".done", ".proc"]
        base_path = self._launch_dir + os.sep + self.name
        for ext in exts:
            path = base_path + ext
            if os.path.exists(path):
                os.remove(path)
    
    def _test_run_name(self):
        '''
        Test whether run_name consists only of letters, numbers and
        underscores
        '''
        match = re.match(r'[_A-Za-z0-9]+', self.name)
        if not match or match.group() != self.name:
            raise Exception("Bad eun name: %s" % self.name)

class DmRunInfo(object):
    '''
    Data mining run execution info
    '''    
    SECTION="info"
    
    def __init__(self, path):
        '''
        '''
        info = ConfigParser()
        info.readfp(self._add_section_header(path))
        self.runid = info.getint(self.SECTION, "runid")
        self.success = info.getboolean(self.SECTION, "success")
        self.message = info.get(self.SECTION, "message")
    
    def _add_section_header(self, properties_file):
        '''
        For a section-less properties file, prepend a section name to the
        file content so that the properties can be read using a SafeConfigParser
        '''
        wrapper = StringIO()
        wrapper.write("[%s]\n" % self.SECTION)
        wrapper.write(open(properties_file).read())
        wrapper.seek(0, os.SEEK_SET)
        return wrapper

class DmRunPublisher(object):
    '''
    Data mining run publisher
    '''
    @staticmethod
    def publish_runs(publish_dir, run_ids, publish_groups, group=None,
                     mode=None):
        '''
        Publish the specified list of runs
        '''
        rundef_lines = [ "ACTION=PUBLISH RUN\n",
                         "RUNID={run_id}\n",
                         "PUBLISH_TO_LOGINGROUPS={publish_groups}\n"
                       ]

        publish_rundefs = []
        for run_id in run_ids:
            named_vars = {"run_id": run_id,
                          "publish_groups": publish_groups}

            # create the run definition in the publish dir
            name = "publish_run_" + run_id
            target_path_base = os.path.join(publish_dir, name)
            target_path_tmp = target_path_base + ".tmp"
            with open(target_path_tmp, "w") as target:
                for line in rundef_lines:
                    target.write(line.format(**named_vars))

            # if specified, set the group for the file
            if group:
                gid = grp.getgrnam(group).gr_gid
                os.chown(target_path_tmp, -1, gid)

            # if specified, set the mode for the file
            if mode:
                os.chmod(target_path_tmp, mode)

            # rename the file to append ".in" to the name so that the file
            # will be processed by Empirica Signal.
            target_path_in = target_path_base + ".in"
            os.rename(target_path_tmp, target_path_in)

            # maintain the list of publshing rundefs
            publish_rundefs.append(target_path_in)

        # return the list of paths for the publish rundef files
        return publish_rundefs

    @staticmethod
    def wait_for_publish_runs(publish_rundefs, polling_secs):
        '''
        Wait for the publishing runs to complete
        '''
        still_running = [ rundef.replace(".in", ".done")
                              for rundef in publish_rundefs ]
        while True:
            if len(still_running) == 0:
                break
            else:
                # Wait POLLING_SECS before checking
                time.sleep(polling_secs)

            for done_file in list(still_running):
                still_running = []
                if os.path.exists(done_file):
                   os.remove(done_file)
                else:
                   still_running.append(done_file)
