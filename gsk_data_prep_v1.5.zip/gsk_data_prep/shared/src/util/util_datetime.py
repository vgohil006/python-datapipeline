# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

from datetime import datetime, timedelta

class IsoWeekUtils(object):
    '''
    Manipulate ISO week information
    '''
    @staticmethod
    def incr_yyyyWww(yyyyWww, incr):
        '''
        Increment the ISO week (formatted as "yyyyWyy" by the specified
        number of weeks.  The result is returned as a string in "yyyyWww"
        format.
        '''
        # Convert the ISO week to a date corresponding to the first day
        # of that week
        first_day_of_week = IsoWeekUtils.get_first_day_of_iso_week(yyyyWww)
        incremented_date = first_day_of_week + timedelta(days=incr*7)
        iso_date_parts = incremented_date.isocalendar()
        iso_week = "{}W{:02d}".format(iso_date_parts[0], iso_date_parts[1])
        return iso_week

    @staticmethod
    def get_first_day_of_iso_week(yyyyWww):
        '''
        Convert an ISO week (expressed in "yyyyWww" format) to the
        date corresponding to the first day (Monday) of that week
        '''
        return IsoWeekUtils._convert_iso_week_and_day_to_date(yyyyWww, 1)

    @staticmethod
    def get_last_day_of_iso_week(yyyyWww):
        '''
        Convert an ISO week (expressed in "yyyyWww" format) to the
        date corresponding to the last day (Sunday) of that week
        '''
        return IsoWeekUtils._convert_iso_week_and_day_to_date(yyyyWww, 7)

    @staticmethod
    def _convert_iso_week_and_day_to_date(yyyyWww, weekday):
        '''
        Convert an ISO week (expressed in "yyyyWww" format) and an
        ISO weekday (decimal number from 1 to 7 where 1 is Monday)
        to the corresponding date.
        '''
        as_string = "{}D{}".format(yyyyWww, weekday)
        as_date = datetime.strptime(as_string, "%GW%VD%u").date()
        return as_date


class YyyymmUtils(object):
    '''
    Manipulate month information in yyyymm format
    '''    
    @staticmethod
    def incr_yyyymm(yyyymm, incr):
        '''
        Increment the year and month (formatted as "yyyymm" by the specified
        number of months.  The result is returned as a string in "yyyymm"
        format.
        '''
        yyyymm = int(yyyymm)
        new_num_months = ((yyyymm // 100) * 12) + (yyyymm % 100) + incr
        year = new_num_months // 12
        month = (new_num_months % 12)
        if month == 0:
            year -= 1
            month = 12
        return "%d%02d" % (year, month)


class YyyyQqUtils(object):
    '''
    Manipulate quarter information in yyyyQq format
    '''    
    @staticmethod
    def incr_yyyyQq(yyyyQq, incr):
        '''
        Increment the year and quarter (formatted as "yyyyQq" by the specified
        number of quarters.  The result is returned as a string in "yyyyQq"
        format.
        '''
        yyyy = int(yyyyQq[:4])
        q = int(yyyyQq[5:])
        new_num_quarters = (yyyy * 4) + q + incr
        year = new_num_quarters // 4
        quarter = (new_num_quarters % 4)
        if quarter == 0:
            year -= 1
            quarter = 4
        return "%dQ%d" % (year, quarter)
