CREATE TABLE term_hierarchy_dates (
   name VARCHAR NOT NULL,
   version VARCHAR NOT NULL,
   db_schema VARCHAR NOT NULL,
   term_type CHAR(1) NOT NULL,
   valid_start TIMESTAMP WITHOUT TIME ZONE,
   update_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
   update_user INTEGER DEFAULT 1 NOT NULL,
   PRIMARY KEY (name, version)
);
