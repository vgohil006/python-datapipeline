--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS lab_data CASCADE;

-- Create Table lab_data

CREATE TABLE lab_data(
case_id INTEGER NOT NULL,
primary_id VARCHAR(20) NOT NULL,
lab_seq_num INTEGER NOT NULL,
test_date TIMESTAMP WITHOUT TIME ZONE,
lab_sort_id INTEGER,
results TEXT,
norm_high   TEXT,   
norm_low    TEXT,
lab_date_text   TEXT,
unit    TEXT,
lab_pt  TEXT,
lab_test_notes  TEXT,
lab_llt_code    INTEGER,
lab_hlt TEXT,
lab_hlgt    TEXT,
lab_soc TEXT,
lab_soc_abbrev  TEXT,
test_reptd  TEXT,
valid_case_yn   VARCHAR(1),
spont_case_yn   VARCHAR(1),
spont_valid_case_yn VARCHAR(1),
drug_case_yn    VARCHAR(1),
device_case_yn  VARCHAR(1),
vaccine_case_yn VARCHAR(1)
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

-- Insert values into lab_data

INSERT INTO lab_data (case_id, primary_id,
                      lab_seq_num, test_date,
                      lab_sort_id, results,
                      norm_high, norm_low,
                      lab_date_text, unit,
                      lab_pt, lab_test_notes,
                      lab_llt_code, lab_hlt, 
                      lab_hlgt, lab_soc, lab_soc_abbrev,
                      test_reptd, valid_case_yn,
                      spont_case_yn, spont_valid_case_yn,
                      drug_case_yn, device_case_yn, 
                      vaccine_case_yn
                      )
SELECT cl.case_id, 
    cl.case_num AS primary_id,
    cld.seq_num, 
    cld.test_date,
    cld.sort_id,
    cld.results,
    cld.norm_high,
    cld.norm_low,
    cld.test_date_partial,
    cld.unit,
    COALESCE(cld.lab_test_name, test_reptd) AS lab_pt,
    cld.notes,
    cld.llt_code::INTEGER,
    cld.hlt,
    cld.hlgt,
    cld.soc,
    soc.soc_abbrev,
    cld.test_reptd,
    cl.valid_case_yn,
    cl.spont_case_yn,
    cl.spont_valid_case_yn,
    cl.drug_case_yn,
    cl.device_case_yn,
    cl.vaccine_case_yn
    FROM case_list cl
    JOIN case_lab_data cld ON cl.case_id = cld.case_id AND cld.deleted IS NULL
    LEFT JOIN meddra_soc soc ON soc.soc_code = cld.soc_code::INTEGER AND soc.deleted IS NULL;
                        
ALTER TABLE lab_data ADD CONSTRAINT pk_lab_data PRIMARY KEY(case_id, lab_seq_num); 
CREATE UNIQUE INDEX lab_data_ix1 ON lab_data(primary_id, lab_seq_num);

-- Analyze Table
ANALYZE lab_data;


    


