CREATE TABLE :table_name (
   std_category_name VARCHAR NOT NULL PRIMARY KEY,
   category_type VARCHAR NOT NULL,
   group_name VARCHAR NOT NULL,
   user_label VARCHAR NOT NULL
);
