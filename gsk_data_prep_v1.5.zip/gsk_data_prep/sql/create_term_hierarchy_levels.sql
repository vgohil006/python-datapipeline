CREATE TABLE term_hierarchy_levels (
   hierarchy_name VARCHAR NOT NULL PRIMARY KEY,
   n_levels INTEGER NOT NULL,
   level_1_name VARCHAR NOT NULL,
   level_2_name VARCHAR,
   level_3_name VARCHAR,
   level_4_name VARCHAR,
   level_5_name VARCHAR,
   level_6_name VARCHAR,
   level_1_coded CHAR(1),
   level_2_coded CHAR(1),
   level_3_coded CHAR(1),
   level_4_coded CHAR(1),
   level_5_coded CHAR(1),
   level_6_coded CHAR(1)
);
