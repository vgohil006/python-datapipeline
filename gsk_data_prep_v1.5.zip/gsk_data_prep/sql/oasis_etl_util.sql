--set search_path = sbx_oasis_sample, oasis, meddra;

-- ****************************************************************************
--\echo CREATE FUNCTION datestr_to_ts
SELECT ' CREATE FUNCTION datestr_to_ts';
-- ***************************************************************************
-- Supports converting a string to timestamp for three date formats:
--   YYYYMMDD: Converts to the specified date
--   YYYYMM:   Converts to the first day of the specified month
--   YYYY:     Converts to the first day of the specified year
-- 
-- The following tests should return a value:
--   SELECT datestr_to_ts(NULL);        Return NULL
--   SELECT datestr_to_ts('');          Return NULL
--   SELECT datestr_to_ts('2013');      Return 2013-01-01
--   SELECT datestr_to_ts('201302');    Return 2013-02-01
--   SELECT datestr_to_ts('20130203');  Return 2013-02-03
--    
-- The following tests don't match the support formats and should return NULL
--   SELECT datestr_to_ts('213');
--   SELECT datestr_to_ts('abcd');
DROP FUNCTION IF EXISTS datestr_to_ts (VARCHAR) CASCADE;
CREATE OR REPLACE FUNCTION datestr_to_ts (
   p_datestr VARCHAR)
RETURNS TIMESTAMP WITH TIME ZONE AS
$BODY$
DECLARE
   v_datestr VARCHAR := TRIM(p_datestr);
   v_date DATE;
BEGIN
   IF v_datestr IS NULL OR LENGTH(v_datestr) = 0 THEN
      RETURN NULL;
   END IF;
   
   BEGIN
      CASE LENGTH(p_datestr)
          WHEN 8 THEN NULL;
          WHEN 6 THEN v_datestr := v_datestr || '01';
          WHEN 4 THEN v_datestr := v_datestr || '0101';
          ELSE RETURN NULL;
      END CASE;

      v_date := TO_DATE(v_datestr, 'YYYYMMDD');   
   EXCEPTION WHEN OTHERS THEN
      RETURN NULL;
   END;
   
   RETURN v_date::TIMESTAMP WITH TIME ZONE;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;


-- ****************************************************************************
--\echo CREATE FUNCTION calc_age_in_years
select 'CREATE FUNCTION calc_age_in_years';
-- ****************************************************************************
-- Return the patient's age in years, with up to 4 decimal places
-- Return NULL if the age cannot be determined

DROP FUNCTION IF EXISTS
   calc_age_in_years (NUMERIC, VARCHAR) CASCADE;
CREATE OR REPLACE FUNCTION calc_age_in_years (
   p_age NUMERIC,
   p_age_unit VARCHAR)
RETURNS NUMERIC AS
$BODY$
DECLARE
   v_age NUMERIC;
   v_age_in_years NUMERIC;
   v_age_unit VARCHAR = UPPER(TRIM(p_age_unit));
BEGIN
   BEGIN
      IF p_age IS NULL
         THEN RETURN NULL;
         ELSE v_age := p_age;
      END IF;
   EXCEPTION WHEN OTHERS THEN
      RETURN NULL;
   END;

   CASE v_age_unit
      WHEN 'DECADES'    THEN v_age_in_years := v_age * 10.0;
      WHEN 'YEARS'      THEN v_age_in_years := v_age;
      WHEN 'MONTHS'     THEN v_age_in_years := (v_age / 12.0);
      WHEN 'WEEKS'      THEN v_age_in_years := (v_age / 52.0);
      WHEN 'DAYS'       THEN v_age_in_years := (v_age / 365.25);
      WHEN 'HOURS'      THEN v_age_in_years := (v_age / (365.25 * 24.0));
      WHEN 'MINUTE'     THEN v_age_in_years := (v_age / (365.25 * 24.0 * 60.0));
      WHEN 'SECOND'     THEN v_age_in_years := (v_age / (365.25 * 24.0 * 60.0 * 60.0));
      WHEN 'TRIMESTER'  THEN v_age_in_years := (v_age / 4.0);
      ELSE v_age_in_years := NULL;
   END CASE;
   
   -- Eliminate invalid ages
   IF v_age_in_years < 0 OR v_age_in_years >= 120
      THEN v_age_in_years := NULL;
   END IF;
   v_age_in_years  := ROUND(v_age_in_years, 4);
   RETURN v_age_in_years;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION calc_age_group3
SELECT 'CREATE FUNCTION calc_age_group3';
-- ****************************************************************************
-- Return the patient's three-category age group as one of:
--  00_64
--  65+
--  UNK
-- Return 'UNK' if the age cannot be determined
DROP FUNCTION IF EXISTS
   calc_age_group3 (NUMERIC, VARCHAR, VARCHAR) CASCADE;
CREATE OR REPLACE FUNCTION calc_age_group3 (
   p_age NUMERIC,
   p_age_unit VARCHAR,
   p_age_group VARCHAR DEFAULT NULL)
RETURNS VARCHAR AS
$BODY$
DECLARE
   v_age_in_years NUMERIC;
BEGIN
   v_age_in_years = calc_age_in_years(p_age, p_age_unit);
   IF v_age_in_years IS NULL THEN
      RETURN
         CASE
		    WHEN p_age_group IS NULL        THEN 'UNK'
		    WHEN p_age_group IN ('Neonate','Infant','Child', 'Adolescent','Adult') THEN '00_64'
		    WHEN p_age_group IN ('Elderly') THEN '65+'
		    ELSE 'UNK'
		 END;
   ELSE
      RETURN
         CASE
            WHEN v_age_in_years < 0   THEN 'UNK'
		    WHEN v_age_in_years < 65  THEN '00_64'
            WHEN v_age_in_years < 120 THEN '65+'
            ELSE                           'UNK'
         END;
   END IF;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION calc_age_group4
SELECT 'CREATE FUNCTION calc_age_group4';
-- ****************************************************************************
-- Return the patient's four-category age group as one of:
--  00_17
--  18_64
--  65+
--  UNK
-- Return 'Unknown' if the age cannot be determined
DROP FUNCTION IF EXISTS
   calc_age_group4 (NUMERIC, VARCHAR, VARCHAR) CASCADE;
CREATE OR REPLACE FUNCTION calc_age_group4 (
   p_age NUMERIC,
   p_age_unit VARCHAR,
   p_age_group VARCHAR DEFAULT NULL)
RETURNS VARCHAR AS
$BODY$
DECLARE
   v_age_in_years NUMERIC;
BEGIN
   v_age_in_years = calc_age_in_years(p_age, p_age_unit);
   IF v_age_in_years IS NULL THEN
      RETURN
         CASE
		    WHEN p_age_group IS NULL        THEN 'UNK'
		    WHEN p_age_group IN ('Neonate','Infant','Child', 'Adolescent') THEN '00_17'
		    WHEN p_age_group IN ('Adult')   THEN '18_64'
		    WHEN p_age_group IN ('Elderly') THEN '65+'
		    ELSE 'UNK'
		 END;
   ELSE
      RETURN
         CASE
            WHEN v_age_in_years IS NULL THEN 'UNK'
            WHEN v_age_in_years < 0     THEN 'UNK'
		    WHEN v_age_in_years < 18    THEN '00_17'
		    WHEN v_age_in_years < 65    THEN '18_64'
            WHEN v_age_in_years < 120   THEN '65+'
            ELSE                           'UNK'
         END;
   END IF;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;


-- ****************************************************************************
--\echo CREATE FUNCTION calc_age_group7
SELECT 'CREATE FUNCTION calc_age_group7';
-- ****************************************************************************
-- Return the patient's seven-category age group as one of:
-- 00_0.5
-- 0.5_01
-- 01_09
-- 10_18
-- 19_64
-- 65+
-- UNK
-- Return 'Unknown' if the age cannot be determined
DROP FUNCTION IF EXISTS
   calc_age_group7 (NUMERIC, VARCHAR, VARCHAR) CASCADE;
CREATE OR REPLACE FUNCTION calc_age_group7 (
   p_age NUMERIC,
   p_age_unit VARCHAR,
   p_age_group VARCHAR DEFAULT NULL)
RETURNS VARCHAR AS
$BODY$
DECLARE
   v_age_in_years NUMERIC;
BEGIN
   v_age_in_years = calc_age_in_years(p_age, p_age_unit);
   RETURN
      CASE
         WHEN v_age_in_years IS NULL  THEN 'UNK'
		 WHEN v_age_in_years < 0      THEN 'UNK'
		 WHEN v_age_in_years < 0.5    THEN '00_00.5'
		 WHEN v_age_in_years < 1      THEN '00.5_01'
		 WHEN v_age_in_years < 10     THEN '01_09'
		 WHEN v_age_in_years < 19     THEN '10_18'
         WHEN v_age_in_years < 65     THEN '19_64'
         WHEN v_age_in_years < 120    THEN '65+'
         ELSE                              'UNK'
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;


-- ****************************************************************************
--\echo CREATE FUNCTION calc_age_group8
SELECT 'CREATE FUNCTION calc_age_group8';
-- ****************************************************************************
-- Return the patient's eight-category age group as one of:
--  00_01
--  02_11
--  12_17
--  18_44
--  45_64
--  65_74
--  75+
--  UNK
-- Return 'Unknown' if the age cannot be determined
DROP FUNCTION IF EXISTS
   calc_age_group8 (NUMERIC, VARCHAR, VARCHAR) CASCADE;
CREATE OR REPLACE FUNCTION calc_age_group8 (
   p_age NUMERIC,
   p_age_unit VARCHAR,
   p_age_group VARCHAR DEFAULT NULL)
RETURNS VARCHAR AS
$BODY$
DECLARE
   v_age_in_years NUMERIC;
BEGIN
   v_age_in_years = calc_age_in_years(p_age, p_age_unit);
   
   RETURN
      CASE
         WHEN v_age_in_years IS NULL  THEN 'UNK'
         WHEN v_age_in_years < 0      THEN 'UNK'
         WHEN v_age_in_years < 2      THEN '00_01'
         WHEN v_age_in_years < 12     THEN '02_11'
         WHEN v_age_in_years < 18     THEN '12_17'
         WHEN v_age_in_years < 45     THEN '18_44'
         WHEN v_age_in_years < 65     THEN '45_64'
         WHEN v_age_in_years < 75     THEN '65_74'
         WHEN v_age_in_years >= 75    THEN '75+'
         ELSE                              'UNK'
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION calc_age_group9
SELECT 'CREATE FUNCTION calc_age_group9';
-- ****************************************************************************
-- Return the patient's seven-category age group as one of:
-- 00_01
-- 02_04
-- 05_12
-- 13_16
-- 17_45
-- 46_75
-- 76_85
-- 86+
-- UNK
-- Return 'Unknown' if the age cannot be determined
DROP FUNCTION IF EXISTS
   calc_age_group9 (NUMERIC, VARCHAR, VARCHAR) CASCADE;
CREATE OR REPLACE FUNCTION calc_age_group9 (
   p_age NUMERIC,
   p_age_unit VARCHAR,
   p_age_group VARCHAR DEFAULT NULL)
RETURNS VARCHAR AS
$BODY$
DECLARE
   v_age_in_years NUMERIC;
BEGIN
   v_age_in_years = calc_age_in_years(p_age, p_age_unit);
   RETURN
      CASE
         WHEN v_age_in_years IS NULL  THEN 'UNK'
         WHEN v_age_in_years < 0      THEN 'UNK'
		 WHEN v_age_in_years < 2      THEN '00_01'
		 WHEN v_age_in_years < 5      THEN '02_04'
		 WHEN v_age_in_years < 13     THEN '05_12'
		 WHEN v_age_in_years < 17     THEN '13_16'
		 WHEN v_age_in_years < 46     THEN '17_45'
         WHEN v_age_in_years < 76     THEN '46_75'
         WHEN v_age_in_years < 86     THEN '76_85'
         WHEN v_age_in_years < 120    THEN '86+'
         ELSE                              'UNK'
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION date_to_half_year
SELECT 'CREATE FUNCTION date_to_half_year';
-- ****************************************************************************
-- Return the calendar half year corresponding to p_date in
-- <yyyy>H<h> format (e.g., 02-SEP-2014 -> 2014H2)
DROP FUNCTION IF EXISTS date_to_half_year (timestamp without time zone) CASCADE;
CREATE OR REPLACE FUNCTION date_to_half_year (p_date timestamp without time zone)
RETURNS VARCHAR AS
$BODY$
DECLARE
   v_year VARCHAR  = DATE_PART('year', p_date)::VARCHAR;
   v_month INTEGER = DATE_PART('month', p_date);
BEGIN
   RETURN
      CASE
         WHEN v_month BETWEEN 1 AND  6 THEN v_year || 'H1'
         WHEN v_month BETWEEN 7 AND 12 THEN v_year || 'H2'
         ELSE NULL
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;


-- ****************************************************************************
--\echo CREATE FUNCTION date_to_quarter
SELECT 'CREATE FUNCTION date_to_quarter';
-- ****************************************************************************
-- Return the calendar quarter corresponding to p_date in
-- <yyyy>Q<q> format (e.g., 02-SEP-2014 -> 2014Q3)
DROP FUNCTION IF EXISTS date_to_quarter (timestamp without time zone) CASCADE;
CREATE OR REPLACE FUNCTION date_to_quarter (p_date timestamp without time zone)
RETURNS VARCHAR AS
$BODY$
DECLARE
   year VARCHAR  = DATE_PART('year', p_date)::VARCHAR;
   month INTEGER = DATE_PART('month', p_date);
BEGIN
   RETURN
      CASE
         WHEN month BETWEEN  1 AND  3 THEN year || 'Q1'
         WHEN month BETWEEN  4 AND  6 THEN year || 'Q2'
         WHEN month BETWEEN  7 AND  9 THEN year || 'Q3'
         WHEN month BETWEEN 10 AND 12 THEN year || 'Q4'
         ELSE NULL
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;


-- ****************************************************************************
--\echo CREATE FUNCTION date_to_month
SELECT 'CREATE FUNCTION date_to_month';
-- ****************************************************************************
-- Return the calendar month corresponding to p_date as an integer in
-- <yyyy><mm> format (e.g., 02-SEP-2014 -> 201409)
DROP FUNCTION IF EXISTS date_to_month (timestamp without time zone) CASCADE;
CREATE OR REPLACE FUNCTION date_to_month (p_date timestamp without time zone)
RETURNS INTEGER AS
$BODY$
BEGIN
   RETURN DATE_PART('year', p_date) * 100 +
          DATE_PART('month', p_date);
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;


-- ****************************************************************************
--\echo CREATE FUNCTION date_to_iso_week
SELECT 'CREATE FUNCTION date_to_iso_week';
-- ****************************************************************************
-- Return the ISO week corresponding to p_date in
-- <yyyy>W<ww> format (e.g., 02-SEP-2014 -> 201409)
DROP FUNCTION IF EXISTS date_to_iso_week (timestamp without time zone) CASCADE;
CREATE OR REPLACE FUNCTION date_to_iso_week (p_date timestamp without time zone)
RETURNS VARCHAR AS
$BODY$
BEGIN
   RETURN TO_CHAR(p_date, 'IYYY"W"IW');
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION literature_reference
SELECT 'CREATE FUNCTION literature_reference';
-- ****************************************************************************
-- Return the literature ref is Author.Title.Journal.Year;Vol:Pages
-- ; is only after YEAR. : only between volume and Pagesng to p_date in

DROP FUNCTION IF EXISTS literature_reference(p_author text, p_title text, p_journal text, p_year text, p_vol text, p_pages text) CASCADE;
CREATE OR REPLACE FUNCTION literature_reference(p_author text, p_title text, p_journal text, p_year text, p_vol text, p_pages text)
RETURNS VARCHAR AS
$BODY$
DECLARE
   v_ref TEXT = '';
BEGIN
   IF p_author IS NOT NULL AND LENGTH(TRIM(p_author)) > 0
      THEN v_ref := v_ref || TRIM(p_author) || '. ';
   END IF;
   IF p_title IS NOT NULL AND LENGTH(TRIM(p_title)) > 0
      THEN v_ref := v_ref || TRIM(p_title) || '. ';
   END IF;
   IF p_journal IS NOT NULL AND LENGTH(TRIM(p_journal)) > 0
      THEN v_ref := v_ref || TRIM(p_journal) || '. ';
   END IF;
   IF p_year IS NOT NULL AND LENGTH(TRIM(p_year)) > 0
      THEN v_ref := v_ref || TRIM(p_year) || ';';
   END IF;
   IF p_vol IS NOT NULL AND LENGTH(TRIM(p_vol)) > 0
      THEN v_ref := v_ref || TRIM(p_vol) || ': ';
   END IF;
   IF p_pages IS NOT NULL AND LENGTH(TRIM(p_pages)) > 0
      THEN v_ref := v_ref || TRIM(p_pages);
   END IF;

   IF LENGTH(TRIM(v_ref)) > 0
   THEN RETURN TRIM(v_ref);
   ELSE RETURN NULL;
   END IF;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION decode_yn
SELECT 'CREATE FUNCTION decode_yn';
-- ****************************************************************************
-- Decode 0/1 to N/Y.

DROP FUNCTION IF EXISTS decode_yn(NUMERIC) CASCADE;
CREATE OR REPLACE FUNCTION decode_yn (p_value NUMERIC)
RETURNS VARCHAR AS
$BODY$
BEGIN
   RETURN
      CASE p_value
         WHEN 0 THEN 'N'
         WHEN 1 THEN 'Y'
         ELSE NULL
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION decode_ynu
SELECT 'CREATE FUNCTION decode_ynu';
-- ****************************************************************************
-- Decode 0/1/2 to N/Y/U.

DROP FUNCTION IF EXISTS decode_ynu(NUMERIC) CASCADE;
CREATE OR REPLACE FUNCTION decode_ynu (p_value NUMERIC)
RETURNS VARCHAR AS
$BODY$
BEGIN
   RETURN
      CASE p_value
         WHEN 0 THEN 'N'
         WHEN 1 THEN 'Y'
         WHEN 2 THEN 'U'
         ELSE NULL
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;

-- ****************************************************************************
--\echo CREATE FUNCTION decode_ynu_na
SELECT 'CREATE FUNCTION decode_ynu_na';
-- ****************************************************************************
-- Decode 0/1/2/3 to N/Y/U/NA

DROP FUNCTION IF EXISTS decode_ynu_na(NUMERIC) CASCADE;
CREATE OR REPLACE FUNCTION decode_ynu_na (p_value NUMERIC)
RETURNS VARCHAR AS
$BODY$
BEGIN
   RETURN
      CASE p_value
         WHEN 0 THEN 'N'
         WHEN 1 THEN 'Y'
         WHEN 2 THEN 'U'
         WHEN 3 THEN 'NA'
         ELSE NULL
      END;
END;
$BODY$
LANGUAGE plpgsql IMMUTABLE;
