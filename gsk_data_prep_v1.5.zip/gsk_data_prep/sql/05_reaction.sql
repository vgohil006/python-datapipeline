--SET search_path = sbx_oasis_sample, oasis, meddra;
--SET search_path = oasis_staging, oasis, meddra;


-- ==========================================
-- reaction
-- ==========================================

DROP TABLE IF EXISTS m_smq_pt_map;
DROP TABLE IF EXISTS m_smq_list;
DROP TABLE IF EXISTS g_smq_list;
DROP TABLE IF EXISTS g_smq_pt_map;


CREATE TABLE g_smq_list AS SELECT * FROM meddra_smq_list;
CREATE TABLE m_smq_pt_map AS SELECT * FROM :meddra_schema.smq_pt_map;
CREATE TABLE m_smq_list AS SELECT * FROM :meddra_schema.smq_list;
--CREATE TABLE m_smq_pt_map AS SELECT * FROM smq_pt_map;
--CREATE TABLE m_smq_list AS SELECT * FROM smq_list;
CREATE INDEX idx_smq_pt_map_01 ON m_smq_pt_map(smq_name);
CREATE INDEX idx_smq_pt_map_02 ON m_smq_pt_map(pt_name);
CREATE INDEX idx_smq_pt_map_03 ON m_smq_pt_map(smq_type);

DROP TABLE IF EXISTS helper_primary_reaction;
CREATE TABLE helper_primary_reaction AS SELECT case_id, TRIM(split_part(event_primary, '(', 1 )) AS pt
FROM case_assess WHERE DELETED IS NULL;
ALTER TABLE helper_primary_reaction ADD CONSTRAINT pk_hpr PRIMARY KEY (case_id);



DROP TABLE IF EXISTS reaction CASCADE;
CREATE TABLE reaction (
    case_id INTEGER NOT NULL,
    primary_id TEXT NOT NULL,
    reaction_seq_num INTEGER, -- 
    reaction_sort_id INTEGER, --
    reaction_type TEXT, -- pt or smq
    smq_type INTEGER, -- narrow/alg/broad
    gskmq_yn VARCHAR(1),
    reaction_reported TEXT,
    reaction_diagnosis VARCHAR(1),
    reaction_llt_code INTEGER,
    reaction_llt TEXT,      --E.i.2.1b  reactionmeddrallt
    reaction_pt_plus_smq TEXT,
    reaction_hlt TEXT,
    reaction_hlgt TEXT,
    reaction_soc TEXT,
    reaction_soc_abbrev TEXT,
    reaction_smq_code INTEGER,
    evt_outcome_id INTEGER, reaction_outcome TEXT,  -- E.i.7
    reaction_serious_yn VARCHAR(1),
    reaction_serious_death_yn VARCHAR(1),  -- E.i.3.2a
    reaction_serious_life_threatening_yn VARCHAR(1),  -- E.i.3.2b
    reaction_serious_disabling_yn VARCHAR(1),  -- E.i.3.2d
    reaction_serious_congenital_anomaly_yn VARCHAR(1),  -- E.i.3.2e
    reaction_serious_reqd_intervention_yn VARCHAR(1),
    reaction_serious_hospitalization_yn VARCHAR(1),  -- E.i.3.2c
    reaction_serious_other_yn VARCHAR(1),  -- E.i.3.2f
    reaction_serious_other_text TEXT,
    reaction_serious_text VARCHAR(8),
    reaction_start_date TIMESTAMP WITHOUT TIME ZONE, -- E.i.4
    reaction_start_date_text TEXT,
    reaction_stop_date TIMESTAMP WITHOUT TIME ZONE,  -- E.i.5
    reaction_stop_date_text TEXT,
    reaction_duration_seconds BIGINT,  -- e.i.6a e.i.6b
    reaction_duration_text TEXT,
    reaction_latency_seconds BIGINT,
    reaction_latency_text TEXT,
    reaction_delay_seconds BIGINT,
    reaction_delay_text TEXT,
    evt_intensity_id INTEGER, reaction_intensity TEXT,
    evt_freq_id INTEGER, reaction_frequency TEXT,
    reaction_med_serious_yn VARCHAR(1), -- med_serious
    reaction_past_hist_ynu VARCHAR(1), -- past_hist
    reaction_rechall_related_yn VARCHAR(1),
    reaction_efficacy_yn VARCHAR(1),
    reaction_study_dropped_yn VARCHAR(1),
    reaction_study_related_ynu  VARCHAR(1),
    reaction_treated_ynu VARCHAR(1),
    reaction_primary_yn VARCHAR(1),
    reaction_details TEXT,
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1) NOT NULL,
    device_case_yn VARCHAR(1) NOT NULL,
    vaccine_case_yn VARCHAR(1) NOT NULL
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

/* Insert PTs from Oasis case_event*/
INSERT INTO reaction (
       case_id, primary_id, reaction_seq_num, reaction_sort_id, reaction_type,
       smq_type, gskmq_yn, reaction_reported, reaction_diagnosis,
       reaction_llt_code, reaction_llt, reaction_pt_plus_smq, reaction_hlt,
       reaction_hlgt, reaction_soc, reaction_soc_abbrev, reaction_smq_code,
       evt_outcome_id, reaction_outcome, reaction_serious_yn,
       reaction_serious_death_yn, reaction_serious_life_threatening_yn,
       reaction_serious_disabling_yn, reaction_serious_congenital_anomaly_yn, reaction_serious_reqd_intervention_yn,
       reaction_serious_hospitalization_yn, reaction_serious_other_yn, reaction_serious_other_text, reaction_serious_text,
       reaction_start_date, reaction_start_date_text, reaction_stop_date, reaction_stop_date_text,
       reaction_duration_seconds, reaction_duration_text, reaction_latency_seconds, reaction_latency_text,
       reaction_delay_seconds, reaction_delay_text, 
       evt_intensity_id, reaction_intensity, evt_freq_id, reaction_frequency, reaction_med_serious_yn, reaction_past_hist_ynu,
       reaction_rechall_related_yn, reaction_efficacy_yn, reaction_study_dropped_yn, reaction_study_related_ynu,
       reaction_treated_ynu, reaction_primary_yn, reaction_details,
       valid_case_yn, spont_case_yn, spont_valid_case_yn,
       drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT  cl.case_id,
        cl.case_num AS primary_id,
        r.seq_num AS reaction_seq_num,
        r.sort_id AS reaction_sort_id,
        'PT' AS reaction_type,
        NULL AS smq_type,
        'N' AS gskmq_yn,
        desc_reptd AS reaction_reported,
        DECODE_YN(r.diagnosis) AS reaction_diagnosis_yn,
        r.inc_code::INTEGER AS reaction_llt_code,
        r.inc_term AS reaction_llt,
        r.pref_term AS reaction_pt_plus_smq,
        r.hlt AS reaction_hlt,
        r.hlgt AS reaction_hlgt,
        r.body_sys AS reaction_soc,
        soc.soc_abbrev AS reaction_soc_abbrev,
        NULL AS reaction_smq_code,
        r.evt_outcome_id AS evt_outcome_id,
        lm_evt_outcome.evt_outcome AS reaction_outcome,
        DECODE_YN(r.seriousness)  AS reaction_serious_yn,
        DECODE_YN(r.sc_death)     AS reaction_serious_death_yn,
        DECODE_YN(r.sc_threat)    AS reaction_serious_life_threatening_yn,
        DECODE_YN(r.sc_disable)   AS reaction_serious_disabling_yn,
        DECODE_YN(r.sc_cong_anom) AS reaction_serious_congenital_anomaly_yn,
        DECODE_YN(r.sc_int_req)   AS reaction_serious_reqd_intervention_yn,
        DECODE_YN(r.sc_hosp)      AS reaction_serious_hospitalization_yn,
        DECODE_YN(r.sc_other)     AS reaction_serious_other_yn,
        r.sc_other_text AS reaction_serious_other_text,
       CASE WHEN r.sc_death     = 1 THEN 'F' ELSE '-' END 
    || CASE WHEN r.sc_threat    = 1 THEN 'L' ELSE '-' END 
    || CASE WHEN r.med_serious  = 1 THEN 'M' ELSE '-' END 
    || CASE WHEN r.sc_disable   = 1 THEN 'D' ELSE '-' END 
    || CASE WHEN r.sc_cong_anom = 1 THEN 'C' ELSE '-' END 
    || CASE WHEN r.sc_int_req   = 1 THEN 'I' ELSE '-' END 
    || CASE WHEN r.sc_hosp      = 1 THEN 'H' ELSE '-' END 
    || CASE WHEN r.sc_other     = 1 THEN 'O' ELSE '-' END  AS reaction_serious_text,
        r.onset AS reaction_start_date,
        r.onset_date_partial AS reaction_start_date_text,
        r.stop_date AS reaction_stop_date,
        r.stop_date_partial AS reaction_stop_date_text,
        r.duration_seconds AS reaction_duration_seconds,
        r.duration AS reaction_duration_text,
        r.onset_latency_seconds AS reaction_latency_seconds,
        r.onset_latency AS reaction_latency_text,
        r.onset_delay_seconds AS reaction_delay_seconds,
        r.onset_delay AS reaction_delay_text,
        r.evt_intensity_id AS evt_intensity_id,
        lm_evt_intensity.evt_intensity AS reaction_intensity,
        r.evt_freq_id AS evt_freq_id,
        lm_evt_frequency.evt_freq    AS reaction_frequency,
        DECODE_YN(r.med_serious)     AS reaction_med_serious_yn,
        DECODE_YNU(r.past_hist)      AS reaction_past_hist_ynu,
        DECODE_YN(r.rechall_related) AS reaction_rechall_related_yn,
        DECODE_YN(r.efficacy)        AS reaction_efficacy_yn,
        DECODE_YN(r.study_dropped)   AS reaction_study_dropped_yn,
        DECODE_YNU (r.study_related) AS reaction_study_related_ynu,
        DECODE_YNU(r.treated)        AS reaction_treated_ynu,
        CASE WHEN r.pref_term = hpr.pt THEN 'Y' ELSE 'N' END AS reaction_primary_yn, -- $$$ can be improved
        CASE WHEN LENGTH(TRIM(r.details))=0 THEN NULL ELSE r.details END AS reaction_details,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
  FROM case_list cl
      JOIN case_event r ON cl.case_id=r.case_id AND r.deleted IS NULL
 LEFT JOIN lm_evt_outcome  ON lm_evt_outcome.evt_outcome_id = r.evt_outcome_id AND lm_evt_outcome.deleted IS NULL
 LEFT JOIN lm_evt_intensity ON lm_evt_intensity.evt_intensity_id = r.evt_intensity_id AND lm_evt_intensity.deleted IS NULL
 LEFT JOIN lm_evt_frequency ON lm_evt_frequency.evt_freq_id = r.evt_freq_id AND lm_evt_frequency.deleted IS NULL
 LEFT JOIN meddra_soc soc ON soc.soc_code = r.soc_code::INTEGER AND soc.deleted IS NULL
 LEFT JOIN helper_primary_reaction hpr ON hpr.case_id=cl.case_id
 ;

CREATE UNIQUE INDEX reaction_ix0  ON reaction (case_id, reaction_seq_num);
CREATE INDEX reaction_ix11 ON reaction   (reaction_pt_plus_smq);
ANALYZE reaction;

DROP TABLE IF EXISTS tmp_algorithm;
CREATE TABLE tmp_algorithm (
    primary_id TEXT NOT NULL,
    smq_name TEXT NOT NULL,
    smq_code INTEGER NOT NULL)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);


-- -----------------------------------------------
-- Determine Algorithmic SMQs
-- Algorithm: A or (B and C) or (D and (B or C)) 
-- -----------------------------------------------

INSERT INTO tmp_algorithm (primary_id, smq_name, smq_code)
WITH tmp AS
   (    SELECT DISTINCT t1.primary_id, t2.smq_name, t3.smq_code, t2.term_category
      FROM reaction t1
      JOIN m_smq_pt_map t2 ON t1.reaction_pt_plus_smq = t2.pt_name
      JOIN m_smq_list t3 ON REPLACE(t2.smq_name, ' [algorithm]','')=t3.smq_name
     WHERE T2.smq_algorithm = 'A or (B and C) or (D and (B or C))')
SELECT primary_id, smq_name, smq_code
  FROM (-- A
        SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'A'
        UNION
        -- OR (B AND C)
        (
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'B'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'C'
        )
        UNION
        -- OR (D AND (B OR C))
        (
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'D'
             INTERSECT
             (
                  SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'B'
                  UNION
                  SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'C'
             )
        )
       ) t;


-- -----------------------------------------------
-- Determine Algorithmic SMQs
-- Algorithm: A or (B and C)
-- -----------------------------------------------
INSERT INTO tmp_algorithm (primary_id, smq_name, smq_code)
WITH
tmp AS (
    SELECT DISTINCT t1.primary_id, t2.smq_name, t3.smq_code, t2.term_category
      FROM reaction t1
      JOIN m_smq_pt_map t2
      JOIN m_smq_list t3 ON REPLACE(t2.smq_name, ' [algorithm]','')=t3.smq_name
        ON t1.reaction_pt_plus_smq = t2.pt_name
     WHERE t2.smq_algorithm = 'A or (B and C)')
SELECT primary_id, smq_name, smq_code
  FROM (-- A
        SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'A'
        UNION
        -- OR (B AND C)
        (
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'B'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'C'
        )
       ) t;


-- -----------------------------------------------
-- Determine Algorithmic SMQs
-- Algorithm: A or (B and C and D)
-- -----------------------------------------------
INSERT INTO tmp_algorithm (primary_id, smq_name, smq_code)
WITH
tmp AS (
    SELECT DISTINCT t1.primary_id, t2.smq_name, t3.smq_code, t2.term_category
      FROM reaction t1
      JOIN m_smq_pt_map t2 ON t1.reaction_pt_plus_smq = t2.pt_name
      JOIN m_smq_list t3 ON REPLACE(t2.smq_name, ' [algorithm]','')=t3.smq_name
     WHERE t2.smq_algorithm = 'A or (B and C and D)')
SELECT primary_id, smq_name, smq_code
  FROM (-- A
        SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'A'
        UNION
        -- OR (B AND C AND D)
        (
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'B'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'C'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'D'
        )
       ) t;


-- -----------------------------------------------
-- Determine Algorithmic SMQs
-- Algorithm: A or (B and C and D) or (B and C and E) or (B and D and E)
-- -----------------------------------------------
INSERT INTO tmp_algorithm (primary_id, smq_name, smq_code)
WITH
tmp AS (
    SELECT DISTINCT t1.primary_id, t2.smq_name, t3.smq_code, t2.term_category
      FROM reaction t1
      JOIN m_smq_pt_map t2 ON t1.reaction_pt_plus_smq = t2.pt_name
      JOIN m_smq_list t3 ON REPLACE(t2.smq_name, ' [algorithm]','')=t3.smq_name
     WHERE t2.smq_algorithm = 'A or (B and C and D) or (B and C and E) or (B and D and E)')
SELECT primary_id, smq_name, smq_code
  FROM (-- A
        SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'A'
        UNION
        -- OR (B AND C AND D)
        (
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'B'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'C'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'D'
        )
        UNION
        -- OR (B and C and E)
        (
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'B'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'C'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'E'
        )
        UNION
        -- OR (B and D and E)
        (
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'B'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'D'
             INTERSECT
             SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'E'
        )
       ) t;


-- -----------------------------------------------
-- Determine Algorithmic SMQs
-- Algorithm: A or Sum(Category Term Weight)>6
-- -----------------------------------------------
INSERT INTO tmp_algorithm (primary_id, smq_name, smq_code)
WITH
tmp AS (
    SELECT DISTINCT t1.primary_id, t2.smq_name, t3.smq_code, t2.term_category, t2.term_weight
      FROM reaction t1
      JOIN m_smq_pt_map t2 ON t1.reaction_pt_plus_smq = t2.pt_name
      JOIN m_smq_list t3 ON REPLACE(t2.smq_name, ' [algorithm]','')=t3.smq_name
     WHERE T2.smq_algorithm = 'A or Sum(Category Term Weight)>6')
SELECT primary_id, smq_name, smq_code
  FROM (
        SELECT primary_id, smq_name, smq_code FROM tmp WHERE term_category = 'A'
        UNION
        -- OR WEIGHTS > 6
        (
             SELECT primary_id, smq_name, smq_code
               FROM (SELECT primary_id, smq_name, smq_code, term_category, term_weight
                       FROM tmp WHERE term_category IN ('B','C','D','E','F','G','H','I')) tmp2
             GROUP BY primary_id, smq_name, smq_code
             HAVING SUM(term_weight) > 6
        )
       ) t;

CREATE INDEX tmp_algorithm_ix1 ON tmp_algorithm (primary_id);
ANALYZE tmp_algorithm;

-- -----------------------------------------------
-- Determine GSKMQs
-- -----------------------------------------------

-- Create SMQ PT Map for GSKMQs
DROP TABLE IF EXISTS temp_0 CASCADE;
DROP TABLE IF EXISTS g_smq_pt_map CASCADE;

CREATE TABLE temp_0
AS
WITH
  gskmq_list AS (SELECT *
                   FROM g_smq_list
                  WHERE TRIM(smq_name) LIKE '%(GSKMQ)'
                    AND TRIM(smq_name) NOT ILIKE 'reg rule%'
                    AND status='A'
                )
, L1_to_L2 AS
    ( SELECT t1.smq_code, t1.term_code
        FROM meddra_smq_content t1 JOIN gskmq_list t2 ON t1.term_code=t2.smq_code
       WHERE t1.term_status='A' AND t2.smq_level=2)
, L2_to_L3 AS
    ( SELECT t1.smq_code, t1.term_code
        FROM meddra_smq_content t1 JOIN gskmq_list t2 ON t1.term_code=t2.smq_code
       WHERE t1.term_status='A' AND t2.smq_level=3 )
, L3_to_L4 AS
    ( SELECT t1.smq_code, t1.term_code
        FROM meddra_smq_content t1 JOIN gskmq_list t2 ON t1.term_code=t2.smq_code
       WHERE t1.term_status='A' AND t2.smq_level=4 )
, L4_to_L5 AS
    ( SELECT t1.smq_code, t1.term_code
        FROM meddra_smq_content t1 JOIN gskmq_list t2 ON t1.term_code=t2.smq_code
       WHERE t1.term_status='A' AND t2.smq_level=5 )
, L3_to_L45 AS
    ( SELECT t1.smq_code, COALESCE(t2.term_code, t1.term_code) AS term_code
        FROM L3_to_L4 t1 LEFT JOIN L4_to_L5   t2 ON t1.term_code=t2.smq_code )
, L2_to_L345 AS
    ( SELECT t1.smq_code, COALESCE(t2.term_code, t1.term_code) AS term_code
        FROM L2_to_L3 t1 LEFT JOIN L3_to_L45  t2 ON t1.term_code=t2.smq_code )
, L1_to_L2345 AS
    ( SELECT t1.smq_code, COALESCE(t2.term_code, t1.term_code) AS term_code
        FROM L1_to_L2 t1 LEFT JOIN L2_to_L345 t2 ON t1.term_code=t2.smq_code )
SELECT
      t0.smq_name, t0.smq_code
    , COALESCE(t4.term_code, t3.term_code, t2.term_code, t1.term_code, t0.smq_code) AS term_code
  FROM      gskmq_list  t0
  LEFT JOIN L1_to_L2345 t1 ON t0.smq_code=t1.smq_code
  LEFT JOIN L2_to_L345  t2 ON t0.smq_code=t2.smq_code
  LEFT JOIN L3_to_L45   t3 ON t0.smq_code=t3.smq_code
  LEFT JOIN L4_to_L5    t4 ON t0.smq_code=t4.smq_code
;

CREATE TABLE g_smq_pt_map
(
  smq_name      TEXT,
  smq_code      INTEGER,
  pt_name       VARCHAR(100),
  smq_type      VARCHAR(10)
);


INSERT INTO g_smq_pt_map
       (smq_name, smq_code, pt_name, smq_type)
SELECT DISTINCT
       t0.smq_name || ' [narrow] (CMQ)' AS smq_name, t0.smq_code, pt.pt_name_english,
       'narrow' AS smq_type
  FROM temp_0 t0
  JOIN meddra_smq_content t1 ON t0.term_code=t1.smq_code
  JOIN meddra_pref_term_llt llt ON llt.llt_code=t1.term_code
  JOIN meddra_pref_term pt ON pt.pt_code=llt.pt_code
 WHERE t1.term_status='A'  AND t1.term_scope=2;
 
INSERT INTO g_smq_pt_map
       (smq_name, smq_code, pt_name, smq_type)
SELECT DISTINCT
       t0.smq_name || ' [broad] (CMQ)' AS smq_name, t0.smq_code, pt.pt_name_english,
       'broad' AS smq_type
  FROM temp_0      t0
  JOIN meddra_smq_content t1 ON t0.term_code=t1.smq_code
  JOIN meddra_pref_term_llt llt ON llt.llt_code=t1.term_code
  JOIN meddra_pref_term   pt ON pt.pt_code=llt.pt_code
 WHERE t1.term_status='A' AND llt.llt_currency='Y' AND llt.deleted IS NULL AND pt.deleted IS NULL;
 

DROP TABLE IF EXISTS temp_0 CASCADE;
DROP TABLE IF EXISTS smq_temp_1;
CREATE TABLE smq_temp_1
(
    case_id INTEGER NOT NULL,
    primary_id TEXT NOT NULL,
    smq_name TEXT, -- pt or smq
    smq_code INTEGER,
    smq_type TEXT,
    gskmq_yn VARCHAR(1) DEFAULT 'N',
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1)
);

-- Insert standard SMQs
INSERT INTO smq_temp_1 (case_id, primary_id, smq_name, smq_code, smq_type,
                        valid_case_yn, spont_case_yn, spont_valid_case_yn,
                        drug_case_yn, device_case_yn, vaccine_case_yn) 
SELECT DISTINCT
        t1.case_id,
        t1.primary_id,
        t2.smq_name,
        t3.smq_code,
        t2.smq_type,
        t1.valid_case_yn,
        t1.spont_case_yn,
        t1.spont_valid_case_yn,
        t1.drug_case_yn,
        t1.device_case_yn,
        t1.vaccine_case_yn
  FROM reaction t1
  JOIN m_smq_pt_map t2 ON t1.reaction_pt_plus_smq = t2.pt_name
  JOIN m_smq_list t3 ON REPLACE(REPLACE(t2.smq_name, ' [narrow]',''), ' [broad]','')=t3.smq_name
 WHERE t2.smq_type IN ('narrow', 'broad') AND t1.reaction_type = 'PT';

-- Insert GSKMQs
INSERT INTO smq_temp_1 (case_id, primary_id, smq_name, smq_code, smq_type,
                        valid_case_yn, spont_case_yn, spont_valid_case_yn,
                        drug_case_yn, device_case_yn, vaccine_case_yn, gskmq_yn) 
SELECT DISTINCT
        t1.case_id,
        t1.primary_id,
        t2.smq_name,
        t2.smq_code,
        t2.smq_type,
        t1.valid_case_yn,
        t1.spont_case_yn,
        t1.spont_valid_case_yn,
        t1.drug_case_yn,
        t1.device_case_yn,
        t1.vaccine_case_yn,
        'Y' AS gskmq_yn
  FROM reaction t1
  JOIN g_smq_pt_map t2 ON t1.reaction_pt_plus_smq = t2.pt_name
 WHERE t2.smq_type IN ('narrow', 'broad') AND t1.reaction_type = 'PT'
;

-- insert algorithmic SMQs
INSERT INTO smq_temp_1 (case_id, primary_id, smq_name, smq_code, smq_type, 
                        valid_case_yn, spont_case_yn, spont_valid_case_yn,
                        drug_case_yn, device_case_yn, vaccine_case_yn) 
SELECT DISTINCT
        case_list.case_id,
        smq.primary_id,
        smq.smq_name,
        smq.smq_code,
        'algorithm' AS smq_type,
        case_list.valid_case_yn,
        case_list.spont_case_yn,
        case_list.spont_valid_case_yn,
        case_list.drug_case_yn,
        case_list.device_case_yn,
        case_list.vaccine_case_yn   
 FROM tmp_algorithm smq
 JOIN case_list ON smq.primary_id = case_list.case_num;
 
DROP INDEX reaction_ix0;
DROP INDEX reaction_ix11;
INSERT INTO reaction (
       case_id, primary_id, reaction_seq_num, reaction_sort_id, reaction_type,
       smq_type, gskmq_yn, reaction_pt_plus_smq, reaction_hlt,
       reaction_hlgt, reaction_soc, reaction_soc_abbrev, reaction_smq_code,
       valid_case_yn, spont_case_yn, spont_valid_case_yn,
       drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT
        case_id,
        primary_id,
        0 - rank AS reaction_seq_num,
        1000+rank AS reaction_sort_id,
        CASE
--          WHEN smq_name like '%GSKMQ%' THEN 'GSKMQ'
          WHEN smq_name like '%GSKMQ%' THEN 'CMQ'
          WHEN smq_name like '%SMQ%' THEN 'SMQ'
          WHEN smq_name like '%(Targeted Follow-up)%' THEN 'Targeted Follow-up'
          ELSE 'CAT Profile' END AS reaction_type,
        CASE smq_type WHEN 'narrow' THEN 1 WHEN 'broad' THEN 3 ELSE 2 END AS smq_type,
        gskmq_yn,
        smq_name AS reaction_pt_plus_smq,
        CASE WHEN gskmq_yn='Y' THEN 'GSKMQ' ELSE 'SMQ' END AS reaction_hlt,
        CASE WHEN gskmq_yn='Y' THEN 'GSKMQ' ELSE 'SMQ' END AS reaction_hlgt,
        CASE WHEN gskmq_yn='Y' THEN 'GSKMQ' ELSE 'SMQ' END  AS reaction_soc,
        CASE WHEN gskmq_yn='Y' THEN 'GSKMQ' ELSE 'SMQ' END  AS reaction_soc_abbrev,
        smq_code AS reaction_smq_code,
        valid_case_yn,
        spont_case_yn,
        spont_valid_case_yn,
        drug_case_yn,
        device_case_yn,
        vaccine_case_yn
  FROM  (
 SELECT  case_id, primary_id, smq_name, smq_code, smq_type, gskmq_yn,
        valid_case_yn, spont_case_yn, spont_valid_case_yn,
        drug_case_yn, device_case_yn, vaccine_case_yn,
       RANK() OVER (PARTITION BY case_id ORDER BY smq_name DESC) AS rank
       FROM smq_temp_1) t0;

ALTER TABLE reaction ADD CONSTRAINT pk_reaction PRIMARY KEY(primary_id, reaction_seq_num);
CREATE UNIQUE INDEX reaction_ix0  ON reaction (case_id, reaction_seq_num);
ANALYZE reaction;

-- -----------------------------------------------
-- Create SMQ_SYN_TERMS
-- -----------------------------------------------
DROP TABLE IF EXISTS smq_syn_terms;
CREATE TABLE smq_syn_terms AS
SELECT DISTINCT reaction_pt_plus_smq AS value
  FROM reaction
 WHERE smq_type > 0;

ANALYZE smq_syn_terms;

DROP TABLE IF EXISTS tmp_algorithm;
DROP TABLE IF EXISTS smq_temp_1;
DROP TABLE IF EXISTS g_smq_pt_map;
DROP TABLE IF EXISTS g_smq_list;
DROP TABLE IF EXISTS m_smq_pt_map;
DROP TABLE IF EXISTS m_smq_list;
DROP TABLE IF EXISTS helper_primary_reaction;


