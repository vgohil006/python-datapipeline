--SET search_path = oasis_staging, oasis, meddra;
--SET search_path = sbx_oasis_sample, oasis, meddra;
DROP TABLE IF EXISTS patient_hist CASCADE;

-- Create Table patient_hist

CREATE table patient_hist(
case_id INTEGER NOT NULL,
primary_id VARCHAR(20) NOT NULL,
patient_hist_seq_num INTEGER NOT NULL,
patient_hist_sort_id INTEGER,
condition_type_id INTEGER,
cond_type TEXT,
start_date TIMESTAMP WITHOUT TIME ZONE,
start_date_text TEXT,
stop_date TIMESTAMP WITHOUT TIME ZONE,
stop_date_text TEXT,
continue    TEXT,
patient_or_parent   TEXT,
condition   TEXT,
indication  TEXT,
reaction    TEXT,
item_code_status    TEXT,
ind_code_status     TEXT,
react_code_status   TEXT,
item_reptd  TEXT,
item_llt_code   INTEGER,
item_llt        TEXT,
item_pt     TEXT,
item_hlt    TEXT,
item_hlgt   TEXT,
item_soc    TEXT,
item_soc_abbrev TEXT,
item_w_type     TEXT,
ind_reptd   TEXT,
ind_llt_code    INTEGER,
ind_llt     TEXT,
ind_pt      TEXT,
ind_hlt TEXT,
ind_hlgt    TEXT,
ind_soc TEXT,
ind_soc_abbrev  TEXT,
react_reptd TEXT,
react_llt_code  INTEGER,
react_llt   TEXT,
react_pt    TEXT,
react_hlt   TEXT,
react_hlgt  TEXT,
react_soc   TEXT,
react_soc_abbrev    TEXT,
note    TEXT,
valid_case_yn   VARCHAR(1),
spont_case_yn   VARCHAR(1),
spont_valid_case_yn VARCHAR(1),
drug_case_yn    VARCHAR(1),
device_case_yn  VARCHAR(1),
vaccine_case_yn VARCHAR(1)
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO patient_hist    (case_id, primary_id,
                             patient_hist_seq_num, patient_hist_sort_id,
                             condition_type_id, cond_type,
                             start_date, start_date_text,
                             stop_date, stop_date_text,
                             continue, patient_or_parent, condition, 
                             indication, reaction,
                             item_code_status, ind_code_status, react_code_status,
                             item_reptd, item_llt_code,
                             item_llt, item_pt, item_hlt, item_hlgt, item_soc, item_soc_abbrev,
                             item_w_type,
                             ind_reptd, ind_llt_code,
                             ind_llt, ind_pt, ind_hlt, ind_hlgt, ind_soc, ind_soc_abbrev,
                             react_reptd, react_llt_code,
                             react_llt, react_pt, react_hlt, react_hlgt, react_soc, react_soc_abbrev,
                             note, 
                             valid_case_yn, spont_case_yn, spont_valid_case_yn,
                             drug_case_yn, device_case_yn, vaccine_case_yn )
SELECT cl.case_id,
cl.case_num,
cph.seq_num,
cph.sort_id,
cph.condition_type_id,
lct.cond_type,
cph.start_date,
cph.start_date_partial,
cph.stop_date,
cph.stop_date_partial,
CASE when cph.continue = 0 then 'Not Ongoing'
     when cph.continue = 1 then 'Ongoing'
     when cph.continue = 2 then 'Unknown' END AS continue,
CASE when cph.parent = 0 then 'Patient'
     when cph.parent = 1 then 'Parent' END AS patient_or_parent,
cph.condition,
cph.indication,
cph.reaction,
CASE when cph.item_code_status = 0 then 'Not Coded'
     when cph.item_code_status = 1 then 'Coded'
     when cph.item_code_status = 2 then 'Coded Manually'
     when cph.item_code_status = 3 then 'Coding Pending'
     when cph.item_code_status = 4 then 'Coding Error'
     when cph.item_code_status = 5 then 'CODED, NOT CURRENT'
END AS item_code_status,
CASE when cph.ind_code_status = 0 then 'Not Coded'
     when cph.ind_code_status = 1 then 'Coded'
     when cph.ind_code_status = 2 then 'Coded Manually'
     when cph.ind_code_status = 3 then 'Coding Pending'
     when cph.ind_code_status = 4 then 'Coding Error' 
     when cph.ind_code_status = 5 then 'CODED, NOT CURRENT'
END AS ind_code_status,
CASE when cph.react_code_status = 0 then 'Not Coded'
     when cph.react_code_status = 1 then 'Coded'
     when cph.react_code_status = 2 then 'Coded Manually'
     when cph.react_code_status = 3 then 'Coding Pending'
     when cph.react_code_status = 4 then 'Coding Error'
     when cph.react_code_status = 5 then 'CODED, NOT CURRENT'
END AS react_code_status,
cph.item_reptd,
cph.item_llt_code::INTEGER,
cph.item_llt,
--CASE WHEN item_hlt IS NOT NULL THEN cph.item_coded END AS item_pt,
cph.item_coded AS item_pt,
cph.item_hlt,
cph.item_hlgt,
cph.item_soc,
soc1.soc_abbrev,
CASE WHEN COALESCE(item_coded, condition) IS NOT NULL
      THEN  COALESCE(item_coded, condition) || '(' || map.abbrev || ')'
END AS item_w_type,
cph.ind_reptd,
cph.ind_llt_code::INTEGER,
cph.ind_llt,
cph.ind_coded AS ind_pt,
cph.ind_hlt,
cph.ind_hlgt,
cph.ind_soc,
soc2.soc_abbrev,
cph.react_reptd,
cph.react_llt_code::INTEGER,
cph.react_llt,
cph.react_coded,
cph.react_hlt,
cph.react_hlgt,
cph.react_soc,
soc3.soc_abbrev,
CASE WHEN LENGTH(cph.note) = 0 THEN NULL ELSE note END AS note,
cl.valid_case_yn,
cl.spont_case_yn,
cl.spont_valid_case_yn,
cl.drug_case_yn,
cl.device_case_yn,
cl.vaccine_case_yn
FROM case_list cl 
JOIN case_pat_hist cph ON cl.case_id = cph.case_id AND cph.deleted IS NULL
LEFT JOIN lm_condition_type lct ON lct.condition_type_id = cph.condition_type_id  AND lct.deleted IS NULL
LEFT JOIN medhist_map map ON map.condition_type=lct.cond_type
LEFT JOIN meddra_soc soc1 ON soc1.soc_code = cph.item_soc_code::INTEGER AND soc1.deleted IS NULL
LEFT JOIN meddra_soc soc2 ON soc2.soc_code = cph.ind_soc_code::INTEGER AND soc2.deleted IS NULL
LEFT JOIN meddra_soc soc3 ON soc3.soc_code = cph.react_soc_code::INTEGER AND soc3.deleted IS NULL;

ALTER TABLE patient_hist ADD CONSTRAINT pk_patient_hist PRIMARY KEY(case_id, patient_hist_seq_num); 
CREATE UNIQUE INDEX ix_patient_hist  ON patient_hist (primary_id, patient_hist_seq_num); 

-- Analyze Table
ANALYZE patient_hist;
