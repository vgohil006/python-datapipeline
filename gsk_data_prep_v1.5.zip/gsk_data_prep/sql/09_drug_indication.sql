
--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS drug_indication CASCADE;
CREATE TABLE drug_indication (
    case_id INTEGER NOT NULL,
    primary_id TEXT NOT NULL,
    prod_seq_num INTEGER NOT NULL,
    ind_seq_num INTEGER NOT NULL,
    ind_sort_id INTEGER NOT NULL,
    product_name TEXT,
    generic_name TEXT,
    family_name_enhanced TEXT,
    ind_reptd TEXT, -- G.k.7.r.1
    ind_llt_code INTEGER, -- G.k.7.r.2b
    ind_llt TEXT,
    ind_pt TEXT,
    ind_hlt TEXT,
    ind_hlgt TEXT,
    ind_soc TEXT,
    ind_soc_abbrev TEXT,
    valid_case_yn VARCHAR(1) NOT NULL,
    spont_case_yn VARCHAR(1) NOT NULL,
    spont_valid_case_yn VARCHAR(1) NOT NULL,
    drug_case_yn VARCHAR(1) NOT NULL,
    device_case_yn VARCHAR(1) NOT NULL,
    vaccine_case_yn VARCHAR(1) NOT NULL) WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false
);

INSERT INTO drug_indication (
    case_id, primary_id, prod_seq_num, ind_seq_num, ind_sort_id,
    product_name, generic_name, family_name_enhanced,
    ind_reptd, ind_llt_code, ind_llt, ind_pt, ind_hlt, ind_hlgt, ind_soc, ind_soc_abbrev,
    valid_case_yn, spont_case_yn, spont_valid_case_yn, drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT
        d.case_id,
        d.primary_id,
        d.prod_seq_num,
        t1.seq_num AS ind_seq_num,
        t1.sort_id AS ind_sort_id,
        d.product_name,
        d.generic_name,
        d.family_name_enhanced,
        t1.ind_reptd,
        t1.ind_llt_code::INTEGER AS ind_llt_code,
        t1.ind_llt,
        t1.ind_pref_term AS ind_pt,
        t1.ind_hlt AS ind_hlt,
        t1.ind_hlgt AS ind_hlgt,
        t1.ind_soc  AS ind_soc,
        soc.soc_abbrev AS indication_soc_abbrev,
        d.valid_case_yn,
        d.spont_case_yn,
        d.spont_valid_case_yn,
        d.drug_case_yn,
        d.device_case_yn,
        d.vaccine_case_yn
  FROM drug d
       JOIN case_prod_indications t1 ON d.case_id=t1.case_id and d.prod_seq_num=t1.prod_seq_num
  LEFT JOIN meddra_soc soc ON soc.soc_code = t1.ind_soc_code::INTEGER
  WHERE t1.ind_llt_code IS NOT NULL OR t1.ind_pref_term IS NOT NULL OR ind_reptd IS NOT NULL;
  

CREATE UNIQUE INDEX drugindication_ix1 ON drug_indication(primary_id, prod_seq_num,ind_seq_num);
CREATE UNIQUE INDEX drugindication_ix2 ON drug_indication(case_id, prod_seq_num,ind_seq_num);

ANALYZE drug_indication;


 
