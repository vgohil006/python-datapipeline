DROP TABLE IF EXISTS country_region_map CASCADE;

CREATE TABLE country_region_map (country TEXT, region TEXT, CONSTRAINT pk_country_region_map PRIMARY KEY(country));
