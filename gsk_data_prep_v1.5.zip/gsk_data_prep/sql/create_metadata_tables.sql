CREATE TABLE :table_name (
   table_name VARCHAR NOT NULL PRIMARY KEY,
   group_name VARCHAR NOT NULL,
   key1 VARCHAR,
   key2 VARCHAR,
   key3 VARCHAR,
   is_anchor VARCHAR(1) NOT NULL,
   is_sparse VARCHAR(1),
   is_timestamped VARCHAR(1)
);
