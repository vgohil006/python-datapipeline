--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS pregnancy CASCADE;

CREATE TABLE pregnancy
(
    case_id INTEGER,
    primary_id VARCHAR(20),
    date_of_lmp TIMESTAMP WITHOUT TIME ZONE,
    date_of_lmp_text TEXT,
    due_date TIMESTAMP WITHOUT TIME ZONE,
    gest_period REAL,
    gest_period_unit_id INTEGER,
    gest_period_unit TEXT,
    exp_trimester TEXT,
    gestation_exp_period INTEGER,
    parent_or_patient TEXT,
    breastfeeding_yn VARCHAR(1),
    prospective TEXT,
    number_of_fetus INTEGER,
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1))
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO pregnancy (
    case_id, primary_id, date_of_lmp, date_of_lmp_text, due_date, gest_period, gest_period_unit_id, gest_period_unit,
    exp_trimester, gestation_exp_period, parent_or_patient, breastfeeding_yn, prospective, number_of_fetus,
    valid_case_yn, spont_case_yn, spont_valid_case_yn, drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT  cl.case_id,
        cl.case_num as primary_id,
        date_of_lmp,
        date_of_lmp_partial AS date_of_lmp_text,
        due_date,
        gest_period,
        gest_period_unit AS gest_period_unit_id,
        lm_age_units.age_unit AS gest_period_unit,
        CASE exp_trimester
            WHEN NULL THEN 'Unknown'
            WHEN 0 THEN 'Unknown'
            WHEN 1 THEN 'First'
            WHEN 2 THEN 'Second'
            WHEN 1+2 THEN 'First, Second'
            WHEN 4 THEN 'Third'
            WHEN 1+4 THEN 'First, Third'
            WHEN 2+4 THEN 'Second, Third'
            WHEN 1+2+4 THEN 'First, Second, Third'
        END AS exp_trimester,
        gestation_exp_period,
        CASE parent
            WHEN 0 THEN 'Patient'
            WHEN 1 THEN 'Parent'
            ELSE NULL
        END AS parent_or_patient,
        DECODE_YN(breastfeeding) AS breastfeeding_yn,
        CASE prospective
            WHEN -1 THEN 'Unknown'
            WHEN 1 THEN 'Prospective'
            WHEN 2 THEN 'Retrospective'
        END  AS prospective,
        number_of_fetus,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
     FROM case_list cl
     JOIN case_pregnancy p ON cl.case_id = p.case_id AND p.deleted IS NULL
LEFT JOIN lm_age_units ON lm_age_units.age_unit_id = p.gest_period_unit AND lm_age_units.deleted IS NULL
    WHERE (COALESCE(breastfeeding, exp_trimester, gestation_exp_period, gestation_period, prospective) IS NOT NULL
    OR     COALESCE(date_of_lmp, due_date) IS NOT NULL)
;

ALTER TABLE pregnancy ADD CONSTRAINT pk_pregnancy PRIMARY KEY(case_id, parent_or_patient); 
CREATE UNIQUE INDEX pregnancy_ix1 ON pregnancy (primary_id, parent_or_patient); 

ANALYZE pregnancy;
