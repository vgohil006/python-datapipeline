CREATE TABLE valid_asof (
   valid_start TIMESTAMP WITHOUT TIME ZONE NOT NULL
);
