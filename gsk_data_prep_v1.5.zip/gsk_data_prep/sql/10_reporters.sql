
--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS reporters CASCADE;

CREATE TABLE reporters (
    case_id INTEGER,
    primary_id VARCHAR(20),
    reporter_seq_num INTEGER,
    reporter_sort_id INTEGER,
    reporter_country_id INTEGER,
    reporter_country TEXT,
    reporter_country_region TEXT,
    reporter_type_id INTEGER,
    reporter_type TEXT,
    reporter_type_abbrev TEXT,
    hcp_ynu VARCHAR(1),
    intermediary_id INTEGER,
    intermediary TEXT,
    reporter_type_intermediary TEXT,
    sent_to_authority VARCHAR,
    media_id INTEGER,
    media TEXT,
    primary_contact_yn VARCHAR(1),
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1))
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO reporters (
    case_id, primary_id, reporter_seq_num, reporter_sort_id,
    reporter_country_id, reporter_country, reporter_country_region,
    reporter_type_id, reporter_type, reporter_type_abbrev,
    hcp_ynu, intermediary_id, intermediary, reporter_type_intermediary, sent_to_authority, media_id, media,
    primary_contact_yn,
    valid_case_yn, spont_case_yn, spont_valid_case_yn, drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT  cl.case_id,
        cl.case_num AS primary_id,
        t1.seq_num AS reporter_seq_num,
        t1.sort_id AS reporter_sort_id,
        t1.country_id AS reporter_country_id,
        lm_c.country AS reporter_country,
        crm.region AS reporter_country_region,
        t1.reporter_type AS reporter_type_id,
        lm_rt.reporter_type,
        map.abbrev AS reporter_type_abbrev,
        DECODE_YNU(t1.hcp_flag) AS hcp_ynu,
        t1.intermediary_id,
        lm_i.intermediary,
        CASE WHEN t1.reporter_type IS NOT NULL OR t1.intermediary_id IS NOT NULL
            THEN COALESCE(lm_rt.reporter_type, 'Unk') || '(' || COALESCE(lm_i.intermediary, 'Unk') || ')'
        END AS reporter_type_intermediary,
        DECODE_YNU(t1.rpt_sent) AS sent_to_authority_ynu,
        t1.media_id,
        lm_rm.media,
        DECODE_YN(t1.primary_contact) AS primary_contact_yn,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
     FROM case_list cl
     JOIN oasis_case_reporters t1 ON cl.case_id=t1.case_id AND t1.deleted IS NULL
LEFT JOIN lm_countries lm_c ON lm_c.country_id=t1.country_id AND lm_c.deleted IS NULL
LEFT JOIN country_region_map crm ON crm.country=lm_c.country
LEFT JOIN lm_reporter_type lm_rt ON lm_rt.rptr_type_id=t1.reporter_type AND lm_rt.deleted IS NULL
LEFT JOIN lm_intermediary lm_i ON lm_i.intermediary_id=t1.intermediary_id AND lm_i.deleted IS NULL
LEFT JOIN lm_report_media lm_rm ON lm_rm.media_id=t1.media_id AND lm_rm.deleted IS NULL
LEFT JOIN reporter_type_map map ON map.reporter_type=lm_rt.reporter_type
;

ALTER TABLE reporters ADD CONSTRAINT pk_reporters PRIMARY KEY(primary_id, reporter_seq_num);
CREATE UNIQUE INDEX reporters_ix1 ON reporters(case_id, reporter_seq_num);
ANALYZE reporters;

