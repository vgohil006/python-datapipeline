--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS patient_deathcause CASCADE;
CREATE TABLE patient_deathcause(
    case_id INTEGER NOT NULL,
    primary_id TEXT NOT NULL,
    deathcause_seq_num INTEGER,
    deathcause_sort_id INTEGER,
    death_date_text TEXT,
    death_date DATE,
    autopsy_date_text TEXT,
    autopsy_date DATE,
    autopsy_status TEXT,
    cause_type TEXT,
    cause_reptd TEXT,
    cause_llt_code INTEGER,
    cause_llt TEXT,
    cause_pt TEXT,
    cause_hlt TEXT,
    cause_hlgt TEXT,
    cause_soc TEXT,
    cause_soc_abbrev TEXT,
    valid_case_yn VARCHAR(1) NOT NULL,
    spont_case_yn VARCHAR(1) NOT NULL,
    spont_valid_case_yn VARCHAR(1) NOT NULL,
    drug_case_yn VARCHAR(1) NOT NULL,
    device_case_yn VARCHAR(1) NOT NULL,
    vaccine_case_yn VARCHAR(1) NOT NULL
    )
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

--ALTER TABLE patient_deathcause owner to sbx_oasis_sample;

INSERT INTO patient_deathcause (
 	case_id, primary_id, deathcause_seq_num, deathcause_sort_id,
    death_date_text, death_date, autopsy_date_text, autopsy_date, autopsy_status, cause_type, cause_reptd,
    cause_llt_code, cause_llt, cause_pt, cause_hlt, cause_hlgt, cause_soc, cause_soc_abbrev,
    valid_case_yn, spont_case_yn, spont_valid_case_yn, drug_case_yn, device_case_yn, vaccine_case_yn)
   SELECT
        cl.case_id,
        cl.case_num AS primary_id,
        COALESCE(t2.seq_num,-1) AS deathcause_seq_num,
        COALESCE(t2.sort_id,1) AS deathcause_sort_id,
        t1.death_date_partial AS death_date_text,
        t1.death_date,
        CASE WHEN term_type = 2 THEN death_date_partial ELSE NULL END AS autopsy_date_text,
        CASE WHEN term_type = 2 THEN death_date ELSE NULL END AS autopsy_date,        
        CASE t1.autopsy
            WHEN 0 THEN 'No Selection(blank)'
            WHEN 4 THEN 'Autopsy not done'
            WHEN 8 THEN 'Autopsy done'
            WHEN 9 THEN 'Autopsy done, results available'
            WHEN 10 THEN 'Autopsy done, results not available'
            WHEN 12 THEN 'Unknown'
        END AS autopsy_status,
        CASE t2.term_type WHEN 1 THEN 'Cause of Death' WHEN 2 THEN 'Autopsy Result' END AS cause_type,
        t2.cause_reptd,
        COALESCE(t2.cause_llt_code, t2.cause_code)::INTEGER AS cause_llt_code,
        t2.cause_llt,
        t2.cause AS cause_pt,
        t2.cause_hlt,
        t2.cause_hlgt,
        t2.cause_soc,
        soc.soc_abbrev AS cause_soc_abbrev,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
     FROM case_list cl
LEFT JOIN case_death           t1 ON t1.case_id=cl.case_id AND t1.deleted IS NULL
LEFT JOIN case_death_details   t2 ON t2.case_id=cl.case_id AND t2.deleted IS NULL
LEFT JOIN meddra_soc soc ON soc.soc_code = t2.cause_soc_code::INTEGER AND soc.deleted IS NULL
WHERE t1.death_date IS NOT NULL OR t1.death_date_partial IS NOT NULL OR COALESCE(t1.autopsy,0) <> 0 
   OR t2.term_type IS NOT NULL OR t2.cause_reptd IS NOT NULL OR T2.cause IS NOT NULL;


ALTER TABLE patient_deathcause ADD CONSTRAINT pk_patientdeathcause PRIMARY KEY(primary_id, deathcause_seq_num);
CREATE UNIQUE INDEX patientdeathcause_idx1 ON patient_deathcause(case_id,deathcause_seq_num);
ANALYZE patient_deathcause;





