
--SET search_path = sbx_oasis_sample, oasis, meddra;
--SET search_path = oasis_staging, oasis, meddra;

-- --------------------------------------------------------
-- helper_subpop
-- --------------------------------------------------------
DROP TABLE IF EXISTS helper_age;
CREATE TABLE helper_age
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
   SELECT
        cl.case_id,
        calc_age_group3(pat.pat_age, lm_age_units.age_unit, lm_age_groups.group_name) AS age_group3
     FROM case_list cl
     JOIN oasis_case_pat_info pat ON cl.case_id=pat.case_id AND pat.deleted IS NULL
LEFT JOIN lm_age_units  ON pat.age_unit_id = lm_age_units.age_unit_id AND lm_age_units.deleted IS NULL
LEFT JOIN lm_age_groups ON pat.age_group_id = lm_age_groups.age_group_id AND lm_age_groups.deleted IS NULL;

ALTER TABLE helper_age ADD CONSTRAINT pk_helper_age PRIMARY KEY(case_id, age_group3);
ANALYZE helper_age;

DROP TABLE IF EXISTS helper_subpop;
CREATE TABLE helper_subpop
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
SELECT
   cl.case_id,
   CASE udf_od.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_overdose_yn,
   CASE udf_ab.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_abuse_yn,
   CASE udf_fa.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_fatal_yn,
   CASE udf_in.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_interact_yn,
   CASE udf_co.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_complaint_yn,
   CASE udf_el.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_age_elderly_yn,
   CASE udf_ad.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_age_adolescent_yn,
   CASE udf_ch.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_age_child_yn,
   CASE udf_pr.description WHEN NULL THEN 'U' WHEN 'Yes' THEN 'Y' WHEN 'No' THEN 'N' ELSE 'U' END AS subpop_pregnancy_yn
  FROM case_list cl
  JOIN case_master cm ON cm.case_id=cl.case_id
  LEFT JOIN case_assess ca ON ca.case_id=cl.case_id AND ca.deleted IS NULL
  LEFT JOIN oasis_case_pat_info pi ON pi.case_id=cl.case_id AND pi.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_od ON udf_od.id=ca.ud_number_7 AND udf_od.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_ab ON udf_ab.id=ca.ud_number_8 AND udf_ab.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_fa ON udf_fa.id=ca.ud_number_5 AND udf_fa.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_in ON udf_in.id=ca.ud_number_6 AND udf_in.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_co ON udf_co.id=cm.ud_number_3 AND udf_co.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_el ON udf_el.id=pi.ud_number_5 AND udf_el.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_ad ON udf_ad.id=pi.ud_number_4 AND udf_ad.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_ch ON udf_ch.id=pi.ud_number_3 AND udf_ch.deleted IS NULL
  LEFT JOIN lm_UDF_DDL_VALUES udf_pr ON udf_pr.id=pi.ud_number_2 AND udf_pr.deleted IS NULL;
  
ALTER TABLE helper_subpop ADD CONSTRAINT pk_helper_subpop PRIMARY KEY(case_id);
ANALYZE helper_subpop;


-- --------------------------------------------------------
-- helper_seriousness, brings seriousness criteria from event
-- level to case level
-- --------------------------------------------------------
DROP TABLE IF EXISTS helper_seriousness;
CREATE TABLE helper_seriousness
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
 SELECT t0.case_id,
    CASE WHEN MAX(sc_death)  = 1 THEN 'Y' ELSE 'N' END AS serious_death_yn,
    CASE WHEN MAX(sc_threat) = 1 THEN 'Y' ELSE 'N' END AS serious_life_threatening_yn,
    CASE WHEN MAX(sc_disable)   = 1 THEN 'Y' ELSE 'N' END AS serious_disabling_yn,
    CASE WHEN MAX(sc_cong_anom) = 1 THEN 'Y' ELSE 'N' END AS serious_congenital_anomaly_yn,
    CASE WHEN MAX(sc_int_req)   = 1 THEN 'Y' ELSE 'N' END AS serious_reqd_intervention_yn,
    CASE WHEN MAX(sc_hosp)      = 1 THEN 'Y' ELSE 'N' END AS serious_hospitalization_yn,
    CASE WHEN MAX(sc_other)     = 1 THEN 'Y' ELSE 'N' END AS serious_other_yn,
       CASE WHEN MAX(sc_death)     = 1 THEN 'F' ELSE '-' END 
    || CASE WHEN MAX(sc_threat)    = 1 THEN 'L' ELSE '-' END 
    || CASE WHEN MAX(med_serious)  = 1 THEN 'M' ELSE '-' END 
    || CASE WHEN MAX(sc_disable)   = 1 THEN 'D' ELSE '-' END 
    || CASE WHEN MAX(sc_cong_anom) = 1 THEN 'C' ELSE '-' END 
    || CASE WHEN MAX(sc_int_req)   = 1 THEN 'I' ELSE '-' END 
    || CASE WHEN MAX(sc_hosp)      = 1 THEN 'H' ELSE '-' END 
    || CASE WHEN MAX(sc_other)     = 1 THEN 'O' ELSE '-' END  AS serious_text
 FROM case_list t0
 LEFT JOIN case_event t1 ON t0.case_id=t1.case_id AND t1.deleted IS NULL
 GROUP BY t0.case_id;
ALTER TABLE helper_seriousness ADD CONSTRAINT pk_hs PRIMARY KEY(case_id) WITH (FILLFACTOR=100);
ANALYZE helper_seriousness;


-- --------------------------------------------------------
-- helper_n, # events, # suspect drugs, #conmeds, # drugs
-- --------------------------------------------------------
DROP TABLE IF EXISTS helper_n_events;
 CREATE TABLE helper_n_events
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
   SELECT t0.case_id, count(distinct pref_term) AS num_reactions
     FROM case_list t0
     JOIN case_event t1 ON t0.case_id=t1.case_id
 GROUP BY 1;
ALTER TABLE helper_n_events ADD CONSTRAINT pk_he PRIMARY KEY(case_id) WITH (FILLFACTOR=100);
ANALYZE helper_n_events;

DROP TABLE IF EXISTS helper_n_susp;
 CREATE TABLE helper_n_susp
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
   SELECT t0.case_id, count(distinct product_name) AS num_suspect
     FROM case_list t0
     JOIN case_product t1 ON t0.case_id=t1.case_id
    WHERE drug_type =1
 GROUP BY 1;

DROP TABLE IF EXISTS helper_n_conmed;
 CREATE TABLE helper_n_conmed
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
   SELECT t0.case_id, count(distinct product_name) AS num_conmed
     FROM case_list t0
     JOIN case_product t1 ON t0.case_id=t1.case_id
    WHERE drug_type = 2
 GROUP BY 1;

DROP TABLE IF EXISTS helper_n_all;
 CREATE TABLE helper_n_all
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
   SELECT t0.case_id, count(distinct product_name) AS num_therapies
     FROM case_list t0
     JOIN case_product t1 ON t0.case_id=t1.case_id
 GROUP BY 1;

DROP TABLE IF EXISTS helper_n;
CREATE TABLE helper_n
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
   SELECT t1.case_id, t1.num_therapies, COALESCE(t2.num_suspect,0) AS num_suspect,
          COALESCE(t3.num_conmed,0) AS num_conmed, COALESCE(t4.num_reactions,0) AS num_reactions
     FROM helper_n_all t1
LEFT JOIN helper_n_susp t2 ON t2.case_id=t1.case_id
LEFT JOIN helper_n_conmed t3 ON t3.case_id=t1.case_id
LEFT JOIN helper_n_events t4 ON t4.case_id=t1.case_id;

ALTER TABLE helper_n ADD CONSTRAINT pk_hn PRIMARY KEY(case_id) WITH (FILLFACTOR=100);
ANALYZE helper_n;

DROP TABLE IF EXISTS helper_n_susp;
DROP TABLE IF EXISTS helper_n_conmed;
DROP TABLE IF EXISTS helper_n_all;
DROP TABLE IF EXISTS helper_n_events;

-- --------------------------------------------------------
-- helper_rep: rpt_src_consumer_yn, rpt_src_literature_yn,
--             rpt_src_health_professional_yn,
--             rpt_src_regulatory_authority_yn, rpt_src_lawyer_yn
-- --------------------------------------------------------
DROP TABLE IF EXISTS helper_rep_regulatory;
CREATE TABLE helper_rep_regulatory
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
SELECT DISTINCT t0.case_id
  FROM case_list t0
  JOIN oasis_case_reporters t1 ON t0.case_id=t1.case_id
  JOIN lm_reporter_type t2 ON t1.reporter_type=t2.rptr_type_id
  WHERE t2.reporter_type = 'Regulatory Authority'
  AND t1.deleted IS NULL AND t2.deleted IS NULL;
ANALYZE helper_rep_regulatory;

DROP TABLE IF EXISTS helper_rep_consumer;
CREATE TABLE helper_rep_consumer
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
SELECT DISTINCT t0.case_id
  FROM case_list t0
  JOIN oasis_case_reporters t1 ON t0.case_id=t1.case_id AND t1.deleted IS NULL 
  JOIN lm_reporter_type t2 ON t1.reporter_type=t2.rptr_type_id AND t2.deleted IS NULL
 WHERE t2.reporter_type='Consumer';
ANALYZE helper_rep_consumer;

DROP TABLE IF EXISTS helper_rep_lawyer;
CREATE TABLE helper_rep_lawyer
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
SELECT DISTINCT t0.case_id
  FROM case_list t0
  JOIN oasis_case_reporters t1 ON t0.case_id=t1.case_id  AND t1.deleted IS NULL
  JOIN lm_reporter_type t2 ON t1.reporter_type=t2.rptr_type_id  AND t2.deleted IS NULL
 WHERE t2.reporter_type='Lawyer';
ANALYZE helper_rep_lawyer;

DROP TABLE IF EXISTS helper_rep_hp;
CREATE TABLE helper_rep_hp
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
SELECT DISTINCT t0.case_id
  FROM case_list t0
  JOIN oasis_case_reporters t1 ON t0.case_id=t1.case_id AND t1.deleted IS NULL
  WHERE t1.hcp_flag=1;
ANALYZE helper_rep_hp;

DROP TABLE IF EXISTS helper_rep_lit;
CREATE TABLE helper_rep_lit
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
 AS
SELECT DISTINCT t0.case_id
  FROM case_list t0
  JOIN case_master t1 ON t0.case_id=t1.case_id AND t1.deleted IS NULL
  JOIN lm_report_type t2 on t1.rpt_type_id = t2.rpt_type_id AND t2.deleted IS NULL
 WHERE t2.incl_lit=1;
ANALYZE helper_rep_lit;

DROP TABLE IF EXISTS helper_rep;
CREATE TABLE helper_rep
   WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false,FILLFACTOR=100)
AS
SELECT t0.case_id,
CASE WHEN t1.case_id IS NOT NULL THEN 'Y' ELSE 'N' END AS rpt_src_consumer_yn,
CASE WHEN t2.case_id IS NOT NULL THEN 'Y' ELSE 'N' END AS rpt_src_health_professional_yn,
CASE WHEN t3.case_id IS NOT NULL THEN 'Y' ELSE 'N' END AS rpt_src_lawyer_yn,
CASE WHEN t4.case_id IS NOT NULL THEN 'Y' ELSE 'N' END AS rpt_src_literature_yn,
CASE WHEN t5.case_id IS NOT NULL THEN 'Y' ELSE 'N' END AS rpt_src_regulatory_authority_yn,
CASE WHEN COALESCE(t2.case_id, t3.case_id, t4.case_id, t5.case_id) IS NULL AND t1.case_id IS NOT NULL THEN 'Y' ELSE 'N' END AS rpt_src_consumer_only_yn,
CASE WHEN COALESCE(t1.case_id, t2.case_id, t3.case_id, t4.case_id, t5.case_id) IS NULL THEN 'Y' ELSE 'N' END AS rpt_src_other_yn
FROM case_list t0
LEFT JOIN helper_rep_consumer t1 ON t0.case_id=t1.case_id
LEFT JOIN helper_rep_hp       t2 ON t0.case_id=t2.case_id
LEFT JOIN helper_rep_lawyer   t3 ON t0.case_id=t3.case_id
LEFT JOIN helper_rep_lit      t4 ON t0.case_id=t4.case_id
LEFT JOIN helper_rep_regulatory  t5 ON t0.case_id=t5.case_id
;

ALTER TABLE helper_rep ADD CONSTRAINT pk_hrep PRIMARY KEY(case_id) WITH (FILLFACTOR=100);
ANALYZE helper_rep;
DROP TABLE IF EXISTS helper_rep_consumer;
DROP TABLE IF EXISTS helper_rep_regulatory;
DROP TABLE IF EXISTS helper_rep_lit;
DROP TABLE IF EXISTS helper_rep_hp;
DROP TABLE IF EXISTS helper_rep_lawyer;

DROP TABLE IF EXISTS helper_init_rept_date;

CREATE TABLE helper_init_rept_date AS
WITH tmp AS (
 SELECT cl.case_id,
        GREATEST(init_rept_date, '19600101'::DATE) AS init_rept_date_1,
        CASE WHEN followup_date is NOT NULL THEN GREATEST(followup_date, '19600101'::DATE) END AS followup_date_1,
        CASE WHEN last_sig_update is NOT NULL THEN GREATEST(last_sig_update, '19600101'::DATE) END AS last_sig_update_1        
   FROM case_list cl JOIN case_master cm ON cl.case_id=cm.case_id AND deleted IS NULL
   )
SELECT case_id, 
       CAST(TO_CHAR(init_rept_date_1,'YYYY') AS INTEGER) AS init_receive_year,
       date_to_half_year(init_rept_date_1) AS init_receive_half_year,
       date_to_quarter(init_rept_date_1)   AS init_receive_quarter,
       date_to_month(init_rept_date_1)     AS init_receive_month,
       date_to_iso_week(init_rept_date_1)  AS init_receive_week,
       CAST(TO_CHAR(COALESCE(followup_date_1,init_rept_date_1),'YYYY') AS INTEGER) AS receive_year,
       date_to_half_year(COALESCE(followup_date_1,init_rept_date_1)) AS receive_half_year,
       date_to_quarter(COALESCE(followup_date_1,init_rept_date_1))   AS receive_quarter,
       date_to_month(COALESCE(followup_date_1,init_rept_date_1))     AS receive_month,
       date_to_iso_week(COALESCE(followup_date_1,init_rept_date_1))  AS receive_week,
       CAST(TO_CHAR(last_sig_update_1,'YYYY') AS INTEGER) AS last_signif_update_year,
       date_to_half_year(last_sig_update_1) AS last_signif_update_half_year,
       date_to_quarter(last_sig_update_1)   AS last_signif_update_quarter,
       date_to_month(last_sig_update_1)     AS last_signif_update_month,
       date_to_iso_week(last_sig_update_1)  AS last_signif_update_week
FROM tmp;
ALTER TABLE helper_init_rept_date ADD CONSTRAINT pk_irep PRIMARY KEY(case_id) WITH (FILLFACTOR=100);
ANALYZE helper_init_rept_date;

DROP TABLE IF EXISTS helper_related_cases;
CREATE TABLE helper_related_cases
AS
WITH t1 AS (SELECT DISTINCT cl.case_id
              FROM case_list cl
              JOIN case_event_assess t1 ON t1.case_id=cl.case_id AND t1.deleted IS NULL
              JOIN lm_causality t2 ON t1.det_causality_id=t2.causality_id AND t2.deleted IS NULL
             WHERE t1.license_id=0 AND t1.datasheet_id = 0
               AND t2.reportability=1
         UNION
            SELECT DISTINCT cl.case_id
              FROM case_list cl
              JOIN case_event_assess t1 ON t1.case_id=cl.case_id AND t1.deleted IS NULL
              JOIN lm_causality t2 ON t1.rpt_causality_id=t2.causality_id AND t2.deleted IS NULL
             WHERE t1.license_id=0 AND t1.datasheet_id = 0
               AND t2.reportability=1
           )
   , t2 AS (SELECT DISTINCT cl.case_id
              FROM case_list cl
              JOIN case_event_assess t1 ON t1.case_id=cl.case_id AND t1.deleted IS NULL
             WHERE license_id=0 AND datasheet_id = 0 AND (rpt_causality_id > 0 OR det_causality_id > 0)
            )
   SELECT cl.case_id, CASE WHEN t1.case_id IS NOT NULL THEN 'Y' WHEN t2.case_id IS NOT NULL THEN 'N' ELSE 'U' END AS related
     FROM case_list cl
LEFT JOIN t1 ON t1.case_id=cl.case_id
LEFT JOIN t2 ON t2.case_id=cl.case_id;

DROP TABLE IF EXISTS safety_report CASCADE;
CREATE TABLE safety_report (
    case_id INTEGER NOT NULL,
    primary_id TEXT NOT NULL,
    revision INTEGER,
    ww_safetyreport_id TEXT, -- c.1.8.1
    ww_ref_id TEXT,
    last_signif_update_date TIMESTAMP WITHOUT TIME ZONE,
    rpt_src_consumer_yn VARCHAR(1),
    rpt_src_health_professional_yn VARCHAR(1),
    rpt_src_lawyer_yn VARCHAR(1),
    rpt_src_literature_yn VARCHAR(1),
    rpt_src_regulatory_authority_yn VARCHAR(1),
    rpt_src_other_yn VARCHAR(1),
    rpt_src_consumer_only_yn VARCHAR(1),
    create_date TIMESTAMP WITH TIME ZONE,  -- c.1.2
    report_type_code INTEGER,
    report_type TEXT,  -- c.1.3
    report_type_derived TEXT,
    report_rcvd_init TIMESTAMP WITHOUT TIME ZONE, --c.1.4
    report_rcvd TIMESTAMP WITHOUT TIME ZONE, -- c.1.5
    serious_yn VARCHAR(1),
    serious_death_yn VARCHAR(1),
    serious_life_threatening_yn VARCHAR(1),
    serious_disabling_yn VARCHAR(1),
    serious_congenital_anomaly_yn VARCHAR(1),
    serious_reqd_intervention_yn VARCHAR(1),
    serious_hospitalization_yn VARCHAR(1),
    serious_other_yn VARCHAR(1),
    serious_text VARCHAR(8),
    listedness_id INTEGER, listedness TEXT,
    related_ynu VARCHAR(1),
    outcome_id INTEGER, outcome TEXT, e2b_outcome TEXT,
    close_date TIMESTAMP WITHOUT TIME ZONE,
    date_locked TIMESTAMP WITHOUT TIME ZONE,
    safety_date TIMESTAMP WITH TIME ZONE,
    site_id INTEGER, site_desc TEXT,
    standard_strata TEXT NOT NULL,
    init_receive_year INTEGER NOT NULL,
    init_receive_half_year TEXT NOT NULL,
    init_receive_quarter TEXT NOT NULL,
    init_receive_month INTEGER NOT NULL,
    init_receive_week TEXT NOT NULL,
    receive_year INTEGER NOT NULL,
    receive_half_year TEXT NOT NULL,
    receive_quarter TEXT NOT NULL,
    receive_month INTEGER NOT NULL,
    receive_week TEXT NOT NULL,
    last_signif_update_quarter TEXT NOT NULL,
    last_signif_update_month INTEGER NOT NULL,
    last_signif_update_week  TEXT NOT NULL,
    num_therapies INTEGER NOT NULL,
    num_suspect INTEGER NOT NULL,
    num_conmed INTEGER NOT NULL,
    num_reactions INTEGER NOT NULL,
    country_id INTEGER,
    occurred_country TEXT,
    region TEXT,
    subpop_overdose_yn VARCHAR(1),
    subpop_abuse_yn VARCHAR(1),
    subpop_fatal_yn VARCHAR(1),
    subpop_interact_yn VARCHAR(1),
    subpop_complaint_yn VARCHAR(1),
    subpop_age_elderly_yn VARCHAR(1),
    subpop_age_adult_yn VARCHAR(1),    
    subpop_age_adolescent_yn VARCHAR(1),
    subpop_age_child_yn VARCHAR(1),
    subpop_pregnancy_yn VARCHAR(1),
    listedness_notes TEXT,
    company_diagnosis TEXT,
    company_diagnosis_notes TEXT,
    agent_notes TEXT,
    serious_notes TEXT,
    company_agent_suspect_yn VARCHAR(1),
    requires_followup_yn VARCHAR(1),
    susar_yn VARCHAR(1),
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1) NOT NULL,
    device_case_yn VARCHAR(1) NOT NULL,
    vaccine_case_yn VARCHAR(1) NOT NULL
    )
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO safety_report (
       case_id, primary_id, revision,
       ww_safetyreport_id,
       ww_ref_id,
       last_signif_update_date,
       rpt_src_consumer_yn, rpt_src_health_professional_yn, rpt_src_lawyer_yn, rpt_src_literature_yn,
       rpt_src_regulatory_authority_yn, rpt_src_other_yn, rpt_src_consumer_only_yn,
       create_date, report_type_code, report_type, report_type_derived, report_rcvd_init,
       report_rcvd, serious_yn,
       serious_death_yn, serious_life_threatening_yn, serious_disabling_yn,
       serious_congenital_anomaly_yn, serious_reqd_intervention_yn, serious_hospitalization_yn,
       serious_other_yn, serious_text,
       listedness_id, listedness,
       related_ynu,
       outcome_id, outcome, e2b_outcome,
       close_date, date_locked, safety_date,
       site_id, site_desc,
       standard_strata, init_receive_year, init_receive_half_year,
       init_receive_quarter, init_receive_month, init_receive_week,
       receive_year, receive_half_year, receive_quarter, receive_month,
       receive_week, last_signif_update_quarter,last_signif_update_month, last_signif_update_week,
       num_therapies, num_suspect, num_conmed, num_reactions,
       country_id, occurred_country, region,
       subpop_overdose_yn, subpop_abuse_yn, subpop_fatal_yn,
       subpop_interact_yn, subpop_complaint_yn, subpop_age_elderly_yn, subpop_age_adult_yn,
       subpop_age_adolescent_yn, subpop_age_child_yn, subpop_pregnancy_yn,
       listedness_notes,
       company_diagnosis,
       company_diagnosis_notes,
       agent_notes,
       serious_notes,
       company_agent_suspect_yn,
       requires_followup_yn,
       susar_yn,
       valid_case_yn, spont_case_yn, spont_valid_case_yn,
       drug_case_yn, device_case_yn, vaccine_case_yn)
   SELECT
        cl.case_id,
        cm.case_num AS primaryid,
        rev AS revision,
        ww_safetyreport_id AS ww_safetyreport_id,
        ref.ref_no AS ww_ref_id,
        last_sig_update AS last_signif_update_date,
        h_rep.rpt_src_consumer_yn,
        h_rep.rpt_src_health_professional_yn,
        h_rep.rpt_src_lawyer_yn,
        h_rep.rpt_src_literature_yn,
        h_rep.rpt_src_regulatory_authority_yn,
        h_rep.rpt_src_other_yn,
        h_rep.rpt_src_consumer_only_yn,
        create_time AT TIME ZONE 'UTC' AS create_date,
        cm.rpt_type_id AS report_type_code, lm_report_type.report_type AS report_type,
        CASE
          WHEN lm_report_type.report_type IN ('Literature PMS','PMS','PMS EDC') THEN 'PMS'
          WHEN lm_report_type.report_type IN ('Other') THEN NULL::VARCHAR
          WHEN cl.spont_case_yn = 'Y' THEN 'Spontaneous'
          ELSE 'Clinical Trial'
        END AS report_type_derived,
        init_rept_date  AS report_rcvd_init,
        COALESCE(followup_date, init_rept_date) AS report_rcvd,
        CASE WHEN COALESCE(ca.seriousness,0)=1 THEN 'Y' ELSE 'N' END AS serious_yn,
        h_ser.serious_death_yn,
        h_ser.serious_life_threatening_yn,
        h_ser.serious_disabling_yn,
        h_ser.serious_congenital_anomaly_yn,
        h_ser.serious_reqd_intervention_yn,
        h_ser.serious_hospitalization_yn,
        h_ser.serious_other_yn,
        h_ser.serious_text,
        ca.listedness AS listedness_id, lm_listedness.listedness,
        h_r.related AS related_ynu,
        ca.outcome AS outcome_id, lm_evt_outcome.evt_outcome AS outcome,
        CASE when lm_evt_outcome.e2b_code = 1 THEN 'Recovered/Resolved'
        	 when  lm_evt_outcome.e2b_code = 2 THEN 'Recovering/Resolving/Improved'
        	 when  lm_evt_outcome.e2b_code = 3 THEN 'Not recovered/Not resolved/Ongoing'
        	 when  lm_evt_outcome.e2b_code = 4 THEN 'Recovered/Resolved with sequelae'
        	 when  lm_evt_outcome.e2b_code = 5 THEN 'Fatal'
        	 when  lm_evt_outcome.e2b_code = 6 THEN 'Unknown' END AS e2b_outcome,
        cm.close_date, cm.date_locked,cm.safety_date,
        cm.site_id, lm_sites.site_desc,
        COALESCE(t3.gender,'UNK') || ':' || age_group3 || ':' || init_receive_year::VARCHAR(4) AS standard_strata,
        hird.init_receive_year,
        hird.init_receive_half_year,
        hird.init_receive_quarter,
        hird.init_receive_month,
        hird.init_receive_week,
        hird.receive_year,
        hird.receive_half_year,
        hird.receive_quarter,
        hird.receive_month,
        hird.receive_week,
        hird.last_signif_update_quarter,
        hird.last_signif_update_month,
        hird.last_signif_update_week,
        h_n.num_therapies,
        h_n.num_suspect,
        h_n.num_conmed,
        h_n.num_reactions,
        cm.country_id,
        t9.country AS occurred_country,
        t10.region,
        h_pop.subpop_overdose_yn,
        h_pop.subpop_abuse_yn,
        h_pop.subpop_fatal_yn,
        h_pop.subpop_interact_yn,
        h_pop.subpop_complaint_yn,
        h_pop.subpop_age_elderly_yn,
        CASE WHEN h_age.age_group3 = 'UNK' OR h_pop.subpop_age_elderly_yn = 'Y' 
                  OR h_pop.subpop_age_adolescent_yn = 'Y' OR h_pop.subpop_age_child_yn = 'Y' 
             THEN 'N'
             ELSE 'Y'
        END AS subpop_age_adult_yn,
        h_pop.subpop_age_adolescent_yn,
        h_pop.subpop_age_child_yn,
        h_pop.subpop_pregnancy_yn,
        ca.listedness_notes,
        ca.company_diagnosis,
        ca.company_diagnosis_notes,
        ca.agent_notes,
        ca.serious_notes,
        CASE WHEN ca.agent_suspect = 1 THEN 'Y' ELSE 'N' END AS company_agent_suspect_yn,
        CASE WHEN cm.requires_followup = 1 THEN 'Y' ELSE 'N' END AS requires_followup_yn,
        CASE WHEN cm.susar = 1 THEN 'Y' ELSE 'N' END AS susar_yn,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
 FROM case_list cl
     JOIN case_master cm ON cl.case_id=cm.case_id
     JOIN oasis_case_pat_info pat ON cl.case_id=pat.case_id AND pat.deleted IS NULL
LEFT JOIN helper_init_rept_date hird ON hird.case_id=cl.case_id     
LEFT JOIN case_assess ca ON ca.case_id=cl.case_id AND ca.deleted IS NULL
LEFT JOIN oasis_case_reference ref ON ref.case_id=cl.case_id AND ref.deleted IS NULL AND ref_type_id=987 -- bogus
LEFT JOIN lm_report_type  ON cm.rpt_type_id = lm_report_type.rpt_type_id AND lm_report_type.deleted IS NULL
LEFT JOIN lm_gender t3 ON pat.gender_id = t3.gender_id AND t3.deleted IS NULL
LEFT JOIN helper_age h_age ON cl.case_id=h_age.case_id
LEFT JOIN helper_seriousness h_ser ON h_ser.case_id=cl.case_id
     JOIN helper_n   h_n   ON h_n.case_id=cl.case_id
     JOIN helper_rep h_rep ON h_rep.case_id=cl.case_id
LEFT JOIN helper_related_cases h_r ON h_r.case_id=cl.case_id
LEFT JOIN lm_countries t9 ON cm.country_id = t9.country_id AND t9.deleted IS NULL
LEFT JOIN lm_sites ON cm.site_id = lm_sites.site_id AND lm_sites.deleted IS NULL
LEFT JOIN country_region_map t10 ON t9.country=t10.country
LEFT JOIN helper_subpop h_pop ON h_pop.case_id=cl.case_id
LEFT JOIN lm_evt_outcome ON lm_evt_outcome.evt_outcome_id = ca.outcome AND lm_evt_outcome.deleted IS NULL
LEFT JOIN lm_listedness ON lm_listedness.listedness_id = ca.listedness AND lm_listedness.deleted IS NULL
;

CREATE UNIQUE INDEX safety_report_ix1 ON safety_report (case_id);
CREATE UNIQUE INDEX safety_report_ix2 ON safety_report (primary_id);
ANALYZE safety_report;

DROP TABLE IF EXISTS helper_seriousness;
DROP TABLE IF EXISTS helper_rep;
DROP TABLE IF EXISTS helper_n;
DROP TABLE IF EXISTS helper_subpop;
DROP TABLE IF EXISTS helper_death;
DROP TABLE IF EXISTS helper_age;
DROP TABLE IF EXISTS helper_init_rept_date;
DROP TABLE IF EXISTS helper_related_cases;
