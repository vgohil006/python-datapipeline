# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

class EncryptKey(object):
    '''
    Key used for encryption and decryption within the application
    '''
    # 24 byte encryption key generated as follows:
    # from os import urandom
    # urandom(24)
    KEY = b'\x1c\xcc$\xc2\x9e\xc8\x12\x97\xc2\xec\xb1\xb0,,\x7fq\x0c\x81\xcbM\xdf3\xafb'
