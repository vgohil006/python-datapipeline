# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

import logging
import subprocess

from util import DbCursorRegistry, DbPsql

class BaseStep(object):
    '''
    classdocs
    '''
    def __init__(self, short_name, description, parent=None):
        '''
        Constructor
        '''
        self.short_name = short_name
        self.description = description
        self._parent = parent
        self._logger = logging.getLogger(self.get_short_name_path())
        if parent is None:
            self._cursors = DbCursorRegistry()
        
    def get_cursors(self):
        if self._parent:
            cursors = self._parent.get_cursors()
        else:
            cursors = self._cursors
        return cursors

    def get_short_name_path(self):
        if self._parent:
            path = "%s.%s" % (self._parent.get_short_name_path(),
                              self.short_name)
        else:
            path = self.short_name
        return path

    def get_step_id(self):
        if self._parent:
            step_id = "%s.%02d" % (self._parent.get_step_id(),
                                   self._step_number) 
        else:
            step_id = "%02d" % self._step_number

        return step_id;
    
    def is_substep(self):
        return self._parent is not None

    def execute(self, resume, step_number, interactive, config_settings,
                run_vars, run_status):
        '''
        Execute the step        
        If either resume or interactive are True, the user will be prompted
        to choose whether to execute or skip the step.
        '''
        self._resume = resume
        self._step_number = step_number

        step_msg = "step %s -- %s" % (self.get_step_id(), self.description)
        if not self.is_substep() and run_vars and (resume or interactive):
            run_vars.load("%s_%s" % (self.get_step_id(), self.short_name))
        
        if resume or interactive:
            yes = self._prompt("Execute %s?" % step_msg)
        else:
            yes = True
        
        action_msg = "Executing" if yes else "Skipped"
        self._logger.info("%s %s" % (action_msg, step_msg))
        if not yes:
            return resume
        else:
            # Executing a step caused resume mode to be turned off for
            # subsequent steps
            resume = False
            try:
                # Only initialize cursors for s top-level step
                if not self.is_substep():
                    self._init_cursors(config_settings)

                self._do_step(interactive, config_settings, run_vars,
                              run_status)
            finally:
                # At the end of each top-level step, save the run_vars and
                # close the_cursors and connections used by the step
                if not self.is_substep():
                    if run_vars:
                        run_vars.store("%02d_%s" % (step_number, self.short_name))
                    self._cursors.close_all()
            
        self._logger.info("Completed %s" % step_msg)
        return resume

    def execute_substeps(self, substeps):    
        resume = self._resume
        substep_number = 1

        # loop through the substeps
        for substep in substeps:
            resume = substep.execute(resume, substep_number,
                                     self._interactive, self._settings,
                                     self._run_vars, self._run_status)
            substep_number += 1
        return resume

    def _prompt(self, message):
        '''
        Print the message on the console and _prompt the user until a valid
        (y/n) response is entered.
        
        If the response is empty or starts with 'y' or 'Y', return True
        If the response starts with 'n' or 'N', return False
        '''
        while True:
            response = input("%s [Yn]: " % message)
            response = response.strip()
            if len(response) == 0 or response[0] == 'y' or response[0] == 'Y':
                return True
            elif response[0] == 'n' or response[0] == 'N':
                return False

    def _should_proceed(self, done, prompt):
        '''
        Determine whether to proceed by testing the following (in order):
          if done then return False
          if not interactive then return True
          if interactive then prompt the user
        '''
        if done:
            return False
        elif not self._interactive:
            return True
        else:
            return self._prompt(prompt)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Perform initialization common to all steps.       
        Subclasses are expected to override this method and invoke the
        superclass method at the start of the subclass implementation.
        '''
        self._interactive = interactive
        self._settings = config_settings
        self._run_vars = run_vars
        self._run_status = run_status
    
    def _init_cursors(self, settings):
        '''
        Initialize all cursors needed by the step.
        Subclasses are expected to override this method and invoke the
        superclass method at the start of the subclass implementation.
        '''
        self._db_connect_str = settings.get("database", "db_connect_str")

        
class SqlScriptSpec(object):
    '''
    SQL script file name, short name and description
    '''

    def __init__(self, file_name, short_name, description):
        '''
        Constructor
        '''
        self.file_name = file_name
        self.short_name = short_name
        self.description = description


class RunSqlScriptStep(BaseStep):
    def __init__(self, parent_step, psql_path, script_dir, script_spec,
                 connect_str, user, password, schema, script_arg_list=[]):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          script_spec.short_name,
                          script_spec.description,
                          parent=parent_step)
        self._psql_path = psql_path
        self._script_dir = script_dir
        self._script_spec = script_spec
        self._connect_str = connect_str
        self._user = user
        self._password = password
        self._schema = schema
        self._script_arg_list = script_arg_list

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(RunSqlScriptStep, self)._do_step(interactive,
                                               config_settings,
                                               run_vars, run_status)

        spec = self._script_spec
        script = spec.file_name
        result = DbPsql.invoke_db_cmd(self._psql_path, self._script_dir,
                                      self._user, self._password, self._schema,
                                      self._connect_str, script,
                                      self._script_arg_list)
