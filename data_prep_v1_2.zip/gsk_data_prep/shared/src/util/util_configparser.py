# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

from configparser import ConfigParser, ExtendedInterpolation
import base64
import pyDes


class ConfigParserExt(ConfigParser):
    '''
    Extensions to the ConfigParser class to support storing secrets
    (encrypted strings)
    '''
    def __init__(self, key, defaults={}, dict_type=dict):
        '''
        Constructor
        
        Arguments:
          key - 24-byte key used to encrypt/decrypt secrets
          defaults - an optional dictionary of values that can be referenced
                     in configuration variables by including string format
                     specifiers such as '${key}' where "key" is a key of
                     "defaults".
          dict_type - specifies the type of the dictionary that is used
                      internal for storing configuration variables.  By
                      default, it is "dict" (the built-in dictionary).
        '''
        ConfigParser.__init__(self, defaults, dict_type,
                              interpolation=ExtendedInterpolation())
        if key:
            if len(key) != 24:
                raise RuntimeError("Encryption key should be 24 bytes")
            self._key = pyDes.triple_des(key, pyDes.CBC, "\0\0\0\0\0\0\0\0",
                                         pad=None, padmode=pyDes.PAD_PKCS5)
        else:
            self._key = None                

    def getsecret(self, section, option):
        '''
        Decrypts and returns the value of the designated configuration
        section and option.
        '''
        if not self._key:
            raise RuntimeError("getsecret(): encryption key not provided")
        
        decoded = base64.standard_b64decode(self.get(section, option))
        decrypted = self._key.decrypt(decoded).decode(encoding="utf-8")
        return decrypted
    
    def setsecret(self, section, option, value):
        '''
        Sets the result of encrypting "value" to the designated configuration
        section and option.  "value" should be a string.
        '''
        if not self._key:
            raise RuntimeError("getsecret(): encryption key not provided")
        
        # encrypt the value, base64 encode it and then decode the result
        # to UTF-8 in order to obtain a string containing the cipher text
        encrypted = self._key.encrypt(value)
        encoded = base64.standard_b64encode(encrypted).decode("utf-8")
        self.set(section, option, encoded)
