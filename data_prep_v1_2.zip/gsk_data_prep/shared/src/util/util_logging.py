# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

import logging
import os

class LoggingUtils(object):
    '''
    Logging utilities
    '''
    @staticmethod
    def init_logging(filename, fmt, level, removeIfExists=True):
        """
        initialize the logging facility
        """       
        if level == "CRITICAL":
            log_level = logging.CRITICAL
        elif level == "ERROR":
            log_level = logging.ERROR
        elif level == "WARNING":
            log_level = logging.WARNING
        elif level == "INFO":
            log_level = logging.INFO
        elif level == "DEBUG":
            log_level = logging.DEBUG
        
        if removeIfExists:
            # remove the log file if it already exists
            try:
                os.remove(filename)
            except OSError:
                pass
        
        logging.basicConfig(filename=filename, format=fmt, level=log_level)
