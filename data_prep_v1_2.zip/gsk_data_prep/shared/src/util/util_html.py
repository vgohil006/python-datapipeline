# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

from requests import get
from contextlib import closing

class HtmlUtils(object):
    '''
    HTML request utilities
    '''
    @staticmethod
    def simple_get(url):
        '''
        Attempts to get the content at "url" by making an HTTP GET request.
        If the content-type of response is some kind of HTML/XML, return the
        text content, otherwise return None.
        '''
        with closing(get(url, stream=True)) as resp:
            if HtmlUtils.is_good_response(resp):
                return resp.content
            else:
                return None

    @staticmethod
    def is_good_response(resp):
        '''
        Returns True if the response seems to be HTML, False otherwise.
        '''
        content_type = resp.headers["Content-Type"].lower()
        return (resp.status_code == 200 
                and content_type is not None 
                and content_type.find("html") > -1)
