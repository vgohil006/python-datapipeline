# ##############################################################################
# Copyright (c) 2013-2019 Commonwealth Informatics, Inc.  All rights reserved.
# No part of this work may be reproduced in whole or in part in any manner
# without the permission of the copyright owner.
# 
# Author: rschaaf
# ##############################################################################

class StringUtils(object):
    '''
    Utility methods for working with strings
    '''
    @staticmethod
    def reindent(s, num_spaces):
        '''
        reindent a multiline string to have the specified number of leading
        spaces
        '''
        lines = s.split('\n')
        indented_lines = [(num_spaces * ' ') + line for line in lines]
        indented_s = '\n'.join(indented_lines)
        return indented_s
