#!/bin/bash

# venv_bindir=/opt/commonwealth/envs/data_prep_env/bin
base_dir="C:\Users\vgohil\Documents\foi_faers\foi_faers\encrypt_secrets"

# source ${venv_bindir}/activate
cd ${base_dir}

python src/encrypt_secrets.py --secrets-file ../../../gsk_data_prep/etc/secrets.ini
