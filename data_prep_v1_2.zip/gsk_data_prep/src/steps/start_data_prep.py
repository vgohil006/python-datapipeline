'''
@author: rschaaf
'''
from util import BaseStep, DbUtils

class StartDataPrep(BaseStep):
    '''
    Start the data prep process
    '''

    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "start_data_prep",
                          "Start the data prep process")

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(StartDataPrep, self)._init_cursors(settings)
        self._prep_info_user = settings.get("postgresql", "postgresql_user")
        prep_info_pass = settings.getsecret("postgresql", "postgresql_user_pass")
        prep_info_schema = settings.get("db-common", "prep_info_schema")
        
        self._data_prep_cursor = self._cursors.get_cursor(self._prep_info_user,
                                                          prep_info_pass,
                                                          self._db_connect_str,
                                                          prep_info_schema)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(StartDataPrep, self)._do_step(interactive, config_settings,
                                            run_vars, run_status)

        stmt = ("INSERT INTO activity_log\n"
                "   (refresh_type, status, start_dt)\n"
                "VALUES\n"
                "   ('GSK ARGUS data prep', 'Started', now())\n"
                "RETURNING id")
        self._data_prep_cursor.execute(stmt)
        self._data_prep_cursor.connection.commit()
        row_id = self._data_prep_cursor.fetchone()[0]

        # keep track of the id for the newly added row so that the row can be
        # updated when the run finishes
        self._run_vars.set("activity_log_rowid", str(row_id))
