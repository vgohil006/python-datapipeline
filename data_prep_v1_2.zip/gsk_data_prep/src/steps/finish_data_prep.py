'''

@author: mfilho

'''
from util import BaseStep, DbUtils, EmailUtils, SmtpSettings
import cx_Oracle


class FinishDataPrep(BaseStep):
    '''
    Finish the data prep process
    '''

    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "finish_data_prep",
                          "Finish the data prep process")

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(FinishDataPrep, self)._init_cursors(settings)
        
        self._prep_info_user = settings.get("postgresql", "postgresql_user")
        prep_info_pass = settings.getsecret("postgresql", "postgresql_user_pass")
        prep_info_schema = settings.get("db-common", "prep_info_schema")
        icsr_staging_schema = settings.get("db-common","icsr_staging_schema")
        
        self._data_prep_cursor = self._cursors.get_cursor(self._prep_info_user,
                                                          prep_info_pass,
                                                          self._db_connect_str,
                                                          prep_info_schema)
        

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''

        super(FinishDataPrep, self)._do_step(interactive, config_settings,
                                            run_vars, run_status)
        
        substeps = [FinishDataPrepOracle(self),
                    FinishDataPrepPostgres(self, self._data_prep_cursor)
                    ]
        
        self.execute_substeps(substeps)

            
class FinishDataPrepOracle(BaseStep):
    '''
    Finish Oracle Data Prep
    '''
    def __init__(self,parent_step):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "finish_oracle",
                          "Finish Oracle Data Prep",
                          parent=parent_step)

    def _do_step(self, interactive, settings, run_vars, run_status):
        '''
        Execute the step
        
        '''
        super(FinishDataPrepOracle, self)._do_step(interactive, settings, run_vars, run_status)
        #Oracle Cursor
        
        self._oracle_user = settings.get("oracle", "oracle_user")
        self._oracle_user_pass = settings.getsecret("oracle", "oracle_user_pass")
        self._oracle_host = settings.get("oracle", "oracle_host")
        self._oracle_port = settings.get("oracle", "oracle_port")
        self._service_name= settings.get("oracle", "oracle_service_name")
        self._icsr_info_schema = settings.get("oracle", "icsr_info_schema")
        self._conn_srcrds = cx_Oracle.makedsn(host=self._oracle_host, port=self._oracle_port, service_name=self._service_name) # will user oracle_connect_str        
        self._conn_src = cx_Oracle.connect(user=self._oracle_user, password=self._oracle_user_pass, dsn=self._conn_srcrds)
        self._oracle_cursor = self._conn_src.cursor()

        statements = ["DROP TABLE " + self._icsr_info_schema + ".PREV_ROWCOUNTS", 
                      "RENAME " + self._icsr_info_schema + ".LAST_ROWCOUNTS TO " + self._icsr_info_schema +".PREV_ROWCOUNTS",
                      "RENAME " + self._icsr_info_schema + ".INPROGRESS_ROWCOUNTS TO " + self._icsr_info_schema + ".LAST_ROWCOUNTS"]
        
        for statement in statements:
                try:
                    self._logger.info(statement)
                    self._oracle_cursor.execute(statement)
                except cx_Oracle.DatabaseError as error:
                    self._logger.error(error)
                continue
            
class FinishDataPrepPostgres(BaseStep):
    '''
    Finish Postgres Data Prep
    '''
    def __init__(self, parent_step, cursor):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "finish_postgres",
                          "Finish Postgres Data Prep",
                          parent=parent_step)
        
        self._cursor = cursor

    def _do_step(self, interactive, settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(FinishDataPrepPostgres, self)._do_step(interactive, settings, run_vars, run_status)
        
        #This should be oasis_info schema
        prep_info_schema = settings.get("db-common", "prep_info_schema")
        
        #This should be oasis_staging schema
        icsr_staging_schema = settings.get("db-common","icsr_staging_schema")
        
        #Check if the table exists
        table_name = "oasis_family_names_last"
        tables_exist = DbUtils.table_exists(self._cursor, prep_info_schema, table_name)
        if (tables_exist == False):
            self._logger.info('------ Creating Table oasis_family_names_last for the first time -------')
            sql = 'CREATE TABLE '
            sql += prep_info_schema + '.oasis_family_names_last as select * from '
            sql += icsr_staging_schema + '.oasis_family_names;'
            self._logger.info(sql)
            self._cursor.execute(sql)
            DbUtils.commit(self._cursor)
        
        #Compare Family Names between schemas
        sql = 'select t1.family_id::INTEGER AS family_id, t1.family_name AS previous_name, t2.family_name AS new_name '
        sql += 'from '
        sql += prep_info_schema + '.oasis_family_names_last t1 left join '
        sql += icsr_staging_schema + '.oasis_family_names t2 on t2.family_id = t1.family_id '
        sql += 'where t2.family_name IS NULL OR t2.family_name <> t1.family_name'
        self._logger.info(sql)
        self._cursor.execute(sql)
        result = self._cursor.fetchall()
        self._logger.info('Comparison result:\n' + '(family_id, previous_name, new_name)\n' + str(result).strip('[]'))
        
        if(len(result)> 0):
            '''Send an email notification indicating the names that have been modified '''
            smtp_settings = SmtpSettings(settings.get("email", "smtp_server"),
                                         settings.getint("email", "smtp_port"),
                                         settings.get("email", "smtp_encryption"),
                                         settings.getboolean("email", "smtp_requires_authentication"),
                                         settings.get("email", "smtp_auth_user"),
                                         settings.getsecret("email", "smtp_auth_pass"))
    
            # don't try to send email unless an SMTP server has been configured
            if smtp_settings.server:        
                subject = "GSK_ETL  - Family name changes detected" 
                body_text = "Please see the following details.\r\n"
                body_text += '\n'
                body_text += '(family_id, previous_name, new_name)\n'
                body_text += '\n'
                loopSize = len(result)
                for i in range (loopSize):
                    body_text += str(result[i]).strip('[]')
                    body_text += '\n'

                body_text += '\n'
                body_text += 'This is an automated e-mail please do not respond'
                msg_from = settings.get("email", "msg_from")
                msg_to = [ addr.strip() for addr in settings.get("email", "alerts").split(",") ]
                zips = [ ]
        
                msg = EmailUtils.create_message_with_zips(msg_from, msg_to, subject, body_text, zips)
                EmailUtils.send_email(msg_from, msg_to, msg, smtp_settings)
                
                sql = 'DROP TABLE IF EXISTS '
                sql += prep_info_schema + '.family_names_prev CASCADE;'
                self._logger.info(sql)
                self._cursor.execute(sql)
                DbUtils.commit(self._cursor)

                sql = 'ALTER TABLE ' + prep_info_schema + '.oasis_family_names_last '
                sql += 'RENAME TO family_names_prev;'
                self._logger.info(sql)
                self._cursor.execute(sql)
                DbUtils.commit(self._cursor)
        
                sql = 'CREATE TABLE '
                sql += prep_info_schema + '.oasis_family_names_last as select * from '
                sql += icsr_staging_schema + '.oasis_family_names;'
                self._logger.info(sql)
                self._cursor.execute(sql)
                DbUtils.commit(self._cursor)
        else:
            self._logger.info('There are no differences between Family Names')

        # Update the activity log
        row_id = int(self._run_vars.get("activity_log_rowid"))
        stmt = ("UPDATE activity_log\n"
                "   SET status = 'Success',\n"
                "       finish_dt = now()\n"
                " WHERE id = %(row_id)s")
        self._cursor.execute(stmt, {'row_id': row_id})
        DbUtils.commit(self._cursor)
        
