'''
Created on 10 Jul 2020

@author: vgohil
'''
#from util.util_step import BaseStep
import cx_Oracle
from util import BaseStep

class OasisTableDifference(BaseStep):
    '''
    Verify table rowcount difference between current import and last import
    '''


    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self, 
                          "oasis_import_table_difference", 
                          "Table difference between current and previous oasis import")
        
        
    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(OasisTableDifference, self)._init_cursors(settings)
        
        self._oracle_user = settings.get("oracle", "oracle_user")
        self._oracle_user_pass = settings.getsecret("oracle", "oracle_user_pass")
        self._oracle_host = settings.get("oracle", "oracle_host")
        self._oracle_port = settings.get("oracle", "oracle_port")
        self._service_name= settings.get("oracle", "oracle_service_name")
             
        self._conn_srcrds = cx_Oracle.makedsn(host=self._oracle_host, port=self._oracle_port, service_name=self._service_name) # will user oracle_connect_str        
        self._conn_src = cx_Oracle.connect(user=self._oracle_user, password=self._oracle_user_pass, dsn=self._conn_srcrds)
        
        self._oracle_cursor = self._conn_src.cursor()
        
    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(OasisTableDifference, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        
        
        
        self._icsr_info_schema = config_settings.get("oracle", "icsr_info_schema")
        self._oasis_schema = config_settings.get("oracle", "target_icsr_schema")
        
        substeps = [CheckTableRowDifferences(self, self._conn_src,self._oracle_cursor,self._icsr_info_schema, self._oasis_schema),
                    CheckTableSchemaDifferences(self, self._conn_src,self._oracle_cursor,self._icsr_info_schema, self._oasis_schema)]
        
        self.execute_substeps(substeps)
        
        
class CheckTableRowDifferences(BaseStep):
    '''
    Validate table rowcount difference between current and previous import
    '''
    
    def __init__(self, parent_step, conn_src, cursor, info_schema, oasis_schema):
        '''
        Constructor
        '''
        BaseStep.__init__(self, 
                          f"Validate OASIS Table Rowcount", 
                          f"Validate OASIS Table Rowcount difference on schema: {info_schema}", 
                          parent=parent_step)
        
        self._conn_src = conn_src
        self._oracle_cursor = cursor
        self._icsr_info_schema = info_schema
        self._oasis_schema = oasis_schema
        
    def _do_step(self, interactive, config_settings, run_vars, run_status):
        
        super(CheckTableRowDifferences, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        
        
        statements = ["DROP TABLE "   + self._icsr_info_schema + ".INPROGRESS_ROWCOUNTS PURGE",
                      "CREATE TABLE " + self._icsr_info_schema + ".INPROGRESS_ROWCOUNTS" +
                               " AS SELECT TABLE_NAME, NUM_ROWS FROM DBA_TABLES WHERE OWNER = '" + self._oasis_schema +  "' ORDER BY 1",
                      "CREATE TABLE " + self._icsr_info_schema + ".LAST_ROWCOUNTS AS SELECT * FROM " + self._icsr_info_schema + ".INPROGRESS_ROWCOUNTS",
                      "DROP TABLE "   + self._icsr_info_schema + ".COUNT_DIFF PURGE",
                      "CREATE TABLE " + self._icsr_info_schema + ".COUNT_DIFF" +
                               " AS SELECT A.TABLE_NAME AS CURRENT_TABLE_NAME, A.NUM_ROWS AS NUM_ROWS_INPROGRESS," +
                               "           B.TABLE_NAME AS LAST_TABLE_NAME, B.NUM_ROWS AS NUM_ROWS_LAST" +
                               "      FROM " + self._icsr_info_schema + ".INPROGRESS_ROWCOUNTS A" +
                         " FULL OUTER JOIN " + self._icsr_info_schema + ".LAST_ROWCOUNTS B ON A.TABLE_NAME=B.TABLE_NAME"
                     ]

        while True:
            for statement in statements:
                try:
                    print(statement)
                    self._oracle_cursor.execute(statement)

                except cx_Oracle.DatabaseError as error:
                    print(error)
                continue
            break

        sql = "SELECT CURRENT_TABLE_NAME, NUM_ROWS_INPROGRESS, LAST_TABLE_NAME, NUM_ROWS_LAST, (NUM_ROWS_INPROGRESS - NUM_ROWS_LAST) DIFFERENCE " + \
              "  FROM " + self._icsr_info_schema + ".COUNT_DIFF" + \
              " WHERE (NUM_ROWS_INPROGRESS - NUM_ROWS_LAST < 0 OR LAST_TABLE_NAME IS NULL) " + \
              "   AND ( NVL(CURRENT_TABLE_NAME, LAST_TABLE_NAME) LIKE 'CASE%'" + \
              "      OR NVL(CURRENT_TABLE_NAME, LAST_TABLE_NAME) LIKE 'OASIS_CASE%')" + \
              " ORDER BY 1"
        self._logger.info(sql)
        self._oracle_cursor.execute(sql)
        data = self._oracle_cursor.fetchall()
        self._logger.info(data)

        self._logger.info(len(data))

        if len(data) > 0:
            raise Exception("Error: Negative row count differences in OASIS tables verified between Current and Last Import")

class CheckTableSchemaDifferences(BaseStep):
    '''
    Validate table rowcount difference between current and previous import
    '''
    
    def __init__(self, parent_step, conn_src, cursor, info_schema, oasis_schema):
        '''
        Constructor
        '''
        BaseStep.__init__(self, 
                          f"Validate OASIS Table Structures", 
                          f"Validate OASIS Table Structures: {oasis_schema} vs {info_schema}", 
                          parent=parent_step)
        
        self._conn_src = conn_src
        self._oracle_cursor = cursor
        self._icsr_info_schema = info_schema
        self._oasis_schema = oasis_schema
        
    def _do_step(self, interactive, config_settings, run_vars, run_status):
        
        super(CheckTableSchemaDifferences, self)._do_step(interactive, config_settings,
                                         run_vars, run_status)
        
        statements = ["DROP TABLE " + self._icsr_info_schema + ".OASIS_SCHEMA_DIFFERENCES",
                      "CREATE TABLE " + self._icsr_info_schema + ".OASIS_SCHEMA AS " +  
                            "SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE FROM ALL_TAB_COLUMNS WHERE OWNER = 'OASIS'",
                      "CREATE TABLE " + self._icsr_info_schema + ".OASIS_SCHEMA_DIFFERENCES AS " +
                            "WITH T1 AS (SELECT * FROM " + self._icsr_info_schema + ".OASIS_SCHEMA)" +
                            ", T2 AS (SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE FROM ALL_TAB_COLUMNS WHERE OWNER = 'OASIS') " +
                            ", T3 AS (SELECT * FROM T1 MINUS SELECT * FROM T2) " +
                            ",    T4 AS (SELECT * FROM T2 MINUS SELECT * FROM T1)" +
                            " SELECT " +
                                " CASE " +
                                " WHEN T3.DATA_TYPE IS NULL THEN 'ADDED'"  +
                                " WHEN T4.DATA_TYPE IS NULL THEN 'DELETED'" +
                                " ELSE 'CHANGED'" +
                                " END AS CHANGE_TYPE," +
                                " NVL(T3.TABLE_NAME, T4.TABLE_NAME) AS TABLE_NAME," +
                                " NVL(T3.COLUMN_NAME, T4.COLUMN_NAME) AS COLUMN_NAME," +
                                " T3.DATA_TYPE AS OLD_DATA_TYPE," +
                                " T3.DATA_LENGTH AS OLD_DATA_LENGTH," +
                                " T3.DATA_PRECISION AS OLD_DATA_PRECISION," +
                                " T4.DATA_TYPE AS NEW_DATA_TYPE," +
                                " T4.DATA_LENGTH AS NEW_DATA_LENGTH," +
                                " T4.DATA_PRECISION AS NEW_DATA_PRECISION" +
                                " FROM T3 FULL OUTER JOIN T4 ON T3.TABLE_NAME = T4.TABLE_NAME AND T3.COLUMN_NAME = T4.COLUMN_NAME" +
                                " ORDER BY 1,2,3"
                     ]

        while True:
            for statement in statements:
                try:
                    print(statement)
                    self._oracle_cursor.execute(statement)

                except cx_Oracle.DatabaseError as error:
                    print(error)
                continue
            break

        sql = "SELECT * FROM " + self._icsr_info_schema + ".OASIS_SCHEMA_DIFFERENCES"
        
        self._logger.info(sql)
        self._oracle_cursor.execute(sql)
        res = self._oracle_cursor.fetchall()
        self._logger.info(res)
        
        sql = "SELECT COUNT(*) FROM " + self._icsr_info_schema + ".OASIS_SCHEMA_DIFFERENCES"
        
        self._logger.info(sql)
        self._oracle_cursor.execute(sql)
        data = self._oracle_cursor.fetchone()
        self._logger.info(data)
        count = int(str(data[0]))

        self._oracle_cursor.close()

        if count > 0:
            raise Exception("Error: Schema differences detected")
