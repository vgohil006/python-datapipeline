'''
Created on May 21, 2020

@author: mfilho
'''

from steps import CopyToTable
from util import BaseStep, SqlScriptSpec, RunSqlScriptStep, DbUtils, DbCsvLoader,DbPsql, AppError

from datetime import datetime

now = datetime.now()
now = now.replace(hour=0,minute=0,second=0)
year = now.strftime("%Y")
month = now.strftime("%m")
day = now.strftime("%d")
time = now.strftime("%H:%M:%S")
asof_date_am_pm = now.strftime("%m/%d/%Y %I:%M:%S %p")
asof_date = now.strftime("%m/%d/%Y %H:%M:%S")
asof_date = asof_date.replace("12:00:00","00:00:00")


class PrepareCases(BaseStep):
    '''
    Prepare the case data for loading into the data mart
    '''

    def __init__(self, meddra_schema, data_prep_version):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "prepare_cases",
                          "Prepare the case data")
#        self._meddra_schema = "meddra"
        self._data_prep_version = data_prep_version

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(PrepareCases, self)._init_cursors(settings)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(PrepareCases, self)._do_step(interactive, config_settings,
                                           run_vars, run_status)

        self._oasis_staging_user = config_settings.get("postgresql", "postgresql_user")
        self._oasis_staging_pass = config_settings.getsecret("postgresql", "postgresql_user_pass")
        self._oasis_staging_schema = config_settings.get("db-common", "icsr_staging_schema")
        self._icsr_orig_schema = config_settings.get("db-common","icsr_orig_schema")
        self._meddra_schema = config_settings.get("db-common","meddra_schema")
        self._oasis_meddra_schema = config_settings.get("db-common","oasis_meddra_schema")
        
        self._icsr_tables = [ "drug","drug_dosage","drug_indication","drug_reaction", "followup", "lab_data","literature","narrative",
                              "neonates","parent","patient","patient_deathcause","patient_hist", "pregnancy", "reaction","reporters",
                              "safety_report","study"
                            ]
                      
        
        self._asof_date_am_pm = asof_date_am_pm
        self._asof_date = asof_date
        
        self._search_path = self._oasis_staging_schema + "," + self._oasis_meddra_schema + "," + self._icsr_orig_schema

        meddra_schema = self._meddra_schema
        meddra_version = meddra_schema[-3:-1] + '.' + meddra_schema[-1]
        
        #
        run_vars.set("meddra_version", meddra_version)
        run_vars.set("meddra_schema", meddra_schema)
        run_vars.set("asof_date", self._asof_date)
        run_vars.set("asof_date_am_pm", self._asof_date_am_pm)
        run_vars.set("snapshot_schema", self._oasis_staging_schema)
        run_vars.set("snapshot_version", "1")
        run_status.set_inprogress_setting("asof_date", self._asof_date)
        
        self._cursor = self._cursors.get_cursor(self._oasis_staging_user,
                                                self._oasis_staging_pass,
                                                self._db_connect_str,
                                                self._oasis_staging_schema)

        script_specs = [ SqlScriptSpec("oasis_etl_util.sql", "load_data_prep_funcs","Load the data prep stored functions"),
                         SqlScriptSpec("01_caselist.sql","create_case_list","Create case list table"),
                         SqlScriptSpec("02_safety_report.sql","create_safety_report","Create the safety_report table"),
                         SqlScriptSpec("03_patient.sql","create_patient","Create patient table"),
                         SqlScriptSpec("04_drug.sql","create_drug","Create drug table"),
                         SqlScriptSpec("05_reaction.sql","create_reaction","Create reaction table"),
                         SqlScriptSpec("06_narrative.sql","create_narrative","Create narrative table"),
                         SqlScriptSpec("071_drug_reaction_helper_part1.sql","create_drug_reaction_helpers_1","Create drug reaction helper tables part 1"),
                         SqlScriptSpec("072_drug_reaction_helper_part2.sql","create_drug_reaction_helpers_2","Create drug reaction helper tables part 2"),
                         SqlScriptSpec("073_drug_reaction.sql","create_drug_reaction","Create drug_reaction table"),
                         SqlScriptSpec("08_drug_dosage.sql","create_drug_dosage","Create drug_dosage table"),
                         SqlScriptSpec("09_drug_indication.sql","create_drug_indication","Create drug_indication table"),
                         SqlScriptSpec("10_reporters.sql","create_reporters","Create reporters table"),
                         SqlScriptSpec("11_literature.sql","create_literature","Create literature table"),
                         SqlScriptSpec("12_study.sql","create_study","Create study table"),
                         SqlScriptSpec("13_death.sql","create_patient_deathcause","Create patient_deathcause table"),
                         SqlScriptSpec("14_lab_data.sql","create_lab_data","Create lab_data table"),
                         SqlScriptSpec("15_neonates.sql","create_neonates","Create noenates table"),
                         SqlScriptSpec("16_parent.sql","create_parent","Create parent table"),
                         SqlScriptSpec("17_patient_hist.sql","create_patient_hist","Create patient_hist table"),
                         SqlScriptSpec("18_pregnancy.sql","create_pregnancy","Create pregnancy table"),
                         SqlScriptSpec("19_followup.sql","create_followup","Create followup table"),
                         SqlScriptSpec("create_oasis_reference_tables.sql","oasis_reference_tables","Create reference data tables")
                       ]

        psql_path = config_settings.get("data_prep", "psql_path")
                                                
        # Pass the name of the "by_quarter" schema and the "meddra_schema"
        # as arguments to the scripts
        sql_script_args = [ "-v", f"meddra_schema={self._meddra_schema}",
                          ]

        substeps = [ RunSqlScriptStep(self, psql_path, "sql",
                                      SqlScriptSpec("create_country_region_map.sql","create_country_code_map","Create the country_code_map table"),
                                      self._db_connect_str, self._oasis_staging_user,
                                      self._oasis_staging_pass, self._oasis_staging_schema),
                     
                     CopyToTable(self, self._cursor,
                                 "data/country_region_map.txt",
                                 f"{self._oasis_staging_schema}.country_region_map",
                                 cols=("country", "region"), fmt="csv",
                                 delimiter="e'\t'", null="''", header="ON",
                                 encoding="UTF-8"),

                     RunSqlScriptStep(self, psql_path, "sql",
                                      SqlScriptSpec("create_medhist_map.sql","create_medhist_map","Create the medical history abbreviations map table"),
                                      self._db_connect_str, self._oasis_staging_user,
                                      self._oasis_staging_pass, self._oasis_staging_schema),

                     CopyToTable(self, self._cursor,
                                 "data/medhist_map.txt",
                                 f"{self._oasis_staging_schema}.medhist_map",
                                 cols=("condition_type", "abbrev"), fmt="csv",
                                 delimiter="e'\t'", null="''", header="ON",
                                 encoding="UTF-8"),

                     RunSqlScriptStep(self, psql_path, "sql",
                                      SqlScriptSpec("create_reporter_type_map.sql","create_reporter_type_map","Create the reporter type abbreviations map table"),
                                      self._db_connect_str, self._oasis_staging_user,
                                      self._oasis_staging_pass, self._oasis_staging_schema),

                     CopyToTable(self, self._cursor,
                                 "data/reporter_type_map.txt",
                                 f"{self._oasis_staging_schema}.reporter_type_map",
                                 cols=("reporter_type", "abbrev"), fmt="csv",
                                 delimiter="e'\t'", null="''", header="ON",
                                 encoding="UTF-8"),
                     
                     RunSqlScriptStep(self, psql_path, "sql",
                                      SqlScriptSpec("create_family_group_map.sql","create_family_group_map","Create the family group map table"),
                                      self._db_connect_str, self._oasis_staging_user,
                                      self._oasis_staging_pass, self._oasis_staging_schema),
                     
                     CopyToTable(self, self._cursor,
                                 "data/family_group_map.txt",
                                 f"{self._oasis_staging_schema}.family_group_map",
                                 cols=("grouped_family_name","family_name"), fmt="csv",
                                 delimiter="e'\t'", null="''", header="ON",
                                 encoding="UTF-8"),
                     
                    ]
        
        substeps.extend([ RunSqlScriptStep(self, psql_path, "sql", script_spec,
                                           self._db_connect_str, self._oasis_staging_user,
                                           self._oasis_staging_pass, self._search_path,
                                           sql_script_args)
                          for script_spec in script_specs ] )
                          
                          
        substeps.extend([
                         # TODO
#                        GatherSnapshotInfo(self._data_prep_version),

                        CreateMartMetadataTables(self,
                                            self._cursor, 
                                            self._oasis_staging_schema, 
                                            self._icsr_tables),

                        CreateViews(self, 
                                    self._cursor,
                                    self._oasis_staging_schema,
                                    self._icsr_tables),
                     
                        CreateUvtTables(self, 
                                    self._cursor,
                                    self._oasis_staging_schema),

                        CreateDataConfigs(self, 
                                          self._cursor, 
                                          self._oasis_staging_schema,
                                          self._db_connect_str,
                                          self._oasis_staging_user, 
                                          self._oasis_staging_pass 
                                          ),

                        CreateOtherTables(self, 
                                          self._cursor, 
                                          self._oasis_staging_schema,
                                          self._data_prep_version,
                                          self._oasis_staging_user, 
                                          self._oasis_staging_pass, 
                                          self._db_connect_str),
                        
                        CreateReferenceTables(self,
                                              self._cursor)                                 
                     ])
                             
        self.execute_substeps(substeps)
        
class CreateMartMetadataTables(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, staging_cursor, staging_schema, icsr_tables):
        BaseStep.__init__(self,
                          "create_mart_metadata_tables",
                          "Create the mart metadata tables",
                          parent=parent_step)
        self._cursor = staging_cursor
        self._staging_schema = staging_schema
        self._icsr_tables = icsr_tables

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateMartMetadataTables, self)._do_step(interactive, config_settings,
                                                       run_vars, run_status)

        # Create the mart_objects table
        table = "mart_objects"
        DbUtils.drop_table(self._cursor, None, table)
        DbUtils.create_table(self._cursor, None, table,
                             "object_name VARCHAR PRIMARY KEY, object_type VARCHAR NOT NULL")

        icsr_tables = self._icsr_tables

        other_tables = ["smq_syn_terms"]

        # Populate mart_objects with the icsr tables
        for table in icsr_tables:
            sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(table)s, 'timestamped table')"
            self._cursor.execute(sql, {"table": table})
            self._cursor.connection.commit()

        # Populate mart_objects with the other tables
        for table in other_tables:
            # Add an entry to the mart_objects table
            sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(table)s, 'table')"
            self._cursor.execute(sql, {"table": table})
            self._cursor.connection.commit()
        
        # Create and populate the mart_indexes table
        table = "mart_indexes"
        DbUtils.drop_table(self._cursor, None, table)
        cols = ["index_name VARCHAR PRIMARY KEY",
                "table_name VARCHAR NOT NULL",
                "method VARCHAR NOT NULL",
                "unique_yn VARCHAR NOT NULL",
                "cols_or_expr VARCHAR NOT NULL"]
        DbUtils.create_table(self._cursor, None, table, ", ".join(cols))
        self._load_mart_indexes_info(table)

    def _load_mart_indexes_info(self, mart_indexes_table):
        # use DbCsvLoader to load the mart_indexes information
        path = "data/mart_indexes.txt"
        loader = DbCsvLoader(path, self._staging_schema, mart_indexes_table,
                             num_header_rows=2)
        loader.insert_data(self._cursor, {})

        self._cursor.connection.commit()
        
class CreateOtherTables(BaseStep):
    '''
    Initialize the other (non-config) tables
    '''

    def __init__(self, parent_step,_cursor, staging_schema, data_prep_version, db_user, db_pass, db_connect_str):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "create_other_tables",
                          "Create other (non-config) tables",
                          parent=parent_step)
        self._cursor = _cursor
        self._staging_schema = staging_schema
        self._data_prep_version = data_prep_version
        self._db_user = db_user
        self._db_pass = db_pass
        self._db_connect_str = db_connect_str

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateOtherTables, self)._do_step(interactive, config_settings,
                                              run_vars, run_status)
        psql_path = config_settings.get("data_prep", "psql_path")
        target_schema = self._staging_schema
        
        
        # table_info is a tuple identifying table, associated sequence (if any)
        # and the sequence column (if any)
        table_info = [("annotation_value", "annotation_value_id_seq", "id"),
                      ("qbe_layout", "qbe_layout_id_seq", "id"),
                      ("snapshot_version", None, None),
                      ("spontaneous_datasource_flag", None, None),
                      ("term_hierarchy_dates", None, None),
                      ("term_hierarchy_levels", None, None),
                      ("valid_asof", None, None),
                     ]
        
        # substitution variables used when populating data tables
        substitution_vars = {
            "asof": run_vars.get("asof_date_am_pm"),
            "data_prep_version": self._data_prep_version,
            "meddra_schema": run_vars.get("meddra_schema"),
            "meddra_version": run_vars.get("meddra_version"),
            "snapshot_schema": run_vars.get("snapshot_schema"),
            "snapshot_version": run_vars.get("snapshot_version"),
        }
        
        for table, seq, seq_column in table_info:
            # drop the table if it already exists
            DbUtils.drop_table(self._cursor, "", table)

            # run the SQL script to create the table
            script = f"create_{table}.sql"
            DbPsql.invoke_db_cmd(
                psql_path, "sql", self._db_user, self._db_pass,
                target_schema, self._db_connect_str, script)
            self._logger.info(f"Executed the '{script}' script to create the '{table}' table")

            # use DbCsvLoader to load the data
            path = f"data/{table}.txt"
            loader = DbCsvLoader(path, target_schema, table, num_header_rows=2)
            loader.insert_data(self._cursor, substitution_vars)
            self._cursor.connection.commit()
            
            # Delete an entry from the mart_objects table if it already exists
            delete_sql = ("DELETE FROM mart_objects\n"
                          " WHERE object_name = %(table)s AND object_type = 'table'")
            self._cursor.execute(delete_sql, {"table": table})

            # Add an entry to the mart_objects table
            sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(table)s, 'table')"
            self._cursor.execute(sql, {"table": table})
            self._cursor.connection.commit()
            
            if seq and seq_column:
                self._cursor.execute(f"SELECT MAX({seq_column}) FROM {table}")
                max_id = self._cursor.fetchone()[0]
                next_id = max_id + 1 if max_id else 1
                
                DbUtils.drop_sequence(self._cursor, None, seq)
                DbUtils.create_sequence(self._cursor, None, seq, start=next_id)

                # Delete an entry from the mart_objects table if it already exists
                delete_sql = ("DELETE FROM mart_objects\n"
                              " WHERE object_name = %(sequence)s AND object_type = 'sequence'")
                self._cursor.execute(delete_sql, {"sequence": seq})

                # Add an entry to the mart_objects table
                sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(sequence)s, 'sequence')"
                self._cursor.execute(sql, {"sequence": seq})
                self._cursor.connection.commit()
            
            self._logger.info(f"Loaded data for the '{table}' table")
            

class CreateUvtTables(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, snapshot_cursor, staging_schema):
        BaseStep.__init__(self,
                          "create_uvt_tables",
                          "Create the UVT tables",
                          parent=parent_step)
        
        self._cursor = snapshot_cursor
        self._snapshot_schema = staging_schema

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateUvtTables, self)._do_step(interactive, config_settings,
                                              run_vars, run_status)

        uvt_info_table = "tmp_uvt_info"
        self._load_uvt_info(uvt_info_table)        

        self._populate_uvts(uvt_info_table)

        self._drop_uvt_info(uvt_info_table)
    
    def _load_uvt_info(self, uvt_info_table):
        # drop the uvt info table if it already exists
        DbUtils.drop_table(self._cursor, "", uvt_info_table)
        
        # create the uvt info table table
        DbUtils.create_table(self._cursor, "", uvt_info_table,
                             "uvt_name VARCHAR, table_name VARCHAR, column_name VARCHAR")

        # use DbCsvLoader to load the uvt information
        path = "data/uvt_info.txt"
        loader = DbCsvLoader(path, self._snapshot_schema, uvt_info_table,
                             num_header_rows=2)
        loader.insert_data(self._cursor, {})

        self._cursor.connection.commit()
        
        self._logger.info(f"Loaded data for the '{uvt_info_table}' table")

    def _populate_uvts(self, uvt_info_table):
        sql = (f"SELECT uvt_name, table_name, column_name\n"
               f"  FROM {uvt_info_table}\n"
               f"ORDER BY uvt_name")
        
        for row in list(DbUtils.execute_query(self._cursor, sql)):
            uvt_name = row["uvt_name"]
            table = row["table_name"]
            column = row["column_name"]
            self._logger.info(f"Populating the {uvt_name} table")
            DbUtils.drop_table(self._cursor, "", uvt_name)
            
            # Delete an entry from the mart_objects table if it already exists
            delete_sql = ("DELETE FROM mart_objects\n"
                          " WHERE object_name = %(uvt_name)s AND object_type = 'uvt'")
            self._cursor.execute(delete_sql, {"uvt_name": uvt_name})
            
            select_sql = (f"SELECT DISTINCT {column} AS item_value\n"
                          f"  FROM {table}\n"
                          f" WHERE {column} IS NOT NULL")
            DbUtils.create_table(self._cursor, "", uvt_name, select_stmt=select_sql)
            DbUtils.create_index(self._cursor, "", uvt_name, f"{uvt_name}_ix1", "item_value", unique=True)
            DbUtils.compute_table_statistics(self._cursor, "", [uvt_name])
            
            # Add an entry to the mart_objects table
            sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(uvt_name)s, 'uvt')"
            self._cursor.execute(sql, {"uvt_name": uvt_name})
            self._cursor.connection.commit()
    
    def _drop_uvt_info(self, uvt_info_table):
        # drop the table if it already exists
        DbUtils.drop_table(self._cursor, "", uvt_info_table)

class CreateViews(BaseStep):
    '''
    Create the views for the snapshot
    '''

    def __init__(self, parent_step, snapshot_cursor, staging_schema, icsr_tables):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "create_views",
                          "Create the views for the snapshot",
                          parent=parent_step)
        self._cursor = snapshot_cursor
        self._staging_schema = staging_schema
        self._icsr_tables = icsr_tables

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateViews, self)._do_step(interactive, config_settings,
                                          run_vars, run_status)
        
        tables = self._icsr_tables
        suffixes = ['spont',
                    'all',
                    'all_w_invalid',
                   ]
        products = ['d',
                    'v',
                   ]
        
        delete_sql = ("DELETE FROM mart_objects\n"
                      " WHERE object_name = %(view_name)s AND object_type = 'view'")
        for table in tables:
            for product in products:
                for suffix in suffixes:
                    view_name = f"{table}_{product}_{suffix}"
                    DbUtils.drop_view(self._cursor, None, view_name)
                    
                    if product == 'd':
                        where_sql = "drug_case_yn='Y'"
                    elif product == 'v':
                        where_sql = "vaccine_case_yn='Y'"
                    else:
                        raise AppError(f"Unexpected product suffix: {product}")
                
                    
                    if suffix == 'spont':
                        where_sql += " AND spont_valid_case_yn = 'Y'"
                    elif suffix == 'all':
                        where_sql += " AND valid_case_yn = 'Y'"
                    elif suffix == 'all_w_invalid':
                        pass
                    else:
                        raise AppError(f"Unexpected view suffix: {suffix}")

                    # Delete an entry from the mart_objects table if it already exists
                    self._cursor.execute(delete_sql, {"view_name": view_name})

                    select_sql = f"SELECT * FROM {table} WHERE {where_sql}"
                    DbUtils.create_view(self._cursor, None, view_name, select_sql)
                
                    # Add an entry to the mart_objects table
                    sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(view_name)s, 'view')"
                    self._cursor.execute(sql, {"view_name": view_name})
                    self._cursor.connection.commit()


        # Create views used for CASE DETAILS lists of suspect drugs, conmeds, preferred terms
        other_views = [("suspect_drug", "drug", "suspect_yn = 'Y'"),
                       ("non_suspect_drug", "drug", "suspect_yn = 'N'"),
                       ("primary_reporter", "reporters", "primary_contact_yn = 'Y'"),
                       ("reaction_pt", "reaction", "reaction_type = 'PT'")
                       ]
        for view in other_views:
            view_name = view[0]
            table = view[1]
            where_sql = view[2]
            select_sql = f"SELECT * FROM {table} WHERE {where_sql}"
            DbUtils.create_view(self._cursor, None, view_name, select_sql)

            # Delete an entry from the mart_objects table if it already exists
            self._cursor.execute(delete_sql, {"view_name": view_name})

            # Add an entry to the mart_objects table
            sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(view_name)s, 'view')"
            self._cursor.execute(sql, {"view_name": view_name})
            self._cursor.connection.commit()


class CreateDataConfigs(BaseStep):
    '''
    Initialize the data configuration tables
    '''

    def __init__(self, parent_step, snapshot_cursor, snapshot_schema,
                 db_connect_str, db_user, db_pass):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "create_data_configs",
                          "Create the data configuration tables",
                          parent=parent_step)
        self._cursor = snapshot_cursor
        self._snapshot_schema = snapshot_schema
        self._db_connect_str = db_connect_str
        self._db_user= db_user
        self._db_pass = db_pass

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateDataConfigs, self)._do_step(interactive, config_settings,
                                                run_vars, run_status)
        psql_path = config_settings.get("data_prep", "psql_path")
        target_schema = self._snapshot_schema
        
        # table_info is a tuple identifying table, associated sequence (if any)
        # and the sequence column (if any)
        table_info = [("datasource_info", "datasource_info_id_seq", "id"),
                 ]
        
        for table, seq, seq_column in table_info:
            # drop the table if it already exists
            DbUtils.drop_table(self._cursor, "", table)

            # run the SQL script to create the table
            script = f"create_{table}.sql"
            DbPsql.invoke_db_cmd(
                psql_path, "sql", self._db_user, self._db_pass,
                target_schema, self._db_connect_str, script)
            self._logger.info(f"Executed the '{script}' script to create the '{table}' table")

            # use DbCsvLoader to load the data
            path = f"data/{table}.txt"
            loader = DbCsvLoader(path, target_schema, table, num_header_rows=2)
            loader.insert_data(self._cursor, {})
                            
            # Delete an entry from the mart_objects table if it already exists
            delete_sql = ("DELETE FROM mart_objects\n"
                          " WHERE object_name = %(table)s AND object_type = 'table'")
            self._cursor.execute(delete_sql, {"table": table})

            # Add an entry to the mart_objects table
            sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(table)s, 'table')"
            self._cursor.execute(sql, {"table": table})
            self._cursor.connection.commit()
            
            if seq and seq_column:
                self._cursor.execute(f"SELECT MAX({seq_column}) FROM {table}")
                max_id = self._cursor.fetchone()[0]
                next_id = max_id + 1 if max_id else 1
                
                DbUtils.drop_sequence(self._cursor, None, seq)
                DbUtils.create_sequence(self._cursor, None, seq, start=next_id)

                # Delete an entry from the mart_objects table if it already exists
                delete_sql = ("DELETE FROM mart_objects\n"
                              " WHERE object_name = %(sequence)s AND object_type = 'sequence'")
                self._cursor.execute(delete_sql, {"sequence": seq})

                # Add an entry to the mart_objects table
                sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(sequence)s, 'sequence')"
                self._cursor.execute(sql, {"sequence": seq})
                self._cursor.connection.commit()
            
            self._logger.info(f"Loaded data for the '{table}' table")
            
        products = ["drug", "vacc"]
        
        datasource_variants = ["spont", "all", "all_w_invalid",]
        
        metadata_tables = ["metadata_categories",
                           "metadata_columns",
                           "metadata_drilldown",
                           "metadata_tables",
                          ]
        
        for product in products:
            product_abbrev = product[:1]
            for variant in datasource_variants:
                for table in metadata_tables:
                
                    # drop the table if it already exists
                    variant_table = f"{product}_{variant}_{table}"
                    variant_suffix = f"{product_abbrev}_{variant}"
                    DbUtils.drop_table(self._cursor, "", variant_table)
    
                    # run the SQL script to create the table
                    script = f"create_{table}.sql"
                    DbPsql.invoke_db_cmd(
                        psql_path, "sql", self._db_user, self._db_pass,
                        target_schema, self._db_connect_str, script, ["-v", f"table_name={variant_table}"])
                    self._logger.info(f"Executed the '{script}' script to create the '{variant_table}' table")
    
                    # use DbCsvLoader to load the data
                    path = f"data/{table}.txt"
                    loader = DbCsvLoader(path, target_schema, variant_table, num_header_rows=2)
                    loader.insert_data(self._cursor, {"suffix": f"_{variant_suffix}"})
                    self._cursor.connection.commit()

                    # Delete an entry from the mart_objects table if it already exists
                    delete_sql = ("DELETE FROM mart_objects\n"
                                  " WHERE object_name = %(table)s AND object_type = 'table'")
                    self._cursor.execute(delete_sql, {"table": variant_table})
                
                    # Add an entry to the mart_objects table
                    sql = "INSERT INTO mart_objects (object_name, object_type) VALUES (%(table)s, 'table')"
                    self._cursor.execute(sql, {"table": variant_table})
                    self._cursor.connection.commit()
                
                    self._logger.info(f"Loaded data for the '{variant_table}' table")
                    

class CreateReferenceTables(BaseStep):
    '''
    Constructor
    '''
    def __init__(self, parent_step, staging_cursor):
        BaseStep.__init__(self,
                          "create_reference_tables",
                          "Create reference tables",
                          parent=parent_step)
        
        self._cursor = staging_cursor

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateReferenceTables, self)._do_step(interactive, config_settings,
                                                       run_vars, run_status)

        # Create the mart_objects table
        table = "reference_objects"
        DbUtils.drop_table(self._cursor, None, table)
        DbUtils.create_table(self._cursor, None, table,
                             "object_name VARCHAR PRIMARY KEY, object_type VARCHAR NOT NULL")

        reference_tables = ["oasis_serious_terms",
                            "oasis_dme_terms",
                            "oasis_med_error_terms",
                            "oasis_labelled_terms"]

        # Populate reference_objects with the reference tables
        for table in reference_tables:
            # Add an entry to the mart_objects table
            sql = "INSERT INTO reference_objects (object_name, object_type) VALUES (%(table)s, 'table')"
            self._cursor.execute(sql, {"table": table})
            self._cursor.connection.commit()