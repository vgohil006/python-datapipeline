'''
@author: vgohil
'''

from util import BaseStep
import boto3
from time import sleep



class StartRDSInstance(BaseStep):
    '''
    Start the Oracle instance needed for the AWS Data Migration Service
    '''

    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "start_rds_instance",
                          "Start the Oracle instance for AWS DMS")

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(StartRDSInstance, self)._init_cursors(settings)
        
        self._source_endpoint = settings.get("dms", "source_endpoint")

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(StartRDSInstance, self)._do_step(interactive, config_settings,
                                       run_vars, run_status)
        
        self._source_endpoint = config_settings.get("dms", "source_endpoint")
        
        # The code to start the Oracle instance goes here
        client = boto3.client('rds')
        
        response = client.describe_db_instances(DBInstanceIdentifier = self._source_endpoint,
                                        MaxRecords=100,
                                        Marker='string')
        
        status = response['DBInstances'][0]['DBInstanceStatus']

        self._logger.info('==== Source Database Instance Status ====\n')
        
        self._logger.info(response['DBInstances'][0]['DBInstanceIdentifier'] + ' => ' + response['DBInstances'][0]['DBInstanceArn'])
        
        self._logger.info(f" --- RDS Instance: {status} ---")
        
        WAIT_TIME = 30 # seconds to wait between each poll
        MAX_RETRY = 2000 # the max number of seconds to poll before timing out
              
        retry = 0

        while True:
            if status == 'available':
                self._logger.info("--- RDS Instance is already running!! ---")
                break

            elif status == 'failed':
                raise Exception('--- RDS Instance failed ---')

            elif retry > MAX_RETRY:
                raise Exception('--- RDS Instance failed or timed out ---')

            elif status == 'stopped':
                client.start_db_instance(DBInstanceIdentifier=self._source_endpoint)
        
            
            retry += WAIT_TIME
            sleep(WAIT_TIME)
            rds_response = client.describe_db_instances(DBInstanceIdentifier=self._source_endpoint,
                                                        MaxRecords = 100, 
                                                        Marker='string')

            status = rds_response['DBInstances'][0]['DBInstanceStatus']
            self._logger.info(f"--- RDS Instance: {status} ---")

