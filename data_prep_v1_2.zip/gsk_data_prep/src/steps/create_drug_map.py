'''
Created on May 21, 2020

@author: mfilho
'''
from steps import PopulateLookupTable, PopulateSingleColTable
from util import BaseStep, SqlScriptSpec, RunSqlScriptStep


class CreateDrugMap(BaseStep):
    '''
    Create a map from drug name verbatims to the corresponding set of
    product active ingredients
    '''

    def __init__(self):
        '''
        Constructor
        '''
        BaseStep.__init__(self,
                          "create_drug_map",
                          "Create a mapping for use in drug name cleaning")

    def _init_cursors(self, settings):
        '''
        Initialize the cursors used by this step
        '''
        super(CreateDrugMap, self)._init_cursors(settings)
        self._oasis_staging_user = settings.get("postgres", "postgresql_user")
        self._oasis_staging_pass = settings.getsecret("postgresql", "postgresql_user_pass")
        self._oasis_staging_schema = settings.get("db-common", "icsr_staging_schema")
        
        self._cursor = self._cursors.get_cursor(self._oasis_staging_user,
                                                self._oasis_staging_pass,
                                                self._db_connect_str,
                                                self._oasis_staging_schema)

    def _do_step(self, interactive, config_settings, run_vars, run_status):
        '''
        Execute the step
        '''
        super(CreateDrugMap, self)._do_step(interactive, config_settings,
                                            run_vars, run_status)

        script_specs = [ SqlScriptSpec("create_drug_map.sql", "create_drug_map",
                                       "Create a mapping for use in drug name cleaning"),
                       ]

        psql_path = config_settings.get("data_prep", "psql_path")
                                                
        # Pass the name of the "by_quarter" schema as an argument to the script
        sql_script_args = [ "-v", f"combined_schema={self._faers_combined_schema}",
                          ]

        substeps = [ PopulateLookupTable(self, self._cursor,
                                         self._oasis_staging_schema,
                                         "data/drug_name_mappings",
                                         "verbatim", "verbatim_*.txt",
                                         "verbatim_lookup", "verbatim",
                                         "prod_ai"),
                     PopulateLookupTable(self, self._cursor,
                                         self._oasis_staging_schema,
                                         "data/drug_name_mappings",
                                         "adjusted_verbatim", "adjusted_verbatim_*.txt",
                                         "adjusted_verbatim_lookup", "adjusted_verbatim",
                                         "prod_ai", "seq"),
                     PopulateLookupTable(self, self._cursor,
                                         self._oasis_staging_schema,
                                         "data/drug_name_mappings",
                                         "single_ingred", "ingredient_moiety_map.txt",
                                         "ingredient_moiety_map", "single_ingred",
                                         "single_moiety"),
                     PopulateSingleColTable(self, self._cursor,
                                            self._oasis_staging_schema,
                                            "data/drug_name_mappings",
                                            "salt pattern", "salt_patterns.txt",
                                            "salt_pattern", "salt_pattern"),
                   ]
        
        substeps.extend([ RunSqlScriptStep(self, psql_path, "sql", script_spec,
                                           self._db_connect_str, self._oasis_staging_user,
                                           self._oasis_staging_pass, self._oasis_staging_schema,
                                           sql_script_args)
                          for script_spec in script_specs ])
        
        self.execute_substeps(substeps)
