'''
@author: rschaaf
'''

from encrypt_key import EncryptKey
from argparse import ArgumentParser
from util import ConfigParserExt

def parse_cmd_args():
    '''
    parse the command line arguments
    '''
    parser = ArgumentParser(usage='%(prog)s -s <secrets_file>')
    parser.add_argument("-s", "--secrets-file",
                        help="secrets file",
                        action="store", dest="secrets_file")

    # Check for the presence of required arguments
    options = parser.parse_args()
    if not options.secrets_file:
        parser.error("no secrets_file")
        
    return options

def encrypt_secrets(secrets_file):
    '''
    Encrypt the settings in the secrets file
    '''
    secrets = ConfigParserExt(EncryptKey.KEY)
    secrets.read(secrets_file)

    if secrets.has_option("status", "encrypted"):
        encrypted = secrets.getboolean("status", "encrypted")
    else:
        encrypted = False

    if not encrypted:
        # Indicate that the settings are encrypted
        if not secrets.has_section("status"):
            secrets.add_section("status")
        secrets.set("status", "encrypted", str(True))
        
        for section in secrets.sections():
            for option in secrets.options(section):
                if section == "status" and option == "encrypted":
                    continue
                else:
                    plaintext = secrets.get(section, option)
                    secrets.setsecret(section, option, plaintext)
                    
        store_secrets(secrets, secrets_file)
        print(f"The settings in '{secrets_file}' have been encrypted.")
    else:
        print(f"The settings in '{secrets_file}' are already encrypted.")

def store_secrets(secrets, secrets_file):
    '''
    Write out the secrets config file
    '''
    fp = open(secrets_file, "w")
    secrets.write(fp)

if __name__ == '__main__':
    options = parse_cmd_args()
    encrypt_secrets(options.secrets_file)
