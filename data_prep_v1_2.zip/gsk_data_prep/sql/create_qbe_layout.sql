CREATE TABLE qbe_layout (
   id INTEGER NOT NULL PRIMARY KEY,
   layout_id INTEGER NOT NULL,
   layout_name VARCHAR NOT NULL,
   layout_description VARCHAR,
   case_series_bean VARCHAR NOT NULL,
   qbe_class VARCHAR NOT NULL,
   icsr_class VARCHAR NOT NULL,
   create_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
   create_user INTEGER NOT NULL DEFAULT 1,
   update_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
   update_user INTEGER NOT NULL DEFAULT 1,
   isvalid CHAR(1) NOT NULL DEFAULT 'Y'
);
