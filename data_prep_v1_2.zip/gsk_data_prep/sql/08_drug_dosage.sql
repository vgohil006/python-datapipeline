--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS drug_dosage CASCADE;
CREATE TABLE drug_dosage
(
    case_id INTEGER NOT NULL,
    primary_id VARCHAR(20) NOT NULL,
    prod_seq_num INTEGER,
    dose_seq_num INTEGER,
    prod_sort_id INTEGER,
    dose_sort_id INTEGER,
    product_name TEXT,
    generic_name TEXT,
    family_name_enhanced TEXT,
    dose FLOAT,
    dose_unit_id INTEGER,
    dose_unit TEXT,
    dose_freq_id INTEGER,
    dose_frequency TEXT,
    admin_route_id INTEGER,
    dose_route TEXT,
    par_admin_route_id INTEGER,
    dose_parent_route TEXT,
    daily_dose FLOAT,
    daily_dose_unit_id INTEGER,
    daily_dose_unit TEXT,
    total_reg_dose FLOAT,
    tot_reg_dose_unit_id INTEGER,
    tot_reg_dose_unit TEXT,
    dose_start_date_text TEXT,
    dose_start_date TIMESTAMP WITHOUT TIME ZONE,
    dose_stop_date_text TEXT,
    dose_stop_date TIMESTAMP WITHOUT TIME ZONE,
    dose_ongoing_yn VARCHAR(1),
    dose_off_label_yn VARCHAR(1),
    dose_lot_no TEXT,
    dose_expiry_date_text TEXT,
    dose_expiry_date TIMESTAMP WITHOUT TIME ZONE,
    dose_duration_seconds BIGINT,
    dose_description TEXT,
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1) NOT NULL,
    device_case_yn VARCHAR(1) NOT NULL,
    vaccine_case_yn VARCHAR(1) NOT NULL)
    WITH (autovacuum_enabled = FALSE, toast.autovacuum_enabled = FALSE);

INSERT INTO drug_dosage (
    case_id, primary_id, prod_seq_num, dose_seq_num,
    prod_sort_id, dose_sort_id,
    product_name,  generic_name, family_name_enhanced,
    dose, dose_unit_id, dose_unit, dose_freq_id, dose_frequency,
    admin_route_id, dose_route, par_admin_route_id, dose_parent_route,
    daily_dose, daily_dose_unit_id, daily_dose_unit,
    total_reg_dose, tot_reg_dose_unit_id, tot_reg_dose_unit,
    dose_start_date_text, dose_start_date, dose_stop_date_text, dose_stop_date,
    dose_ongoing_yn, dose_off_label_yn, dose_lot_no,
    dose_expiry_date_text, dose_expiry_date,
    dose_duration_seconds,
    dose_description,
    valid_case_yn, spont_case_yn, spont_valid_case_yn,
    drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT  t0.case_id,
        t0.primary_id,
        t0.prod_seq_num,
        t1.dose_no AS dose_seq_num,
        t0.prod_sort_id,
        t1.sort_id AS dose_sort_id,
        t0.product_name,
        t0.generic_name,
        t0.family_name_enhanced,
        t1.dose AS dose,  
        t1.dose_unit_id,
        lm_du.unit AS dose_unit,
        t1.freq_id AS dose_freq_id,
        lm_freq.freq  AS dose_frequency,
        t1.admin_route_id,
        lm_r.route_desc AS dose_route,
        t1.par_admin_route AS par_admin_route_id,
        lm_r2.route_desc AS dose_parent_route,
        t1.daily_dose AS daily_dose,  
        t1.daily_dose_unit_id,
        lm_du2.unit AS daily_dose_unit,
        t1.total_reg_dose,
        t1.tot_reg_dose_unit_id,
        lm_du3.unit AS tot_reg_dose_unit,
        t1.start_date_partial AS dose_start_date_text,
        t1.start_datetime AS dose_start_date,
        t1.stop_date_partial AS dose_stop_date_text,
        t1.stop_datetime AS dose_stop_date,
        DECODE_YN(t1.ongoing) AS dose_ongoing_yn,
        DECODE_YN(t1.off_label) AS dose_off_label_yn,
        t1.lot_no AS dose_lot_no,
        t1.exp_date_partial AS dose_expiry_date_text,
        t1.exp_date  AS dose_expiry_date,
        t1.duration_seconds AS dose_duration_seconds,
        CASE WHEN t1.dose_description IS NOT NULL AND LENGTH(t1.dose_description) > 0 THEN t1.dose_description END AS dose_description,
        t0.valid_case_yn,
        t0.spont_case_yn,
        t0.spont_valid_case_yn,
        t0.drug_case_yn,
        t0.device_case_yn,
        t0.vaccine_case_yn
  FROM drug t0
  JOIN case_dose_regimens t1     ON t0.case_id=t1.case_id AND t0.prod_seq_num=t1.seq_num
  LEFT JOIN lm_dose_units lm_du  ON t1.dose_unit_id = lm_du.unit_id AND lm_du.deleted IS NULL
  LEFT JOIN lm_dose_units lm_du2 ON t1.daily_dose_unit_id = lm_du2.unit_id AND lm_du2.deleted IS NULL
  LEFT JOIN lm_dose_units lm_du3 ON t1.tot_reg_dose_unit_id = lm_du3.unit_id AND lm_du3.deleted IS NULL
  LEFT JOIN lm_dose_frequency lm_freq ON t1.freq_id = lm_freq.freq_id AND lm_freq.deleted IS NULL
  LEFT JOIN lm_admin_route lm_r  ON t1.admin_route_id = lm_r.admin_route_id AND lm_r.deleted IS NULL
  LEFT JOIN lm_admin_route lm_r2 ON t1.par_admin_route = lm_r2.admin_route_id AND lm_r2.deleted IS NULL
;

CREATE INDEX drug_dose_ix1 ON drug_dosage(primary_id, prod_seq_num);
CREATE INDEX drug_dose_ix2 ON drug_dosage(case_id, prod_seq_num);

ANALYZE drug_dosage;
