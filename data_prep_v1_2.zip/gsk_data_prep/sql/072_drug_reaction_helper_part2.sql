--set search_path = sbx_oasis_sample, oasis, meddra;
--set search_path = oasis_staging, oasis, meddra;

-- ==========================================
-- drug_reaction.
-- Helper tables (part 2) for case_event_detail and tto
-- ==========================================

-- Helper table with information from case_event_detail
SELECT 'Create helper_event_detail_0 ' || now();

DROP TABLE IF EXISTS helper_event_detail_0;
 CREATE TABLE helper_event_detail_0 AS
  SELECT
        cl.case_id,
        t1.prod_seq_num::INTEGER AS prod_seq_num,
        t1.event_seq_num::INTEGER AS reaction_seq_num,
        t1.seq_num::INTEGER AS ed_seq_num,
        t1.rechallenge::INTEGER AS rechallenge_id,
        CASE t1.rechallenge
           WHEN 0 THEN 'No rechallenge'
           WHEN 1 THEN 'Rechallenge'
           WHEN 2 THEN 'Unknown'
           WHEN 3 THEN 'Does not apply'
        END AS rechallenge,
        t1.dechallenge::INTEGER AS dechallenge_id,
        CASE t1.dechallenge
           WHEN 0 THEN 'No dechallenge' --? 'Negative dechallenge'
           WHEN 1 THEN 'Dechallenge'  -- ? 'Positive dechallenge'
           WHEN 2 THEN 'Unknown'
           WHEN 3 THEN 'Does not apply'
        END AS dechallenge,
        t1.onset_delay,
        t1.onset_delay_seconds AS onset_delay_seconds,
        t1.onset_latency,
        t1.onset_latency_seconds AS onset_latency_seconds,
        t1.total_dose AS total_dose_to_onset,
        t1.total_dose_unit_id::INTEGER AS total_dose_unit_id,
        lm_du.unit AS total_dose_to_onset_unit
      FROM case_list cl
      JOIN case_event_detail t1 ON cl.case_id=t1.case_id::INTEGER AND t1.deleted IS NULL
 LEFT JOIN lm_dose_units lm_du ON lm_du.unit_id=t1.total_dose_unit_id AND lm_du.deleted IS NULL
;

-- Convert onset_latency to onset_latency_days

DROP TABLE IF EXISTS tmp_tto_0 CASCADE;
CREATE TABLE tmp_tto_0 AS
WITH tmp AS (
SELECT case_id, ed_seq_num, onset_latency,
  NULLIF(split_part(onset_latency, ' ', 1),'') as n_1,
  LOWER(NULLIF(split_part(onset_latency,  ' ', 2),'')) AS unit_1,
  NULLIF(split_part(onset_latency, ' ', 3),'') as n_2,
  LOWER(NULLIF(split_part(onset_latency,  ' ', 4),'')) AS unit_2
FROM helper_event_detail_0
  )
 , tmp1 AS (
SELECT case_id, ed_seq_num, onset_latency,
COALESCE(n_1, '0')::NUMERIC AS n_1,
LEFT(COALESCE(unit_1, 'da'),2) AS unit_1,
COALESCE(n_2, '0')::NUMERIC AS n_2,
LEFT(COALESCE(unit_2, 'da'),2) AS unit_2
FROM tmp)
SELECT case_id, ed_seq_num, onset_latency, n_1 * t1.factor + n_2 * t2.factor AS onset_latency_days_derived
FROM tmp1 t0
JOIN tmp_unit_map t1 ON t0.unit_1=t1.unit
JOIN tmp_unit_map t2 ON t0.unit_2=t2.unit
WHERE onset_latency is not null;

SELECT 'Create helper_event_detail ' || now();
DROP TABLE IF EXISTS helper_event_detail;
CREATE TABLE helper_event_detail AS
 SELECT t1.*, t2.onset_latency_days_derived
 FROM helper_event_detail_0 t1
 LEFT JOIN tmp_tto_0 t2 ON t1.case_id=t2.case_id AND t1.ed_seq_num = t2.ed_seq_num;
 
ALTER TABLE helper_event_detail ADD CONSTRAINT pk_helper_event_detail PRIMARY KEY(case_id, prod_seq_num, reaction_seq_num);
CREATE UNIQUE INDEX idx_helper_event_detail_1 ON helper_event_detail (case_id, ed_seq_num);
CREATE UNIQUE INDEX idx_helper_event_detail_2 ON helper_event_detail (case_id, reaction_seq_num, prod_seq_num);
ANALYZE helper_event_detail;
DROP TABLE IF EXISTS helper_event_detail_0;

-- Get relevant records from consequence
DROP TABLE IF EXISTS  tmp_tto_1;
CREATE TABLE tmp_tto_1 AS
SELECT  t2.case_id, t2.prod_seq_num, t2.reaction_seq_num, t1.term, t1.seq_num, t5.num_days, t1.ed_seq_num --$$$
FROM case_event_consequence t1
JOIN helper_event_detail t2 ON t1.case_id=t2.case_id AND t1.ed_seq_num=t2.ed_seq_num
LEFT JOIN consequence_map t5 ON t5.term=t1.term
WHERE t1.deleted IS NULL AND t1.consequence = 'Onset from First Dose';

-- Distill to a single record per DEC, with the lowest non-null onset_latency_days
SELECT 'Create helper_consequence ' || now();
DROP TABLE IF EXISTS  helper_consequence;
CREATE TABLE helper_consequence AS
SELECT DISTINCT ON (case_id, prod_seq_num, reaction_seq_num)
                    case_id, prod_seq_num, reaction_seq_num, term, seq_num, num_days AS onset_latency_days_derived, ed_seq_num
              FROM tmp_tto_1
          ORDER BY case_id, prod_seq_num, reaction_seq_num, num_days, seq_num DESC;

ALTER TABLE helper_consequence ADD CONSTRAINT pk_helper_consequence PRIMARY KEY(case_id, prod_seq_num, reaction_seq_num);
CREATE UNIQUE INDEX ix_helper_consequence_2 ON helper_consequence (case_id, reaction_seq_num, prod_seq_num);
ANALYZE helper_event_detail;
          

DROP TABLE IF EXISTS tmp_unit_map CASCADE;
--DROP TABLE IF EXISTS consequence_map CASCADE;
DROP TABLE IF EXISTS tmp_tto_0 CASCADE;
DROP TABLE IF EXISTS tmp_tto_1 CASCADE;

