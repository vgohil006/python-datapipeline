CREATE TABLE annotation_value (
   id INTEGER NOT NULL PRIMARY KEY,
   casediagram_id INTEGER NOT NULL,
   ww_safetyreport_id VARCHAR NOT NULL,
   category_name VARCHAR NOT NULL,
   annotation_values TEXT[],
   safetyreport_validstart TIMESTAMP WITHOUT TIME ZONE NOT NULL,
   safetyreport_validend TIMESTAMP WITHOUT TIME ZONE NOT NULL,
   create_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
   create_user INTEGER DEFAULT 1 NOT NULL,
   update_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
   update_user INTEGER NOT NULL DEFAULT 1
);
COMMENT ON TABLE annotation_value
  IS 'annotations on a diagram';
