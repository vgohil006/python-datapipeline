DROP TABLE IF EXISTS family_group_map cascade;

CREATE TABLE family_group_map (grouped_family_name TEXT, family_name TEXT,
 CONSTRAINT pk_family_group_map PRIMARY KEY(family_name));
