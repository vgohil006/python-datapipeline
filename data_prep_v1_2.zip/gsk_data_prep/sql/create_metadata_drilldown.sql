CREATE TABLE :table_name (
   drilldown_type VARCHAR NOT NULL,
   section_seq INTEGER NOT NULL,
   section_label VARCHAR,
   headings VARCHAR NOT NULL,
   columns VARCHAR NOT NULL,
   order_by VARCHAR,
   added_conditions VARCHAR,
   PRIMARY KEY (drilldown_type, section_seq)
);
