/* 
AlTER TABLE oasis.case_assess DROP CONSTRAINT pk_case_assess;
ALTER TABLE oasis.case_classifications DROP CONSTRAINT pk_case_classifications;
ALTER TABLE oasis.case_comments DROP CONSTRAINT pk_case_comments;
ALTER TABLE oasis.case_company_cmts DROP CONSTRAINT pk_case_company_cmts;
ALTER TABLE oasis.case_death DROP CONSTRAINT pk_case_death;
ALTER TABLE oasis.case_death_details DROP CONSTRAINT pk_case_death_details;
ALTER TABLE oasis.case_dose_regimens DROP CONSTRAINT pk_case_dose_regimens;
ALTER TABLE oasis.case_event DROP CONSTRAINT pk_case_event;
ALTER TABLE oasis.case_event_assess DROP CONSTRAINT pk_case_event_assess;
ALTER TABLE oasis.case_event_consequence DROP CONSTRAINT pk_case_event_consequence;
ALTER TABLE oasis.case_event_detail DROP CONSTRAINT pk_case_event_detail;
ALTER TABLE oasis.case_event_detail DROP CONSTRAINT uc_case_event_detail_cpe;
ALTER TABLE oasis.case_followup DROP CONSTRAINT pk_case_followup;
ALTER TABLE oasis.case_lab_data DROP CONSTRAINT pk_case_lab_data;
ALTER TABLE oasis.case_literature DROP CONSTRAINT pk_case_literature;
ALTER TABLE oasis.case_master DROP CONSTRAINT ak_csm_case_num;
ALTER TABLE oasis.case_master DROP CONSTRAINT pk_case_master;
ALTER TABLE oasis.case_narrative DROP CONSTRAINT pk_case_narrative;
ALTER TABLE oasis.case_neonates DROP CONSTRAINT pk_case_neonates;
ALTER TABLE oasis.case_pat_hist DROP CONSTRAINT pk_case_pat_hist;
ALTER TABLE oasis.case_pat_tests DROP CONSTRAINT pk_case_pat_tests;
ALTER TABLE oasis.case_pmoa_cons_relation DROP CONSTRAINT pk_case_pmoa_cons_relation;
ALTER TABLE oasis.case_pregnancy DROP CONSTRAINT pk_case_pregnancy;
ALTER TABLE oasis.case_prod_devices DROP CONSTRAINT pk_case_prod_devices;
ALTER TABLE oasis.case_prod_drugs DROP CONSTRAINT pk_case_prod_drugs;
ALTER TABLE oasis.case_prod_indications DROP CONSTRAINT pk_case_prod_indications;
ALTER TABLE oasis.case_prod_qc_cid DROP CONSTRAINT pk_case_prod_qc_cid;
ALTER TABLE oasis.case_product DROP CONSTRAINT pk_case_product;
ALTER TABLE oasis.case_study DROP CONSTRAINT pk_case_study;
ALTER TABLE oasis.cfg_medwatch_codes DROP CONSTRAINT pk_cfg_medwatch_codes;
ALTER TABLE oasis.code_list_detail_discrete DROP CONSTRAINT pk_code_list_detail_discrete;
ALTER TABLE oasis.lm_action_taken DROP CONSTRAINT pk_lm_action_taken;
ALTER TABLE oasis.lm_admin_route DROP CONSTRAINT pk_lm_admin_route;
ALTER TABLE oasis.lm_age_groups DROP CONSTRAINT pk_lm_age_groups;
ALTER TABLE oasis.lm_age_units DROP CONSTRAINT pk_lm_age_units;
ALTER TABLE oasis.lm_always_serious_term DROP CONSTRAINT pk_lm_always_serious_term;
ALTER TABLE oasis.lm_birth_type DROP CONSTRAINT pk_lm_birth_type;
ALTER TABLE oasis.lm_case_classification DROP CONSTRAINT pk_lm_case_classification;
ALTER TABLE oasis.lm_causality DROP CONSTRAINT pk_lm_causality;
ALTER TABLE oasis.lm_centers DROP CONSTRAINT pk_lm_centers;
ALTER TABLE oasis.lm_condition_type DROP CONSTRAINT pk_lm_condition_type;
ALTER TABLE oasis.lm_countries DROP CONSTRAINT pk_lm_countries;
ALTER TABLE oasis.lm_datasheet DROP CONSTRAINT pk_lm_datasheet;
ALTER TABLE oasis.lm_delivery_types DROP CONSTRAINT pk_lm_delivery_types;
ALTER TABLE oasis.lm_dev_phase DROP CONSTRAINT pk_lm_dev_phase;
ALTER TABLE oasis.lm_device_type DROP CONSTRAINT pk_lm_device_type;
ALTER TABLE oasis.lm_dose_frequency DROP CONSTRAINT pk_lm_dose_frequency;
ALTER TABLE oasis.lm_dose_units DROP CONSTRAINT pk_lm_dose_units;
ALTER TABLE oasis.lm_ethnicity DROP CONSTRAINT pk_lm_ethnicity;
ALTER TABLE oasis.lm_evt_frequency DROP CONSTRAINT pk_lm_evt_frequency;
ALTER TABLE oasis.lm_evt_intensity DROP CONSTRAINT pk_lm_evt_intensity;
ALTER TABLE oasis.lm_evt_outcome DROP CONSTRAINT pk_lm_evt_outcome;
ALTER TABLE oasis.lm_fetal_outcome DROP CONSTRAINT pk_lm_fetal_outcome;
ALTER TABLE oasis.lm_formulation DROP CONSTRAINT pk_lm_formulation;
ALTER TABLE oasis.lm_gender DROP CONSTRAINT pk_lm_gender;
ALTER TABLE oasis.lm_hcp DROP CONSTRAINT pk_lm_hcp;
ALTER TABLE oasis.lm_intermediary DROP CONSTRAINT pk_lm_intermediary;
ALTER TABLE oasis.lm_lab_assessment DROP CONSTRAINT pk_lm_lab_assessment;
ALTER TABLE oasis.lm_labeled_terms DROP CONSTRAINT pk_lm_labeled_terms;
ALTER TABLE oasis.lm_license DROP CONSTRAINT pk_lm_license;
ALTER TABLE oasis.lm_license DROP CONSTRAINT sys_c0012635;
ALTER TABLE oasis.lm_license_types DROP CONSTRAINT pk_lm_license_types;
ALTER TABLE oasis.lm_listedness DROP CONSTRAINT pk_lm_listedness;
ALTER TABLE oasis.lm_manufacturer DROP CONSTRAINT pk_lm_manufacturer;
ALTER TABLE oasis.lm_mfr_eval_reason DROP CONSTRAINT pk_lm_mfr_eval_reason;
ALTER TABLE oasis.lm_product DROP CONSTRAINT pk_lm_products;
ALTER TABLE oasis.lm_product_family DROP CONSTRAINT pk_lm_product_family;
ALTER TABLE oasis.lm_product_group DROP CONSTRAINT pk_lm_product_group;
ALTER TABLE oasis.lm_protocols DROP CONSTRAINT pk_lm_protocols;
ALTER TABLE oasis.lm_ref_types DROP CONSTRAINT pk_lm_ref_types;
ALTER TABLE oasis.lm_report_media DROP CONSTRAINT pk_lm_report_media;
ALTER TABLE oasis.lm_report_type DROP CONSTRAINT pk_lm_report_type;
ALTER TABLE oasis.lm_reporter_type DROP CONSTRAINT pk_lm_reporter_type;
ALTER TABLE oasis.lm_sites DROP CONSTRAINT chk_lm_sites_approved_reports;
ALTER TABLE oasis.lm_sites DROP CONSTRAINT pk_lm_sites;
ALTER TABLE oasis.lm_study_types DROP CONSTRAINT pk_lm_study_types;
ALTER TABLE oasis.lm_udf_ddl_values DROP CONSTRAINT pk_lm_udf_ddl_values;
ALTER TABLE oasis.lm_unblinding_status DROP CONSTRAINT pk_lm_unblinding_status;
*/

-- ------------ Write CREATE-CONSTRAINT-stage scripts -----------
/*
ALTER TABLE oasis.case_assess
ADD CONSTRAINT pk_case_assess PRIMARY KEY (case_id);
ALTER TABLE oasis.case_classifications
ADD CONSTRAINT pk_case_classifications PRIMARY KEY (case_id, seq_num);
*/

select 'drop index oasis.' || indexname || ';'
from pg_indexes
where schemaname = 'oasis' and indexname like 'pk%'

SELECT con.*
       FROM pg_catalog.pg_constraint con
            INNER JOIN pg_catalog.pg_class rel
                       ON rel.oid = con.conrelid
            INNER JOIN pg_catalog.pg_namespace nsp
                       ON nsp.oid = connamespace
       WHERE nsp.nspname = 'oasis' or conname like 'pk_case_comments%'

ALTER TABLE oasis.case_comments
ADD CONSTRAINT pk_case_comments PRIMARY KEY (case_id);

ALTER TABLE oasis.case_company_cmts
ADD CONSTRAINT pk_case_company_cmts PRIMARY KEY (case_id);

ALTER TABLE oasis.case_death
ADD CONSTRAINT pk_case_death PRIMARY KEY (case_id);

ALTER TABLE oasis.case_death_details
ADD CONSTRAINT pk_case_death_details PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_dose_regimens
ADD CONSTRAINT pk_case_dose_regimens PRIMARY KEY (case_id, seq_num, log_no);

ALTER TABLE oasis.case_event
ADD CONSTRAINT pk_case_event PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_event_assess
ADD CONSTRAINT pk_case_event_assess PRIMARY KEY (case_id, event_seq_num, prod_seq_num, datasheet_id, license_id, seq_num);

ALTER TABLE oasis.case_event_consequence
ADD CONSTRAINT pk_case_event_consequence PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_event_detail
ADD CONSTRAINT pk_case_event_detail PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_event_detail
ADD CONSTRAINT uc_case_event_detail_cpe UNIQUE (case_id, prod_seq_num, event_seq_num);

ALTER TABLE oasis.case_followup
ADD CONSTRAINT pk_case_followup PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_lab_data
ADD CONSTRAINT pk_case_lab_data PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_literature
ADD CONSTRAINT pk_case_literature PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_master
ADD CONSTRAINT ak_csm_case_num UNIQUE (case_num);

ALTER TABLE oasis.case_master
ADD CONSTRAINT pk_case_master PRIMARY KEY (case_id);

ALTER TABLE oasis.case_narrative
ADD CONSTRAINT pk_case_narrative PRIMARY KEY (case_id);

ALTER TABLE oasis.case_neonates
ADD CONSTRAINT pk_case_neonates PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_pat_hist
ADD CONSTRAINT pk_case_pat_hist PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_pat_tests
ADD CONSTRAINT pk_case_pat_tests PRIMARY KEY (rel_test_id);

ALTER TABLE oasis.case_pmoa_cons_relation
ADD CONSTRAINT pk_case_pmoa_cons_relation PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_pregnancy
ADD CONSTRAINT pk_case_pregnancy PRIMARY KEY (case_id, parent);

ALTER TABLE oasis.case_prod_devices
ADD CONSTRAINT pk_case_prod_devices PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_prod_drugs
ADD CONSTRAINT pk_case_prod_drugs PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_prod_indications
ADD CONSTRAINT pk_case_prod_indications PRIMARY KEY (case_id, prod_seq_num, seq_num);

ALTER TABLE oasis.case_prod_qc_cid
ADD CONSTRAINT pk_case_prod_qc_cid PRIMARY KEY (case_id, prod_seq_num, seq_num);

ALTER TABLE oasis.case_product
ADD CONSTRAINT pk_case_product PRIMARY KEY (case_id, seq_num);

ALTER TABLE oasis.case_study
ADD CONSTRAINT pk_case_study PRIMARY KEY (case_id);

ALTER TABLE oasis.cfg_medwatch_codes
ADD CONSTRAINT pk_cfg_medwatch_codes PRIMARY KEY (dialog, value, sortby);

ALTER TABLE oasis.code_list_detail_discrete
ADD CONSTRAINT pk_code_list_detail_discrete PRIMARY KEY (code_list_id, decode_context, code);

ALTER TABLE oasis.lm_action_taken
ADD CONSTRAINT pk_lm_action_taken PRIMARY KEY (act_taken_id);

ALTER TABLE oasis.lm_admin_route
ADD CONSTRAINT pk_lm_admin_route PRIMARY KEY (admin_route_id);

ALTER TABLE oasis.lm_age_groups
ADD CONSTRAINT pk_lm_age_groups PRIMARY KEY (age_group_id);

ALTER TABLE oasis.lm_age_units
ADD CONSTRAINT pk_lm_age_units PRIMARY KEY (age_unit_id);

ALTER TABLE oasis.lm_always_serious_term
ADD CONSTRAINT pk_lm_always_serious_term PRIMARY KEY (ast_id);

ALTER TABLE oasis.lm_birth_type
ADD CONSTRAINT pk_lm_birth_type PRIMARY KEY (birth_type_id);

ALTER TABLE oasis.lm_case_classification
ADD CONSTRAINT pk_lm_case_classification PRIMARY KEY (classification_id);

ALTER TABLE oasis.lm_causality
ADD CONSTRAINT pk_lm_causality PRIMARY KEY (causality_id);

ALTER TABLE oasis.lm_centers
ADD CONSTRAINT pk_lm_centers PRIMARY KEY (center_id);

ALTER TABLE oasis.lm_condition_type
ADD CONSTRAINT pk_lm_condition_type PRIMARY KEY (condition_type_id);

ALTER TABLE oasis.lm_countries
ADD CONSTRAINT pk_lm_countries PRIMARY KEY (country_id);

ALTER TABLE oasis.lm_datasheet
ADD CONSTRAINT pk_lm_datasheet PRIMARY KEY (datasheet_id, revision);

ALTER TABLE oasis.lm_delivery_types
ADD CONSTRAINT pk_lm_delivery_types PRIMARY KEY (delivery_type_id);

ALTER TABLE oasis.lm_dev_phase
ADD CONSTRAINT pk_lm_dev_phase PRIMARY KEY (dev_phase_id);

ALTER TABLE oasis.lm_device_type
ADD CONSTRAINT pk_lm_device_type PRIMARY KEY (device_type_id);

ALTER TABLE oasis.lm_dose_frequency
ADD CONSTRAINT pk_lm_dose_frequency PRIMARY KEY (freq_id);

ALTER TABLE oasis.lm_dose_units
ADD CONSTRAINT pk_lm_dose_units PRIMARY KEY (unit_id);

ALTER TABLE oasis.lm_ethnicity
ADD CONSTRAINT pk_lm_ethnicity PRIMARY KEY (ethnicity_id);

ALTER TABLE oasis.lm_evt_frequency
ADD CONSTRAINT pk_lm_evt_frequency PRIMARY KEY (evt_freq_id);

ALTER TABLE oasis.lm_evt_intensity
ADD CONSTRAINT pk_lm_evt_intensity PRIMARY KEY (evt_intensity_id);

ALTER TABLE oasis.lm_evt_outcome
ADD CONSTRAINT pk_lm_evt_outcome PRIMARY KEY (evt_outcome_id);

ALTER TABLE oasis.lm_fetal_outcome
ADD CONSTRAINT pk_lm_fetal_outcome PRIMARY KEY (fetal_outcome_id);

ALTER TABLE oasis.lm_formulation
ADD CONSTRAINT pk_lm_formulation PRIMARY KEY (formulation_id);

ALTER TABLE oasis.lm_gender
ADD CONSTRAINT pk_lm_gender PRIMARY KEY (gender_id);

ALTER TABLE oasis.lm_hcp
ADD CONSTRAINT pk_lm_hcp PRIMARY KEY (hcp_id);

ALTER TABLE oasis.lm_intermediary
ADD CONSTRAINT pk_lm_intermediary PRIMARY KEY (intermediary_id);

ALTER TABLE oasis.lm_lab_assessment
ADD CONSTRAINT pk_lm_lab_assessment PRIMARY KEY (assessment_id);

ALTER TABLE oasis.lm_labeled_terms
ADD CONSTRAINT pk_lm_labeled_terms PRIMARY KEY (seq_num);

ALTER TABLE oasis.lm_license
ADD CONSTRAINT pk_lm_license PRIMARY KEY (license_id);

ALTER TABLE oasis.lm_license
ADD CHECK (otc_product IN (0, 1));

ALTER TABLE oasis.lm_license_types
ADD CONSTRAINT pk_lm_license_types PRIMARY KEY (license_type_id);

ALTER TABLE oasis.lm_listedness
ADD CONSTRAINT pk_lm_listedness PRIMARY KEY (listedness_id);

ALTER TABLE oasis.lm_manufacturer
ADD CONSTRAINT pk_lm_manufacturer PRIMARY KEY (manufacturer_id);

ALTER TABLE oasis.lm_mfr_eval_reason
ADD CONSTRAINT pk_lm_mfr_eval_reason PRIMARY KEY (mfr_eval_id);

ALTER TABLE oasis.lm_product
ADD CONSTRAINT pk_lm_products PRIMARY KEY (product_id);

ALTER TABLE oasis.lm_product_family
ADD CONSTRAINT pk_lm_product_family PRIMARY KEY (family_id);

ALTER TABLE oasis.lm_product_group
ADD CONSTRAINT pk_lm_product_group PRIMARY KEY (product_group_id);

ALTER TABLE oasis.lm_protocols
ADD CONSTRAINT pk_lm_protocols PRIMARY KEY (protocol_id);

ALTER TABLE oasis.lm_ref_types
ADD CONSTRAINT pk_lm_ref_types PRIMARY KEY (ref_type_id);

ALTER TABLE oasis.lm_report_media
ADD CONSTRAINT pk_lm_report_media PRIMARY KEY (media_id);

ALTER TABLE oasis.lm_report_type
ADD CONSTRAINT pk_lm_report_type PRIMARY KEY (rpt_type_id);

ALTER TABLE oasis.lm_reporter_type
ADD CONSTRAINT pk_lm_reporter_type PRIMARY KEY (rptr_type_id);

ALTER TABLE oasis.lm_sites
ADD CONSTRAINT chk_lm_sites_approved_reports CHECK (approved_reports IN (0, 1));

ALTER TABLE oasis.lm_sites
ADD CONSTRAINT pk_lm_sites PRIMARY KEY (site_id);

ALTER TABLE oasis.lm_study_types
ADD CONSTRAINT pk_lm_study_types PRIMARY KEY (study_type_id);

ALTER TABLE oasis.lm_udf_ddl_values
ADD CONSTRAINT pk_lm_udf_ddl_values PRIMARY KEY (id, field_id);

ALTER TABLE oasis.lm_unblinding_status
ADD CONSTRAINT pk_lm_unblinding_status PRIMARY KEY (status_id);

ALTER TABLE oasis.oasis_case_parent_info
ADD CONSTRAINT pk_oasis_case_parent_info PRIMARY KEY (case_id);

ALTER TABLE oasis.oasis_case_pat_info
ADD CONSTRAINT pk_oasis_case_pat_info PRIMARY KEY (case_id);

ALTER TABLE oasis.oasis_case_reporters
ADD CONSTRAINT pk_oasis_case_reporters PRIMARY KEY (case_id, seq_num); 


