--SET search_path = sbx_oasis_sample, oasis, meddra;
--SET search_path = oasis_staging, oasis, meddra;

CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ==========================================================
-- Narrative
-- ==========================================================
DROP TABLE IF EXISTS narrative CASCADE;
CREATE TABLE narrative (
    case_id INTEGER NOT NULL,
    primary_id VARCHAR(20) NOT NULL,
    case_narrative TEXT,
    psur_comments TEXT,
    case_company_comments TEXT,
    case_comments TEXT,
    valid_case_yn VARCHAR(1) NOT NULL,
    spont_case_yn VARCHAR(1) NOT NULL,
    spont_valid_case_yn VARCHAR(1) NOT NULL,
    drug_case_yn VARCHAR(1) NOT NULL,
    device_case_yn VARCHAR(1) NOT NULL,
    vaccine_case_yn VARCHAR(1) NOT NULL
    )
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO narrative (
       case_id, primary_id,
       case_narrative, psur_comments, case_company_comments, case_comments,
       valid_case_yn, spont_case_yn, spont_valid_case_yn,
       drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT  t0.case_id,
        t0.case_num AS primary_id,
        CASE WHEN t1.narrative IS NOT NULL AND LENGTH(t1.narrative) > 1 THEN t1.narrative END AS case_narrative, -- H.1
        CASE WHEN t1.abbrev_narrative IS NOT NULL AND LENGTH(t1.abbrev_narrative) > 1 THEN t1.abbrev_narrative END AS psur_comments,
        CASE WHEN t2.comment_txt IS NOT NULL AND LENGTH(t2.comment_txt) > 1 THEN t2.comment_txt END AS case_company_comments, -- H.4
        CASE WHEN t3.comment_txt IS NOT NULL AND LENGTH(t3.comment_txt) > 1 THEN t3.comment_txt END AS case_comments, -- H.2
        t0.valid_case_yn,
        t0.spont_case_yn,
        t0.spont_valid_case_yn,
        t0.drug_case_yn,
        t0.device_case_yn,
        t0.vaccine_case_yn
  FROM case_list t0
 LEFT JOIN case_narrative t1 ON t0.case_id=t1.case_id
 LEFT JOIN case_company_cmts t2 ON t0.case_id=t2.case_id
 LEFT JOIN case_comments t3 ON t0.case_id=t3.case_id
 WHERE (t1.narrative IS NOT NULL AND LENGTH(t1.narrative) > 1)
    OR (t2.comment_txt IS NOT NULL AND LENGTH(t2.comment_txt) > 1)
    OR (t3.comment_txt IS NOT NULL AND LENGTH(t3.comment_txt) > 1)
    OR (t1.abbrev_narrative IS NOT NULL AND LENGTH(t1.abbrev_narrative) > 1)
    ;

CREATE INDEX case_comment_ix1 ON narrative (primary_id);
CREATE INDEX case_comment_ix2 ON narrative (case_id);

ANALYZE narrative;


