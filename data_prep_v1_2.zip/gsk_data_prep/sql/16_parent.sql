--SET search_path = oasis_staging, oasis, meddra;

DROP TABLE IF EXISTS parent CASCADE;

-- Create Table parent

CREATE table parent(
case_id INTEGER NOT NULL,
primary_id VARCHAR(20) NOT NULL,
gender_id INTEGER,
gender TEXT,
age INTEGER,
age_unit_id INTEGER,
age_unit    TEXT,
dob TIMESTAMP WITHOUT TIME ZONE,
dob_text    TEXT,
height_cm FLOAT,
height_in   FLOAT,
weight_kg   FLOAT,
weight_lbs  FLOAT,
date_of_lmp TIMESTAMP WITHOUT TIME ZONE,
date_of_lmp_text TEXT,
med_hist_text   TEXT,
valid_case_yn   VARCHAR(1),
spont_case_yn VARCHAR(1),
spont_valid_case_yn VARCHAR(1),
drug_case_yn    VARCHAR(1),
device_case_yn  VARCHAR(1),
vaccine_case_yn VARCHAR(1)
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

-- Insert Values into parent

INSERT INTO parent (case_id, primary_id,
                    gender_id, gender, 
                    age, age_unit_id, age_unit,
                    dob, dob_text,
                    height_cm, height_in,
                    weight_kg, weight_lbs,
                    date_of_lmp, date_of_lmp_text,
                    med_hist_text,
                    valid_case_yn, spont_case_yn, spont_valid_case_yn,
                    drug_case_yn, device_case_yn, vaccine_case_yn
                    )
SELECT cl.case_id,
cl.case_num,
ocpi.gender_id,
lg.gender,
CASE when ocpi.age >= 0 then ocpi.age END AS age,
ocpi.age_unit_id,
CASE when ocpi.age >= 0 then lau.age_unit END AS age_unit,
ocpi.dob,
ocpi.dob_partial,
ocpi.height_cm,
ocpi.height_in,
ocpi.weight_kg,
ocpi.weight_lbs,
ocpi.date_of_lmp,
ocpi.date_of_lmp_partial,
ocpi.med_hist_text,
cl.valid_case_yn,
cl.spont_case_yn,
cl.spont_valid_case_yn,
cl.drug_case_yn,
cl.device_case_yn,
cl.vaccine_case_yn
FROM  case_list cl
JOIN oasis_case_parent_info ocpi ON cl.case_id = ocpi.case_id 
LEFT JOIN lm_gender lg ON lg.gender_id = ocpi.gender_id  AND lg.deleted IS NULL
LEFT JOIN lm_age_units lau ON lau.age_unit_id = ocpi.age_unit_id AND lau.deleted IS NULL;

ALTER TABLE parent ADD CONSTRAINT pk_parent PRIMARY KEY(case_id); 
CREATE UNIQUE INDEX ix_parent ON parent (primary_id); 

-- Analyze Table
ANALYZE parent;