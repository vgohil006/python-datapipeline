--SET search_path = sbx_oasis_sample, oasis, meddra;
-- SET search_path = oasis_staging, oasis, meddra;

--
-- Helper table of product/Generic/Family names
-- 
SELECT 'Create helper_drug ' || now();

-- ---------------------------------------------------------------
-- helper_case_product: selected rows and cols from case_product,
-- with derivations to replace bad characetrs from product name
-- and generic name
-- ---------------------------------------------------------------

DROP TABLE IF EXISTS helper_case_product CASCADE;
CREATE TABLE helper_case_product AS
SELECT
cl.case_id, seq_num, product_id, co_drug_code,
prod_lic_id, pat_exposure, manufacturer_id, prod_reptd, prod_coded,
TRIM(TRANSLATE(product_name, '+'||CHR(10)||CHR(13), '&')) AS product_name,
TRIM(TRANSLATE(generic_name, '+'||CHR(10)||CHR(13), '&')) AS generic_name
FROM case_product cp JOIN case_list cl ON cl.case_id=cp.case_id
WHERE cp.deleted IS NULL;
ALTER TABLE helper_case_product ADD CONSTRAINT pk_helper_case_product PRIMARY KEY(case_id, seq_num);
ANALYZE  helper_case_product;


-- ---------------------------------------------------------------
-- helper_drug: Helper table with derived product name fields
-- product_name, product_name_orig,
-- generic_name, generic_name_orig,
-- family_name, prod_reported, manufacturer
-- ---------------------------------------------------------------
DROP TABLE IF EXISTS helper_drug CASCADE;
CREATE TABLE helper_drug AS
with temp_unblind AS
(
    SELECT cl.case_id, status_id, CASE WHEN unblinding_status IS NULL THEN 'None' WHEN unblinding_status like 'Broken%' THEN 'Broken' 
                            else unblinding_status END AS status
      FROM case_list cl
 LEFT JOIN case_study   cs ON cl.case_id = cs.case_id AND cs.deleted IS NULL
 LEFT JOIN lm_unblinding_status lm_unb ON lm_unb.status_id=cs.code_broken AND lm_unb.deleted IS NULL
    )
, lm_product AS 
    (
    SELECT product_id, family_id,
           TRIM(TRANSLATE(prod_name,  '+'||CHR(10)||CHR(13), '&')) AS prod_name_0,
           TRIM(TRANSLATE(prod_generic_name,  '+'||CHR(10)||CHR(13), '&')) AS prod_generic_name,
           CASE WHEN prod_name IS NOT NULL THEN
              TRIM(TRANSLATE(prod_name,  '+'||CHR(10)||CHR(13), '&')) ||
                 ' (' || COALESCE(lm_f.formulation,'') || ', '
                      || TRIM(COALESCE(concentration,'') ||' '|| COALESCE(lm_du.unit,'')) || ', '
                      || COALESCE(indication_text,'') || ')'
           END AS prod_name
      FROM lm_product
 LEFT JOIN lm_formulation lm_f ON lm_f.formulation_id=lm_product.formulation_id AND lm_f.deleted IS NULL
 LEFT JOIN lm_dose_units lm_du ON lm_du.unit_id=lm_product.conc_unit_id AND lm_du.deleted IS NULL
     WHERE lm_product.deleted IS NULL
     )
, lm_product_family AS 
    (
    SELECT family_id,
           TRIM(TRANSLATE(name, '+'||CHR(10)||CHR(13), '&')) AS name
      FROM lm_product_family
     WHERE deleted IS NULL
     )
, lm_license AS
(
    SELECT license_id, TRIM(TRANSLATE(trade_name, '+'||CHR(10)||CHR(13), '&')) AS trade_name FROM lm_license WHERE deleted IS NULL
)
 SELECT
        cl.case_id,
        cp.seq_num AS seq_num,
        cp.product_id AS product_id,
        cp.pat_exposure AS pat_exposure,
--
-- product_name, product_name_orig
--
        CASE
        -- Spontaneous case, derive through lm_product and product_id
          WHEN COALESCE(cp.pat_exposure,0) <= 0
              AND cl.spont_case_yn = 'Y'
              AND COALESCE(cs.study_key,-9999) = -9999
              AND cp.product_id > 0
            THEN lm_p2.prod_name
        --
        -- Study case, blinded, derive through lm_study_cohort
          WHEN COALESCE(cp.pat_exposure,0) <= 0
              AND cl.spont_case_yn = 'N'
              AND cp.co_drug_code = 'Study Drug'
              -- AND lm_scoh.blind_name IS NOT NULL
              THEN TRIM(TRANSLATE(cs.blind_name, '+'||CHR(10)||CHR(13), '&'))
        --
        -- Study case, unblinded (or broken), derive through lm_product and pat_exposure
          WHEN cp.pat_exposure > 0 AND lm_p.prod_name IS NOT NULL 
            THEN lm_p.prod_name
        --
        -- Fall back on lm_product/product_id  and case_product.prod_name
            ELSE COALESCE(lm_p2.prod_name, '[' || cp.product_name || ']')
        END AS product_name,
        cp.product_name AS product_name_orig,
--
--  Generic name, generic_name_orig
--
        CASE
          WHEN COALESCE(cp.pat_exposure,0) <= 0
              AND cl.spont_case_yn = 'N'
              AND unb.status = 'Blinded'
              AND cp.co_drug_code = 'Study Drug'
            THEN TRIM(TRANSLATE(COALESCE(cs.blind_name, cp.prod_coded), '+'||CHR(10)||CHR(13), '&')) || ' (Blinded)'
          ELSE
            COALESCE(lm_p.prod_generic_name, lm_p2.prod_generic_name, '[' || UPPER(cp.generic_name) || ']')
         END  AS generic_name,
        cp.generic_name AS generic_name_orig,
--
--  Family_name
--
        CASE WHEN COALESCE(cp.pat_exposure,0) <= 0
              AND cl.spont_case_yn = 'N'
              AND unb.status = 'Blinded'
              AND cp.co_drug_code = 'Study Drug'
             THEN TRIM(TRANSLATE(COALESCE(cs.blind_name, cp.prod_coded), '+'||CHR(10)||CHR(13), '&')) || ' (Blinded)'
          ELSE
            COALESCE(lm_pf.name, lm_pf2.name)
         END        AS family_name,
--
-- prod_reported, trade_name, manufacturer
--
        TRIM(COALESCE(cp.prod_reptd, 'Unk')) AS prod_reported,
        TRIM(cp.prod_coded) AS prod_coded,
        lm_l.trade_name AS trade_name,
        cp.manufacturer_id::INTEGER AS manufacturer_id,
        lm_m.manu_name AS manufacturer
     FROM case_list cl
     JOIN case_master cm ON cm.case_id=cl.case_id
LEFT JOIN helper_case_product cp  ON cl.case_id = cp.case_id
LEFT JOIN case_study   cs ON cl.case_id = cs.case_id AND cs.deleted IS NULL
LEFT JOIN lm_product lm_p ON cp.pat_exposure = lm_p.product_id
LEFT JOIN lm_product_family lm_pf ON lm_p.family_id = lm_pf.family_id
LEFT JOIN lm_product lm_p2 ON cp.product_id = lm_p2.product_id
LEFT JOIN lm_product_family lm_pf2 ON lm_p2.family_id = lm_pf2.family_id
LEFT JOIN lm_manufacturer lm_m ON cp.manufacturer_id = lm_m.manufacturer_id AND lm_m.deleted IS NULL
LEFT JOIN temp_unblind unb ON unb.case_id=cl.case_id
LEFT JOIN lm_license lm_l ON lm_l.license_id = cp.prod_lic_id
;

ALTER TABLE helper_drug ADD CONSTRAINT pk_hdrug PRIMARY KEY(case_id, seq_num);
ANALYZE helper_drug;

SELECT 'Create helper_prod_drugs ' || now();

-- ---------------------------------------------------------------
-- Helper table of ancillary information from case_prod_drugs
-- ---------------------------------------------------------------
DROP TABLE IF EXISTS helper_prod_drugs CASCADE;
CREATE TABLE helper_prod_drugs
AS SELECT
    cl.case_id, cpd.seq_num::INTEGER AS seq_num,
    cpd.act_taken_id::INTEGER AS act_taken_id,
    lm_a.action_taken,
    CASE WHEN cpd.total_dose >= 0 THEN total_dose ELSE NULL END AS total_dose,
    cpd.tot_dose_unit_id::INTEGER AS tot_dose_unit_id,
    CASE WHEN cpd.total_dose >= 0 THEN lm_du.unit ELSE NULL END AS total_dose_unit,
    cpd.first_dose,
    cpd.last_dose,
    cpd.dechall_date,
    cpd.rechall_start,
    cpd.rechall_stop,
    CASE cpd.dechallenge
       WHEN 0 THEN 'No dechallenge' --? 'Negative dechallenge'
       WHEN 1 THEN 'Dechallenge'  -- ? 'Positive dechallenge'
       WHEN 2 THEN 'Unknown'
       WHEN 3 THEN 'Does not apply'
    END AS dechallenge,
    CASE cpd.rechallenge
       WHEN 0 THEN 'No rechallenge'
       WHEN 1 THEN 'Rechallenge'
       WHEN 2 THEN 'Unknown'
       WHEN 3 THEN 'Does not apply'
    END AS rechallenge,
    CASE rechall_outcome WHEN 1 THEN 'Positive' WHEN 0 THEN 'Negative' END AS rechallenge_outcome,
    cpd.duration_seconds::BIGINT as duration_seconds,
--    drug_duration_text,
    cpd.formulation_id::INTEGER AS formulation_id,
    lm_f.formulation,
    cpd.latency_seconds::BIGINT AS latency_seconds,
    -- latency_text,
    decode_ynu(cpd.interaction) AS interaction_ynu,
    cpd.cumulative_dose,
    cpd.concentration,
    cpd.conc_units_id,
    lm_du2.unit AS drug_concentration_unit,
    CASE prev_use
       WHEN -1 THEN 'Unknown / N/A'
       WHEN 0 THEN 'No / N/A'
       WHEN 1 THEN 'Yes / Unknown'
       WHEN 2 THEN 'Yes / Not Tolerated'
       WHEN 3 THEN 'Yes / Tolerated'
    END AS prev_use,
    DECODE_YN(abuse) AS abuse_yn,
    DECODE_YN(overdose) AS overdose_yn,
    first_dose_partial AS first_dose_text,
    last_dose_partial AS last_dose_text,
    DECODE_YN(tampering) AS tampering_yn,
    delay_seconds::BIGINT AS delay_seconds,
    -- delay_text,
    cpd.obtain_drug_country_id::INTEGER AS obtain_drug_country_id,
    lm_c.country AS obtain_drug_country,
    cpd.drug_auth_country_id::INTEGER AS drug_auth_country_id,
    map.region AS obtain_drug_region,
    lm_c2.country AS drug_authorization_country,
    map2.region AS drug_authorization_region
     FROM case_list cl
     JOIN case_prod_drugs cpd ON cl.case_id=cpd.case_id AND cpd.deleted IS NULL
LEFT JOIN lm_countries lm_c ON cpd.obtain_drug_country_id = lm_c.country_id AND lm_c.deleted IS NULL
LEFT JOIN country_region_map map ON map.country = lm_c.country
LEFT JOIN lm_countries lm_c2 ON cpd.drug_auth_country_id = lm_c2.country_id AND lm_c2.deleted IS NULL
LEFT JOIN country_region_map map2 ON map2.country = lm_c2.country
LEFT JOIN lm_formulation lm_f ON lm_f.formulation_id = cpd.formulation_id and lm_f.deleted IS NULL
LEFT JOIN lm_action_taken lm_a ON lm_a.act_taken_id=cpd.act_taken_id and lm_a.deleted IS NULL
LEFT JOIN lm_dose_units lm_du ON lm_du.unit_id=cpd.tot_dose_unit_id and lm_du.deleted IS NULL
LEFT JOIN lm_dose_units lm_du2 ON lm_du2.unit_id=cpd.conc_units_id and lm_du2.deleted IS NULL
;
ALTER TABLE helper_prod_drugs ADD CONSTRAINT pk_hpdrug PRIMARY KEY(case_id, seq_num);
ANALYZE helper_prod_drugs;

-- ---------------------------------------------------------------
-- Finally .... create and populate DRUG
-- ---------------------------------------------------------------

SELECT 'Create drug ' || now();
DROP TABLE IF EXISTS drug CASCADE;

CREATE TABLE drug
(
    case_id INTEGER,
    primary_id VARCHAR(20),
    prod_seq_num INTEGER,
    prod_sort_id INTEGER,
    drug_type_id INTEGER,
    drug_type TEXT,      -- G.k.1
    first_suspect_prod_yn VARCHAR(1),
    co_drug_code TEXT,
    who_drug_code TEXT,
    product_id INTEGER,
    pat_exposure INTEGER,
    prod_reported TEXT,  --G.k.2.2
    prod_coded TEXT,
    product_name TEXT,
    product_name_orig TEXT,
    generic_name TEXT,
    generic_name_orig TEXT,
    family_name TEXT,
    family_name_grouped TEXT,
    family_name_enhanced TEXT,
    trade_name TEXT,
    manufacturer_id INTEGER,
    manufacturer TEXT,
    act_taken_id INTEGER,
    action_taken TEXT,
    total_dose FLOAT,
    tot_dose_unit_id INTEGER,
    total_dose_unit TEXT,
    first_dose TIMESTAMP WITHOUT TIME ZONE,
    last_dose TIMESTAMP WITHOUT TIME ZONE,
    dechall_date TIMESTAMP WITHOUT TIME ZONE,
    rechall_start TIMESTAMP WITHOUT TIME ZONE,
    rechall_stop TIMESTAMP WITHOUT TIME ZONE,
    dechallenge TEXT,
    rechallenge TEXT,
    rechallenge_outcome TEXT,
    duration_seconds BIGINT,
    formulation_id INTEGER,
    formulation TEXT,
    latency_seconds BIGINT,
    interaction_ynu VARCHAR(1),
    cumulative_dose FLOAT,
    concentration VARCHAR(10),
    conc_units_id INTEGER,
    drug_concentration_unit TEXT,
    prev_use TEXT,
    abuse_yn VARCHAR(1),
    overdose_yn VARCHAR(1),
    first_dose_text VARCHAR(20),
    last_dose_text VARCHAR(20),
    tampering_yn VARCHAR(1),
    delay_seconds BIGINT,
    obtain_drug_country_id INTEGER,
    obtain_drug_country TEXT,
    obtain_drug_region TEXT,
    drug_auth_country_id INTEGER,
    drug_authorization_country TEXT,
    drug_authorization_region TEXT,
    protocol_followed_ynu VARCHAR(1),
    sdrug_not_admin VARCHAR(1),
    suspect_yn VARCHAR(1),
    notes TEXT,
    drug_yn VARCHAR(1),
    device_yn VARCHAR(1),
    vaccine_yn VARCHAR(1),
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1)
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO drug (case_id, primary_id, prod_seq_num, prod_sort_id, drug_type_id, drug_type,
                  first_suspect_prod_yn, co_drug_code, who_drug_code, product_id, pat_exposure, prod_reported,
                  prod_coded, product_name, product_name_orig, generic_name, generic_name_orig, family_name,
                  family_name_grouped, family_name_enhanced, trade_name, manufacturer_id, manufacturer, act_taken_id,
                  action_taken, total_dose, tot_dose_unit_id, total_dose_unit, first_dose, last_dose,
                  dechall_date, rechall_start, rechall_stop, dechallenge, rechallenge, rechallenge_outcome,
                  duration_seconds, formulation_id, formulation, latency_seconds, interaction_ynu, cumulative_dose,
                  concentration, conc_units_id, drug_concentration_unit, prev_use, abuse_yn, overdose_yn, first_dose_text,
                  last_dose_text, tampering_yn, delay_seconds, obtain_drug_country_id, obtain_drug_country,
                  obtain_drug_region, drug_auth_country_id, drug_authorization_country, drug_authorization_region,
                  protocol_followed_ynu, sdrug_not_admin, suspect_yn, notes,
                  drug_yn, device_yn, vaccine_yn,
                  valid_case_yn, spont_case_yn, spont_valid_case_yn,
                  drug_case_yn, device_case_yn, vaccine_case_yn
 )
SELECT  cl.case_id,
        cl.case_num AS primary_id,
        hd.seq_num AS prod_seq_num,
        cp.sort_id::integer AS prod_sort_id,
        cp.drug_type::integer AS drug_type_id,
        CASE cp.drug_type
                WHEN 1 THEN 'Suspect'
                WHEN 2 THEN 'Concomitant'
                WHEN 3 THEN 'Treatment'
                ELSE 'Not classified'
        END AS drug_type,
        DECODE_YN(cp.first_sus_prod) AS first_suspect_prod_yn,
        cp.co_drug_code,
        cp.who_drug_code,
        hd.product_id,
        hd.pat_exposure,
        hd.prod_reported,
        hd.prod_coded,
        hd.product_name,
        hd.product_name_orig,
        hd.generic_name,
        hd.generic_name_orig,
        hd.family_name,
        COALESCE(fgm.grouped_family_name, hd.family_name) AS family_name_grouped,
        CASE
          WHEN fgm.grouped_family_name IS NOT NULL THEN fgm.grouped_family_name
          WHEN hd.family_name IS NOT NULL THEN hd.family_name
          WHEN hd.generic_name IS NOT NULL THEN
              CASE
                WHEN hd.generic_name LIKE '[%' THEN hd.generic_name
                ELSE '[' || UPPER(hd.generic_name) || ']'
              END
          WHEN hd.product_name_orig IS NOT NULL THEN '[' || UPPER(hd.product_name_orig) || ']'
        END AS family_name_enhanced,
        hd.trade_name,
        hd.manufacturer_id,
        hd.manufacturer,
        hpd.act_taken_id,
        hpd.action_taken,
        hpd.total_dose,
        hpd.tot_dose_unit_id,
        hpd.total_dose_unit,
        hpd.first_dose,
        hpd.last_dose,
        hpd.dechall_date,
        hpd.rechall_start,
        hpd.rechall_stop,
        hpd.dechallenge,
        hpd.rechallenge,
        hpd.rechallenge_outcome,
        hpd.duration_seconds,
        hpd.formulation_id,
        hpd.formulation,
        hpd.latency_seconds,
        hpd.interaction_ynu,
        hpd.cumulative_dose,
        hpd.concentration,
        hpd.conc_units_id,
        hpd.drug_concentration_unit,
        hpd.prev_use,
        hpd.abuse_yn,
        hpd.overdose_yn,
        hpd.first_dose_text,
        hpd.last_dose_text,
        hpd.tampering_yn,
        hpd.delay_seconds,
        hpd.obtain_drug_country_id,
        hpd.obtain_drug_country,
        hpd.obtain_drug_region,
        hpd.drug_auth_country_id,
        hpd.drug_authorization_country,
        hpd.drug_authorization_region,
        DECODE_YNU(cp.protocol_followed) AS protocol_followed_ynu,
        DECODE_YNU(cp.sdrug_not_admin) AS sdrug_not_admin,
        CASE drug_type
          WHEN 1 THEN 'Y'
          ELSE 'N'
        END AS suspect_yn,
        CASE WHEN LENGTH(cp.notes) > 0 THEN notes END AS notes,
        CASE WHEN selected_view=1 THEN 'Y' ELSE 'N' END AS drug_yn,
        CASE WHEN selected_view=2 THEN 'Y' ELSE 'N' END AS device_yn,
        CASE WHEN selected_view=3 THEN 'Y' ELSE 'N' END AS vaccine_yn,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
     FROM case_list cl
     JOIN case_product cp ON cp.case_id=cl.case_id AND cp.deleted IS NULL
     JOIN helper_drug hd ON cl.case_id=hd.case_id AND cp.seq_num=hd.seq_num
LEFT JOIN helper_prod_drugs hpd ON hpd.case_id=cp.case_id AND hpd.seq_num=cp.seq_num
LEFT JOIN (SELECT grouped_family_name, TRANSLATE(family_name, '+','&') AS family_name  -- this join does not need to worry about crlf
             FROM family_group_map) fgm ON fgm.family_name=hd.family_name
;

ALTER TABLE drug ADD CONSTRAINT pk_drug PRIMARY KEY(case_id, prod_seq_num);
CREATE UNIQUE INDEX drug_ix1 ON drug(primary_id, prod_seq_num);
ANALYZE drug;


DROP TABLE IF EXISTS helper_case_product;
DROP TABLE IF EXISTS helper_drug;
DROP TABLE IF EXISTS helper_prod_drugs;

