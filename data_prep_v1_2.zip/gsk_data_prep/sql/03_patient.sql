--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS patient CASCADE;
CREATE TABLE patient
(
    case_id INTEGER,
    primary_id VARCHAR(20),
    pat_age FLOAT,
    age_unit_id INTEGER,
    age_unit TEXT,
    age_in_years FLOAT,
    pat_age_at_vacc FLOAT,
    age_unit_id_at_vacc INTEGER,
    age_unit_at_vacc TEXT,
    age_in_years_at_vacc FLOAT,
    age_group_id INTEGER,
    age_group TEXT,
    age_group3 TEXT,
    age_group4 TEXT,
    age_group8 TEXT,
    age_group9 TEXT,
    pat_weight_kg FLOAT,
    pat_weight_unit_code TEXT,
    pat_height_cm FLOAT,
    pat_height_unit_code TEXT,
    ethnicity_id INTEGER,
    ethnicity TEXT,
    pregnancy_status TEXT,
    gender_id INTEGER,
    sex TEXT,
    child_only_yn VARCHAR(1),
    pat_subj_num TEXT,
    rand_num TEXT,
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1)/*,
    valid_start timestamp without time zone,
    valid_end timestamp without time zone */
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);
ALTER TABLE patient   OWNER to dbadm;


WITH lm_udf AS (SELECT * FROM lm_udf_ddl_values WHERE deleted IS NULL)
INSERT INTO patient 
        (case_id, primary_id,
         pat_age, age_unit_id, age_unit, age_in_years,
         pat_age_at_vacc, age_unit_id_at_vacc, age_unit_at_vacc, age_in_years_at_vacc,
         age_group_id, age_group, age_group3, age_group4, age_group8, age_group9,
         pat_weight_kg, pat_weight_unit_code, pat_height_cm, pat_height_unit_code,
         ethnicity_id, ethnicity, pregnancy_status, gender_id, sex, child_only_yn,
         pat_subj_num, rand_num,
         valid_case_yn, spont_case_yn, spont_valid_case_yn,
         drug_case_yn, device_case_yn, vaccine_case_yn
--         , valid_start, valid_end
         )
SELECT  cl.case_id,
        cl.case_num AS primary_id,
        CASE WHEN cpi.pat_age>=0 THEN cpi.pat_age END AS pat_age,
        cpi.age_unit_id AS age_unit_id,
        lm_a.age_unit AS age_unit,
        calc_age_in_years(cpi.pat_age, lm_a.age_unit) AS age_in_years,
        CASE WHEN cpi.pat_age_at_vacc>=0 THEN cpi.pat_age_at_vacc END AS pat_age_at_vacc,
        cpi.age_unit_id_at_vacc AS age_unit_id_at_vacc,
        lm_a2.age_unit AS age_unit_at_vacc,
        calc_age_in_years(cpi.pat_age_at_vacc, lm_a2.age_unit) AS age_in_years_at_vacc,
        cpi.age_group_id AS age_group_id,
        lm_ag.group_name AS age_group,
        calc_age_group3(cpi.pat_age, lm_a.age_unit, lm_ag.group_name) AS age_group3,
        calc_age_group4(cpi.pat_age, lm_a.age_unit, lm_ag.group_name) AS age_group4,
        calc_age_group8(cpi.pat_age, lm_a.age_unit, lm_ag.group_name) AS age_group8,
        calc_age_group9(cpi.pat_age, lm_a.age_unit, lm_ag.group_name) AS age_group9,
        cpi.pat_weight_kg,
        CASE WHEN cpi.pat_weight_kg IS NOT NULL THEN 'KG' END AS pat_weight_unit_code,
        cpi.pat_height_cm,
        CASE WHEN cpi.pat_height_cm IS NOT NULL THEN 'CM' END AS pat_height_unit_code,
        cpi.ethnicity_id AS ethnicity_id,
        lm_e.ethnicity,
        decode_ynu_na(cpi.pat_stat_preg) AS pregnancy_status,
        cpi.gender_id AS ethnicity_id,
        lm_g.gender AS sex,
        DECODE_yn(child_only) AS child_only_yn,
        cpi.pat_subj_num,
        cpi.rand_num,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
        /*, cl.valid_start, cl.valid_end*/
FROM case_list cl
     JOIN oasis_case_pat_info cpi ON cl.case_id=cpi.case_id AND cpi.deleted IS NULL
LEFT JOIN lm_gender  lm_g ON cpi.gender_id = lm_g.gender_id AND lm_g.deleted IS NULL
LEFT JOIN lm_age_units lm_a on cpi.age_unit_id = lm_a.age_unit_id AND lm_a.deleted IS NULL
LEFT JOIN lm_age_units lm_a2 on cpi.age_unit_id_at_vacc = lm_a2.age_unit_id AND lm_a2.deleted IS NULL
LEFT JOIN lm_age_groups lm_ag on cpi.age_group_id = lm_ag.age_group_id AND lm_ag.deleted IS NULL
LEFT JOIN lm_ethnicity lm_e on cpi.ethnicity_id = lm_e.ethnicity_id AND lm_e.deleted IS NULL
;

ALTER TABLE patient ADD CONSTRAINT pk_patient PRIMARY KEY(case_id);

--select * from patient order by pat_age limit 100

CREATE UNIQUE INDEX patient_ix1 ON patient(primary_id);
CREATE INDEX patient_ix14 ON patient(drug_case_yn, primary_id);
CREATE INDEX patient_ix15 ON patient(device_case_yn, primary_id);
CREATE INDEX patient_ix16 ON patient(vaccine_case_yn, primary_id);
ANALYZE patient;

-- select count(*) from patient
--select * from patient limit 50