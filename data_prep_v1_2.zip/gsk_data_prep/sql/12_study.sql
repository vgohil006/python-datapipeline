--SET search_path = sbx_oasis_sample, oasis, meddra;

DROP TABLE IF EXISTS study CASCADE;
CREATE TABLE study(
    case_id INTEGER NOT NULL,
    primary_id TEXT NOT NULL,
    study_desc TEXT,  -- c.5.2 studyname
    study_num TEXT,   -- c.5.3 sponsorstudynumb
    study_type_id INTEGER,
    study_type TEXT,  -- c.5.4 observestudytype
    center_id INTEGER, center_name TEXT, center_no TEXT,
    protocol_num TEXT,
    protocol_id INTEGER, protocol_desc TEXT, 
    code_broken INTEGER, unblinding_status TEXT,
    product_count INTEGER,
    classification_id INTEGER, classification TEXT,
    other_id TEXT,
    blind_name TEXT,
    broken_date TIMESTAMP WITHOUT TIME ZONE,
    valid_case_yn VARCHAR(1) NOT NULL,
    spont_case_yn VARCHAR(1) NOT NULL,
    spont_valid_case_yn VARCHAR(1) NOT NULL,
    drug_case_yn VARCHAR(1) NOT NULL,
    device_case_yn VARCHAR(1) NOT NULL,
    vaccine_case_yn VARCHAR(1) NOT NULL
    )
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO study (
       case_id,
       primary_id,
       study_desc,
       study_num,
       study_type_id, study_type,
       center_id, center_name, center_no,
       protocol_num,
       protocol_id, protocol_desc, 
       code_broken, unblinding_status,
       product_count,
       classification_id, classification,
       other_id,
       blind_name,
       broken_date,
       valid_case_yn, spont_case_yn, spont_valid_case_yn, drug_case_yn, device_case_yn, vaccine_case_yn)
   SELECT
        cl.case_id,
        cl.case_num AS primaryid,
        CASE WHEN LENGTH(study_desc) > 0 THEN t1.study_desc END AS study_desc,
        CASE WHEN LENGTH(study_num) > 0 THEN t1.study_num END AS study_num,
        t1.study_type AS study_type_id, t2.study_type AS study_type,
        t1.center_id, t3.center_name, t3.center_no,
        t1.protocol_num,
        t1.protocol_id, t4.protocol_desc, 
        t1.code_broken, t5.unblinding_status,
        t1.product_count,
        t1.classification_id,
        t6.description AS classification,
        t1.other_id,
        t1.blind_name,
        t1.broken_date,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
     FROM case_list cl
JOIN case_study t1 ON t1.case_id=cl.case_id
LEFT JOIN lm_study_types         t2 ON t2.study_type_id=t1.study_type AND t2.deleted IS NULL
LEFT JOIN lm_centers             t3 ON t3.center_id=t1.center_id AND t3.deleted IS NULL
LEFT JOIN lm_protocols           t4 ON t4.protocol_id=t1.protocol_id AND t4.deleted IS NULL
LEFT JOIN lm_unblinding_status   t5 ON t5.status_id=t1.code_broken AND t5.deleted IS NULL
LEFT JOIN lm_case_classification t6 ON t6.classification_id=t1.classification_id AND t6.deleted IS NULL
WHERE t1.deleted IS NULL AND 
      (LENGTH(study_desc) > 0 OR LENGTH(study_num) > 0 OR t1.study_num IS NOT NULL OR t1.protocol_num IS NOT NULL
       OR t1.protocol_id IS NOT NULL OR COALESCE(product_count,0) > 0 OR t1.classification_id IS NOT NULL
       OR t1.other_id IS NOT NULL OR t1.blind_name IS NOT NULL OR t1.broken_date IS NOT NULL)
;

ALTER TABLE study ADD CONSTRAINT pk_study PRIMARY KEY(primary_id);
CREATE UNIQUE INDEX idx_case_study_1 ON study(case_id);
ANALYZE study;

