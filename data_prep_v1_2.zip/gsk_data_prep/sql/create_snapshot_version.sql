CREATE TABLE snapshot_version (
   snapshot_schema VARCHAR NOT NULL,
   snapshot_version INTEGER NOT NULL,
   data_prep_version VARCHAR NOT NULL,
   create_timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
   merge_timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
);
