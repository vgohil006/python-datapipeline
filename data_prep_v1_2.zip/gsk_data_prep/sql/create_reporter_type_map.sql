DROP TABLE IF EXISTS reporter_type_map CASCADE;

CREATE TABLE reporter_type_map (
   reporter_type TEXT,
   abbrev TEXT,
 CONSTRAINT pk_reporter_type_map PRIMARY KEY(reporter_type)
 );
 