DROP TABLE IF EXISTS medhist_map CASCADE;

CREATE TABLE medhist_map (
   condition_type TEXT,
   abbrev TEXT,
 CONSTRAINT pk_medhist_map PRIMARY KEY(condition_type)
 );
