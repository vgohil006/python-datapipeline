
--SET search_path = sbx_oasis_sample, oasis;

DROP TABLE IF EXISTS literature CASCADE;

CREATE TABLE literature
(
    case_id INTEGER NOT NULL,
    primary_id VARCHAR(20) NOT NULL,
    lit_seq_num INTEGER NOT NULL,
    author TEXT,
    title TEXT,
    journal VARCHAR(80),
    year VARCHAR(4),
    vol TEXT,
    pgs TEXT,
    ref_text TEXT,
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1))
    WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO literature (
	case_id, primary_id, lit_seq_num,
    author, title, journal, year, vol, pgs, ref_text,
    valid_case_yn, spont_case_yn, spont_valid_case_yn,
    drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT  cl.case_id,
        cl.case_num AS primary_id,
        seq_num AS lit_seq_num,
        author,
        title,
        journal,
        year,
        vol,
        pgs,
        literature_reference(t1.author, t1.title, t1.journal, t1.year, t1.vol, t1.pgs) AS lit_reference,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
  FROM case_list cl
JOIN case_literature t1 ON cl.case_id=t1.case_id
 WHERE t1.deleted IS NULL
   AND (t1.author IS NOT NULL OR t1.title IS NOT NULL OR t1.journal IS NOT NULL OR t1.year IS NOT NULL OR t1.vol IS NOT NULL OR t1.pgs IS NOT NULL)
;

CREATE INDEX literature_ix1 ON literature(primary_id);
CREATE INDEX literature_ix2 ON literature(case_id);

ANALYZE literature;


