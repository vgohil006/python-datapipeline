--SET search_path = oasis_staging, oasis, meddra;

DROP TABLE IF EXISTS followup CASCADE;
CREATE TABLE followup
(
    case_id INTEGER,
    primary_id VARCHAR(20),
    followup_seq_num INTEGER,
    receipt_date_text TEXT,
    receipt_date TIMESTAMP WITHOUT TIME ZONE,
    safety_date_text TEXT,
    safety_date TIMESTAMP WITHOUT TIME ZONE,
    time_stamp_text TEXT,
    time_stamp TIMESTAMP WITHOUT TIME ZONE,
    significant_ynu VARCHAR(1),
    significant_device_ynu VARCHAR(1),
    justification TEXT,
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1))
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO followup(
    case_id, primary_id, followup_seq_num,
    receipt_date_text, receipt_date, safety_date_text, safety_date, time_stamp_text, time_stamp,
    significant_ynu, significant_device_ynu, justification,
    valid_case_yn, spont_case_yn, spont_valid_case_yn, drug_case_yn, device_case_yn, vaccine_case_yn)
SELECT  cl.case_id,
        cl.case_num as primary_id,
        t1.seq_num::INTEGER AS followup_seq_num,
        TO_CHAR(t1.receipt_date, 'yyyy-mm-dd') AS receipt_date_text, -- formatted to allow sorting
        t1.receipt_date,
        TO_CHAR(t1.safety_date, 'yyyy-mm-dd') AS safety_date_text, -- formatted to allow sorting
        t1.safety_date,
        TO_CHAR(t1.time_stamp, 'yyyy-mm-dd') AS time_stamp_text, -- formatted to allow sorting
        t1.time_stamp,
        COALESCE(DECODE_YN(t1.significant), 'U') AS significant_ynu,
        COALESCE(DECODE_YN(t1.significant_device),'U') AS significant_device_ynu,
        t1.justification,
        cl.valid_case_yn,
        cl.spont_case_yn,
        cl.spont_valid_case_yn,
        cl.drug_case_yn,
        cl.device_case_yn,
        cl.vaccine_case_yn
     FROM case_list cl
     JOIN case_followup t1 on cl.case_id=t1.case_id; 

ALTER TABLE followup ADD CONSTRAINT followup_pk PRIMARY KEY(case_id, followup_seq_num); 
ANALYZE followup;