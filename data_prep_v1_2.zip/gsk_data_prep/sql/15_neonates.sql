--SET search_path = oasis_staging, oasis, meddra;

DROP TABLE IF EXISTS neonates CASCADE;

--Create Table neonates

CREATE TABLE neonates(
case_id	INTEGER NOT NULL,
primary_id VARCHAR(20) NOT NULL,
neonates_seq_num INTEGER NOT NULL,
neonates_sort_id	INTEGER,
deliver_date TIMESTAMP WITHOUT TIME ZONE,
weight_grams	NUMERIC,
weight_ozs	NUMERIC,
delivery_type_id	INTEGER,
neonates_delivery_type	TEXT,
apgar1	NUMERIC,
apgar2	NUMERIC,
apgar3	NUMERIC,
notes	TEXT,
birth_type_id	INTEGER,
neonates_birth_type	TEXT,
fetal_outcome_id	INTEGER,
neonates_fetal_outcome	TEXT,
valid_case_yn	VARCHAR(1),
spont_case_yn	VARCHAR(1),
spont_valid_case_yn	VARCHAR(1),
drug_case_yn	VARCHAR(1),
device_case_yn	VARCHAR(1),
vaccine_case_yn	VARCHAR(1)
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);


-- Insert Values into neonates

INSERT INTO neonates (case_id, primary_id,
					  neonates_seq_num, neonates_sort_id,
					  deliver_date, weight_grams, weight_ozs,
					  delivery_type_id, neonates_delivery_type,
					  apgar1, apgar2, apgar3,
					  notes, birth_type_id, neonates_birth_type,
					  fetal_outcome_id, neonates_fetal_outcome,
					  valid_case_yn, spont_case_yn, spont_valid_case_yn,
                      drug_case_yn, device_case_yn, vaccine_case_yn
					  )
SELECT cl.case_id, 
cl.case_num,
cn.seq_num,
cn.sort_id,
cn.deliver_date,
cn.weight_grams, 
cn.weight_ozs,
cn.delivery_type_id,
ldt.delivery_type,
cn.apgar1, 
cn.apgar2, 
cn.apgar3,
cn.notes, 
cn.birth_type_id,
lbt.birth_type,
cn.fetal_outcome_id,
lfo.fetal_outcome,
cl.valid_case_yn,
cl.spont_case_yn, 
cl.spont_valid_case_yn,
cl.drug_case_yn, 
cl.device_case_yn,
cl.vaccine_case_yn
FROM case_neonates cn
JOIN case_list cl ON cl.case_id = cn.case_id AND cn.deleted IS NULL 
LEFT JOIN lm_delivery_types ldt ON ldt.delivery_type_id = cn.delivery_type_id AND ldt.deleted IS NULL
LEFT JOIN lm_birth_type lbt ON lbt.birth_type_id = cn.birth_type_id AND lbt.deleted IS NULL
LEFT JOIN lm_fetal_outcome lfo ON lfo.fetal_outcome_id = cn.fetal_outcome_id AND lfo.deleted IS NULL;

ALTER TABLE neonates ADD CONSTRAINT pk_neonates PRIMARY KEY(case_id, neonates_seq_num); 	  
CREATE UNIQUE INDEX neonates_ix1 ON neonates(primary_id, neonates_seq_num);

-- Analyze Table
ANALYZE neonates;