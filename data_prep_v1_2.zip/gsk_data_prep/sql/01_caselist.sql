--set search_path = oasis_data_prep_sample, argus_app, meddra_j_user;
--set search_path = oasis_staging, oasis, meddra;
--set search_path = sbx_oasis_sample, oasis, meddra;

--alter table case_master add constraint pk_case_master primary key(case_id) with (fillfactor=100);
DROP TABLE IF EXISTS case_list CASCADE;
DROP TABLE IF EXISTS cases_of_interest CASCADE;
DROP TABLE IF EXISTS tmp_drug;
DROP TABLE IF EXISTS tmp_device;
DROP TABLE IF EXISTS tmp_vaccine;
DROP TABLE IF EXISTS tmp_sig_update;
DROP TABLE IF EXISTS tmp_invalid;

CREATE TABLE tmp_drug AS SELECT DISTINCT case_id FROM case_product WHERE deleted IS NULL AND selected_view=1;
CREATE TABLE tmp_device AS SELECT DISTINCT case_id FROM case_product WHERE deleted IS NULL AND selected_view=2;
CREATE TABLE tmp_vaccine AS SELECT DISTINCT case_id FROM case_product WHERE deleted IS NULL AND selected_view=3;
CREATE TABLE tmp_sig_update AS
      SELECT case_id, MAX(time_stamp) AS lsu
        FROM case_followup
       WHERE (significant = 1 OR significant_device = 1) AND deleted IS NULL
    GROUP BY case_id;

CREATE TABLE tmp_invalid AS
      SELECT DISTINCT cm.case_id
        FROM case_master cm
   LEFT JOIN case_classifications cc ON cm.case_id=cc.case_id AND cc.deleted IS NULL
   LEFT JOIN lm_case_classification lm_cc ON lm_cc.classification_id = cc.classification_id AND lm_cc.deleted IS NULL
   LEFT JOIN lm_report_type lm_r ON lm_r.rpt_type_id = cm.rpt_type_id AND lm_r.deleted IS NULL
       WHERE cm.deleted IS NULL
         AND (COALESCE(lm_cc.description,'x') ilike '%invalid%' OR COALESCE(lm_r.report_type,'x') = 'Pre-Literature (JP)');

CREATE TABLE CASE_LIST
AS 
SELECT t1.case_id::INTEGER AS case_id, t1.case_num, t2.report_type, t1.e2b_ww_number AS ww_safetyreport_id,
       CASE WHEN t4.case_id IS NOT NULL THEN 'Y'::VARCHAR(1) ELSE 'N'::VARCHAR(1) END AS drug_case_yn,
       CASE WHEN t5.case_id IS NOT NULL THEN 'Y'::VARCHAR(1) ELSE 'N'::VARCHAR(1) END AS device_case_yn,
       CASE WHEN t6.case_id IS NOT NULL THEN 'Y'::VARCHAR(1) ELSE 'N'::VARCHAR(1) END AS vaccine_case_yn,
	   CASE WHEN t8.case_id IS NULL THEN 'Y' ELSE 'N' END AS valid_case_yn,
	   CASE WHEN t2.incl_trial=0 THEN 'Y' ELSE 'N' END AS spont_case_yn,
	   CASE WHEN t2.incl_trial=0 AND t8.case_id IS NULL THEN 'Y' ELSE 'N' END AS spont_valid_case_yn,
       COALESCE(t7.lsu, t1.init_rept_date, t1.create_time) AS last_sig_update
--       ,to_date('20200429','yyyymmdd') AS valid_start,
--       to_date('25000101','yyyymmdd') AS valid_end
FROM case_master t1
 LEFT JOIN lm_report_type t2 ON t1.rpt_type_id = t2.rpt_type_id AND t2.deleted IS NULL
 LEFT JOIN tmp_drug       t4 ON t1.case_id=t4.case_id
 LEFT JOIN tmp_device     t5 ON t1.case_id=t5.case_id
 LEFT JOIN tmp_vaccine    t6 ON t1.case_id=t6.case_id
 LEFT JOIN tmp_sig_update t7 ON t1.case_id=t7.case_id
 LEFT JOIN tmp_invalid    t8 ON t1.case_id=t8.case_id
WHERE t1.deleted IS NULL
  AND t1.state_id <> 1
  AND (t1.close_date IS NOT NULL OR t1.date_locked IS NOT NULL)
  AND t1.case_id NOT IN
         (SELECT case_id
            FROM case_classifications
           WHERE deleted IS NULL
             AND classification_id IN (SELECT classification_id 
                                         FROM lm_case_classification
                                        WHERE deleted IS NULL
                                          AND description ilike '%NVS_Non Case%'
                                      )
         )
-- Use this to control size of data for testing (%4 is 25 pct of cases; %20 is 5 pct, etc
-- AND ( t1.case_id % 4 = 0)  
--  AND ( t1.case_id % 10 In (0,4,8) OR t1.case_id % 8 = 0)  
;


-- ---------------------------------
-- Cases_of_interest table includes
-- Everything in case_list 
--  (PLUS everything in data mart except cases that are currently open)
-- ---------------------------------
DO $$
DECLARE tablecount INTEGER := 0;
BEGIN
select  count(*) into tablecount from information_schema.tables where TABLE_NAME = 'safety_report' and table_schema='oasis_mart';
if tablecount = 0
THEN
    CREATE TABLE cases_of_interest AS SELECT case_id FROM case_list;
ELSE
    CREATE TABLE cases_of_interest AS
    SELECT case_id FROM case_list
    UNION
        (
        SELECT case_id FROM oasis_mart.safety_report WHERE valid_end > now()
        EXCEPT
        SELECT case_id::INTEGER FROM case_master
         WHERE (close_date IS NULL AND date_locked IS NULL)
           AND deleted IS NULL AND state_id <> 1
        );
END IF;
END$$;

ALTER TABLE cases_of_interest ADD CONSTRAINT pk_cases_of_interest PRIMARY KEY(case_id); 

DROP TABLE IF EXISTS tmp_drug;
DROP TABLE IF EXISTS tmp_device;
DROP TABLE IF EXISTS tmp_vaccine;
DROP TABLE IF EXISTS tmp_sig_update;
DROP TABLE IF EXISTS tmp_invalid;
