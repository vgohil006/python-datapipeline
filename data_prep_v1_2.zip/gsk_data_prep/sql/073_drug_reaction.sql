--set search_path = oasis_staging, oasis, meddra;
--set search_path = sbx_oasis_sample, oasis, meddra;

-- ==========================================
-- drug_reaction.
-- (Part 3) Populate the drug_reaction table
-- ==========================================

DROP TABLE IF EXISTS helper_all_records CASCADE;

CREATE TABLE helper_all_records AS
WITH t1 AS 
(
SELECT case_id, prod_seq_num, reaction_seq_num FROM helper_relatedness
UNION
SELECT case_id, prod_seq_num, reaction_seq_num FROM helper_event_detail
)
SELECT cl.*, t1.prod_seq_num, t1.reaction_seq_num
FROM case_list cl JOIN t1 ON t1.case_id=cl.case_id;

ALTER TABLE helper_all_records ADD CONSTRAINT pk_helper_all_records PRIMARY KEY(case_id, prod_seq_num, reaction_seq_num);
CREATE UNIQUE INDEX ix_helper_all_records ON helper_all_records(case_id, reaction_seq_num, prod_seq_num);
ANALYZE helper_all_records;


DROP TABLE IF EXISTS drug_reaction CASCADE;

CREATE TABLE drug_reaction
(
    case_id INTEGER NOT NULL,
    primary_id VARCHAR(20),
    prod_seq_num INTEGER NOT NULL,
    reaction_seq_num INTEGER NOT NULL,
    ed_seq_num INTEGER,
    product_name TEXT,
    generic_name TEXT,
    family_name_enhanced TEXT,
    reaction_pt TEXT,
    rpt_causality_id INTEGER,
    rpt_causality TEXT,
    det_causality_id INTEGER,
    det_causality TEXT,
    core_det_listedness_id INTEGER,
    core_listedness TEXT,
    ib_det_listedness_id INTEGER,
    ib_listedness VARCHAR(20),
    euspc_det_listedness_id INTEGER,
    euspc_listedness TEXT,
    rechallenge_id INTEGER,
    rechallenge TEXT,
    dechallenge_id INTEGER,
    dechallenge TEXT,
    onset_delay TEXT,
    onset_delay_seconds BIGINT,
    onset_latency TEXT,
    onset_latency_seconds BIGINT,
    total_dose_to_onset NUMERIC,
    total_dose_unit_id INTEGER,
    total_dose_to_onset_unit TEXT,
    onset_term TEXT,
    onset_latency_days_derived NUMERIC,
    valid_case_yn VARCHAR(1),
    spont_case_yn VARCHAR(1),
    spont_valid_case_yn VARCHAR(1),
    drug_case_yn VARCHAR(1),
    device_case_yn VARCHAR(1),
    vaccine_case_yn VARCHAR(1)
)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);


INSERT INTO drug_reaction(
  	case_id, primary_id, prod_seq_num, reaction_seq_num, ed_seq_num,
    product_name, generic_name, family_name_enhanced, reaction_pt,
    rpt_causality_id, rpt_causality, det_causality_id, det_causality,
    core_det_listedness_id, core_listedness, ib_det_listedness_id, ib_listedness,
    euspc_det_listedness_id, euspc_listedness,
    rechallenge_id, rechallenge, dechallenge_id, dechallenge,
    onset_delay, onset_delay_seconds, onset_latency, onset_latency_seconds,
    total_dose_to_onset, total_dose_unit_id, total_dose_to_onset_unit, onset_term, onset_latency_days_derived,
    valid_case_yn, spont_case_yn, spont_valid_case_yn, drug_case_yn, device_case_yn, vaccine_case_yn)
 SELECT
        h.case_id,
        h.case_num AS primary_id,
        h.prod_seq_num,
        h.reaction_seq_num,
        t2.ed_seq_num,
        d.product_name,
        d.generic_name,
        d.family_name_enhanced,
        COALESCE(r.reaction_pt_plus_smq, r.reaction_reported) AS reaction_pt,
        t1.rpt_causality_id,
        t1.rpt_causality,
        t1.det_causality_id,
        t1.det_causality,
        t1.core_det_listedness_id,
        t1.core_listedness,
        t1.ib_det_listedness_id,
        t1.ib_listedness,
        t1.euspc_det_listedness_id,
        t1.euspc_listedness,
        t2.rechallenge_id,
        t2.rechallenge,
        t2.dechallenge_id,
        t2.dechallenge,
        t2.onset_delay,
        t2.onset_delay_seconds,
        t2.onset_latency,
        t2.onset_latency_seconds,
        t2.total_dose_to_onset,
        t2.total_dose_unit_id,
        t2.total_dose_to_onset_unit,
        t3.term AS onset_term,
        LEAST(t2.onset_latency_days_derived, t3.onset_latency_days_derived),
        h.valid_case_yn,
        h.spont_case_yn,
        h.spont_valid_case_yn,
        h.drug_case_yn,
        h.device_case_yn,
        h.vaccine_case_yn
     FROM helper_all_records h
LEFT JOIN helper_relatedness   t1 ON h.case_id=t1.case_id
                             AND h.reaction_seq_num=t1.reaction_seq_num AND h.prod_seq_num=t1.prod_seq_num
LEFT JOIN helper_event_detail t2 ON h.case_id=t2.case_id
                             AND h.reaction_seq_num=t2.reaction_seq_num AND h.prod_seq_num=t2.prod_seq_num
LEFT JOIN helper_consequence t3 ON h.case_id=t3.case_id
                             AND h.reaction_seq_num=t3.reaction_seq_num AND h.prod_seq_num=t3.prod_seq_num
JOIN drug d ON d.case_id=h.case_id AND d.prod_seq_num = h.prod_seq_num
JOIN reaction r ON r.case_id=h.case_id AND r.reaction_seq_num = h.reaction_seq_num;

ALTER TABLE drug_reaction ADD CONSTRAINT pk_drug_reaction PRIMARY KEY(primary_id, prod_seq_num, reaction_seq_num);
CREATE UNIQUE INDEX drug_reaction_ix2 ON drug_reaction (case_id, prod_seq_num, reaction_seq_num);

ANALYZE drug_reaction;

DROP TABLE IF EXISTS helper_consequence;
DROP TABLE IF EXISTS helper_event_detail;
DROP TABLE IF EXISTS helper_relatedness;
DROP TABLE IF EXISTS helper_all_records;



