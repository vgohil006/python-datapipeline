--SET search_path = oasis_staging, oasis, meddra;

-- -----------------------------------------------
-- TABLE oasis_serious_terms
-- -----------------------------------------------
DROP TABLE IF EXISTS oasis_serious_terms CASCADE;

CREATE TABLE oasis_serious_terms(
pt_code	INTEGER NOT NULL,
pt_term	TEXT)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO oasis_serious_terms(pt_code, pt_term)
SELECT DISTINCT ast_pt_code::INTEGER, ast_pt_term
  FROM lm_always_serious_term
 WHERE deleted IS NULL;


-- -----------------------------------------------
-- TABLE oasis_dme_terms
-- -----------------------------------------------
DROP TABLE IF EXISTS oasis_dme_terms CASCADE;

CREATE TABLE oasis_dme_terms(
pt_code	INTEGER NOT NULL,
pt_name_english	TEXT)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO oasis_dme_terms(pt_code, pt_name_english)
SELECT DISTINCT t4.pt_code, t4.pt_name_english
  FROM meddra_smq_list t1
  JOIN meddra_smq_content t2 ON t1.smq_code=t2.smq_code AND term_status='A'
  JOIN meddra_pref_term_llt t3 ON t3.llt_code=t2.term_code
  JOIN meddra_pref_term t4 ON t4.pt_code=t3.pt_code
 WHERE t1.smq_name='Designated medical events (GSKMQ)'
   AND t3.deleted IS NULL AND t4.deleted IS NULL
   AND t3.llt_currency='Y';
   

-- -----------------------------------------------
-- TABLE oasis_med_error_terms
-- -----------------------------------------------
DROP TABLE IF EXISTS oasis_med_error_terms CASCADE;

CREATE TABLE oasis_med_error_terms(
pt_code	INTEGER NOT NULL,
pt_name_english	TEXT)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO oasis_med_error_terms(pt_code, pt_name_english)
SELECT DISTINCT t4.pt_code, t4.pt_name_english
  FROM meddra_smq_list t1
  JOIN meddra_smq_content t2 ON t1.smq_code=t2.smq_code AND term_status='A'
  JOIN meddra_pref_term_llt t3 ON t3.llt_code=t2.term_code
  JOIN meddra_pref_term t4 ON t4.pt_code=t3.pt_code
 WHERE t1.smq_name='Medication errors (SMQ)'
   AND t3.deleted IS NULL AND t4.deleted IS NULL
   AND t3.llt_currency='Y';

-- -----------------------------------------------
-- TABLE oasis_labelled_terms
-- -----------------------------------------------
DROP TABLE IF EXISTS oasis_labelled_terms CASCADE;

CREATE TABLE oasis_labelled_terms(
family_id	INTEGER NOT NULL,
family_name	TEXT,
grouped_family_name	TEXT,
pt_code	INTEGER NOT NULL,
pt_name_english	TEXT)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO oasis_labelled_terms(family_id, family_name, grouped_family_name, pt_code, pt_name_english)
SELECT DISTINCT t3.family_id, t3.name AS family_name,
                map.grouped_family_name, pt.pt_code, pt_name_english
  FROM lm_labeled_terms t1
  JOIN lm_datasheet t2 ON t1.datasheet_id=t2.datasheet_id
  JOIN lm_product_family t3 ON t3.family_id=t2.family_id
  JOIN meddra_pref_term_llt llt ON
       llt.llt_code = t1.term_code::INTEGER
  JOIN meddra_pref_term pt ON llt.pt_code = pt.pt_code
  LEFT JOIN oasis_staging.family_group_map map ON map.family_name=t3.name
 WHERE t1.deleted IS NULL AND t2.deleted IS NULL AND t3.deleted IS NULL
   AND llt.llt_currency='Y';
 
 
-- -----------------------------------------------
-- TABLE oasis_family_names
-- -----------------------------------------------
DROP TABLE IF EXISTS oasis_family_names CASCADE;

CREATE TABLE oasis_family_names(
family_id	INTEGER NOT NULL,
family_name	TEXT)
WITH (autovacuum_enabled = false, toast.autovacuum_enabled = false);

INSERT INTO oasis_family_names(family_id, family_name)
SELECT family_id, name AS family_name
  FROM lm_product_family
 WHERE deleted IS NULL;
 