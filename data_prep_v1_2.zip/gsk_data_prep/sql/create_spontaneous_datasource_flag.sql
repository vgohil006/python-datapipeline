CREATE TABLE spontaneous_datasource_flag (id INTEGER);
