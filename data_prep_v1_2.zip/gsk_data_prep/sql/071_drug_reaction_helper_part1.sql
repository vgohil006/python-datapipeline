--set search_path = sbx_oasis_sample, oasis, meddra;
--set search_path = oasis_staging, oasis, meddra;

-- ==========================================
-- drug_reaction.
-- Helper tables (part 1) for causality and listedness
-- ==========================================

CREATE INDEX IF NOT EXISTS ix_event_assess_1 ON case_event_assess(case_id, datasheet_id);
ANALYZE VERBOSE case_event_assess;

DROP TABLE IF EXISTS helper_sheet;
CREATE TABLE helper_sheet AS 
SELECT DISTINCT datasheet_id, sheet_name, 
        CASE
            WHEN sheet_name ilike '%core' THEN 'Core'
            WHEN sheet_name ilike '%eursi' THEN 'EURSI'
            WHEN sheet_name ilike '%IB' THEN 'IB'
            WHEN sheet_name ilike '%euspc' THEN 'EUSPC'
            WHEN sheet_name ilike '%canada' THEN 'CANADA'
            WHEN sheet_name ilike '%uspi' THEN 'USPI'
            WHEN sheet_name ilike '%japan' THEN 'JAPAN'
        END AS sheet_type
  FROM lm_datasheet t1
 WHERE t1.deleted IS NULL AND t1.datasheet_id > 0;
 ALTER TABLE helper_sheet ADD CONSTRAINT pk_helper_sheet PRIMARY KEY(datasheet_id);
 CREATE INDEX helper_sheet_idx ON helper_sheet(sheet_type);
 ANALYZE helper_sheet;
 
 DROP TABLE IF EXISTS consequence_map CASCADE;
CREATE TABLE consequence_map(term TEXT, num_days numeric);
INSERT INTO consequence_map VALUES
('Couple of hours',0),    ('Immediate',0),     ('Immediately',0),   ('Less than a day',0), ('Less than a minute',0)
,('Less than an hour',0), ('Several hours',0), ('Several Hours',0), ('Several minutes',0), ('Several Minutes',0)
,('Between 10 and 11 months',null), ('Between 10 and 12 months',null), ('Between 1 and 2 months',null)
,('Between 1 and 2 weeks',null),    ('Between 1 and 2 years',null),    ('Between 1 and 3 months',null)
,('Between 1 and 3 weeks',null),    ('Between 1 and 4 weeks',null),    ('Between 2 and 3 months',null)
,('Between 2 and 3 weeks',null),    ('Between 3 and 4 months',null),   ('Between 3 and 4 weeks',null)
,('Between 3 and 5 months',null),   ('Between 4 and 5 months',null),   ('Between 4 and 6 months',null)
,('Between 5 and 6 months',null),   ('Between 5 and 7 months',null),   ('Between 6 and 7 months',null)
,('Between 6 and 8 months',null),   ('Between 7 and 8 months',null),   ('Between 7 and 9 months',null)
,('Between 8 and 9 months',null),   ('Between 9 and 10 months',null),  ('Couple of days',null)
,('Couple of months',null),  ('Couple of weeks',null),   ('Couple of years',null),    ('Less than 2 months',null)
,('Less than 2 weeks',null), ('Less than 2 years',null), ('Less than 3 months',null), ('Less than 3 weeks',null)
,('Less than 4 months',null),('Less than 5 months',null),('Less than 6 months',null), ('Less than 9 months',null)
,('Less than a month',null), ('Less than a week',null),  ('less than a year',null),   ('Less than a year',null)
,('More than 10 hours',null),('More than 19 hours',null),('More than 23 hours',null), ('More than 2 days',null)
,('More than 2 hours',null), ('More than 2 months',null),('More than 2 weeks',null),  ('More than 2 years',null)
,('More than 3 days',null),  ('More than 3 hours',null), ('More than 3 months',null), ('More than 3 weeks',null)
,('More than 4 days',null),  ('More than 4 months',null),('More than 5 days',null),   ('More than 6 days',null)
,('More than 6 months',null),('More than 8 hours',null) ,('More than 9 months',null), ('More than a day',null)
,('More than a month',null), ('More than an hour',null), ('More than an hour',null),  ('More than a week',null)
,('More than a year',null), ('Not Applicable',null),     ('Several days',null),       ('Several Days',null), ('Several months',null)
,('Several Months',null),   ('Several weeks',null),      ('Several Weeks',null),      ('Several years',null),('Unknown',null)
;

DROP TABLE IF EXISTS tmp_unit_map CASCADE;
CREATE TABLE tmp_unit_map(unit TEXT, factor NUMERIC);
INSERT INTO tmp_unit_map select 'ye',       365.25;
INSERT INTO tmp_unit_map select 'yr',       365.25;
INSERT INTO tmp_unit_map select 'mo',       365.25/12;
INSERT INTO tmp_unit_map select 'we',         7.0;
INSERT INTO tmp_unit_map select 'wk',         7.0;
INSERT INTO tmp_unit_map select 'da',         1.0;
INSERT INTO tmp_unit_map select 'ho',         1.0/24.0;
INSERT INTO tmp_unit_map select 'hr',         1.0/24.0;
INSERT INTO tmp_unit_map select 'mi',         1.0/24.0/60.0;
INSERT INTO tmp_unit_map select 'se',         1.0/24.0/3600.0;


-- reporter causality is in records where datasheet_id=0. license_id=0

SELECT 'Create helper_rpt_causality ' || now();
DROP TABLE IF EXISTS helper_rpt_causality;
CREATE TABLE helper_rpt_causality AS
SELECT DISTINCT ON ( t0.case_id, t1.event_seq_num, t1.prod_seq_num)
                 t0.case_id, t1.event_seq_num,
                 t1.prod_seq_num,
                 t1.rpt_causality_id, t2.causality
  FROM case_list t0
  JOIN case_event_assess t1 ON t0.case_id=t1.case_id AND t1.deleted IS NULL AND rpt_causality_id IS NOT NULL
  JOIN lm_causality t2  ON t2.causality_id=t1.rpt_causality_id  AND t2.deleted IS NULL
  WHERE t1.datasheet_id=0 AND t1.license_id=0
  ORDER BY t0.case_id, t1.event_seq_num, t1.prod_seq_num, reportability DESC, seq_num DESC;

CREATE INDEX idx_hrc ON helper_rpt_causality(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
CREATE INDEX idx_hrc2 ON helper_rpt_causality(case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
ANALYZE helper_rpt_causality;

SELECT 'Create helper_det_causality ' || now();
DROP TABLE IF EXISTS helper_det_causality;
CREATE TABLE helper_det_causality AS
SELECT DISTINCT ON ( t0.case_id, t1.event_seq_num, t1.prod_seq_num)
                 t0.case_id, t1.event_seq_num AS event_seq_num,
                 t1.prod_seq_num AS prod_seq_num,
                 t1.det_causality_id AS det_causality_id, t2.causality
  FROM case_list t0
  JOIN case_event_assess t1 ON t0.case_id=t1.case_id AND t1.deleted IS NULL AND det_causality_id IS NOT NULL
  JOIN lm_causality t2  ON t2.causality_id=t1.det_causality_id  AND t2.deleted IS NULL
  WHERE t1.datasheet_id=0 AND t1.license_id=0
  ORDER BY t0.case_id, t1.event_seq_num, t1.prod_seq_num, reportability DESC, seq_num DESC;

CREATE INDEX idx_hdc ON helper_det_causality(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
CREATE INDEX idx_hdc2 ON helper_det_causality(case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
ANALYZE helper_det_causality;


-- 2745265 rows affected, 05:00 minutes execution time
-- temp table with the  listedness values by needed datasheet, with listedness values ranked (unlisted, unk, listed)
DROP TABLE IF EXISTS helper_listedness_rank;
CREATE TABLE helper_listedness_rank 
  AS SELECT 1 AS val, 1 as rank UNION SELECT 2, 3 UNION SELECT 3,2;

SELECT 'Create helper_tmp1_core ' || now();
DROP TABLE IF EXISTS helper_tmp1_core;
CREATE TABLE helper_tmp1_core AS
   SELECT
           t0.case_id, t1.event_seq_num, t1.prod_seq_num, max(rank) AS rank
     FROM case_list t0
     JOIN case_event_assess t1 ON t0.case_id=t1.case_id --AND t1.deleted IS NULL
     JOIN helper_sheet t3 ON t1.datasheet_id = t3.datasheet_id
     JOIN helper_listedness_rank tmp0 ON tmp0.val=t1.det_listedness_id
    WHERE t3.sheet_type = 'Core'
    GROUP BY 1,2,3;


SELECT 'Create helper_tmp1_ib ' || now();
DROP TABLE IF EXISTS helper_tmp1_ib;
CREATE TABLE helper_tmp1_ib AS
   SELECT
           t0.case_id, t1.event_seq_num, t1.prod_seq_num, max(rank) AS rank
     FROM case_list t0
     JOIN case_event_assess t1 ON t0.case_id=t1.case_id -- AND t1.deleted IS NULL
     JOIN helper_sheet t3 ON t1.datasheet_id = t3.datasheet_id
     JOIN helper_listedness_rank tmp0 ON tmp0.val=t1.det_listedness_id
    WHERE t3.sheet_type = 'IB'
    GROUP BY 1,2,3;

SELECT 'Create helper_tmp1_euspc ' || now();
DROP TABLE IF EXISTS helper_tmp1_euspc;
CREATE TABLE helper_tmp1_euspc AS
   SELECT
           t0.case_id, t1.event_seq_num, t1.prod_seq_num, max(rank) AS rank
     FROM case_list t0
     JOIN case_event_assess t1 ON t0.case_id=t1.case_id -- AND t1.deleted IS NULL
     JOIN helper_sheet t3 ON t1.datasheet_id = t3.datasheet_id
     JOIN helper_listedness_rank tmp0 ON tmp0.val=t1.det_listedness_id
    WHERE t3.sheet_type = 'EUSPC'
    GROUP BY 1,2,3;

SELECT 'Create helper_tmp1 indexes ' || now();
CREATE INDEX idx_ht1 ON helper_tmp1_core(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
CREATE INDEX idx_ht2 ON helper_tmp1_core(case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
ANALYZE helper_tmp1_core;
CREATE INDEX idx_ht3 ON helper_tmp1_ib(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
CREATE INDEX idx_ht4 ON helper_tmp1_ib(case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
ANALYZE helper_tmp1_ib;
CREATE INDEX idx_ht5 ON helper_tmp1_ib(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
CREATE INDEX idx_ht6 ON helper_tmp1_ib(case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
ANALYZE helper_tmp1_ib;

SELECT 'Create helper_det_euspc_listedness ' || now();
DROP TABLE IF EXISTS helper_det_euspc_listedness;
CREATE TABLE helper_det_euspc_listedness AS 
SELECT t1.case_id, t1.event_seq_num, t1.prod_seq_num, tmp0.val AS det_listedness_id, t2.listedness
FROM helper_tmp1_euspc t1
JOIN helper_listedness_rank tmp0 ON tmp0.rank=t1.rank
JOIN lm_listedness t2  ON t2.listedness_id=tmp0.val AND t2.deleted IS NULL;

SELECT 'Create helper_det_core_listedness ' || now();
DROP TABLE IF EXISTS helper_det_core_listedness;
CREATE TABLE helper_det_core_listedness AS 
SELECT t1.case_id, t1.event_seq_num, t1.prod_seq_num, tmp0.val AS det_listedness_id, t2.listedness
FROM helper_tmp1_core t1
JOIN helper_listedness_rank tmp0 ON tmp0.rank=t1.rank
JOIN lm_listedness t2  ON t2.listedness_id=tmp0.val AND t2.deleted IS NULL;

SELECT 'Create helper_det_ib_listedness ' || now();
DROP TABLE IF EXISTS helper_det_ib_listedness;
CREATE TABLE helper_det_ib_listedness AS 
SELECT t1.case_id, t1.event_seq_num, t1.prod_seq_num, tmp0.val AS det_listedness_id, t2.listedness
FROM helper_tmp1_ib t1
JOIN helper_listedness_rank tmp0 ON tmp0.rank=t1.rank
JOIN lm_listedness t2  ON t2.listedness_id=tmp0.val AND t2.deleted IS NULL;

SELECT 'Create helper_det_x_listedness indexes' || now();
ALTER TABLE helper_det_ib_listedness ADD CONSTRAINT pk_hdl1 PRIMARY KEY(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
ALTER TABLE helper_det_core_listedness ADD CONSTRAINT pk_hdl2 PRIMARY KEY(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
ALTER TABLE helper_det_euspc_listedness ADD CONSTRAINT pk_hdl3 PRIMARY KEY(case_id, event_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
CREATE UNIQUE INDEX ix_hdl1 ON helper_det_ib_listedness (case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
CREATE UNIQUE INDEX ix_hdl2 ON helper_det_core_listedness (case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
CREATE UNIQUE INDEX ix_hdl3 ON helper_det_euspc_listedness (case_id, prod_seq_num, event_seq_num) WITH (FILLFACTOR=100);
DROP TABLE IF EXISTS helper_tmp1_ib;
DROP TABLE IF EXISTS helper_tmp1_core;
DROP TABLE IF EXISTS helper_tmp1_euspc;

-- Tie the causalities and relatedesses together into one table
DROP TABLE IF EXISTS helper_records;
CREATE TABLE helper_records
AS
SELECT case_id, prod_seq_num, event_seq_num FROM helper_det_causality
UNION
SELECT case_id, prod_seq_num, event_seq_num FROM helper_rpt_causality
UNION
SELECT case_id, prod_seq_num, event_seq_num FROM helper_det_core_listedness
UNION
SELECT case_id, prod_seq_num, event_seq_num FROM helper_det_ib_listedness
UNION
SELECT case_id, prod_seq_num, event_seq_num FROM helper_det_euspc_listedness
;

SELECT 'Create helper_relatedness ' || now();
DROP TABLE IF EXISTS helper_relatedness;
CREATE TABLE helper_relatedness AS 
SELECT
        t1.case_id,
        t1.prod_seq_num::INTEGER AS prod_seq_num,
        t1.event_seq_num::INTEGER AS reaction_seq_num,
        core_r.rpt_causality_id::INTEGER AS rpt_causality_id,
        core_r.causality AS rpt_causality,
        core_d.det_causality_id::INTEGER AS det_causality_id,
        core_d.causality AS det_causality,
        core_l.det_listedness_id AS core_det_listedness_id,
        core_l.listedness AS core_listedness,
        ib_l.det_listedness_id AS ib_det_listedness_id,
        ib_l.listedness AS ib_listedness,
        eu_l.det_listedness_id AS euspc_det_listedness_id,
        eu_l.listedness AS euspc_listedness
     FROM helper_records t1
LEFT JOIN helper_rpt_causality core_r ON core_r.case_id=t1.case_id
                AND core_r.prod_seq_num=t1.prod_seq_num AND core_r.event_seq_num=t1.event_seq_num
LEFT JOIN helper_det_causality core_d ON core_d.case_id=t1.case_id
                AND core_d.prod_seq_num=t1.prod_seq_num AND core_d.event_seq_num=t1.event_seq_num
LEFT JOIN helper_det_core_listedness core_l ON core_l.case_id=t1.case_id
                AND core_l.prod_seq_num=t1.prod_seq_num AND core_l.event_seq_num=t1.event_seq_num
LEFT JOIN helper_det_ib_listedness ib_l     ON ib_l.case_id=t1.case_id
                AND ib_l.prod_seq_num=t1.prod_seq_num   AND ib_l.event_seq_num=t1.event_seq_num
LEFT JOIN helper_det_euspc_listedness eu_l   ON eu_l.case_id=t1.case_id
                AND eu_l.prod_seq_num=t1.prod_seq_num   AND eu_l.event_seq_num=t1.event_seq_num;

SELECT 'Create helper_relatedness indexes' || now();
ALTER TABLE helper_relatedness ADD CONSTRAINT pk_helper_relatedness PRIMARY KEY(case_id, prod_seq_num, reaction_seq_num) WITH (FILLFACTOR=100);
CREATE UNIQUE INDEX ix_helper_relatedness ON helper_relatedness(case_id, reaction_seq_num, prod_seq_num) WITH (FILLFACTOR=100);
ANALYZE helper_relatedness;

DROP TABLE IF EXISTS helper_records;
DROP TABLE IF EXISTS helper_sheet;
DROP TABLE IF EXISTS helper_det_core_listedness;
DROP TABLE IF EXISTS helper_det_euspc_listedness;
DROP TABLE IF EXISTS helper_det_ib_listedness;
DROP TABLE IF EXISTS helper_rpt_causality;
DROP TABLE IF EXISTS helper_det_causality;
--DROP INDEX IF EXISTS ix_event_assess_1;
DROP TABLE IF EXISTS helper_listedness_rank;
