On the dataprep1 server, the data_prep_env virtual environment was set up as follows:

 1. Use SSH to connect to the dataprep1 server

 2. Update the packages list and install the prerequisites
    sudo apt update
    sudo apt install software-properties-common

 3. Add the deadsnakes PPA to the sources list
    sudo add-apt-repository ppa:deadsnakes/ppa
    sudo apt-get update

 4. Install Python 3.7
    sudo apt install python3.7

 5. Start a shell with root privileges
    sudo -s -H

 6. Install pip and update it to the latest version
    apt-get install python3-pip
    pip3 install --upgrade pip

 7. Install virtualenv using pip3
    /usr/local/bin/pip3 install virtualenv

 8. Create the gsk_data_prep_env virtual environment directory
    mkdir -p /opt/commonwealth/gsk-etl

 9. Create a virtual environment using Python 3.7
    cd /opt/commonwealth/gsk-etl
    virtualenv -p /usr/bin/python3.7 gsk_data_prep_env

10. Activate the virtual environment
    source /opt/commonwealth/gsk-etl/gsk_data_prep_env/bin/activate

11. Install additional packages
    apt install python3.7-dev

    pip install beautifulsoup4
    pip install psutil
    pip install psycopg2-binary
    pip install pyDes
    pip install requests
    pip install boto3
    pip install cx_Oracle
    pip install configparser
    pip install botocore
    pip install certifi
    pip install docutils
    pip install idna
    pip install python-dateutil
    pip install s3transfer
    pip install setuptools
    pip install six
    pip install soupsieve
    pip install urllib3
    pip install wheel

12. Exit the virtual environment
    exit

13. Grant permissions on the data_prep_env to the commoninf\\domain^users group
    chgrp -R commoninf\\domain^users /opt/commonwealth/gsk-etl/gsk_data_prep_env
    chmod -R g+w /opt/commonwealth/gsk_etl/gsk_data_prep_env

14. Install Java
    sudo apt-get install openjdk-8-jdk

=================================================================================
The resulting setup on the dataprep1 server is:
   Virtual environment name: data_prep_env
   Python version: 3.7.5
   Output from "pip list":
      Package         Version
      --------------- ----------
      beautifulsoup4  4.9.1
      boto3 	      1.14.1
      botocore	      1.17.1
      certifi         2020.4.5.2
      chardet         3.0.4
      configparser    5.0.0
      cx-Oracle	      7.3.0
      docutils	      0.15.2
      idna            2.9
      pip             20.1.1
      psutil          5.7.0
      psycopg2-binary 2.8.5
      pyDes           2.0.1
      python-dateutil 2.8.1
      requests        2.23.0
      s3transfer      0.3.3
      setuptools      47.1.1
      six	      1.15.0
      soupsieve       2.0.1
      urllib3         1.25.9
      wheel           0.34.2

   Output from "java -version":
      openjdk version "1.8.0_222"
      OpenJDK Runtime Environment (build 1.8.0_222-8u222-b10-1ubuntu1~18.04.1-b10)
      OpenJDK 64-Bit Server VM (build 25.222-b10, mixed mode)
