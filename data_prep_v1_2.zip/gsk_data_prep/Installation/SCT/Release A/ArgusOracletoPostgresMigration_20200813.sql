/*-- ------------ Write DROP-CONSTRAINT-stage scripts ----------- */
DROP TABLE IF EXISTS oasis.case_assess;
DROP TABLE IF EXISTS oasis.case_classifications;
DROP TABLE IF EXISTS oasis.case_comments;
DROP TABLE IF EXISTS oasis.case_company_cmts;
DROP TABLE IF EXISTS oasis.case_death;
DROP TABLE IF EXISTS oasis.case_death_details;
DROP TABLE IF EXISTS oasis.case_dose_regimens;
DROP TABLE IF EXISTS oasis.case_event;
DROP TABLE IF EXISTS oasis.case_event_assess;
DROP TABLE IF EXISTS oasis.case_event_consequence;
DROP TABLE IF EXISTS oasis.case_event_detail;
DROP TABLE IF EXISTS oasis.case_followup;
DROP TABLE IF EXISTS oasis.case_lab_data;
DROP TABLE IF EXISTS oasis.case_literature;
DROP TABLE IF EXISTS oasis.case_master;
DROP TABLE IF EXISTS oasis.case_narrative;
DROP TABLE IF EXISTS oasis.case_neonates;
DROP TABLE IF EXISTS oasis.case_pat_hist;
DROP TABLE IF EXISTS oasis.case_pat_tests;
DROP TABLE IF EXISTS oasis.case_pmoa_cons_relation;
DROP TABLE IF EXISTS oasis.case_pregnancy;
DROP TABLE IF EXISTS oasis.case_prod_devices;
DROP TABLE IF EXISTS oasis.case_prod_drugs;
DROP TABLE IF EXISTS oasis.case_prod_indications;
DROP TABLE IF EXISTS oasis.case_prod_qc_cid;
DROP TABLE IF EXISTS oasis.case_product;
DROP TABLE IF EXISTS oasis.case_study;
DROP TABLE IF EXISTS oasis.cfg_medwatch_codes;
DROP TABLE IF EXISTS oasis.code_list_detail_discrete;
DROP TABLE IF EXISTS oasis.lm_action_taken;
DROP TABLE IF EXISTS oasis.lm_admin_route;
DROP TABLE IF EXISTS oasis.lm_age_groups;
DROP TABLE IF EXISTS oasis.lm_age_units;
DROP TABLE IF EXISTS oasis.lm_always_serious_term;
DROP TABLE IF EXISTS oasis.lm_birth_type;
DROP TABLE IF EXISTS oasis.lm_case_classification;
DROP TABLE IF EXISTS oasis.lm_causality;
DROP TABLE IF EXISTS oasis.lm_centers;
DROP TABLE IF EXISTS oasis.lm_condition_type;
DROP TABLE IF EXISTS oasis.lm_countries;
DROP TABLE IF EXISTS oasis.lm_datasheet;
DROP TABLE IF EXISTS oasis.lm_delivery_types;
DROP TABLE IF EXISTS oasis.lm_dev_phase;
DROP TABLE IF EXISTS oasis.lm_device_type;
DROP TABLE IF EXISTS oasis.lm_dose_frequency;
DROP TABLE IF EXISTS oasis.lm_dose_units;
DROP TABLE IF EXISTS oasis.lm_ethnicity;
DROP TABLE IF EXISTS oasis.lm_evt_frequency;
DROP TABLE IF EXISTS oasis.lm_evt_intensity;
DROP TABLE IF EXISTS oasis.lm_evt_outcome;
DROP TABLE IF EXISTS oasis.lm_fetal_outcome;
DROP TABLE IF EXISTS oasis.lm_formulation;
DROP TABLE IF EXISTS oasis.lm_gender;
DROP TABLE IF EXISTS oasis.lm_hcp;
DROP TABLE IF EXISTS oasis.lm_intermediary;
DROP TABLE IF EXISTS oasis.lm_lab_assessment;
DROP TABLE IF EXISTS oasis.lm_labeled_terms;
DROP TABLE IF EXISTS oasis.lm_license;
DROP TABLE IF EXISTS oasis.lm_license_types;
DROP TABLE IF EXISTS oasis.lm_listedness;
DROP TABLE IF EXISTS oasis.lm_manufacturer;
DROP TABLE IF EXISTS oasis.lm_mfr_eval_reason;
DROP TABLE IF EXISTS oasis.lm_product;
DROP TABLE IF EXISTS oasis.lm_product_family;
DROP TABLE IF EXISTS oasis.lm_product_group;
DROP TABLE IF EXISTS oasis.lm_protocols;
DROP TABLE IF EXISTS oasis.lm_ref_types;
DROP TABLE IF EXISTS oasis.lm_report_media;
DROP TABLE IF EXISTS oasis.lm_report_type;
DROP TABLE IF EXISTS oasis.lm_reporter_type;
DROP TABLE IF EXISTS oasis.lm_sites;
DROP TABLE IF EXISTS oasis.lm_study_cohorts;
DROP TABLE IF EXISTS oasis.lm_study_types;
DROP TABLE IF EXISTS oasis.lm_udf_ddl_values;
DROP TABLE IF EXISTS oasis.lm_unblinding_status;
DROP TABLE IF EXISTS oasis.oasis_case_parent_info;
DROP TABLE IF EXISTS oasis.oasis_case_pat_info;
DROP TABLE IF EXISTS oasis.oasis_case_reference;
DROP TABLE IF EXISTS oasis.oasis_case_reporters;

-- ------------ Write DROP-DATABASE-stage scripts -----------
-- ------------ Write CREATE-DATABASE-stage scripts -----------
CREATE SCHEMA IF NOT EXISTS oasis;
-- ------------ Write CREATE-TABLE-stage scripts -----------

CREATE TABLE oasis.case_assess(
    case_id NUMERIC NOT NULL,
    template_id NUMERIC,
    listedness NUMERIC,
    updated TIMESTAMP(0) WITHOUT TIME ZONE,
    outcome NUMERIC,
    comment_id NUMERIC,
    comp_comment_id NUMERIC,
    seriousness NUMERIC,
    serious_notes CHARACTER VARYING(1000),
    agent_suspect NUMERIC,
    agent_notes CHARACTER VARYING(1000),
    listedness_notes CHARACTER VARYING(1000),
    bfarm_causality NUMERIC,
    bfarm_manual_text TEXT DEFAULT NULL,
    company_diagnosis CHARACTER VARYING(250),
    company_diagnosis_notes CHARACTER VARYING(1000),
    diagnosis_dict_id NUMERIC,
    diagnosis_pref_code CHARACTER VARYING(30),
    diagnosis_inc_code CHARACTER VARYING(30),
    diagnosis_inc_term CHARACTER VARYING(250),
    diagnosis_hlgt_code CHARACTER VARYING(30),
    diagnosis_hlgt CHARACTER VARYING(250),
    diagnosis_hlt_code CHARACTER VARYING(30),
    diagnosis_hlt CHARACTER VARYING(250),
    diagnosis_soc_code CHARACTER VARYING(30),
    diagnosis_body_sys CHARACTER VARYING(250),
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    evaluation TEXT DEFAULT NULL,
    co_suspect_count NUMERIC(3,0) DEFAULT 0,
    event_synopsis CHARACTER VARYING(5) DEFAULT 'No',
    event_primary CHARACTER VARYING(400),
    diagnosis_reptd CHARACTER VARYING(255),
    diagnosis_coded CHARACTER VARYING(255),
    diagnosis_syn_code NUMERIC,
    diagnosis_code_status NUMERIC(3,0),
    agent_notes_j CHARACTER VARYING(1000),
    company_diagnosis_j CHARACTER VARYING(250),
    company_diagnosis_notes_j CHARACTER VARYING(1000),
    diagnosis_body_sys_j CHARACTER VARYING(250),
    diagnosis_coded_j CHARACTER VARYING(255),
    diagnosis_code_status_j NUMERIC,
    diagnosis_hlgt_j CHARACTER VARYING(250),
    diagnosis_hlt_j CHARACTER VARYING(250),
    diagnosis_inc_code_j CHARACTER VARYING(30),
    diagnosis_inc_term_j CHARACTER VARYING(250),
    diagnosis_reptd_j CHARACTER VARYING(255),
    evaluation_j TEXT DEFAULT NULL,
    listedness_notes_j CHARACTER VARYING(1000),
    serious_notes_j CHARACTER VARYING(1000),
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    event_primary_j CHARACTER VARYING(400),
    diagnosis_syn_code_j NUMERIC,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_assess
     IS 'Seriousness, Listedness, and Company Agent Causality assessments for a case';
COMMENT ON COLUMN oasis.case_assess.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_assess.template_id
     IS 'Template used for generation of auto narrative, link to CFG_NARRATIVE_TEMPLATE. This column is foreign key to CFG_NARRATIVE_TEMPLATE.TEMPLATE_ID.';
COMMENT ON COLUMN oasis.case_assess.listedness
     IS ' This column is foreign key to LM_LISTEDNESS.LISTEDNESS_ID.';
COMMENT ON COLUMN oasis.case_assess.updated
     IS 'Unused';
COMMENT ON COLUMN oasis.case_assess.outcome
     IS ' This column is foreign key to LM_EVT_OUTCOME.EVT_OUTCOME_ID.';
COMMENT ON COLUMN oasis.case_assess.comment_id
     IS 'Unused';
COMMENT ON COLUMN oasis.case_assess.comp_comment_id
     IS 'Unused';
COMMENT ON COLUMN oasis.case_assess.seriousness
     IS '0=Not Serious 1=Serious 2=Unknown';
COMMENT ON COLUMN oasis.case_assess.serious_notes
     IS 'Reason generation of seriousness flag was overridden';
COMMENT ON COLUMN oasis.case_assess.agent_suspect
     IS '0=Company agent not suspect 1=Company agent suspect';
COMMENT ON COLUMN oasis.case_assess.agent_notes
     IS 'Reason generation of agent_suspect flag was overridden';
COMMENT ON COLUMN oasis.case_assess.listedness_notes
     IS 'Reason generation of listedness flag was overridden.';
COMMENT ON COLUMN oasis.case_assess.bfarm_causality
     IS 'Bfarm information causality type';
COMMENT ON COLUMN oasis.case_assess.bfarm_manual_text
     IS 'Notes of the bfarm causality type';
COMMENT ON COLUMN oasis.case_assess.company_diagnosis
     IS 'Company diagnosis- Primary event Preferred Term. Used when using MedDRA dictionary for encoding.';
COMMENT ON COLUMN oasis.case_assess.company_diagnosis_notes
     IS 'Reason generation of company diagnosis was overridden';
COMMENT ON COLUMN oasis.case_assess.diagnosis_dict_id
     IS 'Dictionary Used for encoding';
COMMENT ON COLUMN oasis.case_assess.diagnosis_pref_code
     IS 'Encoded preferred term code';
COMMENT ON COLUMN oasis.case_assess.diagnosis_inc_code
     IS 'Encoded included term code';
COMMENT ON COLUMN oasis.case_assess.diagnosis_inc_term
     IS 'Encoded included term';
COMMENT ON COLUMN oasis.case_assess.diagnosis_hlgt_code
     IS 'High Level Group Term Code.';
COMMENT ON COLUMN oasis.case_assess.diagnosis_hlgt
     IS 'High Level Group Term.  Used when using MedDRA dictionary for encoding.';
COMMENT ON COLUMN oasis.case_assess.diagnosis_hlt_code
     IS 'High Level Term Code';
COMMENT ON COLUMN oasis.case_assess.diagnosis_hlt
     IS 'High Level Term.  Used when using MedDRA dictionary for encoding.';
COMMENT ON COLUMN oasis.case_assess.diagnosis_soc_code
     IS 'System Organ Class Code';
COMMENT ON COLUMN oasis.case_assess.diagnosis_body_sys
     IS 'Body system';
COMMENT ON COLUMN oasis.case_assess.ud_text_1
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_2
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_3
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_4
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_5
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_6
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_7
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_8
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_9
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_10
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_11
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_text_12
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_assess.ud_date_1
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_2
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_3
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_4
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_5
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_6
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_7
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_8
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_9
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_10
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_11
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_date_12
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_assess.ud_number_1
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_2
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_3
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_4
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_5
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_6
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_7
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_8
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_9
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_10
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_11
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.ud_number_12
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_assess.evaluation
     IS 'Evaluation and comment in light of similar events in the past';
COMMENT ON COLUMN oasis.case_assess.co_suspect_count
     IS 'Number of company suspect products, Default 0';
COMMENT ON COLUMN oasis.case_assess.event_synopsis
     IS 'F if fatal event, else LT if life threatening event, else No - Default No';
COMMENT ON COLUMN oasis.case_assess.event_primary
     IS 'Primary Event Preferred Term (verbatim as reported)';
COMMENT ON COLUMN oasis.case_assess.diagnosis_reptd
     IS 'Description Reported by the user';
COMMENT ON COLUMN oasis.case_assess.diagnosis_coded
     IS 'Description Coded (This should replaced by Synonym Text)';
COMMENT ON COLUMN oasis.case_assess.diagnosis_syn_code
     IS 'What is the encoding status for this record 0 - Not Coded, 1 - Coded, 2 - Coded Manually, 3 - Coding Pending, 4 - Coding Error';
COMMENT ON COLUMN oasis.case_assess.diagnosis_code_status
     IS 'Synonym Id';
COMMENT ON COLUMN oasis.case_assess.agent_notes_j
     IS 'Reason generation of agent_suspect flag was overridden (Japanese).';
COMMENT ON COLUMN oasis.case_assess.company_diagnosis_j
     IS 'Company diagnosis- Primary event Preferred Term. Used when using MedDRA dictionary for encoding. (Japanese).';
COMMENT ON COLUMN oasis.case_assess.company_diagnosis_notes_j
     IS 'Reason generation of company diagnosis was overridden (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_body_sys_j
     IS 'Body system (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_coded_j
     IS 'Description Coded (This should replaced by Synonym Text) (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_code_status_j
     IS 'Synonym Id (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_hlgt_j
     IS 'High Level Group Term.  Used when using MedDRA dictionary for encoding. (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_hlt_j
     IS 'High Level Term.  Used when using MedDRA dictionary for encoding. (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_inc_code_j
     IS 'Encoded included term code (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_inc_term_j
     IS 'Encoded included term (Japanese).';
COMMENT ON COLUMN oasis.case_assess.diagnosis_reptd_j
     IS 'Description Reported by the user (Japanese).';
COMMENT ON COLUMN oasis.case_assess.evaluation_j
     IS 'Evaluation and comment in light of similar events in the past (Japanese).';
COMMENT ON COLUMN oasis.case_assess.listedness_notes_j
     IS 'Reason generation of listedness flag was overridden. (Japanese).';
COMMENT ON COLUMN oasis.case_assess.serious_notes_j
     IS 'Reason generation of seriousness flag was overridden (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_1_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_2_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_3_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_4_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_5_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_6_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_7_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_8_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_9_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_10_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_11_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.ud_text_12_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_assess.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_assess.event_primary_j
     IS 'Primary Event Preferred Term J (verbatim J as reported)';
COMMENT ON COLUMN oasis.case_assess.diagnosis_syn_code_j
     IS 'What is the encoding status for this record 0 - Not Coded, 1 - Coded, 2 - Coded Manually, 3 - Coding Pending, 4 - Coding Error (Japanese).';
COMMENT ON COLUMN oasis.case_assess.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_classifications(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    classification_id NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_classifications
     IS 'Case classification information.';
COMMENT ON COLUMN oasis.case_classifications.case_id
     IS ' This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_classifications.seq_num
     IS 'Incremental value of this record to keep it unique within the case';
COMMENT ON COLUMN oasis.case_classifications.classification_id
     IS 'Classification. This column is foreign key to LM_CASE_CLASSIFICATION.CLASSIFICATION_ID.';
COMMENT ON COLUMN oasis.case_classifications.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_classifications.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_comments(
    case_id NUMERIC NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    comment_txt TEXT DEFAULT NULL,
    comment_txt_j TEXT DEFAULT NULL,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_comments
     IS 'Comments for case assessment.';
COMMENT ON COLUMN oasis.case_comments.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_comments.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_comments.comment_txt
     IS 'Text for Case Assessment comment (30000 characters)';
COMMENT ON COLUMN oasis.case_comments.comment_txt_j
     IS 'Text for Case Assessment comment (30000 characters) (Japanese).';
COMMENT ON COLUMN oasis.case_comments.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_company_cmts(
    case_id NUMERIC NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    comment_txt TEXT DEFAULT NULL,
    comment_txt_j TEXT DEFAULT NULL,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_company_cmts
     IS 'Company comments for case assessment.';
COMMENT ON COLUMN oasis.case_company_cmts.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_company_cmts.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_company_cmts.comment_txt
     IS 'Text for Case Assessment company comment (30000 characters)';
COMMENT ON COLUMN oasis.case_company_cmts.comment_txt_j
     IS 'Text for Case Assessment company comment (30000 characters) (Japanese).';
COMMENT ON COLUMN oasis.case_company_cmts.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_death(
    case_id NUMERIC NOT NULL,
    death_date TIMESTAMP(0) WITHOUT TIME ZONE,
    autopsy NUMERIC,
    death_date_res NUMERIC,
    death_date_partial CHARACTER VARYING(20),
    determine_autopsy CHARACTER VARYING(250),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_death
     IS 'Death details and Cause of death for event Description.';
COMMENT ON COLUMN oasis.case_death.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_death.death_date
     IS 'Date of death';
COMMENT ON COLUMN oasis.case_death.autopsy
     IS '8=Yes, 9=Yes and Autopsy results available, 10=Yes and Autopsy results not available,  4=No, 12=Unknown, 0=No selection(blank) in both Autopsy and Results available column';
COMMENT ON COLUMN oasis.case_death.death_date_res
     IS 'Partial date resolution 8-Full 7-Month and Year 5-Year Only';
COMMENT ON COLUMN oasis.case_death.death_date_partial
     IS 'Partial death date.';
COMMENT ON COLUMN oasis.case_death.determine_autopsy
     IS 'Obsolete column - This is the Autopsy Results';
COMMENT ON COLUMN oasis.case_death.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_death.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_death_details(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    sort_id NUMERIC,
    term_type NUMERIC,
    cause_reptd CHARACTER VARYING(1000),
    cause_coded CHARACTER VARYING(1000),
    cause CHARACTER VARYING(1000),
    cause_code CHARACTER VARYING(50),
    cause_llt CHARACTER VARYING(250),
    cause_llt_code CHARACTER VARYING(50),
    cause_hlt CHARACTER VARYING(250),
    cause_hlt_code CHARACTER VARYING(50),
    cause_hlgt CHARACTER VARYING(250),
    cause_hlgt_code CHARACTER VARYING(50),
    cause_soc CHARACTER VARYING(250),
    cause_soc_code CHARACTER VARYING(50),
    cause_syn_code NUMERIC,
    cause_dict NUMERIC,
    cause_code_status NUMERIC(3,0),
    cause_coded_j CHARACTER VARYING(1000),
    cause_soc_j CHARACTER VARYING(250),
    cause_code_status_j NUMERIC,
    cause_hlgt_j CHARACTER VARYING(250),
    cause_hlt_j CHARACTER VARYING(250),
    cause_j CHARACTER VARYING(1000),
    cause_llt_code_j CHARACTER VARYING(50),
    cause_llt_j CHARACTER VARYING(250),
    cause_reptd_j CHARACTER VARYING(1000),
    cause_syn_code_j NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_death_details
     IS 'Death Cause and Autopsy Results';
COMMENT ON COLUMN oasis.case_death_details.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_death_details.seq_num
     IS 'Primary key component will be populated from S_CASE_DEATH_DETAILS';
COMMENT ON COLUMN oasis.case_death_details.sort_id
     IS 'Display order starting with 1 with in a case';
COMMENT ON COLUMN oasis.case_death_details.term_type
     IS '1 - Cause of Death, 2 - Autopsy Result';
COMMENT ON COLUMN oasis.case_death_details.cause_reptd
     IS 'Death Cause as Reported';
COMMENT ON COLUMN oasis.case_death_details.cause_coded
     IS 'Death Cause to be Coded';
COMMENT ON COLUMN oasis.case_death_details.cause
     IS 'Death Cause Preferred Term';
COMMENT ON COLUMN oasis.case_death_details.cause_code
     IS 'Death Cause Preferred Term Code';
COMMENT ON COLUMN oasis.case_death_details.cause_llt
     IS 'Death Cause Lower Level Term';
COMMENT ON COLUMN oasis.case_death_details.cause_llt_code
     IS 'Death Cause Lower Level Term Code';
COMMENT ON COLUMN oasis.case_death_details.cause_hlt
     IS 'Death Cause High Level Term';
COMMENT ON COLUMN oasis.case_death_details.cause_hlt_code
     IS 'Death Cause High Level Term Code';
COMMENT ON COLUMN oasis.case_death_details.cause_hlgt
     IS 'Death Cause High Level Group Term';
COMMENT ON COLUMN oasis.case_death_details.cause_hlgt_code
     IS 'Death Cause High Level Group Term Code';
COMMENT ON COLUMN oasis.case_death_details.cause_soc
     IS 'Death Cause Body System/SOC';
COMMENT ON COLUMN oasis.case_death_details.cause_soc_code
     IS 'Death Cause Body System/SOC Code';
COMMENT ON COLUMN oasis.case_death_details.cause_syn_code
     IS 'Death Cause Synonym Code';
COMMENT ON COLUMN oasis.case_death_details.cause_dict
     IS 'CFG_DICTIONARIES_ENTERPRISE.DICT_ID';
COMMENT ON COLUMN oasis.case_death_details.cause_code_status
     IS 'Death Cause Coding Status';
COMMENT ON COLUMN oasis.case_death_details.cause_coded_j
     IS 'Death Cause to be Coded (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_soc_j
     IS 'Death Cause Body System/SOC (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_code_status_j
     IS 'Death Cause Coding Status (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_hlgt_j
     IS 'Death Cause High Level Group Term (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_hlt_j
     IS 'Death Cause High Level Term (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_j
     IS 'Death Cause Preferred Term (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_llt_code_j
     IS 'Death Cause Lower Level Term Code (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_llt_j
     IS 'Death Cause Lower Level Term (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_reptd_j
     IS 'Death Cause as Reported (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.cause_syn_code_j
     IS 'Death Cause Synonym Code (Japanese).';
COMMENT ON COLUMN oasis.case_death_details.deleted
     IS 'Deleted';
COMMENT ON COLUMN oasis.case_death_details.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_dose_regimens(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    log_no NUMERIC NOT NULL,
    start_datetime TIMESTAMP(0) WITHOUT TIME ZONE,
    start_datetime_res NUMERIC,
    stop_datetime TIMESTAMP(0) WITHOUT TIME ZONE,
    stop_datetime_res NUMERIC,
    ongoing NUMERIC,
    off_label NUMERIC,
    dose NUMERIC(22,7),
    dose_unit_id NUMERIC,
    freq_id NUMERIC,
    admin_route_id NUMERIC,
    daily_dose NUMERIC(22,7),
    daily_dose_unit_id NUMERIC,
    exp_date TIMESTAMP(0) WITHOUT TIME ZONE,
    exp_date_res NUMERIC,
    total_reg_dose NUMERIC(22,7),
    tot_reg_dose_unit_id NUMERIC,
    sort_id NUMERIC,
    parent_seq_num NUMERIC,
    location_id NUMERIC,
    dose_no NUMERIC,
    par_admin_route NUMERIC,
    exp_date_partial CHARACTER VARYING(20),
    start_date_partial CHARACTER VARYING(20),
    stop_date_partial CHARACTER VARYING(20),
    package_id CHARACTER VARYING(20),
    lot_no CHARACTER VARYING(35),
    pack_units NUMERIC,
    accidental_exposure NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    lot_id NUMERIC,
    lot_just CHARACTER VARYING(1000),
    lot_status NUMERIC(1,0),
    duration_seconds NUMERIC,
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    lot_just_j CHARACTER VARYING(1000),
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE,
    vaers_block_10 NUMERIC DEFAULT 0,
    vaers_block_14 NUMERIC DEFAULT 0,
    enterprise_id NUMERIC NOT NULL,
    duration CHARACTER VARYING(40),
    admin_term_id CHARACTER VARYING(100),
    admin_term_id_version CHARACTER VARYING(10),
    par_admin_term_id CHARACTER VARYING(100),
    par_admin_term_id_version CHARACTER VARYING(10),
    form_term_id CHARACTER VARYING(100),
    form_term_id_version CHARACTER VARYING(10),
    dose_description TEXT,
    dose_description_j TEXT
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_dose_regimens
     IS 'Individual dosage regimens for the case';
COMMENT ON COLUMN oasis.case_dose_regimens.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_PROD_DRUGS.CASE_ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.seq_num
     IS 'Value linked to CASE_PRODUCT. This column is foreign key to CASE_PROD_DRUGS.SEQ_NUM.';
COMMENT ON COLUMN oasis.case_dose_regimens.log_no
     IS 'Sequential value unique to the case';
COMMENT ON COLUMN oasis.case_dose_regimens.start_datetime
     IS 'Start time (partial) of the regimen';
COMMENT ON COLUMN oasis.case_dose_regimens.start_datetime_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_dose_regimens.stop_datetime
     IS 'Stop time (partial) of the regimen';
COMMENT ON COLUMN oasis.case_dose_regimens.stop_datetime_res
     IS 'Partial date resolution 8-Full 7-Month and Year 5-Year Only';
COMMENT ON COLUMN oasis.case_dose_regimens.ongoing
     IS '0=Stopped   1=Ongoing';
COMMENT ON COLUMN oasis.case_dose_regimens.off_label
     IS '0=Not   1=Yes, Off label';
COMMENT ON COLUMN oasis.case_dose_regimens.dose
     IS 'Single dose of agent';
COMMENT ON COLUMN oasis.case_dose_regimens.dose_unit_id
     IS 'Dosage units for each dose, value linked to LM_DOSE_UNITS. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.freq_id
     IS 'Frequency of administration, value linked to LM_DOSE_FREQUENCY. This column is foreign key to LM_DOSE_FREQUENCY.FREQ_ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.admin_route_id
     IS 'Route of administration, value linked to LM_ADMIN_ROUTE';
COMMENT ON COLUMN oasis.case_dose_regimens.daily_dose
     IS 'Daily dose of agent';
COMMENT ON COLUMN oasis.case_dose_regimens.daily_dose_unit_id
     IS 'Dosage units for daily dose, value linked to LM_DOSE_UNITS. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.exp_date
     IS 'Expiration date (partial) of agent administered';
COMMENT ON COLUMN oasis.case_dose_regimens.exp_date_res
     IS 'Partial date resolution 8-Full 7-Month and Year 5-Year Only';
COMMENT ON COLUMN oasis.case_dose_regimens.total_reg_dose
     IS 'Total dosage for regimen';
COMMENT ON COLUMN oasis.case_dose_regimens.tot_reg_dose_unit_id
     IS 'Dosage units for total regimen dose, value linked to LM_DOSE_UNITS. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.sort_id
     IS 'Order to display regimen in case form';
COMMENT ON COLUMN oasis.case_dose_regimens.parent_seq_num
     IS 'SEQ_NUM of agent in CASE_PRODUCT for this CASE_ID';
COMMENT ON COLUMN oasis.case_dose_regimens.location_id
     IS 'Location of administration, value linked to LM_LOCATION';
COMMENT ON COLUMN oasis.case_dose_regimens.dose_no
     IS 'Dose number (not amount of dose)';
COMMENT ON COLUMN oasis.case_dose_regimens.par_admin_route
     IS 'Parent route of administration. This column is foreign key to LM_ADMIN_ROUTE.ADMIN_ROUTE_ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.exp_date_partial
     IS 'Expiration date of agent administered formatted for printing';
COMMENT ON COLUMN oasis.case_dose_regimens.start_date_partial
     IS 'Start time formatted for printing';
COMMENT ON COLUMN oasis.case_dose_regimens.stop_date_partial
     IS 'Stop time formatted for printing';
COMMENT ON COLUMN oasis.case_dose_regimens.package_id
     IS 'Package ID of agent';
COMMENT ON COLUMN oasis.case_dose_regimens.lot_no
     IS 'Lot number of the agent';
COMMENT ON COLUMN oasis.case_dose_regimens.pack_units
     IS 'Package units from LM_PACK_UNITS.ID. This column is foreign key to LM_PACK_UNITS.ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.accidental_exposure
     IS 'Accidental exposure from LM_ACCIDENTAL_EXPOSURE.ID. This column is foreign key to LM_ACCIDENTAL_EXPOSURE.ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_dose_regimens.lot_id
     IS ' This column is foreign key to LM_PRODUCT_LOTS.LOT_ID.';
COMMENT ON COLUMN oasis.case_dose_regimens.lot_just
     IS 'Lot Justification';
COMMENT ON COLUMN oasis.case_dose_regimens.lot_status
     IS '0-Not a Valid Lot Number 1-Valid Lot Number 2-Valid Lot Number but overridden';
COMMENT ON COLUMN oasis.case_dose_regimens.duration_seconds
     IS 'Duration in seconds';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_1
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_2
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_3
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_4
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_5
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_6
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_7
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_8
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_9
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_10
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_11
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_12
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_1
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_2
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_3
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_4
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_5
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_6
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_7
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_8
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_9
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_10
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_11
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_date_12
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_1
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_2
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_3
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_4
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_5
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_6
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_7
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_8
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_9
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_10
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_11
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_number_12
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_1_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_2_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_3_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_4_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_5_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_6_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_7_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_8_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_9_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_10_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_11_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.ud_text_12_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_dose_regimens.lot_just_j
     IS 'Saving User provided text of alternate language in case table.';
COMMENT ON COLUMN oasis.case_dose_regimens.last_update_time
     IS 'Indicates the last update time stored in GMT';
COMMENT ON COLUMN oasis.case_dose_regimens.vaers_block_10
     IS 'This columns stores 0 or 1, 1- Use the start date of this dosage record to be Print in.';
COMMENT ON COLUMN oasis.case_dose_regimens.vaers_block_14
     IS 'This columns stores 0 or 1, 1- Print the dosage record in Block 14.';
COMMENT ON COLUMN oasis.case_dose_regimens.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_dose_regimens.duration
     IS 'Duration of regimens.';
COMMENT ON COLUMN oasis.case_dose_regimens.admin_term_id
     IS 'Route of Admin Term ID';
COMMENT ON COLUMN oasis.case_dose_regimens.admin_term_id_version
     IS 'Route of Admin Term ID Version Date/Number';
COMMENT ON COLUMN oasis.case_dose_regimens.par_admin_term_id
     IS 'Parent Route of Admin Term ID';
COMMENT ON COLUMN oasis.case_dose_regimens.par_admin_term_id_version
     IS 'Parent Route of Admin Term ID Version Date/Number';
COMMENT ON COLUMN oasis.case_dose_regimens.form_term_id
     IS 'Dosage Form Term ID';
COMMENT ON COLUMN oasis.case_dose_regimens.form_term_id_version
     IS 'Dosage Form Term ID Version Date/Number';
COMMENT ON COLUMN oasis.case_dose_regimens.dose_description
     IS 'Description of dosage. Typically (Dose, Frequency)';

CREATE TABLE oasis.case_event(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    desc_reptd CHARACTER VARYING(250),
    desc_coded CHARACTER VARYING(255),
    diagnosis NUMERIC,
    onset TIMESTAMP(0) WITHOUT TIME ZONE,
    onset_res NUMERIC,
    onset_delay CHARACTER VARYING(40),
    stop_date TIMESTAMP(0) WITHOUT TIME ZONE,
    stop_date_res NUMERIC,
    duration CHARACTER VARYING(40),
    onset_latency CHARACTER VARYING(40),
    evt_intensity_id NUMERIC,
    evt_freq_id NUMERIC,
    treated NUMERIC,
    study_related NUMERIC,
    rechall_related NUMERIC,
    prod_seq_num NUMERIC,
    evt_outcome_id NUMERIC,
    receipt_date TIMESTAMP(0) WITHOUT TIME ZONE,
    rpt_serious NUMERIC,
    sc_death NUMERIC,
    sc_hosp NUMERIC,
    sc_cong_anom NUMERIC,
    sc_threat NUMERIC,
    sc_disable NUMERIC,
    sc_int_req NUMERIC,
    sc_other NUMERIC,
    sc_other_text CHARACTER VARYING(30),
    art_code CHARACTER VARYING(30),
    pref_term CHARACTER VARYING(250),
    inc_term CHARACTER VARYING(250),
    body_sys CHARACTER VARYING(250),
    med_serious NUMERIC,
    past_hist NUMERIC,
    dict_id NUMERIC,
    dict_key CHARACTER VARYING(20),
    code_status NUMERIC,
    seriousness NUMERIC,
    sort_id NUMERIC DEFAULT 99,
    onset_date_partial CHARACTER VARYING(20),
    stop_date_partial CHARACTER VARYING(20),
    efficacy NUMERIC,
    disease NUMERIC,
    withdrawal NUMERIC,
    hlgt CHARACTER VARYING(250),
    hlt CHARACTER VARYING(250),
    hlt_code CHARACTER VARYING(30),
    hlgt_code CHARACTER VARYING(30),
    soc_code CHARACTER VARYING(30),
    study_dropped NUMERIC(4,0),
    inc_code CHARACTER VARYING(30),
    onset_minutes NUMERIC,
    delay_minutes NUMERIC,
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    details TEXT DEFAULT NULL,
    syn_code NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    study_related_reptd NUMERIC(1,0),
    duration_unit_e2b NUMERIC,
    onset_latency_unit_e2b NUMERIC,
    onset_delay_unit_e2b NUMERIC,
    duration_seconds NUMERIC,
    onset_latency_seconds NUMERIC,
    onset_delay_seconds NUMERIC,
    body_sys_j CHARACTER VARYING(250),
    code_status_j NUMERIC,
    desc_coded_j CHARACTER VARYING(255),
    desc_reptd_j CHARACTER VARYING(250),
    details_j TEXT DEFAULT NULL,
    hlgt_j CHARACTER VARYING(250),
    hlt_j CHARACTER VARYING(250),
    inc_code_j CHARACTER VARYING(30),
    inc_term_j CHARACTER VARYING(250),
    pref_term_j CHARACTER VARYING(250),
    sc_other_text_j CHARACTER VARYING(30),
    report_exclusion NUMERIC,
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    syn_code_j NUMERIC,
    infection NUMERIC,
    rpt_exclude_cmt CHARACTER VARYING(1000),
    rpt_exclude_cmt_j CHARACTER VARYING(1000),
    enterprise_id NUMERIC NOT NULL,
    emergency_room_visit NUMERIC,
    physician_office_visit NUMERIC,
    country_occured_id NUMERIC,
    medical_confirm NUMERIC(1,0),
    original_language NUMERIC,
    imdrf_code varchar(7),
    revision numeric
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_event
     IS 'Event information for a case.';
COMMENT ON COLUMN oasis.case_event.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_event.seq_num
     IS 'Incremental number unique to events within this case';
COMMENT ON COLUMN oasis.case_event.desc_reptd
     IS 'Description of event as reported';
COMMENT ON COLUMN oasis.case_event.desc_coded
     IS 'Store the synonym as returned by MedDRA browser';
COMMENT ON COLUMN oasis.case_event.diagnosis
     IS '0=Not diagnosis   1=Yes Diagnosis';
COMMENT ON COLUMN oasis.case_event.onset
     IS 'Onset date (partial) of event';
COMMENT ON COLUMN oasis.case_event.onset_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_event.onset_delay
     IS 'Text describing onset delay from last dosage';
COMMENT ON COLUMN oasis.case_event.stop_date
     IS 'Stop date of event';
COMMENT ON COLUMN oasis.case_event.stop_date_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_event.duration
     IS 'Text describing duration of event. Calculated from Onset Date to Event Stop Date';
COMMENT ON COLUMN oasis.case_event.onset_latency
     IS 'Text describing onset latency from first dosage';
COMMENT ON COLUMN oasis.case_event.evt_intensity_id
     IS 'Intensity of event, value from LM_EVT_INTENSIT. This column is foreign key to LM_EVT_INTENSITY.EVT_INTENSITY_ID.';
COMMENT ON COLUMN oasis.case_event.evt_freq_id
     IS 'Frequency of event, value from LM_EVT_FREQUENCY. This column is foreign key to LM_EVT_FREQUENCY.EVT_FREQ_ID.';
COMMENT ON COLUMN oasis.case_event.treated
     IS 'Treatment received   0=Not  1=Yes  2=Unknown';
COMMENT ON COLUMN oasis.case_event.study_related
     IS 'Study related 0=Not  1=Yes  2=Unknown';
COMMENT ON COLUMN oasis.case_event.rechall_related
     IS '0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.prod_seq_num
     IS 'Seq_num of product associated with re-challenge, linked to CASE_PRODUCT for this case.';
COMMENT ON COLUMN oasis.case_event.evt_outcome_id
     IS 'Outcome of event, value from LM_EVT_OUTCOME. This column is foreign key to LM_EVT_OUTCOME.EVT_OUTCOME_ID.';
COMMENT ON COLUMN oasis.case_event.receipt_date
     IS 'Receipt date of event';
COMMENT ON COLUMN oasis.case_event.rpt_serious
     IS '0=No 1=Yes NULL=Event reported during book-in -1=Event reported on Case Form';
COMMENT ON COLUMN oasis.case_event.sc_death
     IS 'Seriousness Criteria Death  0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sc_hosp
     IS 'Seriousness Criteria Hospitalized  0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sc_cong_anom
     IS 'Seriousness Criteria Congenital Anomaly  0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sc_threat
     IS 'Seriousness Criteria life threatening  0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sc_disable
     IS 'Seriousness Criteria Disability 0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sc_int_req
     IS 'Seriousness Criteria Intervention Required  0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sc_other
     IS 'Seriousness Criteria Other (other_text) 0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sc_other_text
     IS 'Text describing Other serious condition';
COMMENT ON COLUMN oasis.case_event.art_code
     IS 'Preferred term code';
COMMENT ON COLUMN oasis.case_event.pref_term
     IS 'Encoded preferred term';
COMMENT ON COLUMN oasis.case_event.inc_term
     IS 'Included/lower level term';
COMMENT ON COLUMN oasis.case_event.body_sys
     IS 'Body system';
COMMENT ON COLUMN oasis.case_event.med_serious
     IS '0=Not serious   1=Serious';
COMMENT ON COLUMN oasis.case_event.past_hist
     IS '0=No  1=Yes  2=Unknown';
COMMENT ON COLUMN oasis.case_event.dict_id
     IS 'Dictionary ID used to encode from CFG_DICTIONARIES_ENTERPRISE table';
COMMENT ON COLUMN oasis.case_event.dict_key
     IS 'Term code';
COMMENT ON COLUMN oasis.case_event.code_status
     IS '1 - encoded';
COMMENT ON COLUMN oasis.case_event.seriousness
     IS '0=No  1=Yes';
COMMENT ON COLUMN oasis.case_event.sort_id
     IS 'Order event is displayed in the case form, Default 99';
COMMENT ON COLUMN oasis.case_event.onset_date_partial
     IS 'Onset date formatted for printing';
COMMENT ON COLUMN oasis.case_event.stop_date_partial
     IS 'Stop date formatted for printing';
COMMENT ON COLUMN oasis.case_event.efficacy
     IS '0 = No 1 = Yes';
COMMENT ON COLUMN oasis.case_event.disease
     IS '0 = No 1 = Yes';
COMMENT ON COLUMN oasis.case_event.withdrawal
     IS '0 = No 1 = Yes';
COMMENT ON COLUMN oasis.case_event.hlgt
     IS 'High Level Group Term.  Used when using MedDRA dictionary for encoding.';
COMMENT ON COLUMN oasis.case_event.hlt
     IS 'High Level Term.  Used when using MedDRA dictionary for encoding.';
COMMENT ON COLUMN oasis.case_event.hlt_code
     IS 'High Level Term Code';
COMMENT ON COLUMN oasis.case_event.hlgt_code
     IS 'High Level Group Term Code';
COMMENT ON COLUMN oasis.case_event.soc_code
     IS 'System Organ Class Code';
COMMENT ON COLUMN oasis.case_event.study_dropped
     IS 'Study dropped. Dropped from study due to event 0=no 1=yes';
COMMENT ON COLUMN oasis.case_event.inc_code
     IS 'Included/Lower Level term code';
COMMENT ON COLUMN oasis.case_event.onset_minutes
     IS 'Unused';
COMMENT ON COLUMN oasis.case_event.delay_minutes
     IS 'Unused';
COMMENT ON COLUMN oasis.case_event.ud_text_1
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_2
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_3
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_4
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_5
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_6
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_7
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_8
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_9
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_10
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_11
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_text_12
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_event.ud_date_1
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_2
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_3
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_4
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_5
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_6
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_7
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_8
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_9
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_10
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_11
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_date_12
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_event.ud_number_1
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_2
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_3
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_4
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_5
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_6
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_7
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_8
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_9
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_10
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_11
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.ud_number_12
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_event.details
     IS 'Details describing the event';
COMMENT ON COLUMN oasis.case_event.syn_code
     IS 'Synonym Id';
COMMENT ON COLUMN oasis.case_event.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_event.study_related_reptd
     IS 'Related to study conduct as reported';
COMMENT ON COLUMN oasis.case_event.duration_unit_e2b
     IS 'E2B_CODE for Unit measurement for Duration';
COMMENT ON COLUMN oasis.case_event.onset_latency_unit_e2b
     IS 'E2B_CODE for Unit measurement of Onset Latency';
COMMENT ON COLUMN oasis.case_event.onset_delay_unit_e2b
     IS 'E2B_CODE for Unit measurement for Onset Delay';
COMMENT ON COLUMN oasis.case_event.duration_seconds
     IS 'Duration in seconds';
COMMENT ON COLUMN oasis.case_event.onset_latency_seconds
     IS 'Latency in seconds';
COMMENT ON COLUMN oasis.case_event.onset_delay_seconds
     IS 'Delay in seconds';
COMMENT ON COLUMN oasis.case_event.body_sys_j
     IS 'Body system (Japanese).';
COMMENT ON COLUMN oasis.case_event.code_status_j
     IS '1 - encoded (Japanese).';
COMMENT ON COLUMN oasis.case_event.desc_coded_j
     IS 'Store the synonym as returned by MedDRA browser (Japanese).';
COMMENT ON COLUMN oasis.case_event.desc_reptd_j
     IS 'Description of event as reported (Japanese).';
COMMENT ON COLUMN oasis.case_event.details_j
     IS 'Details describing the event (Japanese).';
COMMENT ON COLUMN oasis.case_event.hlgt_j
     IS 'High Level Group Term.  Used when using MedDRA dictionary for encoding. (Japanese).';
COMMENT ON COLUMN oasis.case_event.hlt_j
     IS 'High Level Term.  Used when using MedDRA dictionary for encoding. (Japanese).';
COMMENT ON COLUMN oasis.case_event.inc_code_j
     IS 'Included/Lower Level term code (Japanese).';
COMMENT ON COLUMN oasis.case_event.inc_term_j
     IS 'Included/lower level term (Japanese).';
COMMENT ON COLUMN oasis.case_event.pref_term_j
     IS 'Encoded preferred term (Japanese).';
COMMENT ON COLUMN oasis.case_event.sc_other_text_j
     IS 'Text describing Other serious condition (Japanese).';
COMMENT ON COLUMN oasis.case_event.report_exclusion
     IS 'This column stores Event Exclusion check-box values. Possible values are: 1 - Event Excluded. 0 - Event Included.';
COMMENT ON COLUMN oasis.case_event.ud_text_1_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_2_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_3_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_4_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_5_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_6_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_7_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_8_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_9_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_10_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_11_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.ud_text_12_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_event.syn_code_j
     IS 'Synonym Id (Japanese).';
COMMENT ON COLUMN oasis.case_event.infection
     IS 'This column indicates whether this event is an AE or Infection. Possible values are: 0 - AE 1 - Infection';
COMMENT ON COLUMN oasis.case_event.rpt_exclude_cmt
     IS 'This column stores the English justification, when an event is marked to be excluded from PMDA expedited reporting.';
COMMENT ON COLUMN oasis.case_event.rpt_exclude_cmt_j
     IS 'This column stores the Japanese justification, when an event is marked to be excluded from PMDA expedited reporting.';
COMMENT ON COLUMN oasis.case_event.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_event.emergency_room_visit
     IS 'Additional Event outcome - Emergency Room Visit';
COMMENT ON COLUMN oasis.case_event.physician_office_visit
     IS 'Additional Event outcome - Physician Office Visit';
COMMENT ON COLUMN oasis.case_event.country_occured_id
     IS 'Country in which event occurred';
COMMENT ON COLUMN oasis.case_event.medical_confirm
     IS '0, null - unknown||1 = Medically Confirmed by a HCP';
COMMENT ON COLUMN oasis.case_event.original_language
     IS 'Use to denote this was the text from the original language reported.  (1) = Original Language';

CREATE TABLE oasis.case_event_assess(
    case_id NUMERIC NOT NULL,
    event_seq_num NUMERIC NOT NULL,
    prod_seq_num NUMERIC NOT NULL,
    datasheet_id NUMERIC NOT NULL,
    license_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    updated TIMESTAMP(0) WITHOUT TIME ZONE,
    det_listedness_id NUMERIC,
    rpt_causality_id NUMERIC,
    det_causality_id NUMERIC,
    listed_justify CHARACTER VARYING(1000),
    cause_justify CHARACTER VARYING(1000),
    lam_assessed NUMERIC NOT NULL DEFAULT 0,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    causality_assessment CHARACTER VARYING(50),
    causality_score NUMERIC,
    source_id NUMERIC,
    prt_causality_id NUMERIC,
    cause_justify_j CHARACTER VARYING(1000),
    listed_justify_j CHARACTER VARYING(1000),
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    rpt_source_id NUMERIC,
    rpt_method_id NUMERIC,
    det_source_id NUMERIC,
    det_method_id NUMERIC,
    prt_source_id NUMERIC,
    prt_method_id NUMERIC 
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_event_assess
     IS 'Assessments of events versus products.';
COMMENT ON COLUMN oasis.case_event_assess.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_event_assess.event_seq_num
     IS 'Seq_num of event from CASE_EVENT for this case_id';
COMMENT ON COLUMN oasis.case_event_assess.prod_seq_num
     IS 'Seq_num of product from CASE_PRODUCT for this case_id';
COMMENT ON COLUMN oasis.case_event_assess.datasheet_id
     IS 'Datasheet ID for license, value from LM_DATASHEET';
COMMENT ON COLUMN oasis.case_event_assess.license_id
     IS 'License id for product, value from LM_LICENSE. This column is foreign key to LM_LICENSE.LICENSE_ID.';
COMMENT ON COLUMN oasis.case_event_assess.seq_num
     IS 'Incremental number unique within this case';
COMMENT ON COLUMN oasis.case_event_assess.updated
     IS 'Date this row was changed';
COMMENT ON COLUMN oasis.case_event_assess.det_listedness_id
     IS 'As determined listedness id, value from LM_LISTEDNESS. This column is foreign key to LM_LISTEDNESS.LISTEDNESS_ID.';
COMMENT ON COLUMN oasis.case_event_assess.rpt_causality_id
     IS 'As reported causality, value from LM_CAUSALITY. This column is foreign key to LM_CAUSALITY.CAUSALITY_ID.';
COMMENT ON COLUMN oasis.case_event_assess.det_causality_id
     IS 'As determined causality id, value from LM_CAUSALITY. This column is foreign key to LM_CAUSALITY.CAUSALITY_ID.';
COMMENT ON COLUMN oasis.case_event_assess.listed_justify
     IS 'Justification for setting as determined listedness';
COMMENT ON COLUMN oasis.case_event_assess.cause_justify
     IS 'Justification for setting as determined cause';
COMMENT ON COLUMN oasis.case_event_assess.lam_assessed
     IS 'Assessment done. 0-No; 1-Yes.';
COMMENT ON COLUMN oasis.case_event_assess.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_event_assess.causality_assessment
     IS 'Answers to causality questions, comma separated integer values';
COMMENT ON COLUMN oasis.case_event_assess.causality_score
     IS 'Causality score (0-10) in case of "Naranjo algorithm"';
COMMENT ON COLUMN oasis.case_event_assess.source_id
     IS 'Obsolete.This column is foreign key to LM_CAUSALITY_SOURCE.SOURCE_ID.';
COMMENT ON COLUMN oasis.case_event_assess.prt_causality_id
     IS 'This column is foreign key to LM_CAUSALITY.CAUSALITY_ID.';
COMMENT ON COLUMN oasis.case_event_assess.cause_justify_j
     IS 'Justification for setting as determined cause (Japanese).';
COMMENT ON COLUMN oasis.case_event_assess.listed_justify_j
     IS 'Justification for setting as determined listedness (Japanese).';
COMMENT ON COLUMN oasis.case_event_assess.last_update_time
     IS 'Indicates the last update time stored in GMT';
COMMENT ON COLUMN oasis.case_event_assess.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_event_assess.rpt_source_id
     IS 'Source of Causality as Reported';
COMMENT ON COLUMN oasis.case_event_assess.rpt_method_id
     IS 'Method for Reported Causality';
COMMENT ON COLUMN oasis.case_event_assess.det_source_id
     IS 'Source of Causality as Determined';
COMMENT ON COLUMN oasis.case_event_assess.det_method_id
     IS 'Method for As Determined Causality';
COMMENT ON COLUMN oasis.case_event_assess.prt_source_id
     IS 'Source of Other Causality';
COMMENT ON COLUMN oasis.case_event_assess.prt_method_id
     IS 'Method for Other Causality';

CREATE TABLE oasis.case_event_consequence(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    ed_seq_num NUMERIC NOT NULL,
    evt_consequence_id NUMERIC NOT NULL,
    consequence CHARACTER VARYING(100),
    term CHARACTER VARYING(250),
    consequence_j CHARACTER VARYING(100),
    term_j CHARACTER VARYING(250),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_event_consequence
     IS 'Event Occurred as Consequence of case table';
COMMENT ON COLUMN oasis.case_event_consequence.case_id
     IS 'ID of case PK1. This column is foreign key to CASE_EVENT_DETAIL.CASE_ID.';
COMMENT ON COLUMN oasis.case_event_consequence.seq_num
     IS 'Sequence number of record PK2';
COMMENT ON COLUMN oasis.case_event_consequence.ed_seq_num
     IS 'Parent sequence number from CASE_EVENT_DETAIL. This column is foreign key to CASE_EVENT_DETAIL.SEQ_NUM.';
COMMENT ON COLUMN oasis.case_event_consequence.evt_consequence_id
     IS 'ID from list maintenance table. This column is foreign key to LM_EVT_CONSEQUENCE.EVT_CONSEQUENCE_ID.';
COMMENT ON COLUMN oasis.case_event_consequence.consequence
     IS 'Text from list maintenance table for searching';
COMMENT ON COLUMN oasis.case_event_consequence.term
     IS 'Text from list maintenance table for searching';
COMMENT ON COLUMN oasis.case_event_consequence.consequence_j
     IS 'This column holds the Japanese text for the consequence.';
COMMENT ON COLUMN oasis.case_event_consequence.term_j
     IS 'This column holds the Japanese text for the term.';
COMMENT ON COLUMN oasis.case_event_consequence.deleted
     IS 'Date record was logically deleted';
COMMENT ON COLUMN oasis.case_event_consequence.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_event_detail(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    prod_seq_num NUMERIC NOT NULL,
    event_seq_num NUMERIC NOT NULL,
    onset_delay CHARACTER VARYING(40),
    onset_delay_seconds NUMERIC,
    onset_latency CHARACTER VARYING(40),
    onset_latency_seconds NUMERIC,
    total_dose NUMERIC(22,7),
    total_dose_unit_id NUMERIC,
    most_important NUMERIC,
    more_specific NUMERIC,
    act_taken_id NUMERIC,
    other_information CHARACTER VARYING(250),
    dechallenge NUMERIC,
    rechallenge NUMERIC,
    other_information_j CHARACTER VARYING(250),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_event_detail
     IS 'Product Event Details';
COMMENT ON COLUMN oasis.case_event_detail.case_id
     IS 'ID of case PK1';
COMMENT ON COLUMN oasis.case_event_detail.seq_num
     IS 'Sequence number of record PK2';
COMMENT ON COLUMN oasis.case_event_detail.prod_seq_num
     IS 'Product Sequence Number';
COMMENT ON COLUMN oasis.case_event_detail.event_seq_num
     IS 'Event Sequence Number';
COMMENT ON COLUMN oasis.case_event_detail.onset_delay
     IS 'Onset Delay Text';
COMMENT ON COLUMN oasis.case_event_detail.onset_delay_seconds
     IS 'Onset Delay in Seconds';
COMMENT ON COLUMN oasis.case_event_detail.onset_latency
     IS 'Onset Latency Text';
COMMENT ON COLUMN oasis.case_event_detail.onset_latency_seconds
     IS 'Onset Latency in Seconds';
COMMENT ON COLUMN oasis.case_event_detail.total_dose
     IS 'Total dose to event';
COMMENT ON COLUMN oasis.case_event_detail.total_dose_unit_id
     IS 'Total dose unit. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.case_event_detail.most_important
     IS 'Most Important Diagnosis 0-No  1-Yes';
COMMENT ON COLUMN oasis.case_event_detail.more_specific
     IS 'Event more specific/severe than PT 0-No 1-Yes';
COMMENT ON COLUMN oasis.case_event_detail.act_taken_id
     IS 'Action Taken. This column is foreign key to LM_ACTION_TAKEN.ACT_TAKEN_ID.';
COMMENT ON COLUMN oasis.case_event_detail.other_information
     IS 'Other information';
COMMENT ON COLUMN oasis.case_event_detail.dechallenge
     IS '0=No, 1=Yes, 2 = Unknown, 3 = N/A (Default = Null)';
COMMENT ON COLUMN oasis.case_event_detail.rechallenge
     IS '0=No, 1=Yes, 2 = Unknown, 3 = N/A (Default = Null)';
COMMENT ON COLUMN oasis.case_event_detail.other_information_j
     IS 'This column holds the Japanese text for the other information.';
COMMENT ON COLUMN oasis.case_event_detail.deleted
     IS 'Date record was logically deleted';
COMMENT ON COLUMN oasis.case_event_detail.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_followup(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    receipt_date TIMESTAMP(0) WITHOUT TIME ZONE,
    safety_date TIMESTAMP(0) WITHOUT TIME ZONE,
    significant NUMERIC(1,0),
    auditlog_type NUMERIC,
    time_stamp TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL,
    significant_device NUMERIC(1,0),
    data_cleanup NUMERIC(1,0),
    justification_id NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    just_receipt_date_j CHARACTER VARYING(1000),
    receipt_date_j TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    amendment NUMERIC(1,0),
    justification TEXT,
    justification_j TEXT
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_followup
     IS 'Follow-up log on Case Form.';
COMMENT ON COLUMN oasis.case_followup.case_id
     IS ' This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_followup.seq_num
     IS 'Internal case ID.  Automatically generated starting at 1.';
COMMENT ON COLUMN oasis.case_followup.receipt_date
     IS 'Follow-up receipt date at user site.';
COMMENT ON COLUMN oasis.case_followup.safety_date
     IS 'Follow-up receipt date at Central Safety.';
COMMENT ON COLUMN oasis.case_followup.significant
     IS 'Is this follow-up information considered significant, based on company specific policies?  If this follow-up information is marked as significant, the regulatory report algorithm will re-run and will calculate the due date based on the most recent significant follow-up date. 1 = Yes, 0 = No';
COMMENT ON COLUMN oasis.case_followup.auditlog_type
     IS 'Next entry number for case audit log.';
COMMENT ON COLUMN oasis.case_followup.time_stamp
     IS 'This case_followup record creation time';
COMMENT ON COLUMN oasis.case_followup.significant_device
     IS 'Determines whether the follow-up is significant for device';
COMMENT ON COLUMN oasis.case_followup.data_cleanup
     IS '0 - If Data Cleanup is not checked 1 - If data cleanup no checked. Default Value will be 0';
COMMENT ON COLUMN oasis.case_followup.justification_id
     IS 'ID from selected justification. It references LM_JUSTIFICATIONS';
COMMENT ON COLUMN oasis.case_followup.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_followup.just_receipt_date_j
     IS 'Justification for changing the Japanese follow-up receipt date from the default';
COMMENT ON COLUMN oasis.case_followup.receipt_date_j
     IS 'Follow-up receipt date at user site. (Japanese).';
COMMENT ON COLUMN oasis.case_followup.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_followup.amendment
     IS '0, null - unknown||1 = Amendment follow-up';
COMMENT ON COLUMN oasis.case_followup.justification
     IS 'Followup Justification text will be saved in this field.';

CREATE TABLE oasis.case_lab_data(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    lab_test_id NUMERIC,
    test_date TIMESTAMP(0) WITHOUT TIME ZONE,
    sort_id NUMERIC,
    assessment NUMERIC,
    test_date_res NUMERIC(4,0),
    results CHARACTER VARYING(50),
    norm_high CHARACTER VARYING(50),
    norm_low CHARACTER VARYING(50),
    test_date_partial CHARACTER VARYING(20),
    result CHARACTER VARYING(20),
    unit CHARACTER VARYING(70),
    lab_test_name CHARACTER VARYING(250),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    notes TEXT DEFAULT NULL,
    pt_code CHARACTER VARYING(50),
    llt_code CHARACTER VARYING(50),
    hlt_code CHARACTER VARYING(50),
    hlgt_code CHARACTER VARYING(50),
    soc_code CHARACTER VARYING(50),
    syn_code NUMERIC,
    dict_id NUMERIC,
    llt CHARACTER VARYING(250),
    hlt CHARACTER VARYING(250),
    hlgt CHARACTER VARYING(250),
    soc CHARACTER VARYING(250),
    code_status NUMERIC,
    test_reptd CHARACTER VARYING(250),
    unit_id NUMERIC,
    code_status_j NUMERIC,
    hlgt_j CHARACTER VARYING(250),
    hlt_j CHARACTER VARYING(250),
    lab_test_name_j CHARACTER VARYING(250),
    llt_code_j CHARACTER VARYING(50),
    llt_j CHARACTER VARYING(250),
    notes_j TEXT DEFAULT NULL,
    results_j CHARACTER VARYING(50),
    result_j CHARACTER VARYING(20),
    soc_j CHARACTER VARYING(250),
    test_reptd_j CHARACTER VARYING(250),
    syn_code_j NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    comments TEXT DEFAULT NULL,
    comments_j TEXT DEFAULT NULL,
    info_available NUMERIC 
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_lab_data
     IS 'Lab data results for patient.';
COMMENT ON COLUMN oasis.case_lab_data.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_PAT_INFO.CASE_ID.';
COMMENT ON COLUMN oasis.case_lab_data.seq_num
     IS 'Incremental value of this record to keep it unique within the case';
COMMENT ON COLUMN oasis.case_lab_data.lab_test_id
     IS 'Lab test id, value from LM_LAB_TEST_TYPES. This column is foreign key to LM_LAB_TEST_TYPES.LAB_TEST_ID.';
COMMENT ON COLUMN oasis.case_lab_data.test_date
     IS 'Date test was administered';
COMMENT ON COLUMN oasis.case_lab_data.sort_id
     IS 'Order to display lab data in case form';
COMMENT ON COLUMN oasis.case_lab_data.assessment
     IS 'Assessment Value entered by end user';
COMMENT ON COLUMN oasis.case_lab_data.test_date_res
     IS 'Partial data resolution for CASE_LAB_DATA.TEST_DATE';
COMMENT ON COLUMN oasis.case_lab_data.results
     IS 'Description of Lab test results';
COMMENT ON COLUMN oasis.case_lab_data.norm_high
     IS 'Description of high value for test';
COMMENT ON COLUMN oasis.case_lab_data.norm_low
     IS 'Description of low value for test';
COMMENT ON COLUMN oasis.case_lab_data.test_date_partial
     IS 'Partial date string for printing from CASE_LAB_DATA.TEST_DATE and CASE_LAB_DATA.TEST_DATE_RES';
COMMENT ON COLUMN oasis.case_lab_data.result
     IS 'Unused';
COMMENT ON COLUMN oasis.case_lab_data.unit
     IS 'Case lab data test unit';
COMMENT ON COLUMN oasis.case_lab_data.lab_test_name
     IS 'Lab test name.';
COMMENT ON COLUMN oasis.case_lab_data.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_lab_data.notes
     IS 'Notes for test (10,000 characters)';
COMMENT ON COLUMN oasis.case_lab_data.pt_code
     IS 'Preferred term Code';
COMMENT ON COLUMN oasis.case_lab_data.llt_code
     IS 'Low Level Term Code';
COMMENT ON COLUMN oasis.case_lab_data.hlt_code
     IS 'High Level Term Code';
COMMENT ON COLUMN oasis.case_lab_data.hlgt_code
     IS 'HLGT Code';
COMMENT ON COLUMN oasis.case_lab_data.soc_code
     IS 'SOC Code';
COMMENT ON COLUMN oasis.case_lab_data.syn_code
     IS 'Synonym Code';
COMMENT ON COLUMN oasis.case_lab_data.dict_id
     IS 'Dictionary Id';
COMMENT ON COLUMN oasis.case_lab_data.llt
     IS 'Low Level Term';
COMMENT ON COLUMN oasis.case_lab_data.hlt
     IS 'High Level Term';
COMMENT ON COLUMN oasis.case_lab_data.hlgt
     IS 'HLGT';
COMMENT ON COLUMN oasis.case_lab_data.soc
     IS 'SOC';
COMMENT ON COLUMN oasis.case_lab_data.code_status
     IS 'Synonym';
COMMENT ON COLUMN oasis.case_lab_data.test_reptd
     IS 'Code Status for Showing diff status Icons';
COMMENT ON COLUMN oasis.case_lab_data.unit_id
     IS 'Value from lm_dose_units';
COMMENT ON COLUMN oasis.case_lab_data.code_status_j
     IS 'Synonym (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.hlgt_j
     IS 'HLGT (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.hlt_j
     IS 'High Level Term (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.lab_test_name_j
     IS 'Lab test name. (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.llt_code_j
     IS 'Low Level Term Code (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.llt_j
     IS 'Low Level Term (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.notes_j
     IS 'Notes for test (10,000 characters) (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.results_j
     IS 'Description of Lab test results (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.result_j
     IS 'Unused (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.soc_j
     IS 'SOC (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.test_reptd_j
     IS 'Code Status for Showing diff status Icons (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.syn_code_j
     IS 'Synonym Code (Japanese).';
COMMENT ON COLUMN oasis.case_lab_data.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_lab_data.comments
     IS 'Lab data comments (2000 characters)';
COMMENT ON COLUMN oasis.case_lab_data.comments_j
     IS 'Lab data Japanese comments (2000 characters)';
COMMENT ON COLUMN oasis.case_lab_data.info_available
     IS 'NULL :-  Default ||0 :- More Information Not Available (CheckBox Unchecked)||1:-  More Information Available (CheckBox checked)';

CREATE TABLE oasis.case_literature(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    sort_id NUMERIC,
    literature_id NUMERIC,
    journal CHARACTER VARYING(80),
    author CHARACTER VARYING(200),
    title CHARACTER VARYING(500),
    vol CHARACTER VARYING(15),
    year CHARACTER VARYING(4),
    pgs CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    author_j CHARACTER VARYING(200),
    journal_j CHARACTER VARYING(80),
    title_j CHARACTER VARYING(500),
    enterprise_id NUMERIC NOT NULL,
    country_id NUMERIC,
    classification_id NUMERIC,
    object_identifier CHARACTER VARYING(100)
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_literature
     IS 'Literature Description.';
COMMENT ON COLUMN oasis.case_literature.case_id
     IS ' This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_literature.seq_num
     IS 'Incremental number unique to attachments within this case';
COMMENT ON COLUMN oasis.case_literature.sort_id
     IS 'Order displayed on case form';
COMMENT ON COLUMN oasis.case_literature.literature_id
     IS ' This column is foreign key to LM_LIT_CITATIONS.LITERATURE_ID.';
COMMENT ON COLUMN oasis.case_literature.journal
     IS 'Journal name';
COMMENT ON COLUMN oasis.case_literature.author
     IS 'Author name';
COMMENT ON COLUMN oasis.case_literature.title
     IS 'Title of the literature';
COMMENT ON COLUMN oasis.case_literature.vol
     IS 'Volume';
COMMENT ON COLUMN oasis.case_literature.year
     IS 'Year published';
COMMENT ON COLUMN oasis.case_literature.pgs
     IS 'Pages';
COMMENT ON COLUMN oasis.case_literature.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_literature.author_j
     IS 'Author name (Japanese).';
COMMENT ON COLUMN oasis.case_literature.journal_j
     IS 'Journal name (Japanese).';
COMMENT ON COLUMN oasis.case_literature.title_j
     IS 'Title of the literature (Japanese).';
COMMENT ON COLUMN oasis.case_literature.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_literature.country_id
     IS 'Country of publication';
COMMENT ON COLUMN oasis.case_literature.classification_id
     IS 'Study / Trial classification from Codelist (1) = Clinical trial/research (2) = Non-clinical trial/research';
COMMENT ON COLUMN oasis.case_literature.object_identifier
     IS 'Document Object Identifier of a Literature Journal';

CREATE TABLE oasis.case_master(
    case_id NUMERIC NOT NULL,
    case_num CHARACTER VARYING(20),
    rev NUMERIC,
    workflow_seq_num NUMERIC,
    last_workflow_seq_num NUMERIC,
    create_time TIMESTAMP(0) WITHOUT TIME ZONE,
    init_rept_date TIMESTAMP(0) WITHOUT TIME ZONE NOT NULL,
    user_id NUMERIC,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE,
    last_update_user_id NUMERIC NOT NULL,
    requires_followup NUMERIC NOT NULL DEFAULT 0,
    followup_date TIMESTAMP(0) WITHOUT TIME ZONE,
    owner_id NUMERIC DEFAULT 0,
    state_id NUMERIC,
    country_id NUMERIC,
    lang_id NUMERIC,
    priority NUMERIC,
    site_id NUMERIC,
    seriousness NUMERIC,
    rpt_type_id NUMERIC,
    last_state_id NUMERIC,
    assessment_needed NUMERIC DEFAULT 0,
    priority_override NUMERIC(1,0),
    sid CHARACTER VARYING(128),
    safety_date TIMESTAMP(0) WITHOUT TIME ZONE,
    normal_time TIMESTAMP(0) WITHOUT TIME ZONE,
    max_time TIMESTAMP(0) WITHOUT TIME ZONE,
    report_scheduling NUMERIC DEFAULT 0,
    priority_assessment NUMERIC DEFAULT 0,
    close_user_id NUMERIC,
    close_date TIMESTAMP(0) WITHOUT TIME ZONE,
    close_notes CHARACTER VARYING(200),
    date_locked TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    due_soon TIMESTAMP(0) WITHOUT TIME ZONE,
    global_num CHARACTER VARYING(20),
    priority_date_assessed TIMESTAMP(0) WITHOUT TIME ZONE,
    lam_assess_done NUMERIC(1,0) NOT NULL DEFAULT 0,
    e2b_ww_number CHARACTER VARYING(100),
    worklist_owner_id NUMERIC,
    susar NUMERIC DEFAULT 0,
    last_update_event TIMESTAMP(0) WITHOUT TIME ZONE,
    initial_justification CHARACTER VARYING(1000),
    force_soon TIMESTAMP(0) WITHOUT TIME ZONE,
    due_soon_j TIMESTAMP(0) WITHOUT TIME ZONE,
    followup_date_j TIMESTAMP(0) WITHOUT TIME ZONE,
    init_rept_date_j TIMESTAMP(0) WITHOUT TIME ZONE,
    just_init_rept_date_j CHARACTER VARYING(1000),
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    initial_justification_j CHARACTER VARYING(1000),
    enterprise_id NUMERIC NOT NULL,
    lock_status_id NUMERIC NOT NULL DEFAULT 1,
    medically_confirm NUMERIC 
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_master
     IS 'Master record for case form.';
COMMENT ON COLUMN oasis.case_master.case_id
     IS 'Unique value of the case, used in all tables linked to the case';
COMMENT ON COLUMN oasis.case_master.case_num
     IS 'Case number';
COMMENT ON COLUMN oasis.case_master.rev
     IS 'Revision of the case based on follow-up date changes';
COMMENT ON COLUMN oasis.case_master.workflow_seq_num
     IS 'Value from CFG_WORKFLOW_RULES. This column is foreign key to CFG_WORKFLOW_RULES.SEQ_NUM.';
COMMENT ON COLUMN oasis.case_master.last_workflow_seq_num
     IS 'Value from CFG_WORKFLOW_RULES. This column is foreign key to CFG_WORKFLOW_RULES.SEQ_NUM.';
COMMENT ON COLUMN oasis.case_master.create_time
     IS 'Initial creation date of case, stored in GMT';
COMMENT ON COLUMN oasis.case_master.init_rept_date
     IS 'Initial receipt date of case';
COMMENT ON COLUMN oasis.case_master.user_id
     IS 'Value from CFG_USERS, originator of the case. This column is foreign key to CFG_USERS.USER_ID.';
COMMENT ON COLUMN oasis.case_master.last_update_time
     IS 'Last date case was saved, stored in GMT';
COMMENT ON COLUMN oasis.case_master.last_update_user_id
     IS 'Last user to save the case, value from CFG_USERS';
COMMENT ON COLUMN oasis.case_master.requires_followup
     IS 'Case Requires Follow-up (yes = 1); Default=0';
COMMENT ON COLUMN oasis.case_master.followup_date
     IS 'Follow-up date';
COMMENT ON COLUMN oasis.case_master.owner_id
     IS 'User that created the initial case, value from CFG_USERS,Default 0';
COMMENT ON COLUMN oasis.case_master.state_id
     IS 'Current state the case is in, value from CFG_WORKFLOW_STATES. This column is foreign key to CFG_WORKFLOW_STATES.STATE_ID.';
COMMENT ON COLUMN oasis.case_master.country_id
     IS 'Country id, from LM_COUNTRIES. This column is foreign key to LM_COUNTRIES.COUNTRY_ID.';
COMMENT ON COLUMN oasis.case_master.lang_id
     IS 'Unused';
COMMENT ON COLUMN oasis.case_master.priority
     IS 'Case priority value';
COMMENT ON COLUMN oasis.case_master.site_id
     IS 'Value from CFG_USERS which in turn comes from LM_SITES';
COMMENT ON COLUMN oasis.case_master.seriousness
     IS '0=No  1-Yes   2-Unknown  case serious';
COMMENT ON COLUMN oasis.case_master.rpt_type_id
     IS 'Type of case entered, value from LM_REPORT_TYPE. This column is foreign key to LM_REPORT_TYPE.RPT_TYPE_ID.';
COMMENT ON COLUMN oasis.case_master.last_state_id
     IS 'Last state the case was in, value from CFG_WORKFLOW_STATES';
COMMENT ON COLUMN oasis.case_master.assessment_needed
     IS '1 = Event Assessment to be run by AGService';
COMMENT ON COLUMN oasis.case_master.priority_override
     IS '0=No,  1=Yes, Default = 0.';
COMMENT ON COLUMN oasis.case_master.sid
     IS 'Database in which this case was entered.';
COMMENT ON COLUMN oasis.case_master.safety_date
     IS 'Central Safety receipt date.';
COMMENT ON COLUMN oasis.case_master.normal_time
     IS 'Normal priority update time.';
COMMENT ON COLUMN oasis.case_master.max_time
     IS 'Max priority update time.';
COMMENT ON COLUMN oasis.case_master.report_scheduling
     IS 'Scheduling Needed. 0 = Null, 1 = Drug, 2 = Device, 3 = Drug / Device, 4 = Local Report Scheduling';
COMMENT ON COLUMN oasis.case_master.priority_assessment
     IS 'Priority Assessment Needed. 0 = No, 1 = Yes, Default = 0.';
COMMENT ON COLUMN oasis.case_master.close_user_id
     IS 'Closing user id. This column is foreign key to CFG_USERS.USER_ID.';
COMMENT ON COLUMN oasis.case_master.close_date
     IS 'Closing date.';
COMMENT ON COLUMN oasis.case_master.close_notes
     IS 'Closing notes.';
COMMENT ON COLUMN oasis.case_master.date_locked
     IS 'Lock date.';
COMMENT ON COLUMN oasis.case_master.ud_text_1
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_2
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_3
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_4
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_5
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_6
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_7
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_8
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_9
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_10
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_11
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_text_12
     IS 'User Defined Text';
COMMENT ON COLUMN oasis.case_master.ud_date_1
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_2
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_3
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_4
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_5
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_6
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_7
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_8
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_9
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_10
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_11
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_date_12
     IS 'User Defined Date';
COMMENT ON COLUMN oasis.case_master.ud_number_1
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_2
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_3
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_4
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_5
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_6
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_7
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_8
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_9
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_10
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_11
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.ud_number_12
     IS 'User Defined Number';
COMMENT ON COLUMN oasis.case_master.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_master.due_soon
     IS 'Earliest date of a possible report for unlocked cases.';
COMMENT ON COLUMN oasis.case_master.global_num
     IS 'Global Number for case - will be used to store Global Case Number, for Lilly it will store GlobalID, in future also be used for E2b cases';
COMMENT ON COLUMN oasis.case_master.priority_date_assessed
     IS 'Internal use only';
COMMENT ON COLUMN oasis.case_master.lam_assess_done
     IS 'Determines whether lam assessment is complete at the case level Default value = 0 - lam assessment pending 1 = LAM assessment is complete';
COMMENT ON COLUMN oasis.case_master.e2b_ww_number
     IS 'WWW unique number for the case';
COMMENT ON COLUMN oasis.case_master.worklist_owner_id
     IS 'User ID of the current owner of the Case (as assigned through Worklist). . This column is foreign key to CFG_USERS.USER_ID.';
COMMENT ON COLUMN oasis.case_master.susar
     IS 'The column identifies if the case is classified for SUSAR reporting. Default = 0.  1 if case is SUSAR.';
COMMENT ON COLUMN oasis.case_master.last_update_event
     IS 'Last Date when event was encoded using central coding';
COMMENT ON COLUMN oasis.case_master.initial_justification
     IS 'DATA WILL POPULATE FORM BOOKIN, GENERAL TAB,LAM ACCEPTANCE, E2B ACCEPTANCE NOTES';
COMMENT ON COLUMN oasis.case_master.force_soon
     IS 'Date on which Report has to be scheduled forcibly';
COMMENT ON COLUMN oasis.case_master.due_soon_j
     IS 'Earliest date of a possible report for unlocked cases. (Japanese).';
COMMENT ON COLUMN oasis.case_master.followup_date_j
     IS 'Follow-up date (Japanese).';
COMMENT ON COLUMN oasis.case_master.init_rept_date_j
     IS 'Initial receipt date of case (Japanese).';
COMMENT ON COLUMN oasis.case_master.just_init_rept_date_j
     IS 'Justification for changing the Japanese initial receipt date from the default';
COMMENT ON COLUMN oasis.case_master.ud_text_1_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_2_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_3_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_4_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_5_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_6_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_7_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_8_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_9_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_10_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_11_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.ud_text_12_j
     IS 'User Defined Text (Japanese).';
COMMENT ON COLUMN oasis.case_master.initial_justification_j
     IS 'DATA WILL POPULATE FORM BOOKIN, GENERAL TAB,LAM ACCEPTANCE, E2B ACCEPTANCE NOTES (Japanese).';
COMMENT ON COLUMN oasis.case_master.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_master.lock_status_id
     IS 'Stores current lock status of the case';
COMMENT ON COLUMN oasis.case_master.medically_confirm
     IS '0, null - unknown
1 = Medically Confirmed by a HCP';

CREATE TABLE oasis.case_narrative(
    case_id NUMERIC NOT NULL,
    abbrev_narrative TEXT DEFAULT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    narrative TEXT DEFAULT NULL,
    abbrev_narrative_j TEXT DEFAULT NULL,
    narrative_j TEXT DEFAULT NULL,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_narrative
     IS 'Narrative text for case assessment.';
COMMENT ON COLUMN oasis.case_narrative.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_narrative.abbrev_narrative
     IS 'Abbreviated narrative text';
COMMENT ON COLUMN oasis.case_narrative.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_narrative.narrative
     IS 'Narrative text (30,000 characters)';
COMMENT ON COLUMN oasis.case_narrative.abbrev_narrative_j
     IS 'Abbreviated narrative text (Japanese).';
COMMENT ON COLUMN oasis.case_narrative.narrative_j
     IS 'Narrative text (30,000 characters) (Japanese).';
COMMENT ON COLUMN oasis.case_narrative.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_neonates(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    deliver_date TIMESTAMP(0) WITHOUT TIME ZONE,
    weight_grams NUMERIC(22,7),
    weight_ozs NUMERIC(22,7),
    delivery_type_id NUMERIC,
    apgar1 NUMERIC,
    apgar2 NUMERIC,
    apgar3 NUMERIC,
    notes CHARACTER VARYING(1000),
    sort_id NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    birth_type_id NUMERIC,
    fetal_outcome_id NUMERIC,
    parent NUMERIC NOT NULL,
    notes_j CHARACTER VARYING(1000),
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_neonates
     IS 'Neonates information for pregnancy information.';
COMMENT ON COLUMN oasis.case_neonates.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_PREGNANCY.CASE_ID.';
COMMENT ON COLUMN oasis.case_neonates.seq_num
     IS 'Incremental number unique to neonates within this case';
COMMENT ON COLUMN oasis.case_neonates.deliver_date
     IS 'Date of delivery';
COMMENT ON COLUMN oasis.case_neonates.weight_grams
     IS 'Birth weight in grams';
COMMENT ON COLUMN oasis.case_neonates.weight_ozs
     IS 'Birth weight in ounces';
COMMENT ON COLUMN oasis.case_neonates.delivery_type_id
     IS 'Type of delivery, value from LM_DELIVERY_TYPES. This column is foreign key to LM_DELIVERY_TYPES.DELIVERY_TYPE_ID.';
COMMENT ON COLUMN oasis.case_neonates.apgar1
     IS 'APGAR1 score 1.10';
COMMENT ON COLUMN oasis.case_neonates.apgar2
     IS 'APGAR2 score 1.10';
COMMENT ON COLUMN oasis.case_neonates.apgar3
     IS 'APGAR3 score 1.10';
COMMENT ON COLUMN oasis.case_neonates.notes
     IS 'Notes for neonate';
COMMENT ON COLUMN oasis.case_neonates.sort_id
     IS 'Order to display neonates in the pregnancy information dialog';
COMMENT ON COLUMN oasis.case_neonates.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_neonates.birth_type_id
     IS 'Type of Birth, value from LM_BIRTH_TYE to LM_BIRTH_TYPE.BIRTH_TYPE_ID. This column is foreign key to LM_BIRTH_TYPE.BIRTH_TYPE_ID.';
COMMENT ON COLUMN oasis.case_neonates.fetal_outcome_id
     IS 'Type of Fetal Outcome, value from LM_FETAL_OUTCOME to LM_FETAL_OUTCOME.FETAL_OUTCOME_ID. This column is foreign key to LM_FETAL_OUTCOME.FETAL_OUTCOME_ID.';
COMMENT ON COLUMN oasis.case_neonates.parent
     IS '0-Patient 1-Parent';
COMMENT ON COLUMN oasis.case_neonates.notes_j
     IS 'Notes for neonate (Japanese).';
COMMENT ON COLUMN oasis.case_neonates.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_pat_hist(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    start_date TIMESTAMP(0) WITHOUT TIME ZONE,
    start_date_res NUMERIC,
    stop_date TIMESTAMP(0) WITHOUT TIME ZONE,
    stop_date_res NUMERIC,
    condition_type_id NUMERIC,
    sort_id NUMERIC,
    continue NUMERIC(1,0),
    parent NUMERIC(1,0),
    item_dict NUMERIC,
    item_code CHARACTER VARYING(45),
    start_date_partial CHARACTER VARYING(20),
    stop_date_partial CHARACTER VARYING(20),
    condition CHARACTER VARYING(250),
    note TEXT DEFAULT NULL,
    item_llt CHARACTER VARYING(250),
    item_hlt CHARACTER VARYING(250),
    item_hlgt CHARACTER VARYING(250),
    item_soc CHARACTER VARYING(250),
    item_llt_code CHARACTER VARYING(50),
    item_hlt_code CHARACTER VARYING(50),
    item_hlgt_code CHARACTER VARYING(50),
    item_soc_code CHARACTER VARYING(50),
    item_reptd CHARACTER VARYING(255),
    item_coded CHARACTER VARYING(255),
    item_syn_code NUMERIC,
    item_code_status NUMERIC(3,0),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    indication CHARACTER VARYING(250),
    ind_reptd CHARACTER VARYING(255),
    ind_coded CHARACTER VARYING(255),
    ind_pt_code CHARACTER VARYING(50),
    ind_llt_code CHARACTER VARYING(50),
    ind_llt CHARACTER VARYING(250),
    ind_hlt_code CHARACTER VARYING(50),
    ind_hlt CHARACTER VARYING(250),
    ind_hlgt_code CHARACTER VARYING(50),
    ind_hlgt CHARACTER VARYING(250),
    ind_soc_code CHARACTER VARYING(50),
    ind_soc CHARACTER VARYING(250),
    ind_syn_code NUMERIC,
    ind_dict_id NUMERIC,
    ind_code_status NUMERIC(3,0),
    reaction CHARACTER VARYING(250),
    react_reptd CHARACTER VARYING(255),
    react_coded CHARACTER VARYING(255),
    react_pt_code CHARACTER VARYING(50),
    react_llt_code CHARACTER VARYING(50),
    react_llt CHARACTER VARYING(250),
    react_hlt_code CHARACTER VARYING(50),
    react_hlt CHARACTER VARYING(250),
    react_hlgt_code CHARACTER VARYING(50),
    react_hlgt CHARACTER VARYING(250),
    react_soc_code CHARACTER VARYING(50),
    react_soc CHARACTER VARYING(250),
    react_syn_code NUMERIC,
    react_dict_id NUMERIC,
    react_code_status NUMERIC(3,0),
    condition_j CHARACTER VARYING(250),
    indication_j CHARACTER VARYING(250),
    ind_coded_j CHARACTER VARYING(255),
    ind_code_status_j NUMERIC,
    ind_hlgt_j CHARACTER VARYING(250),
    ind_hlt_j CHARACTER VARYING(250),
    ind_llt_code_j CHARACTER VARYING(50),
    ind_llt_j CHARACTER VARYING(250),
    ind_reptd_j CHARACTER VARYING(255),
    ind_soc_j CHARACTER VARYING(250),
    item_coded_j CHARACTER VARYING(255),
    item_code_status_j NUMERIC,
    item_hlgt_j CHARACTER VARYING(250),
    item_hlt_j CHARACTER VARYING(250),
    item_llt_code_j CHARACTER VARYING(50),
    item_llt_j CHARACTER VARYING(250),
    item_reptd_j CHARACTER VARYING(255),
    item_soc_j CHARACTER VARYING(250),
    note_j TEXT DEFAULT NULL,
    reaction_j CHARACTER VARYING(250),
    react_coded_j CHARACTER VARYING(255),
    react_code_status_j NUMERIC,
    react_hlgt_j CHARACTER VARYING(250),
    react_hlt_j CHARACTER VARYING(250),
    react_llt_code_j CHARACTER VARYING(50),
    react_llt_j CHARACTER VARYING(250),
    react_reptd_j CHARACTER VARYING(255),
    react_soc_j CHARACTER VARYING(250),
    ind_syn_code_j NUMERIC,
    item_syn_code_j NUMERIC,
    react_syn_code_j NUMERIC,
    item_dict_j NUMERIC,
    item_code_j CHARACTER VARYING(50),
    enterprise_id NUMERIC NOT NULL,
    family_history NUMERIC(1,0),
    age NUMERIC(3,0),
    age_unit_id NUMERIC,
    identifier_type_id NUMERIC,
    identifier CHARACTER VARYING(1000),
    identifier_version CHARACTER VARYING(10),
    MFDS_PRODUCT_CODE varchar(70),
    MEDICINAL_PROD_ID varchar(10)
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_pat_hist
     IS 'Other relevant history for patient.';
COMMENT ON COLUMN oasis.case_pat_hist.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_pat_hist.seq_num
     IS 'Incremental number unique to patient history within this case';
COMMENT ON COLUMN oasis.case_pat_hist.start_date
     IS 'Start date (partial) of condition';
COMMENT ON COLUMN oasis.case_pat_hist.start_date_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_pat_hist.stop_date
     IS 'Stop date (partial) of condition';
COMMENT ON COLUMN oasis.case_pat_hist.stop_date_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_pat_hist.condition_type_id
     IS 'Condition type, value from LM_CONDITION_TYPE. This column is foreign key to LM_CONDITION_TYPE.CONDITION_TYPE_ID.';
COMMENT ON COLUMN oasis.case_pat_hist.sort_id
     IS 'Order to display history in case form';
COMMENT ON COLUMN oasis.case_pat_hist.continue
     IS 'Patient other relevant history is ongoing or not. Ongoing=1, not ongoing=0, Unknown=2';
COMMENT ON COLUMN oasis.case_pat_hist.parent
     IS 'Indicate it is parent or patient information.';
COMMENT ON COLUMN oasis.case_pat_hist.item_dict
     IS '2 - ICD9';
COMMENT ON COLUMN oasis.case_pat_hist.item_code
     IS 'Encoded value of condition';
COMMENT ON COLUMN oasis.case_pat_hist.start_date_partial
     IS 'Start date formatted for printing';
COMMENT ON COLUMN oasis.case_pat_hist.stop_date_partial
     IS 'Stop date formatted for printing';
COMMENT ON COLUMN oasis.case_pat_hist.condition
     IS 'Condition';
COMMENT ON COLUMN oasis.case_pat_hist.note
     IS 'Notes for this condition';
COMMENT ON COLUMN oasis.case_pat_hist.item_llt
     IS 'Lower Level Term for condition';
COMMENT ON COLUMN oasis.case_pat_hist.item_hlt
     IS 'High Level Term';
COMMENT ON COLUMN oasis.case_pat_hist.item_hlgt
     IS 'High Level Group Term';
COMMENT ON COLUMN oasis.case_pat_hist.item_soc
     IS 'Body System Organ Class';
COMMENT ON COLUMN oasis.case_pat_hist.item_llt_code
     IS 'Lower Level Term Code';
COMMENT ON COLUMN oasis.case_pat_hist.item_hlt_code
     IS 'High Level Term code';
COMMENT ON COLUMN oasis.case_pat_hist.item_hlgt_code
     IS 'High Level Group Term code';
COMMENT ON COLUMN oasis.case_pat_hist.item_soc_code
     IS 'System Organ Class Code';
COMMENT ON COLUMN oasis.case_pat_hist.item_reptd
     IS 'Description Reported by the user';
COMMENT ON COLUMN oasis.case_pat_hist.item_coded
     IS 'Description Coded (This should replaced by Synonym Text when encoded) This could be MedDRA or WHO-Drug Synonym.';
COMMENT ON COLUMN oasis.case_pat_hist.item_syn_code
     IS 'Synonym Id';
COMMENT ON COLUMN oasis.case_pat_hist.item_code_status
     IS 'What is the encoding status for this record 0 - Not Coded, 1 - Coded, 2 - Coded Manually, 3 - Coding Pending, 4 - Coding Error ';
COMMENT ON COLUMN oasis.case_pat_hist.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted. ';
COMMENT ON COLUMN oasis.case_pat_hist.indication
     IS 'Indication';
COMMENT ON COLUMN oasis.case_pat_hist.ind_reptd
     IS 'Indication reported';
COMMENT ON COLUMN oasis.case_pat_hist.ind_coded
     IS 'Indication coded';
COMMENT ON COLUMN oasis.case_pat_hist.ind_pt_code
     IS 'Indication PT code';
COMMENT ON COLUMN oasis.case_pat_hist.ind_llt_code
     IS 'Indication LLT code';
COMMENT ON COLUMN oasis.case_pat_hist.ind_llt
     IS 'Indication LLT Term';
COMMENT ON COLUMN oasis.case_pat_hist.ind_hlt_code
     IS 'Indication HLT code';
COMMENT ON COLUMN oasis.case_pat_hist.ind_hlt
     IS 'Indication HLT Term';
COMMENT ON COLUMN oasis.case_pat_hist.ind_hlgt_code
     IS 'Indication HLGT code';
COMMENT ON COLUMN oasis.case_pat_hist.ind_hlgt
     IS 'Indication HLGT Term';
COMMENT ON COLUMN oasis.case_pat_hist.ind_soc_code
     IS 'Indication SOC code';
COMMENT ON COLUMN oasis.case_pat_hist.ind_soc
     IS 'Indication SOC Term';
COMMENT ON COLUMN oasis.case_pat_hist.ind_syn_code
     IS 'Indication synonym code';
COMMENT ON COLUMN oasis.case_pat_hist.ind_dict_id
     IS 'Indication coding dictionary ID';
COMMENT ON COLUMN oasis.case_pat_hist.ind_code_status
     IS 'Indication coding status';
COMMENT ON COLUMN oasis.case_pat_hist.reaction
     IS 'Reaction';
COMMENT ON COLUMN oasis.case_pat_hist.react_reptd
     IS 'Reaction reported';
COMMENT ON COLUMN oasis.case_pat_hist.react_coded
     IS 'Reaction coded';
COMMENT ON COLUMN oasis.case_pat_hist.react_pt_code
     IS 'Reaction PT code';
COMMENT ON COLUMN oasis.case_pat_hist.react_llt_code
     IS 'Reaction LLT code';
COMMENT ON COLUMN oasis.case_pat_hist.react_llt
     IS 'Reaction LLT Term';
COMMENT ON COLUMN oasis.case_pat_hist.react_hlt_code
     IS 'Reaction HLT code';
COMMENT ON COLUMN oasis.case_pat_hist.react_hlt
     IS 'Reaction HLT Term';
COMMENT ON COLUMN oasis.case_pat_hist.react_hlgt_code
     IS 'Reaction HLGT code';
COMMENT ON COLUMN oasis.case_pat_hist.react_hlgt
     IS 'Reaction HLGT Term';
COMMENT ON COLUMN oasis.case_pat_hist.react_soc_code
     IS 'Reaction SOC code';
COMMENT ON COLUMN oasis.case_pat_hist.react_soc
     IS 'Reaction SOC Term';
COMMENT ON COLUMN oasis.case_pat_hist.react_syn_code
     IS 'Reaction synonym code';
COMMENT ON COLUMN oasis.case_pat_hist.react_dict_id
     IS 'Reaction coding dictionary ID';
COMMENT ON COLUMN oasis.case_pat_hist.react_code_status
     IS 'Reaction coding status';
COMMENT ON COLUMN oasis.case_pat_hist.condition_j
     IS 'Condition (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.indication_j
     IS 'Indication (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_coded_j
     IS 'Indication coded (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_code_status_j
     IS 'Indication coding status (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_hlgt_j
     IS 'Indication HLGT Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_hlt_j
     IS 'Indication HLT Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_llt_code_j
     IS 'Indication LLT code (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_llt_j
     IS 'Indication LLT Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_reptd_j
     IS 'Indication reported (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_soc_j
     IS 'Indication SOC Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_coded_j
     IS 'Description Coded (This should replaced by Synonym Text when encoded) This could be MedDRA or WHO-Drug Synonym. (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_code_status_j
     IS 'What is the encoding status for this record 0 - Not Coded, 1 - Coded, 2 - Coded Manually, 3 - Coding Pending, 4 - Coding Error  (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_hlgt_j
     IS 'High Level Group Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_hlt_j
     IS 'High Level Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_llt_code_j
     IS 'Lower Level Term Code (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_llt_j
     IS 'Lower Level Term for condition (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_reptd_j
     IS 'Description Reported by the user (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_soc_j
     IS 'Body System Organ Class (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.note_j
     IS 'Notes for this condition (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.reaction_j
     IS 'Reaction (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_coded_j
     IS 'Reaction coded (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_code_status_j
     IS 'Reaction coding status (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_hlgt_j
     IS 'Reaction HLGT Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_hlt_j
     IS 'Reaction HLT Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_llt_code_j
     IS 'Reaction LLT code (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_llt_j
     IS 'Reaction LLT Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_reptd_j
     IS 'Reaction reported (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_soc_j
     IS 'Reaction SOC Term (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.ind_syn_code_j
     IS 'Indication synonym code (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_syn_code_j
     IS 'Synonym Id (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.react_syn_code_j
     IS 'Reaction synonym code (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_dict_j
     IS '2 - ICD9 (Japanese).';
COMMENT ON COLUMN oasis.case_pat_hist.item_code_j
     IS 'Description Coded (This should replaced by Synonym Text when encoded) This could be MedDRA or WHO-Drug Synonym.';
COMMENT ON COLUMN oasis.case_pat_hist.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_pat_hist.family_history
     IS '0, null - unknown||1 = Family has History for this condition';
COMMENT ON COLUMN oasis.case_pat_hist.age
     IS 'Age at time of vaccination';
COMMENT ON COLUMN oasis.case_pat_hist.age_unit_id
     IS 'Age unit from code list';
COMMENT ON COLUMN oasis.case_pat_hist.identifier_type_id
     IS 'Product Identifier Type.  CodeList: PRODUCT_IDENTFIER_TYPE';
COMMENT ON COLUMN oasis.case_pat_hist.identifier
     IS 'Product Identifier';
COMMENT ON COLUMN oasis.case_pat_hist.identifier_version
     IS 'Product Identifier Version';

CREATE TABLE oasis.case_pat_tests(
    rel_test_id NUMERIC NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    rel_tests TEXT DEFAULT NULL,
    rel_tests_j TEXT DEFAULT NULL,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_pat_tests
     IS 'Information about relevant tests.';
COMMENT ON COLUMN oasis.case_pat_tests.rel_test_id
     IS 'Is CASE_ID, value linked to CASE_MASTER';
COMMENT ON COLUMN oasis.case_pat_tests.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_pat_tests.rel_tests
     IS 'Description (10,000 characters)';
COMMENT ON COLUMN oasis.case_pat_tests.rel_tests_j
     IS 'Description (10,000 characters) (Japanese).';
COMMENT ON COLUMN oasis.case_pat_tests.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_pmoa_cons_relation(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    pmoa_seq_num NUMERIC NOT NULL,
    pmoa_license_id NUMERIC,
    pmoa_country_id NUMERIC,
    cons_seq_num NUMERIC NOT NULL,
    cons_license_id NUMERIC,
    cons_country_id NUMERIC,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_pmoa_cons_relation
     IS 'This table Stores PMOA and constituent relationship.';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.case_id
     IS 'This value is reference to CASE_PRODUCT.CASE_ID (PK)';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.seq_num
     IS 'This value is for sequence number (PK)';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.pmoa_seq_num
     IS 'Product seq num for PMOA drug. This value is reference to CASE_PRODUCT.SEQ_NUM';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.pmoa_license_id
     IS 'PMOA Drug license_id. This value is reference to LM_LICENSE.LICENSE_ID';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.pmoa_country_id
     IS 'PMOA Drug Country ID. This value is reference to LM_COUNTRIES.COUNTRY_ID';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.cons_seq_num
     IS 'Product seq num for Constituent drug . This value is reference to CASE_PRODUCT.SEQ_NUM';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.cons_license_id
     IS 'Constituent Drug license_id. This value is reference to LM_LICENSE.LICENSE_ID';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.cons_country_id
     IS 'Constituent Drug Country ID. This value is reference to LM_COUNTRIES.COUNTRY_ID';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.last_update_time
     IS 'Last update date time for the record';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.deleted
     IS 'Deleted date time';
COMMENT ON COLUMN oasis.case_pmoa_cons_relation.enterprise_id
     IS 'This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID (PK)';

CREATE TABLE oasis.case_pregnancy(
    case_id NUMERIC NOT NULL,
    date_of_lmp TIMESTAMP(0) WITHOUT TIME ZONE,
    gest_period NUMERIC,
    due_date TIMESTAMP(0) WITHOUT TIME ZONE,
    exp_trimester NUMERIC,
    gestation_exp_period NUMERIC,
    parent NUMERIC(1,0) NOT NULL DEFAULT 0,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    breastfeeding NUMERIC(1,0),
    prospective NUMERIC(1,0),
    number_of_fetus NUMERIC(2,0),
    date_of_lmp_res NUMERIC,
    date_of_lmp_partial CHARACTER VARYING(20),
    gravida NUMERIC,
    para NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    gest_period_unit NUMERIC,
    PREG_AT_VACCINE numeric
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_pregnancy
     IS 'Pregnancy information.';
COMMENT ON COLUMN oasis.case_pregnancy.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_pregnancy.date_of_lmp
     IS 'Date of Last Menstrual Period';
COMMENT ON COLUMN oasis.case_pregnancy.gest_period
     IS 'Pregnancy Information Gestation Period';
COMMENT ON COLUMN oasis.case_pregnancy.due_date
     IS 'Due date';
COMMENT ON COLUMN oasis.case_pregnancy.exp_trimester
     IS 'Obsolete.Trimester of exposure, 1=First  2=Second  4=Third';
COMMENT ON COLUMN oasis.case_pregnancy.gestation_exp_period
     IS 'Obsolete.Weeks at exposure';
COMMENT ON COLUMN oasis.case_pregnancy.parent
     IS 'Second part of primary Key. Indicate it is parent or patient information. 1-Parent, 0-Patient';
COMMENT ON COLUMN oasis.case_pregnancy.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_pregnancy.breastfeeding
     IS '1 - Yes, 0 - No';
COMMENT ON COLUMN oasis.case_pregnancy.prospective
     IS '1 - Prospective, 2 - Retrospective';
COMMENT ON COLUMN oasis.case_pregnancy.number_of_fetus
     IS 'Number of fetus';
COMMENT ON COLUMN oasis.case_pregnancy.date_of_lmp_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_pregnancy.date_of_lmp_partial
     IS 'Start time formatted for printing';
COMMENT ON COLUMN oasis.case_pregnancy.gravida
     IS 'Stores the numerical value entered by the user in Gravida field on case form -> Patient Tab -> Pregnancy Information';
COMMENT ON COLUMN oasis.case_pregnancy.para
     IS 'Stores the numerical value entered by the user in Para field on case form -> Patient Tab -> Pregnancy Information';
COMMENT ON COLUMN oasis.case_pregnancy.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_pregnancy.gest_period_unit
     IS 'Gestation period age units';

CREATE TABLE oasis.case_prod_devices(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    model_no CHARACTER VARYING(80),
    lot_no CHARACTER VARYING(35),
    serial_no CHARACTER VARYING(30),
    date_implant TIMESTAMP(0) WITHOUT TIME ZONE,
    date_impant_res NUMERIC,
    date_explant TIMESTAMP(0) WITHOUT TIME ZONE,
    date_explant_res NUMERIC,
    device_age CHARACTER VARYING(10),
    exp_date TIMESTAMP(0) WITHOUT TIME ZONE,
    exp_date_res NUMERIC,
    sort_id NUMERIC,
    explant_date_partial CHARACTER VARYING(20),
    implant_date_partial CHARACTER VARYING(20),
    exp_date_partial CHARACTER VARYING(20),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    malfunction_date TIMESTAMP(0) WITHOUT TIME ZONE,
    lot_id NUMERIC,
    lot_just CHARACTER VARYING(1000),
    lot_status NUMERIC(1,0),
    mfr_evaluation NUMERIC,
    mfr_eval_reason_id NUMERIC,
    mfg_date TIMESTAMP(0) WITHOUT TIME ZONE,
    remedial_action NUMERIC,
    remedial_other CHARACTER VARYING(40),
    dev_usage NUMERIC,
    dev_oper NUMERIC,
    dev_oper_other_text CHARACTER VARYING(40),
    catalog CHARACTER VARYING(30),
    catalog_other CHARACTER VARYING(150),
    evaluation NUMERIC,
    return_date TIMESTAMP(0) WITHOUT TIME ZONE,
    subcomponent_id NUMERIC,
    subcomponent_lot CHARACTER VARYING(35),
    device_type NUMERIC,
    trained_user NUMERIC,
    improper_use NUMERIC,
    preliminary_comments TEXT DEFAULT NULL,
    malfunction NUMERIC,
    malfunction_type NUMERIC,
    reprocessed_reuse NUMERIC DEFAULT NULL,
    reprocessor_name_address CHARACTER VARYING(200),
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    followup_type NUMERIC,
    meth_cd1 CHARACTER VARYING(4),
    meth_cd2 CHARACTER VARYING(4),
    meth_cd3 CHARACTER VARYING(4),
    meth_cd4 CHARACTER VARYING(4),
    res_cd1 CHARACTER VARYING(4),
    res_cd2 CHARACTER VARYING(4),
    res_cd3 CHARACTER VARYING(4),
    res_cd4 CHARACTER VARYING(4),
    conc_cd1 CHARACTER VARYING(4),
    conc_cd2 CHARACTER VARYING(4),
    conc_cd3 CHARACTER VARYING(4),
    conc_cd4 CHARACTER VARYING(4),
    usc CHARACTER VARYING(24),
    manu_narrative NUMERIC(1,0),
    manu_corrected NUMERIC(1,0),
    narrative_text TEXT DEFAULT NULL,
    adverse_event NUMERIC,
    product_problem NUMERIC,
    report_type NUMERIC,
    mfg_date_partial CHARACTER VARYING(20),
    mfg_date_res NUMERIC,
    preliminary_comments_j TEXT DEFAULT NULL,
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    lot_just_j CHARACTER VARYING(1000),
    implant_duration CHARACTER VARYING(20),
    enterprise_id NUMERIC NOT NULL,
    dev_cd1 CHARACTER(4),
    dev_cd2 CHARACTER(4),
    dev_cd3 CHARACTER(4),
    pat_cd1 CHARACTER(4),
    pat_cd2 CHARACTER(4),
    pat_cd3 CHARACTER(4),
    repro_address_1 CHARACTER VARYING(30),
    repro_address_2 CHARACTER VARYING(30),
    repro_city CHARACTER VARYING(30),
    repro_state CHARACTER VARYING(40),
    repro_country_id NUMERIC,
    repro_postal_code CHARACTER VARYING(10),
    repro_fax CHARACTER VARYING(22),
    repro_email CHARACTER VARYING(43),
    age NUMERIC(5,0),
    age_unit_id NUMERIC,
    mfr_other_reason CHARACTER VARYING(40),
    ce_marked NUMERIC,
    udi_system CHARACTER VARYING(100),
    IMPLANT_FACILITY   VARCHAR(200),
    EXPLANT_FACILITY   VARCHAR(200),
    UDI_DI VARCHAR(50),
    UDI_PI VARCHAR(50),
    UDI_DI_UNIT_OF_USE VARCHAR (50),
    IMPLANT_FACILITY_J VARCHAR(200),
    EXPLANT_FACILITY_J VARCHAR(200),
    SIMILAR_DEVICE numeric
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_prod_devices
     IS 'Device information.';
COMMENT ON COLUMN oasis.case_prod_devices.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_prod_devices.seq_num
     IS 'Value linked to CASE_PRODUCT';
COMMENT ON COLUMN oasis.case_prod_devices.model_no
     IS 'Model Number';
COMMENT ON COLUMN oasis.case_prod_devices.lot_no
     IS 'Lot Number';
COMMENT ON COLUMN oasis.case_prod_devices.serial_no
     IS 'Serial Number';
COMMENT ON COLUMN oasis.case_prod_devices.date_implant
     IS 'Date (partial) device was implanted';
COMMENT ON COLUMN oasis.case_prod_devices.date_impant_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_prod_devices.date_explant
     IS 'Date (partial) device was explanted ';
COMMENT ON COLUMN oasis.case_prod_devices.date_explant_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_prod_devices.device_age
     IS 'Obsolete.Age of device description';
COMMENT ON COLUMN oasis.case_prod_devices.exp_date
     IS 'Expiration date (partial) of device';
COMMENT ON COLUMN oasis.case_prod_devices.exp_date_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_prod_devices.sort_id
     IS 'Unused';
COMMENT ON COLUMN oasis.case_prod_devices.explant_date_partial
     IS 'Explant date formatted for printing';
COMMENT ON COLUMN oasis.case_prod_devices.implant_date_partial
     IS 'Implant date formatted for printing';
COMMENT ON COLUMN oasis.case_prod_devices.exp_date_partial
     IS 'Expiration date formatted for printing';
COMMENT ON COLUMN oasis.case_prod_devices.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_prod_devices.malfunction_date
     IS 'Manufacturer/Importer Awareness Date, used for Canadian Report';
COMMENT ON COLUMN oasis.case_prod_devices.lot_id
     IS ' This column is foreign key to LM_PRODUCT_LOTS.LOT_ID.';
COMMENT ON COLUMN oasis.case_prod_devices.lot_just
     IS 'Lot Justification';
COMMENT ON COLUMN oasis.case_prod_devices.lot_status
     IS '0-Not a Valid Lot Number 1-Valid Lot Number 2-Valid Lot Number but overridden';
COMMENT ON COLUMN oasis.case_prod_devices.mfr_evaluation
     IS 'Device Evaluated by Manufacturer?';
COMMENT ON COLUMN oasis.case_prod_devices.mfr_eval_reason_id
     IS 'If evaluation is no, reason to LM_MFR_EVAL_REASON.mfr_eval_id. This column is foreign key to LM_MFR_EVAL_REASON.MFR_EVAL_ID.';
COMMENT ON COLUMN oasis.case_prod_devices.mfg_date
     IS 'Manufacturing date';
COMMENT ON COLUMN oasis.case_prod_devices.remedial_action
     IS 'Remedial Action';
COMMENT ON COLUMN oasis.case_prod_devices.remedial_other
     IS 'Remedial Action Other text';
COMMENT ON COLUMN oasis.case_prod_devices.dev_usage
     IS 'Usage of Device, 0 - Initial 1 - Reuse 2 - Unknown';
COMMENT ON COLUMN oasis.case_prod_devices.dev_oper
     IS 'Operator of Device';
COMMENT ON COLUMN oasis.case_prod_devices.dev_oper_other_text
     IS 'Operator of Device - Other text';
COMMENT ON COLUMN oasis.case_prod_devices.catalog
     IS 'Catalog#';
COMMENT ON COLUMN oasis.case_prod_devices.catalog_other
     IS 'Unique Device Identifier';
COMMENT ON COLUMN oasis.case_prod_devices.evaluation
     IS 'Device available for evaluation';
COMMENT ON COLUMN oasis.case_prod_devices.return_date
     IS 'Returned to manufacturer';
COMMENT ON COLUMN oasis.case_prod_devices.subcomponent_id
     IS 'Obsolete.Device Subcomponent name. This column is foreign key to  LM_DEVICE_SUBCOMPONENTS.SUBCOMPONENT_ID.';
COMMENT ON COLUMN oasis.case_prod_devices.subcomponent_lot
     IS 'Obsolete.Device Subcomponent Lot#';
COMMENT ON COLUMN oasis.case_prod_devices.device_type
     IS 'Device Type. This column is foreign key to LM_DEVICE_TYPE.DEVICE_TYPE_ID.';
COMMENT ON COLUMN oasis.case_prod_devices.trained_user
     IS 'Trained User';
COMMENT ON COLUMN oasis.case_prod_devices.improper_use
     IS 'Improper use or storage';
COMMENT ON COLUMN oasis.case_prod_devices.preliminary_comments
     IS 'Preliminary Comments';
COMMENT ON COLUMN oasis.case_prod_devices.malfunction
     IS 'Malfunction';
COMMENT ON COLUMN oasis.case_prod_devices.malfunction_type
     IS 'Malfunction Type';
COMMENT ON COLUMN oasis.case_prod_devices.reprocessed_reuse
     IS 'Device Reprocessed and reused. Default is null.';
COMMENT ON COLUMN oasis.case_prod_devices.reprocessor_name_address
     IS 'Name of Reprocessor Company';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_1
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_2
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_3
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_4
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_5
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_6
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_7
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_8
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_9
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_10
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_11
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_12
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_1
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_2
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_3
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_4
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_5
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_6
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_7
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_8
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_9
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_10
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_11
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_date_12
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_1
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_2
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_3
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_4
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_5
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_6
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_7
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_8
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_9
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_10
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_11
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.ud_number_12
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_devices.followup_type
     IS 'Type of follow-up report. Combination of Values: Correction, Additional Information, Resp. to FDA Request, Device Evaluation';
COMMENT ON COLUMN oasis.case_prod_devices.meth_cd1
     IS 'Obsolete.Evaluation codes - Method1';
COMMENT ON COLUMN oasis.case_prod_devices.meth_cd2
     IS 'Obsolete.Evaluation codes - Method2';
COMMENT ON COLUMN oasis.case_prod_devices.meth_cd3
     IS 'Obsolete.Evaluation codes - Method3';
COMMENT ON COLUMN oasis.case_prod_devices.meth_cd4
     IS 'Obsolete.Evaluation codes - Method4';
COMMENT ON COLUMN oasis.case_prod_devices.res_cd1
     IS 'Obsolete.Evaluation codes - Result1';
COMMENT ON COLUMN oasis.case_prod_devices.res_cd2
     IS 'Obsolete.Evaluation codes - Result2';
COMMENT ON COLUMN oasis.case_prod_devices.res_cd3
     IS 'Obsolete.Evaluation codes - Result3';
COMMENT ON COLUMN oasis.case_prod_devices.res_cd4
     IS 'Obsolete.Evaluation codes - Result4';
COMMENT ON COLUMN oasis.case_prod_devices.conc_cd1
     IS 'Obsolete.Evaluation codes - Conclusion1';
COMMENT ON COLUMN oasis.case_prod_devices.conc_cd2
     IS 'Obsolete.Evaluation codes - Conclusion2';
COMMENT ON COLUMN oasis.case_prod_devices.conc_cd3
     IS 'Obsolete.Evaluation codes - Conclusion3';
COMMENT ON COLUMN oasis.case_prod_devices.conc_cd4
     IS 'Obsolete.Evaluation codes - Conclusion4';
COMMENT ON COLUMN oasis.case_prod_devices.usc
     IS '21 USC 360i(f) correction/ removal reporting number';
COMMENT ON COLUMN oasis.case_prod_devices.manu_narrative
     IS 'Additional Manufacturer Narrative Check1 - Yes0 - No';
COMMENT ON COLUMN oasis.case_prod_devices.manu_corrected
     IS 'Corrected data Check1 - Yes0 - No';
COMMENT ON COLUMN oasis.case_prod_devices.narrative_text
     IS 'Additional Manufacturer Narrative text';
COMMENT ON COLUMN oasis.case_prod_devices.adverse_event
     IS ' 0=No   1=Yes';
COMMENT ON COLUMN oasis.case_prod_devices.product_problem
     IS 'Problem with product 0-No  1-Yes';
COMMENT ON COLUMN oasis.case_prod_devices.report_type
     IS '5-day report 0 - No 1 - Yes';
COMMENT ON COLUMN oasis.case_prod_devices.mfg_date_partial
     IS 'Used for storing partial date with time component';
COMMENT ON COLUMN oasis.case_prod_devices.mfg_date_res
     IS '5-For Year Only,7-Month and year,8-fulldate';
COMMENT ON COLUMN oasis.case_prod_devices.preliminary_comments_j
     IS 'Preliminary Comments (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_1_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_2_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_3_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_4_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_5_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_6_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_7_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_8_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_9_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_10_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_11_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.ud_text_12_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_devices.lot_just_j
     IS 'Saving User provided text of alternate language in case table.';
COMMENT ON COLUMN oasis.case_prod_devices.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_prod_devices.dev_cd1
     IS 'Obsolete.FDA Device Code (1)';
COMMENT ON COLUMN oasis.case_prod_devices.dev_cd2
     IS 'Obsolete.FDA Device Code (2)';
COMMENT ON COLUMN oasis.case_prod_devices.dev_cd3
     IS 'Obsolete.FDA Device Code (3)';
COMMENT ON COLUMN oasis.case_prod_devices.pat_cd1
     IS 'Obsolete.FDA Patient Code (1)';
COMMENT ON COLUMN oasis.case_prod_devices.pat_cd2
     IS 'Obsolete.FDA Patient Code (2)';
COMMENT ON COLUMN oasis.case_prod_devices.pat_cd3
     IS 'Obsolete.FDA Patient Code (3)';
COMMENT ON COLUMN oasis.case_prod_devices.repro_address_1
     IS 'Reprocessor Address 1';
COMMENT ON COLUMN oasis.case_prod_devices.repro_address_2
     IS 'Reprocessor Address 2';
COMMENT ON COLUMN oasis.case_prod_devices.repro_city
     IS 'Reprocessor city';
COMMENT ON COLUMN oasis.case_prod_devices.repro_state
     IS 'Reprocessor state';
COMMENT ON COLUMN oasis.case_prod_devices.repro_country_id
     IS 'Reprocessor country ID';
COMMENT ON COLUMN oasis.case_prod_devices.repro_postal_code
     IS 'Reprocessor postal code';
COMMENT ON COLUMN oasis.case_prod_devices.repro_fax
     IS 'Reprocessor fax number';
COMMENT ON COLUMN oasis.case_prod_devices.repro_email
     IS 'Reprocessor email address';
COMMENT ON COLUMN oasis.case_prod_devices.age
     IS 'Device Age';
COMMENT ON COLUMN oasis.case_prod_devices.age_unit_id
     IS 'Device Age Unit ID';
COMMENT ON COLUMN oasis.case_prod_devices.mfr_other_reason
     IS 'Other Reason for Non-Evaluation';
COMMENT ON COLUMN oasis.case_prod_devices.ce_marked
     IS 'European Conformity referring to Codelist CE_MARKED';
COMMENT ON COLUMN oasis.case_prod_devices.udi_system
     IS 'Referring to Codelist UDI_SYSTM';

CREATE TABLE oasis.case_prod_drugs(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    formulation_id NUMERIC,
    concentration CHARACTER VARYING(10),
    conc_units_id NUMERIC,
    act_taken_id NUMERIC,
    severity_id NUMERIC,
    interaction NUMERIC,
    contraind NUMERIC,
    first_dose TIMESTAMP(0) WITHOUT TIME ZONE,
    first_dose_res NUMERIC,
    last_dose TIMESTAMP(0) WITHOUT TIME ZONE,
    last_dose_res NUMERIC,
    total_dose NUMERIC(22,7),
    tot_dose_unit_id NUMERIC,
    prev_use NUMERIC,
    abuse NUMERIC,
    overdose NUMERIC,
    protocol NUMERIC,
    dechallenge NUMERIC DEFAULT NULL,
    dechall_date TIMESTAMP(0) WITHOUT TIME ZONE,
    rechallenge NUMERIC DEFAULT NULL,
    rechall_start TIMESTAMP(0) WITHOUT TIME ZONE,
    rechall_stop TIMESTAMP(0) WITHOUT TIME ZONE,
    rechall_outcome NUMERIC,
    sort_id NUMERIC,
    b_weight_grams NUMERIC,
    n_siblings NUMERIC,
    b_weight_ozs NUMERIC,
    first_dose_partial CHARACTER VARYING(20),
    last_dose_partial CHARACTER VARYING(20),
    tampering NUMERIC(4,0),
    cumulative_dose NUMERIC(22,7),
    cumulative_dose_unit CHARACTER VARYING(10),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    cumulative_dose_unit_id NUMERIC,
    obtain_drug_country_id NUMERIC,
    drug_auth_country_id NUMERIC,
    duration_seconds NUMERIC,
    latency_seconds NUMERIC,
    delay_seconds NUMERIC,
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    enterprise_id NUMERIC NOT NULL,
    duration CHARACTER VARYING(40),
    delay CHARACTER VARYING(40),
    latency CHARACTER VARYING(40),
    batch_in_spec NUMERIC(1,0),
    batch_out_spec NUMERIC(1,0),
    counterfeit NUMERIC(1,0),
    beyond_expired NUMERIC(1,0),
    taken_by_father NUMERIC(1,0),
    occupational_exp NUMERIC(1,0),
    off_label_use NUMERIC(1,0),
    medication_error NUMERIC(1,0),
    misuse NUMERIC(1,0),
    fda_spc_id NUMERIC,
    exposure NUMERIC(3,0),
    exposure_unit_id NUMERIC 
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_prod_drugs
     IS 'Drug specific information for product.';
COMMENT ON COLUMN oasis.case_prod_drugs.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.seq_num
     IS 'Value linked to CASE_PRODUCT';
COMMENT ON COLUMN oasis.case_prod_drugs.formulation_id
     IS 'Formulation ID, value from LM_FORMULATION. This column is foreign key to LM_FORMULATION.FORMULATION_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.concentration
     IS 'Concentration of drug';
COMMENT ON COLUMN oasis.case_prod_drugs.conc_units_id
     IS 'Units for concentration, value from LM_DOSE_UNITS. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.act_taken_id
     IS 'Action taken, value from LM_ACTION_TAKEN. This column is foreign key to LM_ACTION_TAKEN.ACT_TAKEN_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.severity_id
     IS 'Unused. This column is foreign key to LM_SEVERITY.SEVERITY_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.interaction
     IS 'Interaction, 0=No  1=Yes  2=Unknown';
COMMENT ON COLUMN oasis.case_prod_drugs.contraind
     IS 'Contraindicated, 0=No  1=Yes';
COMMENT ON COLUMN oasis.case_prod_drugs.first_dose
     IS 'Date (partial) of first dose';
COMMENT ON COLUMN oasis.case_prod_drugs.first_dose_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_prod_drugs.last_dose
     IS 'Date (partial) of last dose';
COMMENT ON COLUMN oasis.case_prod_drugs.last_dose_res
     IS 'Partial date resolution  8-Full  7-Month and Year  5-Year Only';
COMMENT ON COLUMN oasis.case_prod_drugs.total_dose
     IS 'Total dose of drug regimens';
COMMENT ON COLUMN oasis.case_prod_drugs.tot_dose_unit_id
     IS 'Total dose unit, from LM_DOSE_UNITS. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.prev_use
     IS 'Unknown / N/A = -1 No / N/a = 0 Yes / Unknown = 1 Yes / Not Tolerated = 2 Yes / Tolerated = 3 To store null store -2';
COMMENT ON COLUMN oasis.case_prod_drugs.abuse
     IS 'Abuse of drug, 0=No  1=Yes';
COMMENT ON COLUMN oasis.case_prod_drugs.overdose
     IS 'Overdose of drug, 0=No  1=Yes';
COMMENT ON COLUMN oasis.case_prod_drugs.protocol
     IS 'Unused';
COMMENT ON COLUMN oasis.case_prod_drugs.dechallenge
     IS 'Dechallenged, 0=No, 1=Yes, 2 = Unknown, 3 = N/A (Default = Null)';
COMMENT ON COLUMN oasis.case_prod_drugs.dechall_date
     IS 'Dechallenge date';
COMMENT ON COLUMN oasis.case_prod_drugs.rechallenge
     IS 'Rechallenged, 0=No, 1=Yes, 2 = Unknown, 3 = N/A (Default = Null)';
COMMENT ON COLUMN oasis.case_prod_drugs.rechall_start
     IS 'Start date of rechallenge';
COMMENT ON COLUMN oasis.case_prod_drugs.rechall_stop
     IS 'End date of rechallenge';
COMMENT ON COLUMN oasis.case_prod_drugs.rechall_outcome
     IS 'Outcome of rechallenge, 0=AE did not recur  1=AE recurred';
COMMENT ON COLUMN oasis.case_prod_drugs.sort_id
     IS 'Unused';
COMMENT ON COLUMN oasis.case_prod_drugs.b_weight_grams
     IS 'Birth weight in grams for vaccine';
COMMENT ON COLUMN oasis.case_prod_drugs.n_siblings
     IS 'Number of siblings for vaccine';
COMMENT ON COLUMN oasis.case_prod_drugs.b_weight_ozs
     IS 'Birth weight in ounces for vaccine';
COMMENT ON COLUMN oasis.case_prod_drugs.first_dose_partial
     IS 'First dose formatted for printing';
COMMENT ON COLUMN oasis.case_prod_drugs.last_dose_partial
     IS 'Last dose formatted for printing';
COMMENT ON COLUMN oasis.case_prod_drugs.tampering
     IS '0-no 1-yes, Drug had been tampered with';
COMMENT ON COLUMN oasis.case_prod_drugs.cumulative_dose
     IS 'Cumulative dose of drug regimens';
COMMENT ON COLUMN oasis.case_prod_drugs.cumulative_dose_unit
     IS 'This column is obsolete as of Argus 41SP3 (ECR 026)';
COMMENT ON COLUMN oasis.case_prod_drugs.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_1
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_2
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_3
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_4
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_5
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_6
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_7
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_8
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_9
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_10
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_11
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_12
     IS 'User Defined Text Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_1
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_2
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_3
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_4
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_5
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_6
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_7
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_8
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_9
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_10
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_11
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_date_12
     IS 'User Defined Date Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_1
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_2
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_3
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_4
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_5
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_6
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_7
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_8
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_9
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_10
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_11
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_number_12
     IS 'User Defined Number Field';
COMMENT ON COLUMN oasis.case_prod_drugs.cumulative_dose_unit_id
     IS 'Cumulative dose unit to lm_dose_units. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.obtain_drug_country_id
     IS 'Where purchase the drug. This column is foreign key to LM_COUNTRIES.COUNTRY_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.drug_auth_country_id
     IS 'Where the drug licensed. This column is foreign key to LM_COUNTRIES.COUNTRY_ID.';
COMMENT ON COLUMN oasis.case_prod_drugs.duration_seconds
     IS 'Duration in seconds';
COMMENT ON COLUMN oasis.case_prod_drugs.latency_seconds
     IS 'Latency in seconds';
COMMENT ON COLUMN oasis.case_prod_drugs.delay_seconds
     IS 'Delay in seconds';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_1_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_2_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_3_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_4_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_5_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_6_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_7_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_8_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_9_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_10_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_11_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.ud_text_12_j
     IS 'User Defined Text Field (Japanese).';
COMMENT ON COLUMN oasis.case_prod_drugs.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_prod_drugs.duration
     IS 'Duration';
COMMENT ON COLUMN oasis.case_prod_drugs.delay
     IS 'Delay';
COMMENT ON COLUMN oasis.case_prod_drugs.latency
     IS 'Latency';
COMMENT ON COLUMN oasis.case_prod_drugs.batch_in_spec
     IS '0, null - unknown||1 = Batch and lot tested and found within specifications';
COMMENT ON COLUMN oasis.case_prod_drugs.batch_out_spec
     IS '0, null - unknown||1 = Batch and lot tested and found not within specifications';
COMMENT ON COLUMN oasis.case_prod_drugs.counterfeit
     IS '0, null - unknown||1 = Counterfeit';
COMMENT ON COLUMN oasis.case_prod_drugs.beyond_expired
     IS '0, null - unknown||1 = Drug taken beyond expiry date';
COMMENT ON COLUMN oasis.case_prod_drugs.taken_by_father
     IS '0, null - unknown||1 = Drug taken by the father';
COMMENT ON COLUMN oasis.case_prod_drugs.occupational_exp
     IS '0, null - unknown||1 = Occupational exposure';
COMMENT ON COLUMN oasis.case_prod_drugs.off_label_use
     IS '0, null - unknown||1 = Off label use';
COMMENT ON COLUMN oasis.case_prod_drugs.medication_error
     IS '0, null - unknown||1 = Medication error';
COMMENT ON COLUMN oasis.case_prod_drugs.misuse
     IS '0, null - unknown||1 = Misuse';
COMMENT ON COLUMN oasis.case_prod_drugs.fda_spc_id
     IS 'Food and Drug Administration Specialized Product Category from code list (SPECIALIZED_PROD_CATEGORY)';
COMMENT ON COLUMN oasis.case_prod_drugs.exposure
     IS 'Gestation period at exposure';
COMMENT ON COLUMN oasis.case_prod_drugs.exposure_unit_id
     IS 'Gestation period at exposure unit ID from code list';

CREATE TABLE oasis.case_prod_indications(
    case_id NUMERIC NOT NULL,
    prod_seq_num NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    sort_id NUMERIC,
    ind_reptd CHARACTER VARYING(255),
    ind_coded CHARACTER VARYING(255),
    ind_code CHARACTER VARYING(50),
    ind_pref_term CHARACTER VARYING(250),
    ind_llt_code CHARACTER VARYING(50),
    ind_llt CHARACTER VARYING(250),
    ind_hlt_code CHARACTER VARYING(50),
    ind_hlt CHARACTER VARYING(250),
    ind_hlgt_code CHARACTER VARYING(50),
    ind_hlgt CHARACTER VARYING(250),
    ind_soc_code CHARACTER VARYING(50),
    ind_soc CHARACTER VARYING(250),
    ind_syn_code NUMERIC,
    ind_code_dict NUMERIC,
    ind_code_status NUMERIC(3,0),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    ind_coded_j CHARACTER VARYING(255),
    ind_code_status_j NUMERIC,
    ind_hlgt_j CHARACTER VARYING(250),
    ind_hlt_j CHARACTER VARYING(250),
    ind_llt_code_j CHARACTER VARYING(50),
    ind_llt_j CHARACTER VARYING(250),
    ind_pref_term_j CHARACTER VARYING(250),
    ind_reptd_j CHARACTER VARYING(255),
    ind_soc_j CHARACTER VARYING(250),
    ind_syn_code_j NUMERIC,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_prod_indications
     IS 'Stores Multiple Indications for the Case Product';
COMMENT ON COLUMN oasis.case_prod_indications.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_PRODUCT.CASE_ID. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_prod_indications.prod_seq_num
     IS 'Value linked to CASE_PRODUCT. This column is foreign key to CASE_PRODUCT.SEQ_NUM.';
COMMENT ON COLUMN oasis.case_prod_indications.seq_num
     IS 'Value from sequence S_CASE_PROD_INDICATIONS';
COMMENT ON COLUMN oasis.case_prod_indications.sort_id
     IS 'Display order, starting with 1 with in a case';
COMMENT ON COLUMN oasis.case_prod_indications.ind_reptd
     IS 'Primary indication as reported';
COMMENT ON COLUMN oasis.case_prod_indications.ind_coded
     IS 'Primary Indication as Coded';
COMMENT ON COLUMN oasis.case_prod_indications.ind_code
     IS 'Primary Indication Code';
COMMENT ON COLUMN oasis.case_prod_indications.ind_pref_term
     IS 'Primary indication description';
COMMENT ON COLUMN oasis.case_prod_indications.ind_llt_code
     IS 'Lower Level Term Code for Indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_llt
     IS 'Lower Level Term for Indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_hlt_code
     IS 'High Level Term Code for indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_hlt
     IS 'High Level Term for indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_hlgt_code
     IS 'High Level Group Term Code for indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_hlgt
     IS 'High Level  Group Term for indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_soc_code
     IS 'System Organ Class Code for indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_soc
     IS 'System Organ Class for indication';
COMMENT ON COLUMN oasis.case_prod_indications.ind_syn_code
     IS 'Synonym Id';
COMMENT ON COLUMN oasis.case_prod_indications.ind_code_dict
     IS 'Indication code dictionary';
COMMENT ON COLUMN oasis.case_prod_indications.ind_code_status
     IS 'What is the encoding status for this record 0 - Not Coded, 1 - Coded, 2 - Coded Manually, 3 - Coding Pending, 4 - Coding Error';
COMMENT ON COLUMN oasis.case_prod_indications.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_prod_indications.ind_coded_j
     IS 'Primary Indication as Coded (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_code_status_j
     IS 'What is the encoding status for this record 0 - Not Coded, 1 - Coded, 2 - Coded Manually, 3 - Coding Pending, 4 - Coding Error (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_hlgt_j
     IS 'High Level  Group Term for indication (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_hlt_j
     IS 'High Level Term for indication (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_llt_code_j
     IS 'Lower Level Term Code for Indication (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_llt_j
     IS 'Lower Level Term for Indication (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_pref_term_j
     IS 'Primary indication description (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_reptd_j
     IS 'Primary indication as reported (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_soc_j
     IS 'System Organ Class for indication (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.ind_syn_code_j
     IS 'Synonym Id (Japanese).';
COMMENT ON COLUMN oasis.case_prod_indications.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_prod_qc_cid(
    case_id NUMERIC NOT NULL,
    prod_seq_num NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    sort_id NUMERIC,
    cid_number CHARACTER VARYING(20),
    pcid_number CHARACTER VARYING(20),
    lot_number CHARACTER VARYING(35),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_prod_qc_cid
     IS 'Ingredient specific information for product.';
COMMENT ON COLUMN oasis.case_prod_qc_cid.case_id
     IS 'Case ID, PK (1). This column is foreign key to CASE_PRODUCT.CASE_ID.';
COMMENT ON COLUMN oasis.case_prod_qc_cid.prod_seq_num
     IS 'Product Seq Num, PK (2). This column is foreign key to CASE_PRODUCT.SEQ_NUM.';
COMMENT ON COLUMN oasis.case_prod_qc_cid.seq_num
     IS 'Seq Num, PK(3)';
COMMENT ON COLUMN oasis.case_prod_qc_cid.sort_id
     IS 'Sort ID';
COMMENT ON COLUMN oasis.case_prod_qc_cid.cid_number
     IS 'Complaint Identification Number';
COMMENT ON COLUMN oasis.case_prod_qc_cid.pcid_number
     IS 'PCID';
COMMENT ON COLUMN oasis.case_prod_qc_cid.lot_number
     IS 'Lot Number';
COMMENT ON COLUMN oasis.case_prod_qc_cid.deleted
     IS 'Deleted column';
COMMENT ON COLUMN oasis.case_prod_qc_cid.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.case_product(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    product_id NUMERIC,
    drug_type NUMERIC,
    pat_exposure NUMERIC DEFAULT 0,
    manufacturer_id NUMERIC,
    protocol_followed NUMERIC,
    first_sus_prod NUMERIC,
    selected_view NUMERIC,
    sort_id NUMERIC,
    views_available NUMERIC,
    country_id NUMERIC,
    qc_safety_date TIMESTAMP(0) WITHOUT TIME ZONE,
    qc_sent_date TIMESTAMP(0) WITHOUT TIME ZONE,
    qc_result_date TIMESTAMP(0) WITHOUT TIME ZONE,
    qc_cross_reference CHARACTER VARYING(16),
    who_drug_code CHARACTER VARYING(45),
    co_drug_code CHARACTER VARYING(20),
    product_name CHARACTER VARYING(250),
    generic_name TEXT DEFAULT NULL,
    qc_result TEXT DEFAULT NULL,
    qc_comment TEXT DEFAULT NULL,
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    include_frequency NUMERIC,
    sdrug_not_admin NUMERIC,
    prod_reptd CHARACTER VARYING(255),
    prod_coded CHARACTER VARYING(255),
    prod_syn_id NUMERIC,
    prod_code_status NUMERIC(3,0),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    study_product_num NUMERIC(2,0) DEFAULT 0,
    qc_quantity CHARACTER VARYING(10),
    qc_return_date TIMESTAMP(0) WITHOUT TIME ZONE,
    qc_complaint_cat_date TIMESTAMP(0) WITHOUT TIME ZONE,
    qc_complaint_cat_text TEXT DEFAULT NULL,
    qc_analysis_cat_date TIMESTAMP(0) WITHOUT TIME ZONE,
    qc_analysis_cat_text TEXT DEFAULT NULL,
    qc_analysis_summary_date TIMESTAMP(0) WITHOUT TIME ZONE,
    qc_anal_summary_text TEXT DEFAULT NULL,
    qc_anal_summary_text_j TEXT DEFAULT NULL,
    primary_event NUMERIC,
    medicinal_prod_id CHARACTER VARYING(10),
    family_id NUMERIC,
    existing_rpt_seq_mod_flg NUMERIC DEFAULT - 1,
    drug_code_j CHARACTER VARYING(70),
    drug_code_type_j NUMERIC,
    generic_name_j TEXT DEFAULT NULL,
    notes_j TEXT DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    product_name_j CHARACTER VARYING(250),
    prod_coded_j CHARACTER VARYING(255),
    prod_reptd_j CHARACTER VARYING(255),
    qc_analysis_cat_text_j TEXT DEFAULT NULL,
    qc_comment_j TEXT DEFAULT NULL,
    qc_complaint_cat_text_j TEXT DEFAULT NULL,
    qc_cross_reference_j CHARACTER VARYING(16),
    qc_result_j TEXT DEFAULT NULL,
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE,
    vaers_block_id NUMERIC,
    prod_lic_id NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    acquiring_otc NUMERIC,
    identifier_type_id NUMERIC,
    identifier CHARACTER VARYING(1000),
    identifier_version CHARACTER VARYING(10),
    not_coded NUMERIC(1,0),
    compdd_prod NUMERIC,
    otc_prod NUMERIC,
    auth_type CHARACTER VARYING(5),
    auth_number CHARACTER VARYING(40),
    mkt_auth_holder CHARACTER VARYING(22)
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_product
     IS 'Agent/Product information.';
COMMENT ON COLUMN oasis.case_product.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_NOTES.CASE_ID. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_product.seq_num
     IS 'Incremental number unique to products within this case';
COMMENT ON COLUMN oasis.case_product.product_id
     IS 'Product id if agent, value from LM_PRODUCT. This column is foreign key to LM_PRODUCT.PRODUCT_ID.';
COMMENT ON COLUMN oasis.case_product.drug_type
     IS 'Drug type, 1=Suspect  2=Concomitant  3=Treatment';
COMMENT ON COLUMN oasis.case_product.pat_exposure
     IS 'Study drug id, value from LM_PRODUCT';
COMMENT ON COLUMN oasis.case_product.manufacturer_id
     IS 'Manufacturer ID, value from LM_MANUFACTURER. This column is foreign key to LM_MANUFACTURER.MANUFACTURER_ID.';
COMMENT ON COLUMN oasis.case_product.protocol_followed
     IS 'Was protocol of study followed, 0=No  1=Yes';
COMMENT ON COLUMN oasis.case_product.first_sus_prod
     IS 'Is this the first suspect product, 0=No  1=Yes';
COMMENT ON COLUMN oasis.case_product.selected_view
     IS 'Selected product view, 1=Drug  2=Device  3=Vaccine';
COMMENT ON COLUMN oasis.case_product.sort_id
     IS 'Order in which to display product in case form';
COMMENT ON COLUMN oasis.case_product.views_available
     IS 'Views available for this product, bit mask 1=Drug  2=Device  4=Vaccine';
COMMENT ON COLUMN oasis.case_product.country_id
     IS 'Country_id links to lm_countries. This column is foreign key to LM_COUNTRIES.COUNTRY_ID.';
COMMENT ON COLUMN oasis.case_product.qc_safety_date
     IS 'Quality control date received';
COMMENT ON COLUMN oasis.case_product.qc_sent_date
     IS 'Quality control date sent for testing';
COMMENT ON COLUMN oasis.case_product.qc_result_date
     IS 'Quality control date results received from testing';
COMMENT ON COLUMN oasis.case_product.qc_cross_reference
     IS 'Quality control cross reference identifier';
COMMENT ON COLUMN oasis.case_product.who_drug_code
     IS 'Who drug code';
COMMENT ON COLUMN oasis.case_product.co_drug_code
     IS 'Company drug code';
COMMENT ON COLUMN oasis.case_product.product_name
     IS 'Product name';
COMMENT ON COLUMN oasis.case_product.generic_name
     IS 'Generic name of product';
COMMENT ON COLUMN oasis.case_product.qc_result
     IS 'Quality control testing results';
COMMENT ON COLUMN oasis.case_product.qc_comment
     IS 'Quality control comment';
COMMENT ON COLUMN oasis.case_product.ud_text_1
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_2
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_3
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_4
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_5
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_6
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_7
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_8
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_9
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_10
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_11
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_text_12
     IS 'User defined text field';
COMMENT ON COLUMN oasis.case_product.ud_date_1
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_2
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_3
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_4
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_5
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_6
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_7
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_8
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_9
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_10
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_11
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_date_12
     IS 'User defined date field';
COMMENT ON COLUMN oasis.case_product.ud_number_1
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_2
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_3
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_4
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_5
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_6
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_7
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_8
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_9
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_10
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_11
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.ud_number_12
     IS 'User defined number field';
COMMENT ON COLUMN oasis.case_product.include_frequency
     IS 'Include Frequency 0 - No 1 - Yes';
COMMENT ON COLUMN oasis.case_product.sdrug_not_admin
     IS 'Checkbox with Value of 0,1, -1';
COMMENT ON COLUMN oasis.case_product.prod_reptd
     IS 'Description Reported by the user (Same value as Case_Product.Product_Name)';
COMMENT ON COLUMN oasis.case_product.prod_coded
     IS 'Description Coded. (Same value as Case_Product.Product_Name) Dictionary Interface system will update this with appropriate Synonym Name';
COMMENT ON COLUMN oasis.case_product.prod_syn_id
     IS 'Store Null here (Only for Backend Dictionary Interface Routines)';
COMMENT ON COLUMN oasis.case_product.prod_code_status
     IS 'What is the encoding status for this record 0 - Not Coded, 1 - Coded, 2 - Coded Manually, 3 - Coding Pending, 4 - Coding Error, Applies only to Non-Company Drugs ';
COMMENT ON COLUMN oasis.case_product.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_product.study_product_num
     IS 'Study Product Number, default 0';
COMMENT ON COLUMN oasis.case_product.qc_quantity
     IS 'QC Quantity';
COMMENT ON COLUMN oasis.case_product.qc_return_date
     IS 'QC Return Date';
COMMENT ON COLUMN oasis.case_product.qc_complaint_cat_date
     IS 'Complaint Categories Date';
COMMENT ON COLUMN oasis.case_product.qc_complaint_cat_text
     IS 'Complaint Categories Text';
COMMENT ON COLUMN oasis.case_product.qc_analysis_cat_date
     IS 'Analysis Categories date';
COMMENT ON COLUMN oasis.case_product.qc_analysis_cat_text
     IS 'Analysis Categories Text';
COMMENT ON COLUMN oasis.case_product.qc_analysis_summary_date
     IS 'Analysis summary date';
COMMENT ON COLUMN oasis.case_product.qc_anal_summary_text
     IS 'Analysis Summary text';
COMMENT ON COLUMN oasis.case_product.qc_anal_summary_text_j
     IS 'Analysis Summary text (Japanese).';
COMMENT ON COLUMN oasis.case_product.primary_event
     IS 'SEQ_NUM of primary event for product';
COMMENT ON COLUMN oasis.case_product.medicinal_prod_id
     IS 'Medicinal Product ID from WHO Drug Format C';
COMMENT ON COLUMN oasis.case_product.family_id
     IS 'Family id for case company product';
COMMENT ON COLUMN oasis.case_product.existing_rpt_seq_mod_flg
     IS 'Default value -1. If product is deleted and cmn_reg_reports.seq_num is changed then it is set to 1';
COMMENT ON COLUMN oasis.case_product.drug_code_j
     IS 'Stores the J Drug Code of the product.';
COMMENT ON COLUMN oasis.case_product.drug_code_type_j
     IS 'Stores the Drug Code type of the product i.e. J Drug Code, OTC Drug Code or Temporary Code';
COMMENT ON COLUMN oasis.case_product.generic_name_j
     IS 'Generic name of product (Japanese).';
COMMENT ON COLUMN oasis.case_product.notes_j
     IS 'Text of note, typical size limit of 5,000 characters (Japanese).';
COMMENT ON COLUMN oasis.case_product.notes
     IS 'Text of note, typical size limit of 5,000 characters';
COMMENT ON COLUMN oasis.case_product.product_name_j
     IS 'Product name (Japanese).';
COMMENT ON COLUMN oasis.case_product.prod_coded_j
     IS 'Description Coded. (Same value as Case_Product.Product_Name) Dictionary Interface system will update this with appropriate Synonym Name (Japanese).';
COMMENT ON COLUMN oasis.case_product.prod_reptd_j
     IS 'Description Reported by the user (Same value as Case_Product.Product_Name) (Japanese).';
COMMENT ON COLUMN oasis.case_product.qc_analysis_cat_text_j
     IS 'Analysis Categories Text (Japanese).';
COMMENT ON COLUMN oasis.case_product.qc_comment_j
     IS 'Quality control comment (Japanese).';
COMMENT ON COLUMN oasis.case_product.qc_complaint_cat_text_j
     IS 'Complaint Categories Text (Japanese).';
COMMENT ON COLUMN oasis.case_product.qc_cross_reference_j
     IS 'Quality control cross reference identifier (Japanese).';
COMMENT ON COLUMN oasis.case_product.qc_result_j
     IS 'Quality control testing results (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_1_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_2_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_3_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_4_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_5_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_6_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_7_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_8_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_9_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_10_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_11_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.ud_text_12_j
     IS 'User defined text field (Japanese).';
COMMENT ON COLUMN oasis.case_product.last_update_time
     IS 'Indicates the last update time stored in GMT';
COMMENT ON COLUMN oasis.case_product.vaers_block_id
     IS 'This columns stores VAERS BLOCK_ID where the vaccine record is to be printed in Report.';
COMMENT ON COLUMN oasis.case_product.prod_lic_id
     IS 'License ID chosen during product selection';
COMMENT ON COLUMN oasis.case_product.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.case_product.acquiring_otc
     IS 'Route of acquiring OTC drugs from code list ROUTE_ACQUIRE_OTC';
COMMENT ON COLUMN oasis.case_product.identifier_type_id
     IS 'Product Identifier Type.  CodeList: PRODUCT_IDENTFIER_TYPE';
COMMENT ON COLUMN oasis.case_product.identifier
     IS 'Product Identifier';
COMMENT ON COLUMN oasis.case_product.identifier_version
     IS 'Product Identifier Version';
COMMENT ON COLUMN oasis.case_product.not_coded
     IS '1 = product not coded using Company or WHO Dictionary';
COMMENT ON COLUMN oasis.case_product.compdd_prod
     IS 'Is the  product administered is compounded   0=No  1=Yes';
COMMENT ON COLUMN oasis.case_product.otc_prod
     IS '	Is the  product administered is over the Counter(OTC) product   0=No  1=Yes';
COMMENT ON COLUMN oasis.case_product.auth_type
     IS 'Authorization Type of the product that was administered. Authorization Type can be IND,BLA,PLA etc';
COMMENT ON COLUMN oasis.case_product.auth_number
     IS 'Authorization Number or License number of the product that was administered';
COMMENT ON COLUMN oasis.case_product.mkt_auth_holder
     IS 'Name of the Marketing Authorization Holder of the product that was administered';

CREATE TABLE oasis.case_study(
    case_id NUMERIC NOT NULL,
    study_key NUMERIC,
    cohort_id NUMERIC,
    study_num CHARACTER VARYING(50),
    study_type NUMERIC,
    center_id NUMERIC,
    center_name CHARACTER VARYING(40),
    protocol_id NUMERIC,
    protocol_num CHARACTER VARYING(40),
    other_id CHARACTER VARYING(20),
    code_broken NUMERIC,
    broken_by NUMERIC,
    broken_date TIMESTAMP(0) WITHOUT TIME ZONE,
    reason CHARACTER VARYING(100),
    week CHARACTER VARYING(5),
    visit CHARACTER VARYING(5),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    product_count NUMERIC(2,0) NOT NULL DEFAULT 1,
    classification_id NUMERIC,
    blind_name CHARACTER VARYING(250),
    study_desc TEXT DEFAULT NULL,
    blind_name_j CHARACTER VARYING(250),
    center_name_j CHARACTER VARYING(40),
    clin_compound_num_j CHARACTER VARYING(70),
    protocol_num_j CHARACTER VARYING(40),
    study_desc_j TEXT DEFAULT NULL,
    study_num_j CHARACTER VARYING(50),
    dev_phase_id NUMERIC,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.case_study
     IS 'Case study/trial information.';
COMMENT ON COLUMN oasis.case_study.case_id
     IS 'Value linked to CASE_MASTER. This column is foreign key to CASE_MASTER.CASE_ID.';
COMMENT ON COLUMN oasis.case_study.study_key
     IS 'Study key ID if non-zero, value from LM_STUDIES. This column is foreign key to LM_STUDIES.STUDY_KEY.';
COMMENT ON COLUMN oasis.case_study.cohort_id
     IS 'Cohort ID if non-zero, value from LM_STUDY_COHORTS. This column is foreign key to LM_STUDY_COHORTS. COHORT_ID';
COMMENT ON COLUMN oasis.case_study.study_num
     IS 'Name of study';
COMMENT ON COLUMN oasis.case_study.study_type
     IS 'Type of study, value from LM_STUDY_TYPES';
COMMENT ON COLUMN oasis.case_study.center_id
     IS 'Center ID if non-zero, value from LM_CENTERS. This column is foreign key to LM_CENTERS.CENTER_ID.';
COMMENT ON COLUMN oasis.case_study.center_name
     IS 'Name of center';
COMMENT ON COLUMN oasis.case_study.protocol_id
     IS 'Protocol ID if non-zero, value from LM_PROTOCOLS. This column is foreign key to LM_PROTOCOLS.PROTOCOL_ID.';
COMMENT ON COLUMN oasis.case_study.protocol_num
     IS 'PROTOCOL NUMBER';
COMMENT ON COLUMN oasis.case_study.other_id
     IS 'Other ID';
COMMENT ON COLUMN oasis.case_study.code_broken
     IS '0 = Blinded, 1 = Broken by Investigator, 2 = Broken by Sponsor, 3 = Broken after Study, 4 = Not Blinded';
COMMENT ON COLUMN oasis.case_study.broken_by
     IS ' This column is foreign key to CFG_USERS.USER_ID.';
COMMENT ON COLUMN oasis.case_study.broken_date
     IS 'Date the study code was broken.';
COMMENT ON COLUMN oasis.case_study.reason
     IS 'Reason the study code was broken.';
COMMENT ON COLUMN oasis.case_study.week
     IS 'Week number of the study during which the adverse event occurred.';
COMMENT ON COLUMN oasis.case_study.visit
     IS 'Visit number during or after which the adverse event occurred.';
COMMENT ON COLUMN oasis.case_study.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.case_study.product_count
     IS 'Number of study products contained within the case, default 1';
COMMENT ON COLUMN oasis.case_study.classification_id
     IS 'This Column Represent the Observe Study Type for E2b Report. CLASSIFICATION_ID. This column is foreign key to LM_CASE_CLASSIFICATION.CLASSIFICATION_ID.';
COMMENT ON COLUMN oasis.case_study.blind_name
     IS 'BLIND NAME';
COMMENT ON COLUMN oasis.case_study.study_desc
     IS 'Study Description entered for the Study';
COMMENT ON COLUMN oasis.case_study.blind_name_j
     IS 'BLIND NAME (Japanese).';
COMMENT ON COLUMN oasis.case_study.center_name_j
     IS 'Name of center (Japanese).';
COMMENT ON COLUMN oasis.case_study.clin_compound_num_j
     IS 'Stores the Clinical Compound Number of the Study.';
COMMENT ON COLUMN oasis.case_study.protocol_num_j
     IS 'PROTOCOL NUMBER (Japanese).';
COMMENT ON COLUMN oasis.case_study.study_desc_j
     IS 'Study Description entered for the Study (Japanese).';
COMMENT ON COLUMN oasis.case_study.study_num_j
     IS 'Name of study (Japanese).';
COMMENT ON COLUMN oasis.case_study.dev_phase_id
     IS 'Stores the study phase from the code list table LM_DEV_PHASE';
COMMENT ON COLUMN oasis.case_study.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';

CREATE TABLE oasis.cfg_medwatch_codes(
    dialog NUMERIC NOT NULL,
    value CHARACTER VARYING(4) NOT NULL,
    description CHARACTER VARYING(400) NOT NULL,
    definition CHARACTER VARYING(500),
    sortby NUMERIC NOT NULL DEFAULT 0,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.cfg_medwatch_codes
     IS 'User Group configuration COLUMN.';
COMMENT ON COLUMN oasis.cfg_medwatch_codes.dialog
     IS 'Dialog ID.1,2 - FDA Codes, 3,4,5: Evaluation codes';
COMMENT ON COLUMN oasis.cfg_medwatch_codes.value
     IS 'Value';
COMMENT ON COLUMN oasis.cfg_medwatch_codes.description
     IS 'Description for the codes';
COMMENT ON COLUMN oasis.cfg_medwatch_codes.definition
     IS 'Code definition. Used for FDA codes';
COMMENT ON COLUMN oasis.cfg_medwatch_codes.sortby
     IS 'Sort order to display';
COMMENT ON COLUMN oasis.cfg_medwatch_codes.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.code_list_detail_discrete(
    code_list_id CHARACTER VARYING(100) NOT NULL,
    decode_context CHARACTER VARYING(20) NOT NULL,
    code CHARACTER VARYING(100) NOT NULL,
    display_value CHARACTER VARYING(1000),
    preferred NUMERIC(1,0) DEFAULT 0,
    sort NUMERIC,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.code_list_detail_discrete
     IS 'This table consist of code  decode values for code list defined in master table';
COMMENT ON COLUMN oasis.code_list_detail_discrete.code_list_id
     IS 'This value is reference to CODE_LIST_CODE_ATTRIBUTES.CODE_LIST_ID, Name of the code list';
COMMENT ON COLUMN oasis.code_list_detail_discrete.decode_context
     IS 'Decode_context for which display values are applicable for example  
1.	en: English 
2.	ja: Japanese 
3.	E2B: E2B 
4.	RPT: Display value for Reports 
5.  EN_ABBRV 
6.  SM 
7.	ISOA2: A2 country code for the country code list items 
8.	ISOA3: A3 country code for the country code list items. 
';
COMMENT ON COLUMN oasis.code_list_detail_discrete.code
     IS 'The code list is primary key value for which display value shall be defined';
COMMENT ON COLUMN oasis.code_list_detail_discrete.display_value
     IS 'The re-categorized display value for the code based on a code list, code, and language combination';
COMMENT ON COLUMN oasis.code_list_detail_discrete.preferred
     IS 'A flag that set for a display value row that shall get preference when there are duplicate entries for code list, language and display value combination, populated 0 for factory data';
COMMENT ON COLUMN oasis.code_list_detail_discrete.sort
     IS 'Maintains the sequence in which display values shall appear in the user interface for a code list-language pair';
COMMENT ON COLUMN oasis.code_list_detail_discrete.last_update_time
     IS 'GMT converted SYSDATE on record modification/creation';
COMMENT ON COLUMN oasis.code_list_detail_discrete.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.code_list_detail_discrete.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';

CREATE TABLE oasis.lm_action_taken(
    act_taken_id NUMERIC NOT NULL,
    action_taken CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    e2b_code NUMERIC,
    action_taken_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_action_taken
     IS 'Maintains the list of action taken items on the products in the cases.';
COMMENT ON COLUMN oasis.lm_action_taken.act_taken_id
     IS 'ID number of the action taken. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_action_taken.action_taken
     IS 'Display text for the action taken.';
COMMENT ON COLUMN oasis.lm_action_taken.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_action_taken.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_action_taken.e2b_code
     IS 'E2B Code for the action taken.';
COMMENT ON COLUMN oasis.lm_action_taken.action_taken_j
     IS 'Display text for the action taken. (Japanese).';
COMMENT ON COLUMN oasis.lm_action_taken.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_action_taken.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_action_taken.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_admin_route(
    admin_route_id NUMERIC NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    short_name CHARACTER VARYING(5),
    e2b_code CHARACTER VARYING(6),
    route CHARACTER VARYING(20) NOT NULL,
    route_desc CHARACTER VARYING(60),
    route_desc_j CHARACTER VARYING(60),
    route_j CHARACTER VARYING(20),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_admin_route
     IS 'Maintains the list of routes of administrations for the products given in the cases.';
COMMENT ON COLUMN oasis.lm_admin_route.admin_route_id
     IS 'ID number of the administration route. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_admin_route.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_admin_route.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_admin_route.short_name
     IS 'Short code associated to the route of administration.';
COMMENT ON COLUMN oasis.lm_admin_route.e2b_code
     IS 'E2B code for route of administration.';
COMMENT ON COLUMN oasis.lm_admin_route.route
     IS 'Display text for route of administration.';
COMMENT ON COLUMN oasis.lm_admin_route.route_desc
     IS 'Description for route of administration.';
COMMENT ON COLUMN oasis.lm_admin_route.route_desc_j
     IS 'Description for route of administration. (Japanese).';
COMMENT ON COLUMN oasis.lm_admin_route.route_j
     IS 'Display text for route of administration. (Japanese).';
COMMENT ON COLUMN oasis.lm_admin_route.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_admin_route.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_admin_route.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_age_groups(
    age_group_id NUMERIC NOT NULL,
    group_name CHARACTER VARYING(20) NOT NULL,
    group_low NUMERIC(22,7),
    group_high NUMERIC(22,7),
    protected NUMERIC,
    display NUMERIC,
    e2b_code NUMERIC,
    group_name_j CHARACTER VARYING(20),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_age_groups
     IS 'Maintains the list of patient / parent age groups.';
COMMENT ON COLUMN oasis.lm_age_groups.age_group_id
     IS 'ID number for the age group. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_age_groups.group_name
     IS 'Display text for the age group.';
COMMENT ON COLUMN oasis.lm_age_groups.group_low
     IS 'Inclusive lower limit of the range in years for the age group.';
COMMENT ON COLUMN oasis.lm_age_groups.group_high
     IS 'Inclusive higher limit of the range in years for the age group.';
COMMENT ON COLUMN oasis.lm_age_groups.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_age_groups.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_age_groups.e2b_code
     IS 'E2B code for the age group.';
COMMENT ON COLUMN oasis.lm_age_groups.group_name_j
     IS 'Display text for the age group. (Japanese).';
COMMENT ON COLUMN oasis.lm_age_groups.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_age_groups.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_age_groups.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_age_units(
    age_unit_id NUMERIC NOT NULL,
    age_unit CHARACTER VARYING(12) NOT NULL,
    relation NUMERIC,
    protected NUMERIC,
    display NUMERIC,
    e2b_code NUMERIC,
    age_unit_j CHARACTER VARYING(10),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    age_unit_flag NUMERIC(1,0),
    gestation_period NUMERIC(1,0),
    device_age_unit NUMERIC(1,0),
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_age_units
     IS 'Maintains the list of patient / parent age units.';
COMMENT ON COLUMN oasis.lm_age_units.age_unit_id
     IS 'ID number for the age unit. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_age_units.age_unit
     IS 'Display text for the age unit.';
COMMENT ON COLUMN oasis.lm_age_units.relation
     IS 'Multiplication factor for the age unit to convert it into years.';
COMMENT ON COLUMN oasis.lm_age_units.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_age_units.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_age_units.e2b_code
     IS 'E2B code for the age unit.';
COMMENT ON COLUMN oasis.lm_age_units.age_unit_j
     IS 'Display text for the age unit. (Japanese).';
COMMENT ON COLUMN oasis.lm_age_units.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_age_units.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_age_units.age_unit_flag
     IS '0	= Non Age Unit record||1 = Age Unit Field';
COMMENT ON COLUMN oasis.lm_age_units.gestation_period
     IS '0	= Non Gestation Period Unit Field||1	 = Gestation Period Unit Field';
COMMENT ON COLUMN oasis.lm_age_units.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_always_serious_term(
    ast_id NUMERIC(22,0) NOT NULL,
    ast_pt_code CHARACTER VARYING(50),
    ast_pt_term CHARACTER VARYING(250),
    ast_llt_code CHARACTER VARYING(50),
    ast_llt CHARACTER VARYING(250),
    ast_hlt_code CHARACTER VARYING(50),
    ast_hlt CHARACTER VARYING(250),
    ast_hlgt_code CHARACTER VARYING(50),
    ast_hlgt CHARACTER VARYING(250),
    ast_soc_code CHARACTER VARYING(50),
    ast_soc CHARACTER VARYING(250),
    code_status NUMERIC,
    code_dict NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    ast_coded CHARACTER VARYING(250),
    ast_reptd CHARACTER VARYING(250),
    ast_reptd_j CHARACTER VARYING(250),
    ast_coded_j CHARACTER VARYING(250),
    ast_pt_term_j CHARACTER VARYING(250),
    ast_llt_code_j CHARACTER VARYING(50),
    ast_llt_j CHARACTER VARYING(250),
    ast_hlt_j CHARACTER VARYING(250),
    ast_hlgt_j CHARACTER VARYING(250),
    ast_soc_j CHARACTER VARYING(250),
    code_status_j NUMERIC,
    syn_code NUMERIC,
    syn_code_j NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    ac_id NUMERIC,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_always_serious_term
     IS 'This table will store the list of Always Serious Terms which will be used to automatically mark the matching events / cases as serious';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_id
     IS 'This column stores the primary key to the table';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_pt_code
     IS 'This stores the PT Code of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_pt_term
     IS 'This stores the PT Term of the Always Serious Term Entered by the user.';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_llt_code
     IS 'This stores the LLT Code of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_llt
     IS 'This stores the LLT Term of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_hlt_code
     IS 'This stores the HLT CODE of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_hlt
     IS 'This stores the HLT Term of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_hlgt_code
     IS 'This stores the HLGT CODE of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_hlgt
     IS 'This stores the HLGT Term of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_soc_code
     IS 'This stores the SOC CODE of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_soc
     IS 'This stores the SOC Term of the Always Serious Term Entered by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.code_status
     IS 'This stores the coding status of the terms entered by the user 0-NOT CODED 1-CODED 2-CODED MANUALLY 3-CODING PENDING 4-CODING ERROR';
COMMENT ON COLUMN oasis.lm_always_serious_term.code_dict
     IS 'This stores the DICT_ID from table CFG_DICTIONARIES_ENTERPRISE';
COMMENT ON COLUMN oasis.lm_always_serious_term.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_coded
     IS 'It stores the term that is coded by the MedDRA';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_reptd
     IS 'It stores the term reported by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_reptd_j
     IS 'It stores the Japanese term reported by the user';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_coded_j
     IS 'It stores the Japanese term that is coded by the MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_pt_term_j
     IS 'This stores the PT Term of the Always Serious Term Entered by the user as per MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_llt_code_j
     IS 'This stores the LLT Code of the Always Serious Term Entered by the user as per MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_llt_j
     IS 'This stores the LLT Term of the Always Serious Term Entered by the user as per MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_hlt_j
     IS 'This stores the HLT Term of the Always Serious Term Entered by the user as per MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_hlgt_j
     IS 'This stores the HLGT Term of the Always Serious Term Entered by the user as per MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.ast_soc_j
     IS 'This stores the SOC Term of the Always Serious Term Entered by the user as per MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.code_status_j
     IS 'This stores the coding status of the terms as per MedDRA J  0-NOT CODED ,1-CODED ,2-CODED MANUALLY ,3-CODING PENDING ,4-CODING ERROR';
COMMENT ON COLUMN oasis.lm_always_serious_term.syn_code
     IS 'Synonym Code';
COMMENT ON COLUMN oasis.lm_always_serious_term.syn_code_j
     IS 'Synonym Code as per MedDRA J';
COMMENT ON COLUMN oasis.lm_always_serious_term.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_always_serious_term.ac_id
     IS 'Stores the ID of the Advance Condition used for Conditional implementation of Always Serious Term in the caseform.';
COMMENT ON COLUMN oasis.lm_always_serious_term.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_birth_type(
    birth_type_id NUMERIC NOT NULL,
    birth_type CHARACTER VARYING(35) NOT NULL,
    display NUMERIC,
    protected NUMERIC,
    birth_type_j CHARACTER VARYING(35),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_birth_type
     IS 'Maintains the list of child birth types.';
COMMENT ON COLUMN oasis.lm_birth_type.birth_type_id
     IS 'ID number for the birth type. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_birth_type.birth_type
     IS 'Display text for the birth type.';
COMMENT ON COLUMN oasis.lm_birth_type.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_birth_type.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_birth_type.birth_type_j
     IS 'Display text for the birth type. (Japanese).';
COMMENT ON COLUMN oasis.lm_birth_type.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_birth_type.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_birth_type.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_case_classification(
    classification_id NUMERIC NOT NULL,
    description CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    e2b_code NUMERIC,
    description_j CHARACTER VARYING(30),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_case_classification
     IS 'Maintains the list of case classification types.';
COMMENT ON COLUMN oasis.lm_case_classification.classification_id
     IS 'ID number for the case classification. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_case_classification.description
     IS 'Display text for the case classification.';
COMMENT ON COLUMN oasis.lm_case_classification.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_case_classification.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_case_classification.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_case_classification.e2b_code
     IS 'E2B Code for the case classification.';
COMMENT ON COLUMN oasis.lm_case_classification.description_j
     IS 'Display text for the case classification. (Japanese).';
COMMENT ON COLUMN oasis.lm_case_classification.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_case_classification.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_causality(
    causality_id NUMERIC NOT NULL,
    causality CHARACTER VARYING(60) NOT NULL,
    reportability NUMERIC,
    protected NUMERIC,
    display NUMERIC,
    causality_j CHARACTER VARYING(60),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_causality
     IS 'Maintains the list of Product - Event causality determination term.';
COMMENT ON COLUMN oasis.lm_causality.causality_id
     IS 'ID number for the causality term. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_causality.causality
     IS 'Display text for causality term.';
COMMENT ON COLUMN oasis.lm_causality.reportability
     IS '1 = The causality term shall evaluate to reportable when used as a criteria for auto scheduling of regulatory reports, 0 = Otherwise.';
COMMENT ON COLUMN oasis.lm_causality.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_causality.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_causality.causality_j
     IS 'Display text for causality term. (Japanese).';
COMMENT ON COLUMN oasis.lm_causality.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_causality.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_causality.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_centers(
    center_id NUMERIC NOT NULL,
    center_no CHARACTER VARYING(20),
    center_name CHARACTER VARYING(40),
    address CHARACTER VARYING(120),
    center_name_j CHARACTER VARYING(40),
    center_no_j CHARACTER VARYING(20),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_centers
     IS 'Maintains the details of Study Centers.';
COMMENT ON COLUMN oasis.lm_centers.center_id
     IS 'ID number for the study center. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_centers.center_no
     IS 'User specified Center Number for the study center.';
COMMENT ON COLUMN oasis.lm_centers.center_name
     IS 'Name of the study center.';
COMMENT ON COLUMN oasis.lm_centers.address
     IS 'Address of the study center.';
COMMENT ON COLUMN oasis.lm_centers.center_name_j
     IS 'Name of the study center. (Japanese).';
COMMENT ON COLUMN oasis.lm_centers.center_no_j
     IS 'User specified Center Number for the study center. (Japanese).';
COMMENT ON COLUMN oasis.lm_centers.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_centers.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_centers.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_condition_type(
    condition_type_id NUMERIC NOT NULL,
    cond_type CHARACTER VARYING(20) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    cond_category NUMERIC(1,0),
    cond_type_j CHARACTER VARYING(20),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_condition_type
     IS 'Maintains the list of conditions types for patient / parent medical history or other relevant therapy.';
COMMENT ON COLUMN oasis.lm_condition_type.condition_type_id
     IS 'ID number for the condition type. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_condition_type.cond_type
     IS 'Display text for the condition type.';
COMMENT ON COLUMN oasis.lm_condition_type.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_condition_type.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_condition_type.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_condition_type.cond_category
     IS 'Category for the condition type. 1 = Medical History Episode, 2 = Other Relevant Therapy.';
COMMENT ON COLUMN oasis.lm_condition_type.cond_type_j
     IS 'Display text for the condition type. (Japanese).';
COMMENT ON COLUMN oasis.lm_condition_type.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_condition_type.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_countries(
    country_id NUMERIC NOT NULL,
    country CHARACTER VARYING(50) NOT NULL,
    a2 CHARACTER VARYING(2),
    a3 CHARACTER VARYING(3),
    num NUMERIC,
    protected NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    country_group_id NUMERIC,
    country_group CHARACTER VARYING(50),
    country_j CHARACTER VARYING(50),
    group_2_country NUMERIC(1,0),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_countries
     IS 'Maintains the list of countries. It is pre-populated with ISO-3166 country and along with their codes as part of factory data.';
COMMENT ON COLUMN oasis.lm_countries.country_id
     IS 'ID number for the country. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_countries.country
     IS 'Display name for the country.';
COMMENT ON COLUMN oasis.lm_countries.a2
     IS '2 character A2 code (as per the ISO-3166 country list).';
COMMENT ON COLUMN oasis.lm_countries.a3
     IS '3 character A3 code (as per the ISO-3166 country list).';
COMMENT ON COLUMN oasis.lm_countries.num
     IS 'Numeric code for the country (as per ISO-3166 country list).';
COMMENT ON COLUMN oasis.lm_countries.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_countries.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_countries.country_group_id
     IS 'COUNTRY_ID of the country which is used as Country Group for this country.';
COMMENT ON COLUMN oasis.lm_countries.country_group
     IS 'Country name of the country which is used as Country Group for this country.';
COMMENT ON COLUMN oasis.lm_countries.country_j
     IS 'Display name for the country. (Japanese).';
COMMENT ON COLUMN oasis.lm_countries.group_2_country
     IS '1 - If the country is a group 2 Country. Else 0.';
COMMENT ON COLUMN oasis.lm_countries.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_countries.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_datasheet(
    datasheet_id NUMERIC NOT NULL,
    sheet_name CHARACTER VARYING(40),
    core_sheet NUMERIC,
    family_id NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    revision NUMERIC NOT NULL,
    activation_date TIMESTAMP(0) WITHOUT TIME ZONE,
    notes TEXT DEFAULT NULL,
    max_revision NUMERIC,
    no_local_assessment NUMERIC DEFAULT 0,
    include_datasheet_id NUMERIC DEFAULT 0,
    sheet_name_j CHARACTER VARYING(40),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_datasheet
     IS 'Maintains information about the product family datasheets and their revisions.';
COMMENT ON COLUMN oasis.lm_datasheet.datasheet_id
     IS 'ID number for the datasheet. Primary key component.';
COMMENT ON COLUMN oasis.lm_datasheet.sheet_name
     IS 'Display name for the datasheet.';
COMMENT ON COLUMN oasis.lm_datasheet.core_sheet
     IS '1 = The datasheet is a CORE datasheet, 0 = Otherwise.';
COMMENT ON COLUMN oasis.lm_datasheet.family_id
     IS 'ID of the product family for the datasheet. Foreign key to LM_PRODUCT_FAMILY.FAMILY_ID.';
COMMENT ON COLUMN oasis.lm_datasheet.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_datasheet.revision
     IS 'Revision number for the datasheet. Primary key component.';
COMMENT ON COLUMN oasis.lm_datasheet.activation_date
     IS 'Date of Activation for the datasheet.';
COMMENT ON COLUMN oasis.lm_datasheet.notes
     IS 'Notes for the datasheet.';
COMMENT ON COLUMN oasis.lm_datasheet.max_revision
     IS 'Maximum revision number available for the datasheet.';
COMMENT ON COLUMN oasis.lm_datasheet.no_local_assessment
     IS '1 = No local labeling assessment is required, 0 = Otherwise.';
COMMENT ON COLUMN oasis.lm_datasheet.include_datasheet_id
     IS 'ID of the datasheet that is included in this datasheet.';
COMMENT ON COLUMN oasis.lm_datasheet.sheet_name_j
     IS 'Display name for the datasheet. (Japanese).';
COMMENT ON COLUMN oasis.lm_datasheet.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_datasheet.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_delivery_types(
    delivery_type_id NUMERIC NOT NULL,
    delivery_type CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    delivery_type_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_delivery_types
     IS 'Maintains the list of neonate delivery types.';
COMMENT ON COLUMN oasis.lm_delivery_types.delivery_type_id
     IS 'ID number for the delivery type. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_delivery_types.delivery_type
     IS 'Display text for the delivery type.';
COMMENT ON COLUMN oasis.lm_delivery_types.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_delivery_types.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_delivery_types.delivery_type_j
     IS 'Display text for the delivery type. (Japanese).';
COMMENT ON COLUMN oasis.lm_delivery_types.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_delivery_types.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_delivery_types.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_dev_phase(
    dev_phase_id NUMERIC NOT NULL,
    dev_phase CHARACTER VARYING(50),
    dev_phase_j CHARACTER VARYING(50),
    e2b_code NUMERIC(2,0),
    display NUMERIC(1,0),
    protected NUMERIC(1,0),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_dev_phase
     IS 'This table stores user configured values for Study Development Phases. This is used for drop down in Studies Configuration.';
COMMENT ON COLUMN oasis.lm_dev_phase.dev_phase_id
     IS 'ID number of the Study Development Phase. Primary key for the table.';
COMMENT ON COLUMN oasis.lm_dev_phase.dev_phase
     IS 'Name of Study Development Phase in English.';
COMMENT ON COLUMN oasis.lm_dev_phase.dev_phase_j
     IS 'Name of Study Development Phase in Japanese.';
COMMENT ON COLUMN oasis.lm_dev_phase.e2b_code
     IS 'E2B code for Study Development Phase.';
COMMENT ON COLUMN oasis.lm_dev_phase.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_dev_phase.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_dev_phase.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_dev_phase.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_dev_phase.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_device_type(
    device_type_id NUMERIC NOT NULL,
    device_type_desc CHARACTER VARYING(50) NOT NULL,
    display NUMERIC,
    protected NUMERIC,
    device_type_desc_j CHARACTER VARYING(50),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_device_type
     IS 'Maintains the list of device types.';
COMMENT ON COLUMN oasis.lm_device_type.device_type_id
     IS 'ID number for the device type. Primary Key for the table.';
COMMENT ON COLUMN oasis.lm_device_type.device_type_desc
     IS 'Display text for the device type.';
COMMENT ON COLUMN oasis.lm_device_type.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_device_type.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_device_type.device_type_desc_j
     IS 'Display text for the device type. (Japanese).';
COMMENT ON COLUMN oasis.lm_device_type.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_device_type.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_device_type.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_dose_frequency(
    freq_id NUMERIC NOT NULL,
    freq CHARACTER VARYING(15) NOT NULL,
    protected NUMERIC,
    freq_value NUMERIC,
    display NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    separate_dosage_numb_e2b NUMERIC,
    interval_dosage_unit_e2b NUMERIC,
    interval_dosage_def_e2b NUMERIC,
    freq_j CHARACTER VARYING(15),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_dose_frequency
     IS 'Maintains information about the product dosage frequencies.';
COMMENT ON COLUMN oasis.lm_dose_frequency.freq_id
     IS 'ID number for the dosage frequency. Primary Key for the table.';
COMMENT ON COLUMN oasis.lm_dose_frequency.freq
     IS 'Display text for the dosage frequency.';
COMMENT ON COLUMN oasis.lm_dose_frequency.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_dose_frequency.freq_value
     IS 'Number of dosages is delivered in 1 day.';
COMMENT ON COLUMN oasis.lm_dose_frequency.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_dose_frequency.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_dose_frequency.separate_dosage_numb_e2b
     IS 'Number of separate dosages delivered during an interval.';
COMMENT ON COLUMN oasis.lm_dose_frequency.interval_dosage_unit_e2b
     IS 'Number of units in the interval in which the separate dosages are delivered.';
COMMENT ON COLUMN oasis.lm_dose_frequency.interval_dosage_def_e2b
     IS 'Definition of the interval in which the separate dosages are delivered. Foreign key to ESM_LM_UNITS.ID.';
COMMENT ON COLUMN oasis.lm_dose_frequency.freq_j
     IS 'Display text for the dosage frequency. (Japanese).';
COMMENT ON COLUMN oasis.lm_dose_frequency.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_dose_frequency.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_dose_units(
    unit_id NUMERIC NOT NULL,
    unit CHARACTER VARYING(70) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    dosage_unit NUMERIC NOT NULL DEFAULT 1,
    dose_unit_value NUMERIC,
    e2b_code CHARACTER VARYING(6),
    lab_test_unit NUMERIC,
    unit_j CHARACTER VARYING(70),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL,
    strength_unit NUMERIC 
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_dose_units
     IS 'Maintains information about the product dosage units.';
COMMENT ON COLUMN oasis.lm_dose_units.unit_id
     IS 'ID number for the dosage unit. Primary Key for the table.';
COMMENT ON COLUMN oasis.lm_dose_units.unit
     IS 'Display text for the dosage unit.';
COMMENT ON COLUMN oasis.lm_dose_units.protected
     IS 'Internal field set in factory data to prevent users from deleting the factory data records from UI. 1 = Do not allow deletion of this record, 0 = Allow deletion of this record.';
COMMENT ON COLUMN oasis.lm_dose_units.display
     IS '1 = Display this record in the Argus Safety UI, 0 = Do not display it in the Argus Safety UI.';
COMMENT ON COLUMN oasis.lm_dose_units.dosage_unit
     IS '1 = This dosage unit can be used as a Lab Test unit, 0 = Otherwise.';
COMMENT ON COLUMN oasis.lm_dose_units.dose_unit_value
     IS 'Not Used.';
COMMENT ON COLUMN oasis.lm_dose_units.e2b_code
     IS 'E2B code for the dosage unit.';
COMMENT ON COLUMN oasis.lm_dose_units.lab_test_unit
     IS '1 = This dosage unit can be used as a Lab Test unit, 0 = Otherwise.';
COMMENT ON COLUMN oasis.lm_dose_units.unit_j
     IS 'Display text for the dosage unit. (Japanese).';
COMMENT ON COLUMN oasis.lm_dose_units.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_dose_units.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_dose_units.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';
COMMENT ON COLUMN oasis.lm_dose_units.strength_unit
     IS '1 = This dosage unit can be used as a strength unit, 0 = Otherwise.';

CREATE TABLE oasis.lm_ethnicity(
    ethnicity_id NUMERIC NOT NULL,
    ethnicity CHARACTER VARYING(50) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    ethnicity_j CHARACTER VARYING(50),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_ethnicity
     IS 'This table contains patient ethnicity.';
COMMENT ON COLUMN oasis.lm_ethnicity.ethnicity_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_ethnicity.ethnicity
     IS 'Display text for ethnicity.';
COMMENT ON COLUMN oasis.lm_ethnicity.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_ethnicity.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_ethnicity.ethnicity_j
     IS 'Display text for ethnicity (Japanese).';
COMMENT ON COLUMN oasis.lm_ethnicity.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_ethnicity.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_ethnicity.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_evt_frequency(
    evt_freq_id NUMERIC NOT NULL,
    evt_freq CHARACTER VARYING(15) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    evt_freq_j CHARACTER VARYING(15),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_evt_frequency
     IS 'This table contains event frequency terms.';
COMMENT ON COLUMN oasis.lm_evt_frequency.evt_freq_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_evt_frequency.evt_freq
     IS 'Display text for event frequency. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_evt_frequency.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_evt_frequency.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_evt_frequency.evt_freq_j
     IS 'Display text for event frequency. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_evt_frequency.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_evt_frequency.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_evt_frequency.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_evt_intensity(
    evt_intensity_id NUMERIC NOT NULL,
    evt_intensity CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    evt_intensity_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_evt_intensity
     IS 'This table contains event intensity terms.';
COMMENT ON COLUMN oasis.lm_evt_intensity.evt_intensity_id
     IS 'Primary key Nature of Event ID';
COMMENT ON COLUMN oasis.lm_evt_intensity.evt_intensity
     IS 'Nature of Event';
COMMENT ON COLUMN oasis.lm_evt_intensity.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_evt_intensity.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_evt_intensity.evt_intensity_j
     IS 'Nature of Event (Japanese).';
COMMENT ON COLUMN oasis.lm_evt_intensity.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_evt_intensity.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_evt_intensity.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_evt_outcome(
    evt_outcome_id NUMERIC NOT NULL,
    evt_outcome CHARACTER VARYING(50) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    e2b_code NUMERIC,
    evt_outcome_j CHARACTER VARYING(50),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_evt_outcome
     IS 'This table contains terms descriptive of the outcome of the event (i.e. recovered, fatal, etc.).';
COMMENT ON COLUMN oasis.lm_evt_outcome.evt_outcome_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_evt_outcome.evt_outcome
     IS 'Display text for event outcome. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_evt_outcome.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_evt_outcome.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_evt_outcome.e2b_code
     IS 'E2b code for event outcome';
COMMENT ON COLUMN oasis.lm_evt_outcome.evt_outcome_j
     IS 'Display text for event outcome. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_evt_outcome.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_evt_outcome.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_evt_outcome.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_fetal_outcome(
    fetal_outcome_id NUMERIC NOT NULL,
    fetal_outcome CHARACTER VARYING(35) NOT NULL,
    display NUMERIC,
    protected NUMERIC,
    fetal_outcome_j CHARACTER VARYING(35),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_fetal_outcome
     IS 'This table contains Fetal Outcome';
COMMENT ON COLUMN oasis.lm_fetal_outcome.fetal_outcome_id
     IS 'Primary Key';
COMMENT ON COLUMN oasis.lm_fetal_outcome.fetal_outcome
     IS 'Display text for fetal outcome';
COMMENT ON COLUMN oasis.lm_fetal_outcome.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_fetal_outcome.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_fetal_outcome.fetal_outcome_j
     IS 'Display text for fetal outcome (Japanese).';
COMMENT ON COLUMN oasis.lm_fetal_outcome.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_fetal_outcome.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_fetal_outcome.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_formulation(
    formulation_id NUMERIC NOT NULL,
    formulation CHARACTER VARYING(100) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    formulation_j CHARACTER VARYING(100),
    formulation_symbol_j CHARACTER VARYING(5),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_formulation
     IS 'This table contains product formulation types.';
COMMENT ON COLUMN oasis.lm_formulation.formulation_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_formulation.formulation
     IS 'Display text for formulation. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_formulation.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_formulation.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_formulation.formulation_j
     IS 'Display text for formulation. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_formulation.formulation_symbol_j
     IS 'Formulation Code used for reporting DRUGDOSAGEFORM in E2B reports to Japanese authority - PMDA.';
COMMENT ON COLUMN oasis.lm_formulation.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_formulation.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_formulation.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_gender(
    gender_id NUMERIC NOT NULL,
    gender CHARACTER VARYING(10) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    e2b_code NUMERIC,
    gender_j CHARACTER VARYING(10),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_gender
     IS 'This table contains patient gender types.';
COMMENT ON COLUMN oasis.lm_gender.gender_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_gender.gender
     IS 'Display text for gender type. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_gender.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_gender.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_gender.e2b_code
     IS 'E2b code for gender';
COMMENT ON COLUMN oasis.lm_gender.gender_j
     IS 'Display text for gender type. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_gender.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_gender.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_gender.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_hcp(
    hcp_id NUMERIC NOT NULL,
    hcp CHARACTER VARYING(30) NOT NULL,
    hcp_j CHARACTER VARYING(30),
    protected NUMERIC,
    display NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_hcp
     IS 'Lookup table for HCP values (Yes/No/Unk)';
COMMENT ON COLUMN oasis.lm_hcp.hcp_id
     IS 'Primary Key';
COMMENT ON COLUMN oasis.lm_hcp.hcp
     IS 'Value of HCP';
COMMENT ON COLUMN oasis.lm_hcp.hcp_j
     IS 'Value of HCP (Japanese).';
COMMENT ON COLUMN oasis.lm_hcp.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_hcp.display
     IS '0=no, 1=yes';
COMMENT ON COLUMN oasis.lm_hcp.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted';
COMMENT ON COLUMN oasis.lm_hcp.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_hcp.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_intermediary(
    intermediary_id NUMERIC NOT NULL,
    intermediary CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    intermediary_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_intermediary
     IS 'This table contains the report source intermediary types.';
COMMENT ON COLUMN oasis.lm_intermediary.intermediary_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_intermediary.intermediary
     IS 'Display text for intermediary types. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_intermediary.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_intermediary.intermediary_j
     IS 'Display text for intermediary types. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_intermediary.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_intermediary.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_intermediary.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_lab_assessment(
    assessment_id NUMERIC NOT NULL,
    assessment CHARACTER VARYING(20) NOT NULL,
    display NUMERIC(1,0),
    protected NUMERIC(1,0),
    assessment_j CHARACTER VARYING(20),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_lab_assessment
     IS 'This table contains qualitative lab data assessment terms.';
COMMENT ON COLUMN oasis.lm_lab_assessment.assessment_id
     IS 'Internal assessment ID.';
COMMENT ON COLUMN oasis.lm_lab_assessment.assessment
     IS 'Assessment term. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_lab_assessment.display
     IS '0 = No, 1 = Yes';
COMMENT ON COLUMN oasis.lm_lab_assessment.protected
     IS '0 = No, 1 = Yes';
COMMENT ON COLUMN oasis.lm_lab_assessment.assessment_j
     IS 'Assessment term. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_lab_assessment.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_lab_assessment.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_lab_assessment.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_labeled_terms(
    datasheet_id NUMERIC NOT NULL,
    label_term_id NUMERIC,
    term_code CHARACTER VARYING(40),
    code_dict NUMERIC,
    term_level NUMERIC,
    labeled_term CHARACTER VARYING(250),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    seq_num NUMERIC NOT NULL,
    revision NUMERIC,
    added_date TIMESTAMP(0) WITHOUT TIME ZONE,
    code_status NUMERIC,
    notes TEXT DEFAULT NULL,
    code_status_j NUMERIC,
    labeled_term_j CHARACTER VARYING(250),
    notes_j TEXT DEFAULT NULL,
    term_llt CHARACTER VARYING(250),
    term_hlt CHARACTER VARYING(250),
    term_hlgt CHARACTER VARYING(250),
    term_soc CHARACTER VARYING(250),
    term_llt_code CHARACTER VARYING(50),
    term_hlt_code CHARACTER VARYING(50),
    term_hlgt_code CHARACTER VARYING(50),
    term_soc_code CHARACTER VARYING(50),
    term_as_coded CHARACTER VARYING(250),
    term_as_reptd CHARACTER VARYING(250),
    term_llt_j CHARACTER VARYING(250),
    term_hlt_j CHARACTER VARYING(250),
    term_hlgt_j CHARACTER VARYING(250),
    term_soc_j CHARACTER VARYING(250),
    term_llt_code_j CHARACTER VARYING(50),
    term_as_coded_j CHARACTER VARYING(250),
    term_as_reptd_j CHARACTER VARYING(250),
    syn_code NUMERIC,
    syn_code_j NUMERIC,
    eg_id NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_labeled_terms
     IS 'This table contains labeled terms specified as part of a product data sheet.';
COMMENT ON COLUMN oasis.lm_labeled_terms.datasheet_id
     IS ' This column is foreign key to LM_DATASHEET.DATASHEET_ID.';
COMMENT ON COLUMN oasis.lm_labeled_terms.label_term_id
     IS 'Not used';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_code
     IS 'Term code of labeled term (dictionary specific)';
COMMENT ON COLUMN oasis.lm_labeled_terms.code_dict
     IS 'Identifies source dictionary of labeled term';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_level
     IS 'Term level of labeled term (dictionary specific)';
COMMENT ON COLUMN oasis.lm_labeled_terms.labeled_term
     IS 'Display text for labeled term';
COMMENT ON COLUMN oasis.lm_labeled_terms.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_labeled_terms.seq_num
     IS 'Primary Key from sequence S_LM_LABELED_TERMS';
COMMENT ON COLUMN oasis.lm_labeled_terms.revision
     IS ' This column is foreign key to LM_DATASHEET.REVISION.';
COMMENT ON COLUMN oasis.lm_labeled_terms.added_date
     IS 'Date when revision is added';
COMMENT ON COLUMN oasis.lm_labeled_terms.code_status
     IS 'Status of Coding';
COMMENT ON COLUMN oasis.lm_labeled_terms.notes
     IS 'This column will contain notes corresponding to each Labeled Term in datasheet';
COMMENT ON COLUMN oasis.lm_labeled_terms.code_status_j
     IS 'Status of Coding (Japanese).';
COMMENT ON COLUMN oasis.lm_labeled_terms.labeled_term_j
     IS 'Display text for labeled term (Japanese).';
COMMENT ON COLUMN oasis.lm_labeled_terms.notes_j
     IS 'Japanese Notes associated with the Datasheet Labeled Term.';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_llt
     IS 'Contains Lower Level Term Name';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_hlt
     IS 'Contains High Level Term Name';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_hlgt
     IS 'Contains High Level Group Term Name';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_soc
     IS 'Contains System Organ Class Name';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_llt_code
     IS 'Contains Lower Level Term Code';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_hlt_code
     IS 'Contains High Level Term Code';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_hlgt_code
     IS 'Contains High Level Group Term Code';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_soc_code
     IS 'Contains System Organ Class Code';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_as_coded
     IS 'Contains Term as Coded';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_as_reptd
     IS 'Contains Term as Reported';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_llt_j
     IS 'Contains Lower Level Term Name J';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_hlt_j
     IS 'Contains High Level Term Name J';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_hlgt_j
     IS 'Contains High Level Group Term Name J';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_soc_j
     IS 'Contains System Organ Class Name J';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_llt_code_j
     IS 'Contains Lower Level Term Code J';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_as_coded_j
     IS 'Contains Term as Coded J';
COMMENT ON COLUMN oasis.lm_labeled_terms.term_as_reptd_j
     IS 'Contains Term as Reported J';
COMMENT ON COLUMN oasis.lm_labeled_terms.syn_code
     IS 'Synonym Code';
COMMENT ON COLUMN oasis.lm_labeled_terms.syn_code_j
     IS 'Synonym Code as per MedDRA J';
COMMENT ON COLUMN oasis.lm_labeled_terms.eg_id
     IS 'Foreign Key to LM_EVENT_GROUP EG_ID Column';
COMMENT ON COLUMN oasis.lm_labeled_terms.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_labeled_terms.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_license
(
    license_id numeric NOT NULL,
    trade_name character varying(250) COLLATE pg_catalog."default",
    manufacturer_id numeric,
    country_id numeric,
    license_type_id numeric,
    lic_number character varying(40) COLLATE pg_catalog."default",
    award_date timestamp(0) without time zone,
    withdraw_date timestamp(0) without time zone,
    drl_id character varying(45) COLLATE pg_catalog."default",
    biologic numeric,
    reg_rpt_rules_id numeric,
    use_award_ibd_date numeric,
    active_moiety numeric,
    datasheet_id numeric,
    group_id numeric,
    company_item_no character varying(40) COLLATE pg_catalog."default",
    product_info_location character varying(400) COLLATE pg_catalog."default",
    deleted timestamp(0) without time zone,
    single_use numeric DEFAULT 0,
    combination_product numeric,
    otc_product numeric NOT NULL DEFAULT 0,
    pma character varying(20) COLLATE pg_catalog."default",
    medical_device_info_id numeric,
    ctpr_group_name character varying(50) COLLATE pg_catalog."default",
    comments character varying(1000) COLLATE pg_catalog."default",
    trade_name_j character varying(250) COLLATE pg_catalog."default",
    mhlw_re_examination_date timestamp(0) without time zone,
    clinical_compound_number character varying(70) COLLATE pg_catalog."default",
    exclude_rpt_candidate numeric(1,0) NOT NULL DEFAULT 0,
    comments_j character varying(1000) COLLATE pg_catalog."default",
    pmda_class_id_1 numeric,
    pmda_class_id_2 numeric,
    pmda_class_id_3 numeric,
    enterprise_id numeric NOT NULL,
    app_type character varying(5) COLLATE pg_catalog."default",
    device_company_id character varying(100) COLLATE pg_catalog."default",
    device_id character varying(100) COLLATE pg_catalog."default",
    lic_category_id numeric,
    risk_category_id numeric,
    tiken numeric(1,0),
    blinded_field numeric(1,0),
    last_update_time timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    ce_marked numeric,
    med_device_terminology numeric, 
conformity numeric,
date_of_conformity      date,
nomenclature_txt  varchar(4000),
other varchar(50),
notified_body_id_number_1     varchar(30),
notified_body_id_number_2     varchar(30),
cert_num_notified_body_1      varchar(150),
cert_num_notified_body_2      varchar(150),
basic_udi_di      varchar(50),
nomenclature varchar(500))
WITH (
    OIDS = FALSE
);
COMMENT ON TABLE oasis.lm_license
     IS 'This table contains product license specification.';
COMMENT ON COLUMN oasis.lm_license.license_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_license.trade_name
     IS 'Licensed trade name';
COMMENT ON COLUMN oasis.lm_license.manufacturer_id
     IS 'Identifies the manufacturer of the licensed product;. This column is foreign key to LM_MANUFACTURER.MANUFACTURER_ID.';
COMMENT ON COLUMN oasis.lm_license.country_id
     IS 'Country of license award; . This column is foreign key to LM_COUNTRIES.COUNTRY_ID.';
COMMENT ON COLUMN oasis.lm_license.license_type_id
     IS 'Identifies the type of license;. This column is foreign key to LM_LICENSE_TYPES.LICENSE_TYPE_ID.';
COMMENT ON COLUMN oasis.lm_license.lic_number
     IS 'Display text of license number';
COMMENT ON COLUMN oasis.lm_license.award_date
     IS 'License award date';
COMMENT ON COLUMN oasis.lm_license.withdraw_date
     IS 'Date license withdrawn';
COMMENT ON COLUMN oasis.lm_license.drl_id
     IS 'Not used';
COMMENT ON COLUMN oasis.lm_license.biologic
     IS '1: checked;  0: not checked;  default: 0.';
COMMENT ON COLUMN oasis.lm_license.reg_rpt_rules_id
     IS ' This column is foreign key to CFG_REG_REPORT_RULES.REG_RPT_RULES_ID.';
COMMENT ON COLUMN oasis.lm_license.use_award_ibd_date
     IS 'Use award date; use international birth date for auto regulatory report scheduling';
COMMENT ON COLUMN oasis.lm_license.active_moiety
     IS 'True (1) when ingredient matching is used for report scheduling.';
COMMENT ON COLUMN oasis.lm_license.datasheet_id
     IS 'Core data sheet identification';
COMMENT ON COLUMN oasis.lm_license.group_id
     IS 'This is a reference to LM_GROUPS GROUP_ID';
COMMENT ON COLUMN oasis.lm_license.company_item_no
     IS 'Company item number for license';
COMMENT ON COLUMN oasis.lm_license.product_info_location
     IS 'Product information location; either a link or file on network path';
COMMENT ON COLUMN oasis.lm_license.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_license.single_use
     IS 'Is device labeled for single use (0-no, 1-yes), default 0';
COMMENT ON COLUMN oasis.lm_license.combination_product
     IS 'Combination product in lm_license';
COMMENT ON COLUMN oasis.lm_license.otc_product
     IS 'This column can have two values (0,1),1 - OTC Product checkbox shall automatically be checked on the Case MedWatch Info tab for the case,2- Otherwise';
COMMENT ON COLUMN oasis.lm_license.pma
     IS 'PMA/510K value.';
COMMENT ON COLUMN oasis.lm_license.nomenclature
     IS 'Nomenclature Code value.';
COMMENT ON COLUMN oasis.lm_license.medical_device_info_id
     IS ' This column is foreign key to LM_MEDICAL_DEVICE_INFO.MEDICAL_DEVICE_INFO_ID.';
COMMENT ON COLUMN oasis.lm_license.ctpr_group_name
     IS 'This will store the CTPR group name.';
COMMENT ON COLUMN oasis.lm_license.comments
     IS 'This will store the comments for the LICENSE screen';
COMMENT ON COLUMN oasis.lm_license.trade_name_j
     IS 'Licensed trade name (Japanese).';
COMMENT ON COLUMN oasis.lm_license.mhlw_re_examination_date
     IS 'MHLW (PMDA) Re-examination date';
COMMENT ON COLUMN oasis.lm_license.clinical_compound_number
     IS 'Clinical compound number associated with the Japanese License.';
COMMENT ON COLUMN oasis.lm_license.exclude_rpt_candidate
     IS 'This column stores value "0" or "1". 
Column Comment: Japanese licenses for which "EXCLUDE_RPT_CANDIDATE" value is "0", shall be considered for populating Japanese licenses in Event Assessment and PMDA tabs.';
COMMENT ON COLUMN oasis.lm_license.comments_j
     IS 'Japanese Comments';
COMMENT ON COLUMN oasis.lm_license.pmda_class_id_1
     IS 'Device Classification 1';
COMMENT ON COLUMN oasis.lm_license.pmda_class_id_2
     IS 'Device Classification 2';
COMMENT ON COLUMN oasis.lm_license.pmda_class_id_3
     IS 'Device Classification 3';
COMMENT ON COLUMN oasis.lm_license.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_license.app_type
     IS 'Store the application type of license';
COMMENT ON COLUMN oasis.lm_license.lic_category_id
     IS 'Status Category of new drugs';
COMMENT ON COLUMN oasis.lm_license.risk_category_id
     IS 'Risk Category of OTC Drug';
COMMENT ON COLUMN oasis.lm_license.tiken
     IS 'PMDA E2b B.4.k.19';
COMMENT ON COLUMN oasis.lm_license.blinded_field
     IS 'Blinded Field (Paper Report)';
COMMENT ON COLUMN oasis.lm_license.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';
COMMENT ON COLUMN oasis.lm_license.ce_marked
     IS 'European Conformity referring to Codelist CE_MARKED';

CREATE TABLE oasis.lm_license_types(
    license_type_id NUMERIC NOT NULL,
    license_type CHARACTER VARYING(30),
    license_type_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_license_types
     IS 'This table contains license types (i.e. Marketed Drug, Investigational Vaccine, etc.).';
COMMENT ON COLUMN oasis.lm_license_types.license_type_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_license_types.license_type
     IS 'Display text of license type';
COMMENT ON COLUMN oasis.lm_license_types.license_type_j
     IS 'Display text of license type (Japanese).';
COMMENT ON COLUMN oasis.lm_license_types.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_license_types.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_listedness(
    listedness_id NUMERIC NOT NULL,
    listedness CHARACTER VARYING(20),
    protected NUMERIC,
    display NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    labeledness CHARACTER VARYING(20),
    labeledness_j CHARACTER VARYING(20),
    listedness_j CHARACTER VARYING(20),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_listedness
     IS 'This table contains Event/Product Data sheet listedness determination terms.';
COMMENT ON COLUMN oasis.lm_listedness.listedness_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_listedness.listedness
     IS 'Display text for listedness determination term';
COMMENT ON COLUMN oasis.lm_listedness.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_listedness.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_listedness.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_listedness.labeledness
     IS 'It is shown in the Listedness dropdown list as text in License Row under Event Assessment Screen';
COMMENT ON COLUMN oasis.lm_listedness.labeledness_j
     IS 'It is shown in the Listedness dropdown list as text in License Row under Event Assessment Screen (Japanese).';
COMMENT ON COLUMN oasis.lm_listedness.listedness_j
     IS 'Display text for listedness determination term (Japanese).';
COMMENT ON COLUMN oasis.lm_listedness.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_listedness.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_manufacturer(
    manufacturer_id NUMERIC NOT NULL,
    manu_name CHARACTER VARYING(100) NOT NULL,
    address CHARACTER VARYING(120),
    city CHARACTER VARYING(30),
    state CHARACTER VARYING(40),
    postal_code CHARACTER VARYING(10),
    country CHARACTER VARYING(50),
    contact CHARACTER VARYING(40),
    phone CHARACTER VARYING(29),
    reg_no CHARACTER VARYING(10),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    fax CHARACTER VARYING(50),
    address_j CHARACTER VARYING(120),
    city_j CHARACTER VARYING(30),
    contact_j CHARACTER VARYING(40),
    manu_name_j CHARACTER VARYING(100),
    state_j CHARACTER VARYING(40),
    country_id NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    email CHARACTER VARYING(43),
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_manufacturer
     IS 'This table contains the Product Manufacturer List.';
COMMENT ON COLUMN oasis.lm_manufacturer.manufacturer_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_manufacturer.manu_name
     IS 'Company name of manufacturer. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_manufacturer.address
     IS 'Street address of manufacturer';
COMMENT ON COLUMN oasis.lm_manufacturer.city
     IS 'City';
COMMENT ON COLUMN oasis.lm_manufacturer.state
     IS 'State';
COMMENT ON COLUMN oasis.lm_manufacturer.postal_code
     IS 'Postal code';
COMMENT ON COLUMN oasis.lm_manufacturer.country
     IS 'Country of manufacturer (text)';
COMMENT ON COLUMN oasis.lm_manufacturer.contact
     IS 'Contact person name';
COMMENT ON COLUMN oasis.lm_manufacturer.phone
     IS 'Phone number';
COMMENT ON COLUMN oasis.lm_manufacturer.reg_no
     IS 'Registration number (i.e. FDA registration number)';
COMMENT ON COLUMN oasis.lm_manufacturer.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_manufacturer.fax
     IS 'Fax number of manufacturer';
COMMENT ON COLUMN oasis.lm_manufacturer.address_j
     IS 'Street address of manufacturer (Japanese).';
COMMENT ON COLUMN oasis.lm_manufacturer.city_j
     IS 'City (Japanese).';
COMMENT ON COLUMN oasis.lm_manufacturer.contact_j
     IS 'Contact person name (Japanese).';
COMMENT ON COLUMN oasis.lm_manufacturer.manu_name_j
     IS 'Company name of manufacturer. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_manufacturer.state_j
     IS 'State (Japanese).';
COMMENT ON COLUMN oasis.lm_manufacturer.country_id
     IS 'Country ID of the Manufacturer Country. Foreign key to LM_COUNTRIES.COUNTRY_ID';
COMMENT ON COLUMN oasis.lm_manufacturer.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_manufacturer.email
     IS 'email address';
COMMENT ON COLUMN oasis.lm_manufacturer.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_mfr_eval_reason(
    mfr_eval_id NUMERIC NOT NULL,
    mfr_eval_reason CHARACTER VARYING(100),
    display NUMERIC,
    protected NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    mfr_eval_code NUMERIC NOT NULL,
    mfr_eval_reason_j CHARACTER VARYING(100),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_mfr_eval_reason
     IS 'This table contains Manufacturer Evaluation Reason Data';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.mfr_eval_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.mfr_eval_reason
     IS 'Description- Display text';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.mfr_eval_code
     IS 'This column will store the evaluation code.';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.mfr_eval_reason_j
     IS 'Description- Display text (Japanese).';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_mfr_eval_reason.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_product(
    product_id NUMERIC NOT NULL,
    prod_name CHARACTER VARYING(250),
    family_id NUMERIC,
    formulation_id NUMERIC,
    manufacturer_id NUMERIC,
    concentration CHARACTER VARYING(10),
    conc_unit_id NUMERIC,
    indication_id CHARACTER VARYING(50),
    code_dict NUMERIC,
    indication_text CHARACTER VARYING(250),
    intl_birth_date TIMESTAMP(0) WITHOUT TIME ZONE,
    model_no CHARACTER VARYING(80),
    drl_id CHARACTER VARYING(45),
    drug_code CHARACTER VARYING(20),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    prod_generic_name TEXT DEFAULT NULL,
    ind_llt_code CHARACTER VARYING(50),
    ind_llt CHARACTER VARYING(250),
    ind_hlt_code CHARACTER VARYING(50),
    ind_hlt CHARACTER VARYING(250),
    ind_hlgt_code CHARACTER VARYING(50),
    ind_hlgt CHARACTER VARYING(250),
    ind_soc_code CHARACTER VARYING(50),
    ind_soc CHARACTER VARYING(250),
    ind_syn_code NUMERIC,
    ind_code_status NUMERIC,
    medicinal_prod_id CHARACTER VARYING(10),
    prod_name_abbrv CHARACTER VARYING(5),
    device_code CHARACTER VARYING(50),
    psur_group_name CHARACTER VARYING(50),
    comments CHARACTER VARYING(1000),
    ind_coded CHARACTER VARYING(250),
    ind_reptd CHARACTER VARYING(250),
    drl_id_j CHARACTER VARYING(70),
    drug_code_j CHARACTER VARYING(20),
    drug_code_type_j NUMERIC,
    indication_text_j CHARACTER VARYING(250),
    ind_code_status_j NUMERIC,
    ind_hlgt_j CHARACTER VARYING(250),
    ind_hlt_j CHARACTER VARYING(250),
    ind_llt_code_j CHARACTER VARYING(50),
    ind_llt_j CHARACTER VARYING(250),
    ind_soc_j CHARACTER VARYING(250),
    prod_generic_name_j TEXT DEFAULT NULL,
    prod_name_j CHARACTER VARYING(250),
    ind_syn_code_j NUMERIC,
    ind_coded_j CHARACTER VARYING(250),
    ind_reptd_j CHARACTER VARYING(250),
    dev_intl_birth_date TIMESTAMP(0) WITHOUT TIME ZONE,
    comments_j CHARACTER VARYING(1000),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL,
    AUTH_REPRESENTATIVE_ID numeric
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_product
     IS 'This table contains product identifications.';
COMMENT ON COLUMN oasis.lm_product.product_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_product.prod_name
     IS 'Product name';
COMMENT ON COLUMN oasis.lm_product.family_id
     IS 'Product family identification. This column is foreign key to LM_PRODUCT_FAMILY.FAMILY_ID.';
COMMENT ON COLUMN oasis.lm_product.formulation_id
     IS 'Product formulation identification. This column is foreign key to LM_FORMULATION.FORMULATION_ID.';
COMMENT ON COLUMN oasis.lm_product.manufacturer_id
     IS 'Product manufacturer identification;. This column is foreign key to LM_MANUFACTURER.MANUFACTURER_ID.';
COMMENT ON COLUMN oasis.lm_product.concentration
     IS 'Concentration value (text) ';
COMMENT ON COLUMN oasis.lm_product.conc_unit_id
     IS 'Concentration unit identification;. This column is foreign key to LM_DOSE_UNITS.UNIT_ID.';
COMMENT ON COLUMN oasis.lm_product.indication_id
     IS 'Primary indication ID (ICD-9 code)';
COMMENT ON COLUMN oasis.lm_product.code_dict
     IS 'Future use';
COMMENT ON COLUMN oasis.lm_product.indication_text
     IS 'Primary indication text (ICD-9 term)';
COMMENT ON COLUMN oasis.lm_product.intl_birth_date
     IS 'Product International Birthdate (earliest date license awarded)';
COMMENT ON COLUMN oasis.lm_product.model_no
     IS 'Product model number';
COMMENT ON COLUMN oasis.lm_product.drl_id
     IS 'WHO-DRUG code';
COMMENT ON COLUMN oasis.lm_product.drug_code
     IS 'Company drug code';
COMMENT ON COLUMN oasis.lm_product.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_product.prod_generic_name
     IS 'Product Generic Name';
COMMENT ON COLUMN oasis.lm_product.ind_llt_code
     IS 'Indication LLT Code';
COMMENT ON COLUMN oasis.lm_product.ind_llt
     IS 'Indication LLT';
COMMENT ON COLUMN oasis.lm_product.ind_hlt_code
     IS 'Indication HLT Code';
COMMENT ON COLUMN oasis.lm_product.ind_hlt
     IS 'Indication HLT';
COMMENT ON COLUMN oasis.lm_product.ind_hlgt_code
     IS 'Indication HLGT Code';
COMMENT ON COLUMN oasis.lm_product.ind_hlgt
     IS 'Indication HLGT';
COMMENT ON COLUMN oasis.lm_product.ind_soc_code
     IS 'Indication SOC Code';
COMMENT ON COLUMN oasis.lm_product.ind_soc
     IS 'Indication SOC';
COMMENT ON COLUMN oasis.lm_product.ind_syn_code
     IS 'Indication Synonyms Code';
COMMENT ON COLUMN oasis.lm_product.ind_code_status
     IS 'Encoding Status';
COMMENT ON COLUMN oasis.lm_product.medicinal_prod_id
     IS 'This column is for data from C format who drug';
COMMENT ON COLUMN oasis.lm_product.prod_name_abbrv
     IS 'Abbreviated Product Name entered by User during configuration';
COMMENT ON COLUMN oasis.lm_product.device_code
     IS '3 character Device Code for Device products';
COMMENT ON COLUMN oasis.lm_product.psur_group_name
     IS 'This will store the psur group name.';
COMMENT ON COLUMN oasis.lm_product.comments
     IS 'This will store the comments for the Product screen.';
COMMENT ON COLUMN oasis.lm_product.ind_coded
     IS 'It stores the term that is coded by the MedDRA';
COMMENT ON COLUMN oasis.lm_product.ind_reptd
     IS 'It stores the term reported by the user';
COMMENT ON COLUMN oasis.lm_product.drl_id_j
     IS 'WHO-DRUG code (Japanese).';
COMMENT ON COLUMN oasis.lm_product.drug_code_j
     IS 'This column contains a flag to indicate if the Product added to the Study corresponds to the J Drug Dictionary.
	When a J or Who drug is added to the study, application creates a Dummy row in LM_PRODUCT table. 
	Now this flag indicates if this is a J Drug or not.';
COMMENT ON COLUMN oasis.lm_product.drug_code_type_j
     IS 'ID number of the Japanese Drug Code Type. Foreign key to CL_JPN_DRUG_CODE_TYPE.DRUG_CODE_ID';
COMMENT ON COLUMN oasis.lm_product.indication_text_j
     IS 'Primary indication text (ICD-9 term) (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_code_status_j
     IS 'Encoding Status (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_hlgt_j
     IS 'Indication HLGT (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_hlt_j
     IS 'Indication HLT (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_llt_code_j
     IS 'Indication LLT Code (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_llt_j
     IS 'Indication LLT (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_soc_j
     IS 'Indication SOC (Japanese).';
COMMENT ON COLUMN oasis.lm_product.prod_generic_name_j
     IS 'Product Generic Name (Japanese).';
COMMENT ON COLUMN oasis.lm_product.prod_name_j
     IS 'Product name (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_syn_code_j
     IS 'Indication Synonyms Code (Japanese).';
COMMENT ON COLUMN oasis.lm_product.ind_coded_j
     IS 'It will store Coded J value for Product Indication.';
COMMENT ON COLUMN oasis.lm_product.ind_reptd_j
     IS 'It will store Reported J value for Product Indication.';
COMMENT ON COLUMN oasis.lm_product.dev_intl_birth_date
     IS 'It is used to determine the start of the annual period for the DSUR.';
COMMENT ON COLUMN oasis.lm_product.comments_j
     IS 'Japanese Comments';
COMMENT ON COLUMN oasis.lm_product.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_product.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_product_family(
    family_id NUMERIC NOT NULL,
    name CHARACTER VARYING(40),
    primary_view NUMERIC,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    product_group_id NUMERIC,
    name_j CHARACTER VARYING(40),
    comments CHARACTER VARYING(1000),
    search_equation_number CHARACTER VARYING(10),
    comments_j CHARACTER VARYING(1000),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_product_family
     IS 'This table contains product family identifications.  It is used to group like products that share datasheets and primary ingredients.';
COMMENT ON COLUMN oasis.lm_product_family.family_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_product_family.name
     IS 'Product family name';
COMMENT ON COLUMN oasis.lm_product_family.primary_view
     IS 'Primary view for product family: 1 = Drug, 2 = Device,  3 = Vaccine';
COMMENT ON COLUMN oasis.lm_product_family.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_product_family.product_group_id
     IS ' PRODUCT_GROUP_ID. This column is foreign key to LM_PRODUCT_GROUP.PRODUCT_GROUP_ID.';
COMMENT ON COLUMN oasis.lm_product_family.name_j
     IS 'Product family name (Japanese).';
COMMENT ON COLUMN oasis.lm_product_family.comments
     IS 'This will store the comments for the family screen.';
COMMENT ON COLUMN oasis.lm_product_family.search_equation_number
     IS 'Search Equation Number to be used for Literature Import - Bookin';
COMMENT ON COLUMN oasis.lm_product_family.comments_j
     IS 'Japanese Comments';
COMMENT ON COLUMN oasis.lm_product_family.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_product_family.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_product_group(
    product_group_id NUMERIC NOT NULL,
    name CHARACTER VARYING(70),
    display NUMERIC,
    name_j CHARACTER VARYING(70),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_product_group
     IS 'This table contains product family belongs to Product Groups.';
COMMENT ON COLUMN oasis.lm_product_group.product_group_id
     IS 'Primary key, Product_Group_Id';
COMMENT ON COLUMN oasis.lm_product_group.name
     IS 'Product Group name';
COMMENT ON COLUMN oasis.lm_product_group.display
     IS 'Display in list (0=no, 1=yes)';
COMMENT ON COLUMN oasis.lm_product_group.name_j
     IS 'Product Group name (Japanese).';
COMMENT ON COLUMN oasis.lm_product_group.deleted
     IS 'Date the record was deleted. ';
COMMENT ON COLUMN oasis.lm_product_group.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_product_group.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_protocols(
    protocol_id NUMERIC NOT NULL,
    protocol_desc CHARACTER VARYING(40),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    display NUMERIC,
    protocol_desc_j CHARACTER VARYING(40),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_protocols
     IS 'This table contains protocol identifications.';
COMMENT ON COLUMN oasis.lm_protocols.protocol_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_protocols.protocol_desc
     IS 'Protocol description';
COMMENT ON COLUMN oasis.lm_protocols.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_protocols.display
     IS '0=no, 1=yes';
COMMENT ON COLUMN oasis.lm_protocols.protocol_desc_j
     IS 'Protocol description (Japanese).';
COMMENT ON COLUMN oasis.lm_protocols.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_protocols.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_ref_types(
    ref_type_id NUMERIC NOT NULL,
    type_desc CHARACTER VARYING(25) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    type_desc_j CHARACTER VARYING(25),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_ref_types
     IS 'This table contains identification of case reference types.';
COMMENT ON COLUMN oasis.lm_ref_types.ref_type_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_ref_types.type_desc
     IS 'Display text for reference type description. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_ref_types.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_ref_types.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_ref_types.type_desc_j
     IS 'Display text for reference type description. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_ref_types.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_ref_types.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_ref_types.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_report_media(
    media_id NUMERIC NOT NULL,
    media CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    media_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_report_media
     IS 'This table contains allowable types of case report media (i.e. phone, fax, etc.).';
COMMENT ON COLUMN oasis.lm_report_media.media_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_report_media.media
     IS 'Display text for media type identification. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_report_media.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_report_media.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_report_media.media_j
     IS 'Display text for media type identification. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_report_media.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_report_media.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_report_media.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_report_type(
    rpt_type_id NUMERIC NOT NULL,
    report_type CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    incl_lit NUMERIC,
    incl_trial NUMERIC,
    e2b_code NUMERIC,
    abrv CHARACTER VARYING(3),
    investigational NUMERIC,
    report_type_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    incl_research NUMERIC NOT NULL DEFAULT 0,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_report_type
     IS 'This table identifies allowable case report types (i.e. Spontaneous, Literature, etc.).';
COMMENT ON COLUMN oasis.lm_report_type.rpt_type_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_report_type.report_type
     IS 'Display text for report type. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_report_type.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_report_type.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_report_type.incl_lit
     IS '1 = enable literature case specific fields on the case form';
COMMENT ON COLUMN oasis.lm_report_type.incl_trial
     IS '1 = enable trial case specific fields on the case form';
COMMENT ON COLUMN oasis.lm_report_type.e2b_code
     IS 'E2b code for report type';
COMMENT ON COLUMN oasis.lm_report_type.abrv
     IS 'Abbreviation of report type';
COMMENT ON COLUMN oasis.lm_report_type.investigational
     IS 'Even though a report type may include "clinical trial" type of information, it may still be considered marketed, for example any non-sponsored clinical trial would be reported under the company''s marketed license. It can have 2 values (0=marketed, 1=investigational).';
COMMENT ON COLUMN oasis.lm_report_type.report_type_j
     IS 'Display text for report type. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_report_type.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_report_type.incl_research
     IS '0 (Default) 1(Includes for Research Reporting)';
COMMENT ON COLUMN oasis.lm_report_type.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_report_type.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_reporter_type(
    rptr_type_id NUMERIC NOT NULL,
    reporter_type CHARACTER VARYING(30) NOT NULL,
    protected NUMERIC,
    display NUMERIC,
    e2b_code NUMERIC,
    reporter_type_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_reporter_type
     IS 'This table contains reporter types (i.e. Consumer).';
COMMENT ON COLUMN oasis.lm_reporter_type.rptr_type_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_reporter_type.reporter_type
     IS 'Display text for reporter type. Text NULL for NULL';
COMMENT ON COLUMN oasis.lm_reporter_type.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_reporter_type.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_reporter_type.e2b_code
     IS 'E2b code for reporter type';
COMMENT ON COLUMN oasis.lm_reporter_type.reporter_type_j
     IS 'Display text for reporter type. Text NULL for NULL (Japanese).';
COMMENT ON COLUMN oasis.lm_reporter_type.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_reporter_type.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_reporter_type.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_sites(
    site_id NUMERIC NOT NULL,
    site_desc CHARACTER VARYING(40),
    site_abrv CHARACTER VARYING(4),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    lam_site NUMERIC,
    protect_patient NUMERIC,
    protect_reporter NUMERIC,
    approved_reports NUMERIC(1,0),
    process_lam_assess NUMERIC NOT NULL DEFAULT 0,
    intake_folder_id NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_sites
     IS 'This table contains identification of user sites.';
COMMENT ON COLUMN oasis.lm_sites.site_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_sites.site_desc
     IS 'Display text for site description/identification';
COMMENT ON COLUMN oasis.lm_sites.site_abrv
     IS 'Abbreviation of site description';
COMMENT ON COLUMN oasis.lm_sites.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_sites.lam_site
     IS 'Determine LAM Sites vs. Argus Sites. Values can be 0,1, -1';
COMMENT ON COLUMN oasis.lm_sites.protect_patient
     IS 'Default values for Protect Patient. Values can be 0,1, -1';
COMMENT ON COLUMN oasis.lm_sites.protect_reporter
     IS 'Protect Reporter Confidentiality. Values can be 0,1, -1';
COMMENT ON COLUMN oasis.lm_sites.approved_reports
     IS '1 for YES, 0 for NO, Default 0 ';
COMMENT ON COLUMN oasis.lm_sites.process_lam_assess
     IS 'Process Lam Assess ';
COMMENT ON COLUMN oasis.lm_sites.intake_folder_id
     IS 'Folder ID for Case Intake. This column is foreign key to INTAKE_FOLDERS.INTAKE_FOLDER_ID.';
COMMENT ON COLUMN oasis.lm_sites.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_sites.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_study_cohorts(
    cohort_id NUMERIC NOT NULL,
    study_key NUMERIC NOT NULL,
    blind_name CHARACTER VARYING(250),
    blind_name_j CHARACTER VARYING(250),
    study_type_id NUMERIC NOT NULL,
    sort_id NUMERIC NOT NULL,
    "primary" NUMERIC NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_study_cohorts
     IS 'This table links cohorts to a specific study.';
COMMENT ON COLUMN oasis.lm_study_cohorts.cohort_id
     IS 'Primary key for table LM_STUDY_COHORTS';
COMMENT ON COLUMN oasis.lm_study_cohorts.study_key
     IS 'This column is a foreign key to LM_STUDIES.STUDY_KEY.';
COMMENT ON COLUMN oasis.lm_study_cohorts.blind_name
     IS 'Study Name field UI is mapped to this column. This text is used for populating Product Name when study is associated with a case';
COMMENT ON COLUMN oasis.lm_study_cohorts.blind_name_j
     IS 'For Japanese version Study Name field UI is mapped to this column. This text is used for populating Product Name when study is associated with a case';
COMMENT ON COLUMN oasis.lm_study_cohorts.study_type_id
     IS 'Identification of type of study, value mapping is derived from LM_STUDY_TYPES';
COMMENT ON COLUMN oasis.lm_study_cohorts.sort_id
     IS 'Order in which to display Cohorts in study configuration';
COMMENT ON COLUMN oasis.lm_study_cohorts.PRIMARY
     IS 'Primary Cohort, 0=No  1=Yes';
COMMENT ON COLUMN oasis.lm_study_cohorts.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_study_cohorts.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_study_cohorts.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_study_types(
    study_type_id NUMERIC NOT NULL,
    study_type CHARACTER VARYING(15),
    protected NUMERIC,
    display NUMERIC,
    study_type_j CHARACTER VARYING(15),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_study_types
     IS 'This table identifies allowable study types.';
COMMENT ON COLUMN oasis.lm_study_types.study_type_id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_study_types.study_type
     IS 'Display text for study type identification';
COMMENT ON COLUMN oasis.lm_study_types.protected
     IS '1 = record can not be deleted by the user';
COMMENT ON COLUMN oasis.lm_study_types.display
     IS '1 = display record in user interface dropdowns';
COMMENT ON COLUMN oasis.lm_study_types.study_type_j
     IS 'Display text for study type identification (Japanese).';
COMMENT ON COLUMN oasis.lm_study_types.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_study_types.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_udf_ddl_values(
    id NUMERIC NOT NULL,
    field_id NUMERIC NOT NULL,
    description CHARACTER VARYING(100),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    description_j CHARACTER VARYING(100),
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_udf_ddl_values
     IS 'This table will contain user defined dropdown values for UDF Numeric fields.';
COMMENT ON COLUMN oasis.lm_udf_ddl_values.id
     IS 'Primary key';
COMMENT ON COLUMN oasis.lm_udf_ddl_values.field_id
     IS ' This column is foreign key to CMN_FIELDS.FIELD_ID.';
COMMENT ON COLUMN oasis.lm_udf_ddl_values.description
     IS 'Text value that will appear as user defined  Drop down List option';
COMMENT ON COLUMN oasis.lm_udf_ddl_values.deleted
     IS 'Date deleted column';
COMMENT ON COLUMN oasis.lm_udf_ddl_values.description_j
     IS 'Japanese text value that will appear as user defined drop down list option.';
COMMENT ON COLUMN oasis.lm_udf_ddl_values.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_udf_ddl_values.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.lm_unblinding_status(
    status_id NUMERIC NOT NULL,
    unblinding_status CHARACTER VARYING(30),
    display NUMERIC(1,0),
    protected NUMERIC(1,0),
    unblinding_status_j CHARACTER VARYING(30),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL,
    last_update_time TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL
)
        WITH (
        OIDS=FALSE
        );
COMMENT ON TABLE oasis.lm_unblinding_status
     IS 'This table identifies the unblinding status for cases.';
COMMENT ON COLUMN oasis.lm_unblinding_status.status_id
     IS 'Primary key.';
COMMENT ON COLUMN oasis.lm_unblinding_status.unblinding_status
     IS '0 = Blinded,1 = Broken by Investigator,2 = Broken by Sponsor,3 = Broken after Study';
COMMENT ON COLUMN oasis.lm_unblinding_status.display
     IS '1 = Yes, 0 = No';
COMMENT ON COLUMN oasis.lm_unblinding_status.protected
     IS '1 = Yes, 0 = No';
COMMENT ON COLUMN oasis.lm_unblinding_status.unblinding_status_j
     IS '0 = Blinded,1 = Broken by Investigator,2 = Broken by Sponsor,3 = Broken after Study (Japanese).';
COMMENT ON COLUMN oasis.lm_unblinding_status.deleted
     IS 'Date the record was deleted. If NULL, the record is not deleted.';
COMMENT ON COLUMN oasis.lm_unblinding_status.enterprise_id
     IS ' This value is reference to CFG_ENTERPRISE.ENTERPRISE_ID';
COMMENT ON COLUMN oasis.lm_unblinding_status.last_update_time
     IS 'Last date of update,insert on the table, stored in GMT. Populated by AM TRG_%_LUT triggers.';

CREATE TABLE oasis.oasis_case_parent_info(
    case_id NUMERIC NOT NULL,
    age_unit_id NUMERIC,
    date_of_lmp TIMESTAMP(0) WITHOUT TIME ZONE,
    gender_id NUMERIC,
    age NUMERIC(22,7),
    dob TIMESTAMP(0) WITHOUT TIME ZONE,
    dob_res NUMERIC(1,0),
    height_cm NUMERIC(22,7),
    initials CHARACTER VARYING(60),
    weight_kg NUMERIC(22,7),
    dob_partial CHARACTER VARYING(20),
    weight_lbs NUMERIC(22,7),
    height_in NUMERIC(22,7),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    med_hist_text TEXT,
    breastfeeding NUMERIC,
    date_of_lmp_res NUMERIC,
    date_of_lmp_partial CHARACTER VARYING(20),
    med_hist_text_j TEXT,
    enterprise_id NUMERIC NOT NULL,
    age_unit_id_at_vacc NUMERIC,
    age_at_vacc NUMERIC,
    title CHARACTER VARYING(50),
    title_j CHARACTER VARYING(50),
    first_name CHARACTER VARYING(60),
    first_name_j CHARACTER VARYING(60),
    middle_name CHARACTER VARYING(60),
    middle_name_j CHARACTER VARYING(60),
    last_name CHARACTER VARYING(60),
    last_name_j CHARACTER VARYING(60),
    race_id NUMERIC,
    ethnic_group_id NUMERIC 
)
        WITH (
        OIDS=FALSE
        );

CREATE TABLE oasis.oasis_case_pat_info(
    case_id NUMERIC NOT NULL,
    pat_id CHARACTER VARYING(10),
    pat_subj_num CHARACTER VARYING(20),
    pat_initials CHARACTER VARYING(60),
    pat_firstname CHARACTER VARYING(60),
    pat_mi CHARACTER VARYING(60),
    pat_lastname CHARACTER VARYING(60),
    pat_address CHARACTER VARYING(120),
    pat_city CHARACTER VARYING(35),
    pat_state CHARACTER VARYING(40),
    pat_postal_code CHARACTER VARYING(15),
    pat_country CHARACTER VARYING(50),
    pat_phone CHARACTER VARYING(29),
    pat_dob TIMESTAMP(0) WITHOUT TIME ZONE,
    pat_dob_res NUMERIC,
    pat_age NUMERIC(22,7),
    age_unit_id NUMERIC,
    age_group_id NUMERIC,
    gender_id NUMERIC,
    pat_weight_lbs NUMERIC(22,7),
    pat_weight_kg NUMERIC(22,7),
    pat_height_in NUMERIC(22,7),
    pat_height_cm NUMERIC(22,7),
    ethnicity_id NUMERIC,
    occupation_id NUMERIC,
    pat_stat_preg NUMERIC,
    rel_test_id NUMERIC,
    pat_dob_partial CHARACTER VARYING(20),
    rand_num CHARACTER VARYING(15),
    confidential NUMERIC(1,0),
    number_of_patients CHARACTER VARYING(8),
    ud_text_1 CHARACTER VARYING(100),
    ud_text_2 CHARACTER VARYING(100),
    ud_text_3 CHARACTER VARYING(100),
    ud_text_4 CHARACTER VARYING(100),
    ud_text_5 CHARACTER VARYING(100),
    ud_text_6 CHARACTER VARYING(100),
    ud_text_7 CHARACTER VARYING(100),
    ud_text_8 CHARACTER VARYING(100),
    ud_text_9 CHARACTER VARYING(100),
    ud_text_10 CHARACTER VARYING(100),
    ud_text_11 CHARACTER VARYING(100),
    ud_text_12 CHARACTER VARYING(100),
    ud_date_1 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_2 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_3 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_4 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_5 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_6 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_7 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_8 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_9 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_10 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_11 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_date_12 TIMESTAMP(0) WITHOUT TIME ZONE,
    ud_number_1 NUMERIC(30,10),
    ud_number_2 NUMERIC(30,10),
    ud_number_3 NUMERIC(30,10),
    ud_number_4 NUMERIC(30,10),
    ud_number_5 NUMERIC(30,10),
    ud_number_6 NUMERIC(30,10),
    ud_number_7 NUMERIC(30,10),
    ud_number_8 NUMERIC(30,10),
    ud_number_9 NUMERIC(30,10),
    ud_number_10 NUMERIC(30,10),
    ud_number_11 NUMERIC(30,10),
    ud_number_12 NUMERIC(30,10),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    child_only NUMERIC(1,0),
    pat_bmi NUMERIC(22,7),
    pat_body_area NUMERIC(22,7),
    notes TEXT,
    notes_j TEXT,
    pat_address_j CHARACTER VARYING(120),
    pat_city_j CHARACTER VARYING(35),
    pat_firstname_j CHARACTER VARYING(60),
    pat_lastname_j CHARACTER VARYING(60),
    pat_mi_j CHARACTER VARYING(60),
    pat_state_j CHARACTER VARYING(40),
    ud_text_1_j CHARACTER VARYING(100),
    ud_text_2_j CHARACTER VARYING(100),
    ud_text_3_j CHARACTER VARYING(100),
    ud_text_4_j CHARACTER VARYING(100),
    ud_text_5_j CHARACTER VARYING(100),
    ud_text_6_j CHARACTER VARYING(100),
    ud_text_7_j CHARACTER VARYING(100),
    ud_text_8_j CHARACTER VARYING(100),
    ud_text_9_j CHARACTER VARYING(100),
    ud_text_10_j CHARACTER VARYING(100),
    ud_text_11_j CHARACTER VARYING(100),
    ud_text_12_j CHARACTER VARYING(100),
    pat_country_id NUMERIC,
    pat_age_at_vacc NUMERIC(22,7),
    age_unit_id_at_vacc NUMERIC,
    enterprise_id NUMERIC NOT NULL,
    concom_therapy NUMERIC(1,0),
    military_status_id NUMERIC,
    title CHARACTER VARYING(50),
    title_j CHARACTER VARYING(50),
    county CHARACTER VARYING(100),
    county_j CHARACTER VARYING(100),
    address_2 CHARACTER VARYING(100),
    address_2_j CHARACTER VARYING(100),
    email CHARACTER VARYING(100),
    ethnic_group_id NUMERIC 
)
        WITH (
        OIDS=FALSE
        );

CREATE TABLE oasis.oasis_case_reference(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    ref_no CHARACTER VARYING(100),
    ref_type_id NUMERIC,
    notes CHARACTER VARYING(200),
    ref_case_id NUMERIC,
    sort_id NUMERIC,
    notes_j CHARACTER VARYING(200),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    enterprise_id NUMERIC NOT NULL
)
        WITH (
        OIDS=FALSE
        );

CREATE TABLE oasis.oasis_case_reporters(
    case_id NUMERIC NOT NULL,
    seq_num NUMERIC NOT NULL,
    media_id NUMERIC,
    occupation_id NUMERIC,
    hcp_flag NUMERIC NOT NULL,
    primary_contact NUMERIC,
    corr_contact NUMERIC,
    reporter_type NUMERIC,
    intermediary_id NUMERIC,
    rpt_sent NUMERIC,
    sort_id NUMERIC,
    confidential NUMERIC(1,0),
    country_id NUMERIC,
    suffix CHARACTER VARYING(15),
    middle_name CHARACTER VARYING(60),
    prefix CHARACTER VARYING(50),
    first_name CHARACTER VARYING(60),
    last_name CHARACTER VARYING(60),
    reporter_id CHARACTER VARYING(20),
    institution CHARACTER VARYING(60),
    department CHARACTER VARYING(60),
    city CHARACTER VARYING(35),
    state CHARACTER VARYING(40),
    postcode CHARACTER VARYING(15),
    country CHARACTER VARYING(50),
    phone CHARACTER VARYING(29),
    altphone CHARACTER VARYING(29),
    fax CHARACTER VARYING(50),
    reporter_ref CHARACTER VARYING(20),
    email CHARACTER VARYING(100),
    address CHARACTER VARYING(120),
    suffix_j CHARACTER VARYING(15),
    notes_j TEXT,
    notes TEXT,
    address_j CHARACTER VARYING(120),
    city_j CHARACTER VARYING(35),
    department_j CHARACTER VARYING(60),
    first_name_j CHARACTER VARYING(60),
    institution_j CHARACTER VARYING(60),
    last_name_j CHARACTER VARYING(60),
    middle_name_j CHARACTER VARYING(60),
    prefix_j CHARACTER VARYING(50),
    state_j CHARACTER VARYING(40),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE,
    institution_id CHARACTER VARYING(15),
    enterprise_id NUMERIC NOT NULL,
    county CHARACTER VARYING(100),
    county_j CHARACTER VARYING(100),
    address_2 CHARACTER VARYING(100),
    address_2_j CHARACTER VARYING(100)
)
        WITH (
        OIDS=FALSE
        );
-- ------------ Write CREATE-CONSTRAINT-stage scripts -----------
ALTER TABLE oasis.case_assess ADD CONSTRAINT pk_case_assess PRIMARY KEY (case_id);
ALTER TABLE oasis.case_classifications ADD CONSTRAINT pk_case_classifications PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_comments ADD CONSTRAINT pk_case_comments PRIMARY KEY (case_id);
ALTER TABLE oasis.case_company_cmts ADD CONSTRAINT pk_case_company_cmts PRIMARY KEY (case_id);
ALTER TABLE oasis.case_death ADD CONSTRAINT pk_case_death PRIMARY KEY (case_id);
ALTER TABLE oasis.case_death_details ADD CONSTRAINT pk_case_death_details PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_dose_regimens ADD CONSTRAINT pk_case_dose_regimens PRIMARY KEY (case_id, seq_num, log_no);
ALTER TABLE oasis.case_event ADD CONSTRAINT pk_case_event PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_event_assess ADD CONSTRAINT pk_case_event_assess PRIMARY KEY (case_id, event_seq_num, prod_seq_num, datasheet_id, license_id, seq_num);
ALTER TABLE oasis.case_event_consequence ADD CONSTRAINT pk_case_event_consequence PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_event_detail ADD CONSTRAINT pk_case_event_detail PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_event_detail ADD CONSTRAINT uc_case_event_detail_cpe UNIQUE (case_id, prod_seq_num, event_seq_num);
ALTER TABLE oasis.case_followup ADD CONSTRAINT pk_case_followup PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_lab_data ADD CONSTRAINT pk_case_lab_data PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_literature ADD CONSTRAINT pk_case_literature PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_master ADD CONSTRAINT ak_csm_case_num UNIQUE (case_num);
ALTER TABLE oasis.case_master ADD CONSTRAINT pk_case_master PRIMARY KEY (case_id);
ALTER TABLE oasis.case_narrative ADD CONSTRAINT pk_case_narrative PRIMARY KEY (case_id);
ALTER TABLE oasis.case_neonates ADD CONSTRAINT pk_case_neonates PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_pat_hist ADD CONSTRAINT pk_case_pat_hist PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_pat_tests ADD CONSTRAINT pk_case_pat_tests PRIMARY KEY (rel_test_id);
ALTER TABLE oasis.case_pmoa_cons_relation ADD CONSTRAINT pk_case_pmoa_cons_relation PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_pregnancy ADD CONSTRAINT pk_case_pregnancy PRIMARY KEY (case_id, parent);
ALTER TABLE oasis.case_prod_devices ADD CONSTRAINT pk_case_prod_devices PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_prod_drugs ADD CONSTRAINT pk_case_prod_drugs PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_prod_indications ADD CONSTRAINT pk_case_prod_indications PRIMARY KEY (case_id, prod_seq_num, seq_num);
ALTER TABLE oasis.case_prod_qc_cid ADD CONSTRAINT pk_case_prod_qc_cid PRIMARY KEY (case_id, prod_seq_num, seq_num);
ALTER TABLE oasis.case_product ADD CONSTRAINT pk_case_product PRIMARY KEY (case_id, seq_num);
ALTER TABLE oasis.case_study ADD CONSTRAINT pk_case_study PRIMARY KEY (case_id);
ALTER TABLE oasis.cfg_medwatch_codes ADD CONSTRAINT pk_cfg_medwatch_codes PRIMARY KEY (dialog, value, sortby);
ALTER TABLE oasis.code_list_detail_discrete ADD CONSTRAINT pk_code_list_detail_discrete PRIMARY KEY (code_list_id, decode_context, code);
ALTER TABLE oasis.lm_action_taken ADD CONSTRAINT pk_lm_action_taken PRIMARY KEY (act_taken_id);
ALTER TABLE oasis.lm_admin_route ADD CONSTRAINT pk_lm_admin_route PRIMARY KEY (admin_route_id);
ALTER TABLE oasis.lm_age_groups ADD CONSTRAINT pk_lm_age_groups PRIMARY KEY (age_group_id);
ALTER TABLE oasis.lm_age_units ADD CONSTRAINT pk_lm_age_units PRIMARY KEY (age_unit_id);
ALTER TABLE oasis.lm_always_serious_term ADD CONSTRAINT pk_lm_always_serious_term PRIMARY KEY (ast_id);
ALTER TABLE oasis.lm_birth_type ADD CONSTRAINT pk_lm_birth_type PRIMARY KEY (birth_type_id);
ALTER TABLE oasis.lm_case_classification ADD CONSTRAINT pk_lm_case_classification PRIMARY KEY (classification_id);
ALTER TABLE oasis.lm_causality ADD CONSTRAINT pk_lm_causality PRIMARY KEY (causality_id);
ALTER TABLE oasis.lm_centers ADD CONSTRAINT pk_lm_centers PRIMARY KEY (center_id);
ALTER TABLE oasis.lm_condition_type ADD CONSTRAINT pk_lm_condition_type PRIMARY KEY (condition_type_id);
ALTER TABLE oasis.lm_countries ADD CONSTRAINT pk_lm_countries PRIMARY KEY (country_id);
ALTER TABLE oasis.lm_datasheet ADD CONSTRAINT pk_lm_datasheet PRIMARY KEY (datasheet_id, revision);
ALTER TABLE oasis.lm_delivery_types ADD CONSTRAINT pk_lm_delivery_types PRIMARY KEY (delivery_type_id);
ALTER TABLE oasis.lm_dev_phase ADD CONSTRAINT pk_lm_dev_phase PRIMARY KEY (dev_phase_id);
ALTER TABLE oasis.lm_device_type ADD CONSTRAINT pk_lm_device_type PRIMARY KEY (device_type_id);
ALTER TABLE oasis.lm_dose_frequency ADD CONSTRAINT pk_lm_dose_frequency PRIMARY KEY (freq_id);
ALTER TABLE oasis.lm_dose_units ADD CONSTRAINT pk_lm_dose_units PRIMARY KEY (unit_id);
ALTER TABLE oasis.lm_ethnicity ADD CONSTRAINT pk_lm_ethnicity PRIMARY KEY (ethnicity_id);
ALTER TABLE oasis.lm_evt_frequency ADD CONSTRAINT pk_lm_evt_frequency PRIMARY KEY (evt_freq_id);
ALTER TABLE oasis.lm_evt_intensity ADD CONSTRAINT pk_lm_evt_intensity PRIMARY KEY (evt_intensity_id);
ALTER TABLE oasis.lm_evt_outcome ADD CONSTRAINT pk_lm_evt_outcome PRIMARY KEY (evt_outcome_id);
ALTER TABLE oasis.lm_fetal_outcome ADD CONSTRAINT pk_lm_fetal_outcome PRIMARY KEY (fetal_outcome_id);
ALTER TABLE oasis.lm_formulation ADD CONSTRAINT pk_lm_formulation PRIMARY KEY (formulation_id);
ALTER TABLE oasis.lm_gender ADD CONSTRAINT pk_lm_gender PRIMARY KEY (gender_id);
ALTER TABLE oasis.lm_hcp ADD CONSTRAINT pk_lm_hcp PRIMARY KEY (hcp_id);
ALTER TABLE oasis.lm_intermediary ADD CONSTRAINT pk_lm_intermediary PRIMARY KEY (intermediary_id);
ALTER TABLE oasis.lm_lab_assessment ADD CONSTRAINT pk_lm_lab_assessment PRIMARY KEY (assessment_id);
ALTER TABLE oasis.lm_labeled_terms ADD CONSTRAINT pk_lm_labeled_terms PRIMARY KEY (seq_num);
ALTER TABLE oasis.lm_license ADD CONSTRAINT pk_lm_license PRIMARY KEY (license_id);
ALTER TABLE oasis.lm_license_types ADD CONSTRAINT pk_lm_license_types PRIMARY KEY (license_type_id);
ALTER TABLE oasis.lm_listedness ADD CONSTRAINT pk_lm_listedness PRIMARY KEY (listedness_id);
ALTER TABLE oasis.lm_manufacturer ADD CONSTRAINT pk_lm_manufacturer PRIMARY KEY (manufacturer_id);
ALTER TABLE oasis.lm_mfr_eval_reason ADD CONSTRAINT pk_lm_mfr_eval_reason PRIMARY KEY (mfr_eval_id);
ALTER TABLE oasis.lm_product ADD CONSTRAINT pk_lm_products PRIMARY KEY (product_id);
ALTER TABLE oasis.lm_product_family ADD CONSTRAINT pk_lm_product_family PRIMARY KEY (family_id);
ALTER TABLE oasis.lm_product_group ADD CONSTRAINT pk_lm_product_group PRIMARY KEY (product_group_id);
ALTER TABLE oasis.lm_protocols ADD CONSTRAINT pk_lm_protocols PRIMARY KEY (protocol_id);
ALTER TABLE oasis.lm_ref_types ADD CONSTRAINT pk_lm_ref_types PRIMARY KEY (ref_type_id);
ALTER TABLE oasis.lm_report_media ADD CONSTRAINT pk_lm_report_media PRIMARY KEY (media_id);
ALTER TABLE oasis.lm_report_type ADD CONSTRAINT pk_lm_report_type PRIMARY KEY (rpt_type_id);
ALTER TABLE oasis.lm_reporter_type ADD CONSTRAINT pk_lm_reporter_type PRIMARY KEY (rptr_type_id);
ALTER TABLE oasis.lm_sites ADD CONSTRAINT chk_lm_sites_approved_reports CHECK (approved_reports IN (0, 1));
ALTER TABLE oasis.lm_sites ADD CONSTRAINT pk_lm_sites PRIMARY KEY (site_id);
ALTER TABLE oasis.lm_study_cohorts ADD CONSTRAINT pk_lm_study_cohorts PRIMARY KEY (cohort_id);
ALTER TABLE oasis.lm_study_types ADD CONSTRAINT pk_lm_study_types PRIMARY KEY (study_type_id);
ALTER TABLE oasis.lm_udf_ddl_values ADD CONSTRAINT pk_lm_udf_ddl_values PRIMARY KEY (id, field_id);
ALTER TABLE oasis.lm_unblinding_status ADD CONSTRAINT pk_lm_unblinding_status PRIMARY KEY (status_id);
ALTER TABLE oasis.oasis_case_parent_info ADD CONSTRAINT pk_oasis_case_parent_info PRIMARY KEY (case_id);
ALTER TABLE oasis.oasis_case_pat_info ADD CONSTRAINT pk_oasis_case_pat_info PRIMARY KEY (case_id);
ALTER TABLE oasis.oasis_case_reporters ADD CONSTRAINT pk_oasis_case_reporters PRIMARY KEY (case_id, seq_num); 
