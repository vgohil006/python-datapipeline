
-- ------------ Write DROP-TABLE-stage scripts -----------

DROP TABLE IF EXISTS whodrug.who_drug_c_atc_code CASCADE;



DROP TABLE IF EXISTS whodrug.who_drug_c_therapeutic_group CASCADE;



-- ------------ Write DROP-DATABASE-stage scripts -----------

-- ------------ Write CREATE-DATABASE-stage scripts -----------

CREATE SCHEMA IF NOT EXISTS whodrug;



-- ------------ Write CREATE-TABLE-stage scripts -----------

CREATE TABLE whodrug.who_drug_c_atc_code(
    atc_code CHARACTER VARYING(10) NOT NULL,
    level NUMERIC(1,0),
    text CHARACTER VARYING(110)
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE whodrug.who_drug_c_therapeutic_group(
    therap_group_id CHARACTER VARYING(10) NOT NULL,
    atc_code CHARACTER VARYING(10),
    create_date CHARACTER VARYING(8),
    official_atc_code CHARACTER VARYING(1),
    medicinal_prod_id CHARACTER VARYING(10)
)
        WITH (
        OIDS=FALSE
        );



-- ------------ Write CREATE-CONSTRAINT-stage scripts -----------

ALTER TABLE whodrug.who_drug_c_atc_code
ADD CONSTRAINT pk_who_drug_c_atc_code PRIMARY KEY (atc_code);



ALTER TABLE whodrug.who_drug_c_therapeutic_group
ADD CONSTRAINT pk_who_drug_c_therapeutic_grp PRIMARY KEY (therap_group_id);



