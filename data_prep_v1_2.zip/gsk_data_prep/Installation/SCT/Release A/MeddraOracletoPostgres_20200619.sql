-- ------------ Write DROP-TABLE-stage scripts -----------

DROP TABLE IF EXISTS meddra.meddra_hl_pref_term;



DROP TABLE IF EXISTS meddra.meddra_hl_pref_term_j;



DROP TABLE IF EXISTS meddra.meddra_hlg_pref_term;



DROP TABLE IF EXISTS meddra.meddra_hlg_pref_term_j;



DROP TABLE IF EXISTS meddra.meddra_hlgt_hlt_comp;



DROP TABLE IF EXISTS meddra.meddra_hlt_pref_comp;



DROP TABLE IF EXISTS meddra.meddra_md_hierarchy;



DROP TABLE IF EXISTS meddra.meddra_pref_term;



DROP TABLE IF EXISTS meddra.meddra_pref_term_j;



DROP TABLE IF EXISTS meddra.meddra_pref_term_llt;



DROP TABLE IF EXISTS meddra.meddra_pref_term_llt_j;



DROP TABLE IF EXISTS meddra.meddra_smq_content;



DROP TABLE IF EXISTS meddra.meddra_smq_list;



DROP TABLE IF EXISTS meddra.meddra_smq_list_j;



DROP TABLE IF EXISTS meddra.meddra_soc;



DROP TABLE IF EXISTS meddra.meddra_soc_hlgt_comp;



DROP TABLE IF EXISTS meddra.meddra_soc_intl_order;



DROP TABLE IF EXISTS meddra.meddra_soc_j;



DROP TABLE IF EXISTS meddra.meddra_spec_cat;



DROP TABLE IF EXISTS meddra.meddra_spec_pref_comp;



DROP TABLE IF EXISTS meddra.meddra_synonyms;



-- ------------ Write DROP-DATABASE-stage scripts -----------

-- ------------ Write CREATE-DATABASE-stage scripts -----------

CREATE SCHEMA IF NOT EXISTS meddra;



-- ------------ Write CREATE-TABLE-stage scripts -----------

CREATE TABLE meddra.meddra_hl_pref_term(
    hlt_code DOUBLE PRECISION NOT NULL,
    hlt_name CHARACTER VARYING(120),
    hlt_who_art_code CHARACTER VARYING(7),
    hlt_harts_code DOUBLE PRECISION,
    hlt_costart_fg CHARACTER VARYING(21),
    hlt_icd9_code CHARACTER VARYING(8),
    hlt_icd9cm_code CHARACTER VARYING(8),
    hlt_icd10_code CHARACTER VARYING(8),
    hlt_j_art_code CHARACTER VARYING(6),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_hl_pref_term_j(
    hlt_code DOUBLE PRECISION NOT NULL,
    hlt_kanji CHARACTER VARYING(400),
    hlt_kana CHARACTER VARYING(400),
    hlt_kana1 CHARACTER VARYING(400),
    hlt_kana2 CHARACTER VARYING(400)
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_hlg_pref_term(
    hlgt_code DOUBLE PRECISION NOT NULL,
    hlgt_name CHARACTER VARYING(120),
    hlgt_who_art_code CHARACTER VARYING(7),
    hlgt_harts_code DOUBLE PRECISION,
    hlgt_costart_fg CHARACTER VARYING(21),
    hlgt_icd9_code CHARACTER VARYING(8),
    hlgt_icd9cm_code CHARACTER VARYING(8),
    hlgt_icd10_code CHARACTER VARYING(8),
    hlgt_j_art_code CHARACTER VARYING(6),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_hlg_pref_term_j(
    hlgt_code DOUBLE PRECISION NOT NULL,
    hlgt_kanji CHARACTER VARYING(400),
    hlgt_kana CHARACTER VARYING(400),
    hlgt_kana1 CHARACTER VARYING(400),
    hlgt_kana2 CHARACTER VARYING(400)
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_hlgt_hlt_comp(
    hlgt_code DOUBLE PRECISION NOT NULL,
    hlt_code DOUBLE PRECISION NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_hlt_pref_comp(
    hlt_code DOUBLE PRECISION NOT NULL,
    pt_code DOUBLE PRECISION NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_md_hierarchy(
    pt_code DOUBLE PRECISION NOT NULL,
    hlt_code DOUBLE PRECISION NOT NULL,
    hlgt_code DOUBLE PRECISION NOT NULL,
    soc_code DOUBLE PRECISION NOT NULL,
    pt_name CHARACTER VARYING(120) NOT NULL,
    hlt_name CHARACTER VARYING(120) NOT NULL,
    hlgt_name CHARACTER VARYING(120) NOT NULL,
    soc_name CHARACTER VARYING(120) NOT NULL,
    soc_abbrev CHARACTER VARYING(5) NOT NULL,
    null_field CHARACTER VARYING(1),
    pt_soc_code DOUBLE PRECISION,
    primary_soc_fg CHARACTER VARYING(1),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_pref_term(
    pt_code DOUBLE PRECISION NOT NULL,
    pt_name_english CHARACTER VARYING(120) NOT NULL,
    null_field CHARACTER VARYING(1),
    pt_soc_code DOUBLE PRECISION,
    pt_who_art_code CHARACTER VARYING(7),
    pt_harts_code DOUBLE PRECISION,
    pt_costart_fg CHARACTER VARYING(21),
    pt_icd9_code CHARACTER VARYING(8),
    pt_icd9cm_code CHARACTER VARYING(8),
    pt_icd10_code CHARACTER VARYING(8),
    pt_j_art_code CHARACTER VARYING(6),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_pref_term_j(
    pt_code DOUBLE PRECISION NOT NULL,
    pt_kanji CHARACTER VARYING(400),
    pt_kana CHARACTER VARYING(400),
    pt_kana1 CHARACTER VARYING(400),
    pt_kana2 CHARACTER VARYING(400)
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_pref_term_llt(
    llt_code DOUBLE PRECISION NOT NULL,
    llt_name_english CHARACTER VARYING(100) NOT NULL,
    pt_code DOUBLE PRECISION,
    llt_who_art_code CHARACTER VARYING(7),
    llt_harts_code DOUBLE PRECISION,
    llt_costart_fg CHARACTER VARYING(21),
    llt_icd9_code CHARACTER VARYING(8),
    llt_icd9cm_code CHARACTER VARYING(8),
    llt_icd10_code CHARACTER VARYING(8),
    llt_currency CHARACTER VARYING(1),
    llt_j_art_code CHARACTER VARYING(6),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_pref_term_llt_j(
    llt_code DOUBLE PRECISION NOT NULL,
    llt_kanji CHARACTER VARYING(400),
    llt_jcurr CHARACTER VARYING(10),
    llt_kana CHARACTER VARYING(600),
    llt_kana1 CHARACTER VARYING(600),
    llt_kana2 CHARACTER VARYING(600)
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_smq_content(
    smq_code DOUBLE PRECISION NOT NULL,
    term_code DOUBLE PRECISION NOT NULL,
    term_level DOUBLE PRECISION NOT NULL,
    term_scope DOUBLE PRECISION NOT NULL,
    term_category CHARACTER VARYING(1) NOT NULL,
    term_weight DOUBLE PRECISION NOT NULL,
    term_status CHARACTER VARYING(1) NOT NULL,
    term_addition_version CHARACTER VARYING(5) NOT NULL,
    term_last_modified_version CHARACTER VARYING(5) NOT NULL
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_smq_list(
    smq_code DOUBLE PRECISION NOT NULL,
    smq_name CHARACTER VARYING(100) NOT NULL,
    smq_level DOUBLE PRECISION NOT NULL,
    smq_description CHARACTER VARYING(3000),
    smq_source CHARACTER VARYING(2000),
    smq_note CHARACTER VARYING(2000),
    meddra_version CHARACTER VARYING(5) NOT NULL,
    status CHARACTER VARYING(1) NOT NULL,
    smq_algorithm CHARACTER VARYING(100) NOT NULL
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_smq_list_j(
    smq_code DOUBLE PRECISION NOT NULL,
    smq_kanji CHARACTER VARYING(120) NOT NULL,
    smq_desc_kanji CHARACTER VARYING(4000) NOT NULL
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_soc(
    soc_code DOUBLE PRECISION NOT NULL,
    soc_name_english CHARACTER VARYING(120) NOT NULL,
    soc_abbrev CHARACTER VARYING(5) NOT NULL,
    soc_who_art_code CHARACTER VARYING(7),
    soc_harts_code DOUBLE PRECISION,
    soc_costart_fg CHARACTER VARYING(21),
    soc_icd9_code CHARACTER VARYING(8),
    soc_icd9cm_code CHARACTER VARYING(8),
    soc_icd10_code CHARACTER VARYING(8),
    soc_j_art_code CHARACTER VARYING(6),
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_soc_hlgt_comp(
    soc_code DOUBLE PRECISION NOT NULL,
    hlgt_code DOUBLE PRECISION NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_soc_intl_order(
    intl_ord_code DOUBLE PRECISION NOT NULL,
    soc_code DOUBLE PRECISION NOT NULL
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_soc_j(
    soc_code DOUBLE PRECISION NOT NULL,
    soc_kanji CHARACTER VARYING(400),
    soc_order DOUBLE PRECISION,
    soc_kana CHARACTER VARYING(400),
    soc_kana1 CHARACTER VARYING(400),
    soc_kana2 CHARACTER VARYING(400)
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_spec_cat(
    spec_code DOUBLE PRECISION NOT NULL,
    spec_name CHARACTER VARYING(120) NOT NULL,
    spec_abbrev CHARACTER VARYING(10) NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_spec_pref_comp(
    spec_code DOUBLE PRECISION NOT NULL,
    pt_code DOUBLE PRECISION NOT NULL,
    deleted TIMESTAMP(0) WITHOUT TIME ZONE
)
        WITH (
        OIDS=FALSE
        );



CREATE TABLE meddra.meddra_synonyms(
    syn_id DOUBLE PRECISION NOT NULL,
    llt_code DOUBLE PRECISION NOT NULL,
    syn CHARACTER VARYING(255) NOT NULL,
    syn_j CHARACTER VARYING(255)
)
        WITH (
        OIDS=FALSE
        );



